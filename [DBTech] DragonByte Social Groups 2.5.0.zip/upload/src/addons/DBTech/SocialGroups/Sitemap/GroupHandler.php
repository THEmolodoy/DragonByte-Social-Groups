<?php

namespace DBTech\SocialGroups\Sitemap;

use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Finder\GroupFinder;
use XF\Mvc\Entity\AbstractCollection;
use XF\Sitemap\AbstractHandler;
use XF\Sitemap\Entry;

/**
 * @extends AbstractHandler<Group>
 */
class GroupHandler extends AbstractHandler
{
	/**
	 * @param $start
	 *
	 * @return AbstractCollection<Group>
	 */
	public function getRecords($start): AbstractCollection
	{
		$app = $this->app;
		$user = \XF::visitor();

		$groupIds = $this->getIds('xf_dbtech_social_groups_group', 'group_id', $start);

		$groupFinder = \XF::app()->finder(GroupFinder::class);
		return $groupFinder
			->where('group_id', $groupIds)
			->with(['Permissions|' . $user->permission_combination_id])
			->order('group_id')
			->fetch()
		;
	}

	/**
	 * @param Group $record
	 *
	 * @return Entry
	 */
	public function getEntry($record): Entry
	{
		return Entry::create(
			\XF::app()->router('public')->buildLink('canonical:dbtech-social', $record)
		);
	}

	/**
	 * @param Group $record
	 *
	 * @return bool
	 */
	public function isIncluded($record): bool
	{
		if (!$record->isSearchEngineIndexable())
		{
			return false;
		}

		return $record->canView();
	}
}