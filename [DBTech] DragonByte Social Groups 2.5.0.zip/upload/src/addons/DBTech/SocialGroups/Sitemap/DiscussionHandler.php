<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\Sitemap;

use DBTech\SocialGroups\Entity\Discussion;
use DBTech\SocialGroups\Finder\DiscussionFinder;
use XF\Mvc\Entity\AbstractCollection;
use XF\Sitemap\AbstractHandler;
use XF\Sitemap\Entry;

/**
 * @extends AbstractHandler<Discussion>
 */
class DiscussionHandler extends AbstractHandler
{
	/**
	 * @param $start
	 *
	 * @return AbstractCollection<Discussion>
	 */
	public function getRecords($start)
	{
		$app = $this->app;
		$user = \XF::visitor();

		$ids = $this->getIds('xf_dbtech_social_groups_discussion', 'discussion_id', $start);

		$discussionFinder = \XF::app()->finder(DiscussionFinder::class);
		return $discussionFinder
			->where('discussion_id', $ids)
			->with(['Group', 'Group', 'Group.Permissions|' . $user->permission_combination_id])
			->order('discussion_id')
			->fetch()
		;
	}

	/**
	 * @param Discussion $record
	 *
	 * @return Entry
	 */
	public function getEntry($record)
	{
		return Entry::create($record->getContentUrl(true), [
			'lastmod' => $record->last_message_date,
		]);
	}

	/**
	 * @param Discussion $record
	 *
	 * @return bool
	 */
	public function isIncluded($record)
	{
		if (
			!$record->isVisible() ||
			!$record->isSearchEngineIndexable()
		)
		{
			return false;
		}
		return $record->canView();
	}
}