<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\ModeratorLog;

use DBTech\SocialGroups\Entity\Message;
use XF\Entity\ModeratorLog;
use XF\Entity\User;
use XF\ModeratorLog\AbstractHandler;
use XF\Mvc\Entity\Entity;
use XF\Phrase;

/**
 * @extends AbstractHandler<Message>
 */
class MessageHandler extends AbstractHandler
{
	/**
	 * @param Message $content
	 * @param $action
	 * @param User $actor
	 *
	 * @return bool
	 */
	public function isLoggable(Entity $content, $action, User $actor)
	{
		switch ($action)
		{
			case 'edit':
			case 'attachment_deleted':
				if ($actor->user_id == $content->user_id)
				{
					return false;
				}
		}

		return parent::isLoggable($content, $action, $actor);
	}

	/**
	 * @param Message $content
	 * @param $field
	 * @param $newValue
	 * @param $oldValue
	 *
	 * @return array|false|string
	 */
	protected function getLogActionForChange(Entity $content, $field, $newValue, $oldValue)
	{
		switch ($field)
		{
			case 'message':
				return 'edit';

			case 'message_state':
				if ($newValue == 'visible' && $oldValue == 'moderated')
				{
					return 'approve';
				}
				else if ($newValue == 'visible' && $oldValue == 'deleted')
				{
					return 'undelete';
				}
				else if ($newValue == 'deleted')
				{
					$reason = $content->DeletionLog ? $content->DeletionLog->delete_reason : '';
					return ['delete_soft', ['reason' => $reason]];
				}
				else if ($newValue == 'moderated')
				{
					return 'unapprove';
				}
				break;
		}

		return false;
	}

	/**
	 * @param ModeratorLog $log
	 * @param Message $content
	 */
	protected function setupLogEntityContent(ModeratorLog $log, Entity $content)
	{
		$log->content_user_id = $content->user_id;
		$log->content_username = $content->username;
		$log->content_title = $content->Discussion->title ?: '';
		$log->content_url = \XF::app()->router('public')->buildLink('nopath:dbtech-social/messages', $content);
		$log->discussion_content_type = 'dbtech_social_discussion';
		$log->discussion_content_id = $content->discussion_id;
	}

	/**
	 * @param ModeratorLog $log
	 *
	 * @return Phrase
	 */
	public function getContentTitle(ModeratorLog $log)
	{
		return \XF::phrase('dbtech_social_groups_message_in_discussion_x', [
			'title' => \XF::app()->stringFormatter()->censorText($log->content_title_),
		]);
	}
}