<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\ModeratorLog;

use DBTech\SocialGroups\Entity\Discussion;
use XF\Entity\ModeratorLog;
use XF\Entity\User;
use XF\ModeratorLog\AbstractHandler;
use XF\Mvc\Entity\Entity;

/**
 * @extends AbstractHandler<Discussion>
 */
class DiscussionHandler extends AbstractHandler
{
	/**
	 * @param Discussion $content
	 * @param $action
	 * @param User $actor
	 *
	 * @return bool
	 */
	public function isLoggable(Entity $content, $action, User $actor)
	{
		/** @noinspection PhpSwitchStatementWitSingleBranchInspection */
		switch ($action)
		{
			case 'title':
				if ($actor->user_id == $content->user_id)
				{
					return false;
				}
		}

		return parent::isLoggable($content, $action, $actor);
	}

	/**
	 * @param Discussion $content
	 * @param $field
	 * @param $newValue
	 * @param $oldValue
	 *
	 * @return array|false|string
	 */
	protected function getLogActionForChange(Entity $content, $field, $newValue, $oldValue)
	{
		switch ($field)
		{
			case 'sticky':
				return $newValue ? 'stick' : 'unstick';

			case 'discussion_open':
				return $newValue ? 'unlock' : 'lock';

			case 'discussion_state':
				if ($newValue == 'visible' && $oldValue == 'moderated')
				{
					return 'approve';
				}
				else if ($newValue == 'visible' && $oldValue == 'deleted')
				{
					return 'undelete';
				}
				else if ($newValue == 'deleted')
				{
					$reason = $content->DeletionLog ? $content->DeletionLog->delete_reason : '';
					return ['delete_soft', ['reason' => $reason]];
				}
				else if ($newValue == 'moderated')
				{
					return 'unapprove';
				}
				break;

			case 'title':
				return ['title', ['old' => $oldValue]];
		}

		return false;
	}

	/**
	 * @param ModeratorLog $log
	 * @param Discussion $content
	 */
	protected function setupLogEntityContent(ModeratorLog $log, Entity $content)
	{
		$log->content_user_id = $content->user_id;
		$log->content_username = $content->username;
		$log->content_title = $content->title;
		$log->content_url = \XF::app()->router('public')->buildLink('nopath:dbtech-social/discussions', $content);
		$log->discussion_content_type = 'dbtech_social_discussion';
		$log->discussion_content_id = $content->discussion_id;
	}

	/**
	 * @param ModeratorLog $log
	 *
	 * @return array
	 */
	protected function getActionPhraseParams(ModeratorLog $log)
	{
		if ($log->action == 'edit')
		{
			return ['elements' => implode(', ', array_keys($log->action_params))];
		}
		else
		{
			return parent::getActionPhraseParams($log);
		}
	}
}