<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\ModeratorLog;

use DBTech\SocialGroups\Entity\Group;
use XF\Entity\ModeratorLog;
use XF\ModeratorLog\AbstractHandler;
use XF\Mvc\Entity\Entity;
use XF\Phrase;

/**
 * @extends AbstractHandler<Group>
 */
class GroupHandler extends AbstractHandler
{
	/**
	 * @param Group $content
	 * @param $field
	 * @param $newValue
	 * @param $oldValue
	 *
	 * @return false|string
	 */
	protected function getLogActionForChange(Entity $content, $field, $newValue, $oldValue)
	{
		/** @noinspection PhpSwitchStatementWitSingleBranchInspection */
		switch ($field)
		{
			case 'group_state':
				if ($newValue == 'valid' && $oldValue == 'moderated')
				{
					return 'approve';
				}
				break;
		}

		return false;
	}

	/**
	 * @param ModeratorLog $log
	 * @param Group $content
	 *
	 * @return void
	 */
	protected function setupLogEntityContent(ModeratorLog $log, Entity $content)
	{
		$log->content_user_id = $content->user_id;
		$log->content_username = $content->User->username;
		$log->content_title = $content->title;
		$log->content_url = \XF::app()->router('public')->buildLink('nopath:dbtech-social', $content);
		$log->discussion_content_type = 'dbtech_social_group';
		$log->discussion_content_id = $content->group_id;
	}

	/**
	 * @param ModeratorLog $log
	 *
	 * @return Phrase
	 */
	public function getContentTitle(ModeratorLog $log)
	{
		return \XF::phrase('dbtech_social_groups_group_x', [
			'title' => $log->content_title_,
		]);
	}
}