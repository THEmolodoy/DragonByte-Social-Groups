<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\ModeratorLog;

use DBTech\SocialGroups\Entity\GroupMember;
use XF\Entity\ModeratorLog;
use XF\ModeratorLog\AbstractHandler;
use XF\Mvc\Entity\Entity;
use XF\Phrase;

/**
 * @extends AbstractHandler<GroupMember>
 */
class GroupMemberHandler extends AbstractHandler
{
	/**
	 * @param GroupMember $content
	 * @param $field
	 * @param $newValue
	 * @param $oldValue
	 *
	 * @return false|string
	 */
	protected function getLogActionForChange(Entity $content, $field, $newValue, $oldValue)
	{
		/** @noinspection PhpSwitchStatementWitSingleBranchInspection */
		switch ($field)
		{
			case 'member_state':
				if ($newValue == 'valid' && $oldValue == 'moderated')
				{
					return 'approve';
				}
				break;
		}

		return false;
	}

	/**
	 * @param ModeratorLog $log
	 * @param GroupMember $content
	 *
	 * @return void
	 */
	protected function setupLogEntityContent(ModeratorLog $log, Entity $content)
	{
		$log->content_user_id = $content->user_id;
		$log->content_username = $content->User->username;
		$log->content_title = $content->Group->title;
		$log->content_url = \XF::app()->router('public')->buildLink('nopath:dbtech-social', $content->Group);
		$log->discussion_content_type = 'dbtech_social_member';
		$log->discussion_content_id = $content->group_member_id;
	}

	/**
	 * @param ModeratorLog $log
	 *
	 * @return Phrase
	 */
	public function getContentTitle(ModeratorLog $log)
	{
		return \XF::phrase('dbtech_social_groups_member_x_in_group_y', [
			'username' => $log->content_username,
			'title' => $log->content_title_,
		]);
	}
}