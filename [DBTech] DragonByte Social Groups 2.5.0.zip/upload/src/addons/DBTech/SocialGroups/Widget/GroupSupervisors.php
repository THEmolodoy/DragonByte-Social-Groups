<?php

namespace DBTech\SocialGroups\Widget;

use DBTech\SocialGroups\Entity\Group;
use XF\Widget\AbstractWidget;
use XF\Widget\WidgetRenderer;

class GroupSupervisors extends AbstractWidget
{
	/**
	 * @return string|WidgetRenderer
	 */
	public function render(): string|WidgetRenderer
	{
		/** @var Group|null $group */
		$group = $this->contextParams['group'] ?? null;
		if (!$group || !$group->canViewMemberList())
		{
			return '';
		}

		$viewParams = [
			'group' => $group,
		];
		return $this->renderer('dbtech_social_groups_widget_group_supervisors', $viewParams);
	}

	public function getOptionsTemplate(): ?string
	{
		return null;
	}
}