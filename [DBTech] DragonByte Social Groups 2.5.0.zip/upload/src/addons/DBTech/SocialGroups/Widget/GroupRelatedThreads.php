<?php

namespace DBTech\SocialGroups\Widget;

use DBTech\SocialGroups\Entity\Group;
use XF\Http\Request;
use XF\InputFilterer;
use XF\Widget\AbstractWidget;
use XF\Widget\WidgetRenderer;

class GroupRelatedThreads extends AbstractWidget
{
	protected $defaultOptions = [
		'style' => 'simple',
	];

	/**
	 * @return string|WidgetRenderer
	 */
	public function render(): string|WidgetRenderer
	{
		/** @var Group|null $group */
		$group = $this->contextParams['group'] ?? null;
		if (!$group/* || ($group->canViewDiscussions() && !\XF::$developmentMode)*/)
		{
			return '';
		}

		$visitor = \XF::visitor();

		$with = [
			'Thread',
			'Thread.fullForum',
			'Thread.Forum.Node',
			'Thread.Forum.Node.Permissions|' . $visitor->permission_combination_id,
		];

		$relatedThreads = $group->getRelationFinder('RelatedThreads')
			->with($with)
			->fetch()
			->filterViewable()
		;

		$viewParams = [
			'group' => $group,
			'relatedThreads' => $relatedThreads,
			'style' => $this->options['style'],
			'title' => $this->getTitle() ?: \XF::phrase('dbtech_social_groups_related_threads'),
		];
		return $this->renderer('dbtech_social_groups_widget_group_related_threads', $viewParams);
	}

	/**
	 * @param Request $request
	 * @param array $options
	 * @param $error
	 *
	 * @return bool
	 */
	public function verifyOptions(Request $request, array &$options, &$error = null): bool
	{
		$options = $request->filter([
			'style' => InputFilterer::STRING,
		]);

		return true;
	}
}