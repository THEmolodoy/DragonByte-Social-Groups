<?php

namespace DBTech\SocialGroups\Widget;

use DBTech\SocialGroups\Entity\Discussion;
use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Repository\DiscussionRepository;
use XF\Http\Request;
use XF\InputFilterer;
use XF\Widget\AbstractWidget;
use XF\Widget\WidgetRenderer;

class NewMessages extends AbstractWidget
{
	protected $defaultOptions = [
		'limit' => 5,
		'style' => 'simple',
		'filter' => 'latest',
	];

	/**
	 * @return string|WidgetRenderer
	 */
	public function render(): string|WidgetRenderer
	{
		$visitor = \XF::visitor();

		$options = $this->options;
		$limit = $options['limit'];
		$filter = $options['filter'];

		if (!$visitor->user_id)
		{
			$filter = 'latest';
		}

		/** @var Group|null $group */
		$group = $this->contextParams['group'] ?? null;
		if ($group && !$group->canViewDiscussions())
		{
			return '';
		}

		$router = \XF::app()->router('public');
		$discussionRepo = \XF::app()->repository(DiscussionRepository::class);

		switch ($filter)
		{
			default:
			case 'latest':
				$discussionFinder = $discussionRepo->findDiscussionsWithLatestMessages(!$group);
				$title = \XF::phrase('widget.dbtech_social_groups_latest_messages');
				$link = $router->buildLink('whats-new/dbtech-social-messages', null, ['skip' => 1]);
				break;

			case 'unread':
				$discussionFinder = $discussionRepo->findDiscussionsWithUnreadMessages();
				$title = \XF::phrase('widget.dbtech_social_groups_unread_messages');
				$link = $router->buildLink('whats-new/dbtech-social-messages', null, ['unread' => 1]);
				break;

			case 'watched':
				$discussionFinder = $discussionRepo->findDiscussionsForWatchedList();
				$title = \XF::phrase('widget.dbtech_social_groups_latest_watched');
				$link = $router->buildLink('whats-new/dbtech-social-messages', null, ['watched' => 1]);
				break;
		}

		if ($group)
		{
			$link = $router->buildLink('dbtech-social/discussions/list', $group);
			$discussionFinder->inGroup($group);
		}

		$discussionFinder
			->with('Group.Permissions|' . $visitor->permission_combination_id)
			->limit(max($limit * 2, 10));

		if ($options['style'] == 'full')
		{
			$discussionFinder->with('fullGroup');
		}
		else
		{
			$discussionFinder
				->with('LastPoster')
				->withReadData();
		}

		/** @var Discussion $discussion */
		foreach ($discussions = $discussionFinder->fetch() AS $discussionId => $discussion)
		{
			if (!$discussion->canView()
				|| $discussion->isIgnored()
				|| $visitor->isIgnoring($discussion->last_message_user_id)
			)
			{
				unset($discussions[$discussionId]);
			}
		}
		$total = $discussions->count();
		$discussions = $discussions->slice(0, $limit);

		$viewParams = [
			'title' => $this->getTitle() ?: $title,
			'link' => $link,
			'discussions' => $discussions,
			'style' => $options['style'],
			'filter' => $filter,
			'hasMore' => $total > $discussions->count(),
		];
		return $this->renderer('dbtech_social_groups_widget_new_messages', $viewParams);
	}

	/**
	 * @param Request $request
	 * @param array $options
	 * @param $error
	 *
	 * @return bool
	 */
	public function verifyOptions(Request $request, array &$options, &$error = null): bool
	{
		$options = $request->filter([
			'limit' => InputFilterer::UNSIGNED,
			'style' => InputFilterer::STRING,
			'filter' => InputFilterer::STRING,
		]);
		if ($options['limit'] < 1)
		{
			$options['limit'] = 1;
		}

		return true;
	}
}