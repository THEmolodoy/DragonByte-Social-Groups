<?php

namespace DBTech\SocialGroups\Widget;

use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Repository\MediaRepository;
use XF\Entity\User;
use XF\Http\Request;
use XF\InputFilterer;
use XF\Widget\AbstractWidget;
use XF\Widget\WidgetRenderer;

use function array_slice;

class NewestMedia extends AbstractWidget
{
	protected $defaultOptions = [
		'order' => 'latest',
		'limit' => 12,
		'slider' => [
			'item' => 6,
			'itemWide' => 4,
			'itemMedium' => 3,
			'itemNarrow' => 2,
			'auto' => false,
			'pauseOnHover' => false,
			'loop' => false,
			'pager' => false,
		],
	];

	public function render(): string|WidgetRenderer
	{
		/** @var Group|null $group */
		$group = $this->contextParams['group'] ?? null;
		if (!$group || !$group->canViewMedia())
		{
			return '';
		}

		/** @var User $visitor */
		$visitor = \XF::visitor();
		if (!method_exists($visitor, 'canViewMedia') || !$visitor->canViewMedia())
		{
			return '';
		}

		$mediaRepo = \XF::app()->repository(MediaRepository::class);
		$mediaList = $mediaRepo->findMediaInGroupForWidget($group)
			->with('Category.Permissions|' . $visitor->permission_combination_id)
			->limit($this->options['limit'] * 10);

		$title = \XF::phrase('xfmg_latest_media');

		if ($this->options['order'] == 'random')
		{
			$mediaIds = \XF::app()->simpleCache()->XFMG->randomMediaCache;
			if ($mediaIds)
			{
				$title = \XF::phrase('xfmg_random_media');
				shuffle($mediaIds);
				$mediaIds = array_slice($mediaIds, 0, $this->options['limit'] * 10);
				$mediaList->where('media_id', $mediaIds);
			}
			else
			{
				// Treat as latest media if there are no media IDs.
				$mediaList->orderByDate();
				$this->options['order'] = 'latest';
			}
		}
		else
		{
			$mediaList->orderByDate();
		}

		$mediaItems = $mediaList->fetch()->filterViewable();

		if ($this->options['order'] == 'random')
		{
			$mediaItems = $mediaItems->shuffle();
		}

		$router = \XF::app()->router('public');
		$link = $router->buildLink('dbtech-social/media', $group);

		$viewParams = [
			'mediaItems' => $mediaItems->slice(0, $this->options['limit']),
			'title' => $this->getTitle() ?: $title,
			'link' => $link,
		];
		return $this->renderer('dbtech_social_groups_widget_newest_media', $viewParams);
	}

	/**
	 * @param Request $request
	 * @param array $options
	 * @param $error
	 *
	 * @return true
	 * @noinspection PhpMissingReturnTypeInspection
	 */
	public function verifyOptions(Request $request, array &$options, &$error = null)
	{
		$options = $request->filter([
			'order' => InputFilterer::STRING,
			'limit' => InputFilterer::UNSIGNED,
			'slider' => [
				'item' => InputFilterer::UNSIGNED,
				'itemWide' => InputFilterer::UNSIGNED,
				'itemMedium' => InputFilterer::UNSIGNED,
				'itemNarrow' => InputFilterer::UNSIGNED,
				'auto' => InputFilterer::BOOLEAN,
				'loop' => InputFilterer::BOOLEAN,
				'pager' => InputFilterer::BOOLEAN,
				'pauseOnHover' => InputFilterer::BOOLEAN,
			],
		]);
		if ($options['limit'] < 1)
		{
			$options['limit'] = 1;
		}

		return true;
	}
}