<?php

namespace DBTech\SocialGroups\Widget;

use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Finder\GroupFinder;
use DBTech\SocialGroups\XF\Entity\User as ExtendedUserEntity;
use XF\Http\Request;
use XF\InputFilterer;
use XF\Mvc\Entity\AbstractCollection;
use XF\Widget\AbstractWidget;
use XF\Widget\WidgetRenderer;

abstract class AbstractGroupWidget extends AbstractWidget
{
	/** @var array */
	protected $defaultOptions = [
		'limit' => 5,
		'style' => 'simple',
	];

	abstract protected function getGroupFinder(): GroupFinder;

	/**
	 * @return string|WidgetRenderer
	 */
	public function render(): string|WidgetRenderer
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();
		if (!method_exists($visitor, 'canViewDbtechSocialGroups') || !$visitor->canViewDbtechSocialGroups())
		{
			return '';
		}

		$options = $this->options;
		$limit = $options['limit'];

		/** @var GroupFinder $finder */
		$finder = $this->getGroupFinder();

		if ($options['style'] == 'full')
		{
			$finder->with('full');
		}

		$groups = $finder->fetch(max($limit * 2, 10));

		/** @var Group $group */
		foreach ($groups AS $groupId => $group)
		{
			if (!$group->canView() || $visitor->isIgnoring($group->user_id))
			{
				unset($groups[$groupId]);
			}
		}

		$groups = $groups->slice(0, $limit);

		return $this->renderer(
			'dbtech_social_groups_widget_groups',
			$this->getTemplateParams($groups)
		);
	}

	/**
	 * @param AbstractCollection $groups
	 *
	 * @return array
	 */
	protected function getTemplateParams(AbstractCollection $groups): array
	{
		return [
			'link' => \XF::app()->router('public')->buildLink('dbtech-social'),
			'style' => $this->options['style'],
			'groups' => $groups,
		];
	}

	/**
	 * @return string|null
	 */
	public function getOptionsTemplate(): ?string
	{
		return 'admin:widget_def_options_dbtech_social_groups_widget_groups';
	}

	/**
	 * @param Request $request
	 * @param array $options
	 * @param $error
	 *
	 * @return bool
	 */
	public function verifyOptions(Request $request, array &$options, &$error = null): bool
	{
		$options = $request->filter([
			'limit' => InputFilterer::UNSIGNED,
			'style' => InputFilterer::STRING,
		]);
		if ($options['limit'] < 1)
		{
			$options['limit'] = 1;
		}

		return true;
	}
}