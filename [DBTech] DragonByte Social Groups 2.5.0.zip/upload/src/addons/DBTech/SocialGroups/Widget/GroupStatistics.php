<?php

namespace DBTech\SocialGroups\Widget;

use XF\Widget\AbstractWidget;
use XF\Widget\WidgetRenderer;

class GroupStatistics extends AbstractWidget
{
	/**
	 * @return WidgetRenderer
	 * @noinspection PhpMissingReturnTypeInspection
	 */
	public function render()
	{
		$viewParams = [
			'forumStatistics' => \XF::app()->forumStatistics,
		];
		return $this->renderer('dbtech_social_groups_widget_group_statistics', $viewParams);
	}

	public function getOptionsTemplate(): ?string
	{
		return null;
	}
}