<?php

namespace DBTech\SocialGroups\Widget;

use DBTech\SocialGroups\Repository\GroupRepository;
use XF\Http\Request;
use XF\InputFilterer;
use XF\Repository\TagRepository;
use XF\Widget\AbstractWidget;
use XF\Widget\WidgetRenderer;

class TagCloud extends AbstractWidget
{
	/** @var array */
	protected $defaultOptions = [
		'limit' => 100,
		'minUses' => 1,
	];

	/**
	 * @return string|WidgetRenderer
	 */
	public function render(): string|WidgetRenderer
	{
		$options = $this->options;

		$cloudEntries = \XF::app()->repository(GroupRepository::class)
			->getGroupTagsForCloud(
				$options['limit'],
				$options['minUses']
			)
		;
		$tagCloud = \XF::app()->repository(TagRepository::class)
			->getTagCloud($cloudEntries)
		;
		if (!$tagCloud)
		{
			return '';
		}

		$viewParams = [
			'title' => $this->getTitle(),
			'tagCloud' => $tagCloud,
			'canSearch' => \XF::visitor()->canSearch(),
		];
		return $this->renderer('dbtech_social_groups_widget_tag_cloud', $viewParams);
	}

	/**
	 * @param Request $request
	 * @param array $options
	 * @param $error
	 *
	 * @return bool
	 */
	public function verifyOptions(Request $request, array &$options, &$error = null): bool
	{
		$options = $request->filter([
			'limit' => InputFilterer::UNSIGNED,
			'minUses' => InputFilterer::UNSIGNED,
		]);

		if ($options['limit'] < 1)
		{
			$options['limit'] = 1;
		}

		if ($options['minUses'] < 1)
		{
			$options['minUses'] = 1;
		}

		return true;
	}
}