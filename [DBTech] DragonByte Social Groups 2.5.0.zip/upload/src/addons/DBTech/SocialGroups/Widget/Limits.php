<?php

namespace DBTech\SocialGroups\Widget;

use XF\Widget\AbstractWidget;
use XF\Widget\WidgetRenderer;

class Limits extends AbstractWidget
{
	/**
	 * @return WidgetRenderer
	 * @noinspection PhpMissingReturnTypeInspection
	 */
	public function render()
	{
		return $this->renderer('dbtech_social_groups_widget_limits');
	}

	public function getOptionsTemplate(): ?string
	{
		return null;
	}
}