<?php

namespace DBTech\SocialGroups\Widget;

use DBTech\SocialGroups\Finder\GroupFinder;
use DBTech\SocialGroups\Repository\GroupRepository;

class RandomGroups extends AbstractGroupWidget
{
	protected function getGroupFinder(): GroupFinder
	{
		return \XF::app()->repository(GroupRepository::class)
			->findRandomGroups()
		;
	}
}