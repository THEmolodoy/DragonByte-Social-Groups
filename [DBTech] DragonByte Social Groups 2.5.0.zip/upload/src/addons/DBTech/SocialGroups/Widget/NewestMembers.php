<?php

namespace DBTech\SocialGroups\Widget;

use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Repository\GroupMemberRepository;
use XF\Http\Request;
use XF\InputFilterer;
use XF\Widget\AbstractWidget;
use XF\Widget\WidgetRenderer;

class NewestMembers extends AbstractWidget
{
	/** @var array */
	protected $defaultOptions = [
		'limit' => 12,
	];

	/**
	 * @return string|WidgetRenderer
	 */
	public function render(): string|WidgetRenderer
	{
		/** @var Group|null $group */
		$group = $this->contextParams['group'] ?? null;
		if (!$group || !$group->canViewMemberList())
		{
			return '';
		}

		$options = $this->options;

		$title = \XF::phrase('dbtech_social_groups_newest_members');

		$memberFinder = \XF::app()->repository(GroupMemberRepository::class)
			->getLatestMembersInGroup($group, $options['limit'])
		;

		$viewParams = [
			'title' => $this->getTitle() ?: $title,
			'members' => $memberFinder->fetch(),
		];
		return $this->renderer('dbtech_social_groups_widget_newest_members', $viewParams);
	}

	/**
	 * @param Request $request
	 * @param array $options
	 * @param $error
	 *
	 * @return bool
	 */
	public function verifyOptions(Request $request, array &$options, &$error = null): bool
	{
		$options = $request->filter([
			'limit' => InputFilterer::UNSIGNED,
		]);

		if ($options['limit'] < 1)
		{
			$options['limit'] = 1;
		}

		return true;
	}
}