<?php

namespace DBTech\SocialGroups\Cron;

use DBTech\SocialGroups\Repository\DiscussionReplyBanRepository;
use DBTech\SocialGroups\Repository\DiscussionRepository;
use DBTech\SocialGroups\Repository\GroupRepository;

class CleanUp
{
	/**
	 * Clean up tasks that should be done daily. This task cannot be relied on
	 * to run daily, consistently.
	 */
	public static function runDailyCleanUp(): void
	{
		\XF::app()->repository(DiscussionRepository::class)
			->pruneDiscussionReadLogs()
		;

		\XF::app()->repository(GroupRepository::class)
			->pruneGroupReadLogs()
		;
	}

	/**
	 * Clean up tasks that should be done hourly. This task cannot be relied on
	 * to run every hour, consistently.
	 */
	public static function runHourlyCleanUp(): void
	{
		\XF::app()->repository(DiscussionReplyBanRepository::class)
			->cleanUpExpiredBans()
		;
	}
}