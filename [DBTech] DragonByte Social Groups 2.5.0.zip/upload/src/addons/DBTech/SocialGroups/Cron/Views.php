<?php

namespace DBTech\SocialGroups\Cron;

use DBTech\SocialGroups\Repository\DiscussionRepository;
use DBTech\SocialGroups\Repository\GroupRepository;
use XF\Db\Exception as DbException;

class Views
{
	/**
	 * @return void
	 * @throws DbException
	 */
	public static function runViewUpdate(): void
	{
		\XF::app()->repository(DiscussionRepository::class)
			->batchUpdateDiscussionViews()
		;

		\XF::app()->repository(GroupRepository::class)
			->batchUpdateGroupViews()
		;
	}
}