<?php

namespace DBTech\SocialGroups\Cron;

use DBTech\SocialGroups\Repository\BanningRepository;
use XF\PrintableException;

/**
 * Cron entry for cleaning up bans.
 */
class Ban
{
	/**
	 * Deletes expired bans.
	 *
	 * @throws PrintableException
	 */
	public static function deleteExpiredBans(): void
	{
		\XF::app()->repository(BanningRepository::class)
			->deleteExpiredGroupBans()
		;
	}
}