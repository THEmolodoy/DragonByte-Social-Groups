<?php

namespace DBTech\SocialGroups\NewsFeed;

use DBTech\SocialGroups\Entity\Discussion;
use XF\Mvc\Entity\AbstractCollection;
use XF\NewsFeed\AbstractHandler;
use XF\Repository\AttachmentRepository;

/**
 * @extends AbstractHandler<Discussion>
 */
class DiscussionHandler extends AbstractHandler
{
	/**
	 * @return string[]
	 */
	public function getEntityWith(): array
	{
		$visitor = \XF::visitor();

		return [
			'User',
			'FirstMessage',
			'Group',
			'Group.Permissions|' . $visitor->permission_combination_id,
		];
	}

	/**
	 * @param AbstractCollection<Discussion>|Discussion[] $content
	 *
	 * @return AbstractCollection<Discussion>|Discussion[]
	 */
	protected function addAttachmentsToContent($content): AbstractCollection|array
	{
		$firstMessages = [];

		foreach ($content AS $discussion)
		{
			$firstMessage = $discussion->FirstMessage;
			if ($firstMessage)
			{
				$firstMessages[$firstMessage->message_id] = $firstMessage;
			}
		}

		\XF::app()->repository(AttachmentRepository::class)
			->addAttachmentsToContent($firstMessages, 'dbtech_social_message')
		;

		return $content;
	}
}