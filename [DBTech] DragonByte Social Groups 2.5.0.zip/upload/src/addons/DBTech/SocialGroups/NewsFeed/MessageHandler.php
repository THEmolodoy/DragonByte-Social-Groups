<?php

namespace DBTech\SocialGroups\NewsFeed;

use DBTech\SocialGroups\Entity\Message;
use XF\Mvc\Entity\AbstractCollection;
use XF\Mvc\Entity\Entity;
use XF\NewsFeed\AbstractHandler;

/**
 * @extends AbstractHandler<Message>
 */
class MessageHandler extends AbstractHandler
{
	/**
	 * @param Message $entity
	 * @param string $action
	 *
	 * @return bool
	 */
	public function isPublishable(Entity $entity, $action): bool
	{
		if ($action == 'insert')
		{
			// first message inserts are handled by the discussion
			return !$entity->isFirstMessage();
		}

		return true;
	}

	/**
	 * @return string[]
	 */
	public function getEntityWith(): array
	{
		$visitor = \XF::visitor();

		return [
			'User',
			'Discussion',
			'Discussion.Group',
			'Discussion.Group.Permissions|' . $visitor->permission_combination_id,
		];
	}

	/**
	 * @param AbstractCollection<Message>|Message[] $content
	 *
	 * @return AbstractCollection<Message>|Message[]
	 */
	protected function addAttachmentsToContent($content): AbstractCollection|array
	{
		return $this->addAttachments($content);
	}
}