<?php

namespace DBTech\SocialGroups\Option;

use XF\Entity\Option;
use XF\Option\AbstractOption;

class MemberListDefaultOrder extends AbstractOption
{
	/**
	 * @param Option $option
	 * @param array $htmlParams
	 *
	 * @return string
	 */
	public static function renderSelect(Option $option, array $htmlParams): string
	{
		$data = self::getSelectData($option, $htmlParams);

		return self::getTemplater()->formSelectRow(
			$data['controlOptions'],
			$data['choices'],
			$data['rowOptions']
		);
	}

	/**
	 * @param Option $option
	 * @param array $htmlParams
	 *
	 * @return array
	 */
	protected static function getSelectData(Option $option, array $htmlParams): array
	{
		$choices = [
			'username' => [
				'_type' => 'option',
				'value' => 'username',
				'label' => \XF::phrase('user_name'),
			],
			'join_date' => [
				'_type' => 'option',
				'value' => 'join_date',
				'label' => \XF::phrase('dbtech_social_groups_group_join_date'),
			],
			'last_activity_date' => [
				'_type' => 'option',
				'value' => 'last_activity_date',
				'label' => \XF::phrase('dbtech_social_groups_last_activity_date'),
			],
			'last_message_date' => [
				'_type' => 'option',
				'value' => 'last_message_date',
				'label' => \XF::phrase('dbtech_social_groups_last_message_date'),
			],
		];

		if (\XF::isAddOnActive('XFMG'))
		{
			$choices['last_media_upload_date'] = [
				'_type' => 'option',
				'value' => 'last_media_upload_date',
				'label' => \XF::phrase('dbtech_social_groups_last_media_upload_date'),
			];
		}

		if (\XF::isAddOnActive('NF/Calendar', 2060070))
		{
			$choices['last_event_creation_date'] = [
				'_type' => 'option',
				'value' => 'last_event_creation_date',
				'label' => \XF::phrase('dbtech_social_groups_last_event_creation_date'),
			];
		}

		$choices['message_count'] = [
			'_type' => 'option',
			'value' => 'message_count',
			'label' => \XF::phrase('dbtech_social_groups_messages'),
		];

		if (\XF::isAddOnActive('XFMG'))
		{
			$choices['album_count'] = [
				'_type' => 'option',
				'value' => 'message_count',
				'label' => \XF::phrase('xfmg_albums'),
			];
			$choices['media_count'] = [
				'_type' => 'option',
				'value' => 'message_count',
				'label' => \XF::phrase('xfmg_media'),
			];
		}

		return [
			'choices' => $choices,
			'controlOptions' => self::getControlOptions($option, $htmlParams),
			'rowOptions' => self::getRowOptions($option, $htmlParams),
		];
	}
}