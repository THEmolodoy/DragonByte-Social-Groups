<?php

namespace DBTech\SocialGroups\Option;

use XF\Entity\Option;
use XF\Option\AbstractOption;

class SpamDiscussionAction extends AbstractOption
{
	/**
	 * @param Option $option
	 * @param array $htmlParams
	 *
	 * @return string
	 */
	public static function renderOption(Option $option, array $htmlParams): string
	{
		return self::getTemplate('admin:option_template_dbtechSocialSpamDiscussionAction', $option, $htmlParams);
	}

	/**
	 * @param array $value
	 * @param Option $option
	 *
	 * @return bool
	 */
	public static function verifyOption(array &$value, Option $option): bool
	{
		return true;
	}
}