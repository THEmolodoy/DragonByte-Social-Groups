<?php

namespace DBTech\SocialGroups\Option;

use XF\Entity\Option;
use XF\Entity\ThreadPrefixGroup;
use XF\Option\AbstractOption;
use XF\Repository\ThreadPrefixRepository;

class ThreadPrefix extends AbstractOption
{
	/**
	 * @param Option $option
	 * @param array $htmlParams
	 *
	 * @return string
	 */
	public static function renderSelect(Option $option, array $htmlParams): string
	{
		$data = self::getSelectData($option, $htmlParams);

		return self::getTemplater()->formSelectRow(
			$data['controlOptions'],
			$data['choices'],
			$data['rowOptions']
		);
	}

	/**
	 * @param Option $option
	 * @param array $htmlParams
	 *
	 * @return string
	 */
	public static function renderSelectMultiple(Option $option, array $htmlParams): string
	{
		$data = self::getSelectData($option, $htmlParams);
		$data['controlOptions']['multiple'] = true;
		$data['controlOptions']['size'] = 8;

		return self::getTemplater()->formSelectRow(
			$data['controlOptions'],
			$data['choices'],
			$data['rowOptions']
		);
	}

	/**
	 * @param Option $option
	 * @param array $htmlParams
	 *
	 * @return array
	 */
	protected static function getSelectData(Option $option, array $htmlParams): array
	{
		$choices = [
			0 => ['_type' => 'option', 'value' => 0, 'label' => \XF::phrase('(none)')],
		];

		$prefixData = \XF::app()->repository(ThreadPrefixRepository::class)
			->getPrefixListData()
		;

		foreach ($prefixData['prefixesGrouped'] AS $prefixGroupId => $prefixDatum)
		{
			/** @var ThreadPrefixGroup $prefixGroup */
			$prefixGroup = $prefixData['prefixGroups'][$prefixGroupId];

			$options = [];

			/** @var \XF\Entity\ThreadPrefix[] $prefixDatum */
			foreach ($prefixDatum AS $prefixId => $prefix)
			{
				$options[$prefixId] = [
					'value' => $prefixId,
					'label' => \XF::escapeString($prefix->title),
					'_type' => 'option',
				];
			}

			$choices[] = [
				'label' => \XF::escapeString($prefixGroup->title),
				'options' => $options,
				'_type' => 'optgroup',
			];
		}

		return [
			'choices' => $choices,
			'controlOptions' => self::getControlOptions($option, $htmlParams),
			'rowOptions' => self::getRowOptions($option, $htmlParams),
		];
	}
}