<?php

namespace DBTech\SocialGroups\Option;

use DBTech\SocialGroups\Repository\MediaRepository;
use XF\Entity\Option;
use XF\Option\AbstractOption;

class MediaAlbumCategory extends AbstractOption
{
	/**
	 * @param Option $option
	 * @param array $htmlParams
	 *
	 * @return string
	 */
	public static function renderSelect(Option $option, array $htmlParams): string
	{
		if (\XF::isAddOnActive('XFMG'))
		{
			$data = self::getSelectData($option, $htmlParams);

			return self::getTemplater()->formSelectRow(
				$data['controlOptions'],
				$data['choices'],
				$data['rowOptions']
			);
		}

		return self::getTemplater()->formRow(
			'
				<input type="hidden" name="' . $htmlParams['inputName'] . '" value="' . $option->option_value . '" />
				' . \XF::phrase('dbtech_social_groups_xfmg_required'),
			self::getRowOptions($option, $htmlParams)
		);
	}

	/**
	 * @param Option $option
	 * @param array $htmlParams
	 *
	 * @return string
	 */
	public static function renderSelectMultiple(Option $option, array $htmlParams): string
	{
		if (\XF::isAddOnActive('XFMG'))
		{
			$data = self::getSelectData($option, $htmlParams);
			$data['controlOptions']['multiple'] = true;
			$data['controlOptions']['size'] = 8;

			return self::getTemplater()->formSelectRow(
				$data['controlOptions'],
				$data['choices'],
				$data['rowOptions']
			);
		}

		return '';
	}

	/**
	 * @param Option $option
	 * @param array $htmlParams
	 *
	 * @return array
	 */
	protected static function getSelectData(Option $option, array $htmlParams): array
	{
		$choices = \XF::app()->repository(MediaRepository::class)
			->getCategoryOptionsData(true, 'album', 'option')
		;
		$choices = array_map(function ($v)
		{
			$v['label'] = \XF::escapeString($v['label']);
			return $v;
		}, $choices);

		return [
			'choices' => $choices,
			'controlOptions' => self::getControlOptions($option, $htmlParams),
			'rowOptions' => self::getRowOptions($option, $htmlParams),
		];
	}
}