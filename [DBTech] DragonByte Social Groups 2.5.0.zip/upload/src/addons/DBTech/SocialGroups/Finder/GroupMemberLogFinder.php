<?php

/** @noinspection PhpFullyQualifiedNameUsageInspection */

namespace DBTech\SocialGroups\Finder;

use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\XF\Entity\User as ExtendedUserEntity;
use XF\Mvc\Entity\AbstractCollection;
use XF\Mvc\Entity\Finder;

/**
 * @method AbstractCollection<\DBTech\SocialGroups\Entity\GroupMemberLog> fetch(?int $limit = null, ?int $offset = null)
 * @method AbstractCollection<\DBTech\SocialGroups\Entity\GroupMemberLog> fetchDeferred(?int $limit = null, ?int $offset = null)
 * @method \DBTech\SocialGroups\Entity\GroupMemberLog|null fetchOne(?int $offset = null)
 * @extends Finder<\DBTech\SocialGroups\Entity\GroupMemberLog>
 */
class GroupMemberLogFinder extends Finder
{
	/**
	 * @return $this
	 */
	public function applyGlobalVisibilityChecks(): GroupMemberLogFinder
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		if (!$visitor->canViewAnyDbtechSocialGroupLogs())
		{
			$this->where('User.user_id', '!=', null);
		}

		return $this;
	}

	/**
	 * @return $this
	 */
	public function inGroup(Group $group): GroupMemberLogFinder
	{
		$this->where('group_id', $group->group_id);
		return $this;
	}
}