<?php

/** @noinspection PhpFullyQualifiedNameUsageInspection */

namespace DBTech\SocialGroups\Finder;

use DBTech\SocialGroups\Entity\Group;
use XF\Mvc\Entity\AbstractCollection;
use XF\Mvc\Entity\Finder;

/**
 * @method AbstractCollection<\DBTech\SocialGroups\Entity\GroupBan> fetch(?int $limit = null, ?int $offset = null)
 * @method AbstractCollection<\DBTech\SocialGroups\Entity\GroupBan> fetchDeferred(?int $limit = null, ?int $offset = null)
 * @method \DBTech\SocialGroups\Entity\GroupBan|null fetchOne(?int $offset = null)
 * @extends Finder<\DBTech\SocialGroups\Entity\GroupBan>
 */
class GroupBanFinder extends Finder
{
	/**
	 * @return $this
	 */
	public function inGroup(Group $group): GroupBanFinder
	{
		$this->where('group_id', $group->group_id);
		return $this;
	}
}