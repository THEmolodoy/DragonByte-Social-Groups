<?php

/** @noinspection PhpFullyQualifiedNameUsageInspection */

namespace DBTech\SocialGroups\Finder;

use DBTech\SocialGroups\Repository\GroupRepository;
use DBTech\SocialGroups\XF\Entity\User as ExtendedUserEntity;
use XF\Mvc\Entity\AbstractCollection;
use XF\Mvc\Entity\Finder;

/**
 * @method AbstractCollection<\DBTech\SocialGroups\Entity\Group> fetch(?int $limit = null, ?int $offset = null)
 * @method AbstractCollection<\DBTech\SocialGroups\Entity\Group> fetchDeferred(?int $limit = null, ?int $offset = null)
 * @method \DBTech\SocialGroups\Entity\Group|null fetchOne(?int $offset = null)
 * @extends Finder<\DBTech\SocialGroups\Entity\Group>
 */
class GroupFinder extends Finder
{
	/**
	 * @param bool $allowOwnPending
	 *
	 * @return $this
	 */
	public function applyGlobalVisibilityChecks(
		bool $allowOwnPending = true
	): GroupFinder
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		$conditions = [];
		$viewableStates = ['visible'];

		if ($visitor->canViewDeletedDbtechSocialGroups())
		{
			$viewableStates[] = 'deleted';

			$this->with('DeletionLog');
		}

		if ($visitor->canViewModeratedDbtechSocialGroups())
		{
			$viewableStates[] = 'moderated';
		}
		else if ($visitor->user_id && $allowOwnPending)
		{
			$conditions[] = [
				'group_state' => 'moderated',
				'user_id' => $visitor->user_id,
			];
		}

		$conditions[] = ['group_state', $viewableStates];

		$this->whereOr($conditions);

		return $this;
	}

	/**
	 * @return $this
	 */
	public function isValidGroup(): GroupFinder
	{
		$this->where('group_state', 'visible');
		return $this;
	}

	/**
	 * @param null $userId
	 *
	 * @return $this
	 */
	public function withReadData($userId = null): GroupFinder
	{
		if ($userId === null)
		{
			$userId = \XF::visitor()->user_id;
		}

		if ($userId)
		{
			$this->with([
				'Read|' . $userId,
			]);
		}

		return $this;
	}

	/**
	 * @param int|null $userId
	 *
	 * @return $this
	 */
	public function unreadOnly(?int $userId = null): GroupFinder
	{
		if ($userId === null)
		{
			$userId = \XF::visitor()->user_id;
		}
		if (!$userId)
		{
			// no user, no read tracking
			return $this;
		}

		$groupReadExpression = $this->expression(
			'%s > COALESCE(%s, 0)',
			'last_message_date',
			'Read|' . $userId . '.group_read_date'
		);

		$this->where(
			'last_message_date',
			'>',
			\XF::app()->repository(GroupRepository::class)
				->getReadMarkingCutOff()
		)
			->where($groupReadExpression);

		return $this;
	}

	/**
	 * @param null $userId
	 *
	 * @return $this
	 * @throws \InvalidArgumentException
	 */
	public function watchedOnly($userId = null): GroupFinder
	{
		if ($userId === null)
		{
			$userId = \XF::visitor()->user_id;
		}
		if (!$userId)
		{
			// no user, just ignore
			return $this;
		}

		$this->where('Watch|' . $userId . '.user_id', '!=', null);

		return $this;
	}

	/**
	 * @param string $match
	 * @param bool $caseSensitive
	 * @param bool $prefixMatch
	 * @param bool $exactMatch
	 *
	 * @return $this
	 */
	public function searchText(
		string $match,
		bool $caseSensitive = false,
		bool $prefixMatch = false,
		bool $exactMatch = false
	): GroupFinder
	{
		if ($match)
		{
			//			$expression = 'MasterTitle.phrase_text';
			$expression = 'title';
			if ($caseSensitive)
			{
				$expression = $this->expression('BINARY %s', $expression);
			}

			if ($exactMatch)
			{
				$this->where($expression, $match);
			}
			else
			{
				$this->where($expression, 'LIKE', $this->escapeLike($match, $prefixMatch ? '?%' : '%?%'));
			}
		}

		return $this;
	}



	/**
	 * @param string $match
	 *
	 * @return $this
	 */
	public function searchTitleForAutoComplete(
		string $match
	): GroupFinder
	{
		if ($match)
		{
			$this->where(
				$this->columnUtf8('title'),
				'LIKE',
				$this->escapeLike($match, '%?%')
			);
		}

		return $this;
	}

	/**
	 * @param string $direction
	 * @return $this
	 */
	public function orderTitle(string $direction = 'ASC'): GroupFinder
	{
		//		$expression = $this->columnUtf8('MasterTitle.phrase_text');
		$expression = $this->columnUtf8('title');
		$this->order($expression, $direction);

		return $this;
	}

	/**
	 * @return $this
	 * @throws \InvalidArgumentException
	 */
	public function useDefaultOrder(): GroupFinder
	{
		$defaultOrder = \XF::app()->options()->dbtechSocialListDefaultOrder ?: 'last_message_date';
		$defaultDir = $defaultOrder == 'title' ? 'asc' : 'desc';

		if ($defaultOrder == 'random')
		{
			$this->setDefaultOrder($this->expression('RAND()'));
			//			$this->setDefaultOrder([['featured', 'DESC'], $this->expression('RAND()')]);
		}
		else
		{
			$this->setDefaultOrder($defaultOrder, $defaultDir);
			//			$this->setDefaultOrder([['featured', 'DESC'], [$defaultOrder, $defaultDir]]);
		}

		return $this;
	}
}