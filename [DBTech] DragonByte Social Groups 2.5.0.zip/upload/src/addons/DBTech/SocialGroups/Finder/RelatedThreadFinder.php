<?php

/** @noinspection PhpFullyQualifiedNameUsageInspection */

namespace DBTech\SocialGroups\Finder;

use XF\Mvc\Entity\AbstractCollection;
use XF\Mvc\Entity\Finder;

/**
 * @method AbstractCollection<\DBTech\SocialGroups\Entity\RelatedThread> fetch(?int $limit = null, ?int $offset = null)
 * @method AbstractCollection<\DBTech\SocialGroups\Entity\RelatedThread> fetchDeferred(?int $limit = null, ?int $offset = null)
 * @method \DBTech\SocialGroups\Entity\RelatedThread|null fetchOne(?int $offset = null)
 * @extends Finder<\DBTech\SocialGroups\Entity\RelatedThread>
 */
class RelatedThreadFinder extends Finder
{
}