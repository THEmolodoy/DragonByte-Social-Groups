<?php

/** @noinspection PhpFullyQualifiedNameUsageInspection */

namespace DBTech\SocialGroups\Finder;

use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\XF\Entity\User as ExtendedUserEntity;
use XF\Mvc\Entity\AbstractCollection;
use XF\Mvc\Entity\Finder;

/**
 * @method AbstractCollection<\DBTech\SocialGroups\Entity\GroupMember> fetch(?int $limit = null, ?int $offset = null)
 * @method AbstractCollection<\DBTech\SocialGroups\Entity\GroupMember> fetchDeferred(?int $limit = null, ?int $offset = null)
 * @method \DBTech\SocialGroups\Entity\GroupMember|null fetchOne(?int $offset = null)
 * @extends Finder<\DBTech\SocialGroups\Entity\GroupMember>
 */
class GroupMemberFinder extends Finder
{
	/**
	 * @param bool $allowOwnPending
	 *
	 * @return $this
	 */
	public function applyGlobalGroupVisibilityChecks(
		bool $allowOwnPending = true
	): GroupMemberFinder
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		$conditions = [];
		$viewableStates = ['visible'];

		if ($visitor->canViewDeletedDbtechSocialGroups())
		{
			$viewableStates[] = 'deleted';

			$this->with('Group.DeletionLog');
		}

		if ($visitor->canViewModeratedDbtechSocialGroups())
		{
			$viewableStates[] = 'moderated';
		}
		else if ($visitor->user_id && $allowOwnPending)
		{
			$conditions[] = [
				'Group.group_state' => 'moderated',
				'Group.user_id' => $visitor->user_id,
			];
		}

		$conditions[] = ['Group.group_state', $viewableStates];

		$this->whereOr($conditions);

		return $this;
	}

	/**
	 * @return $this
	 */
	public function inGroup(Group $group): GroupMemberFinder
	{
		$this->where('group_id', $group->group_id);
		return $this;
	}

	/**
	 * @return $this
	 */
	public function isValidMember(): GroupMemberFinder
	{
		$this->where('member_state', 'valid');
		return $this;
	}

	/**
	 * @param bool $recentlyActive
	 *
	 * @return $this
	 */
	public function isValidUser(bool $recentlyActive = false): GroupMemberFinder
	{
		$this->where('User.is_banned', false);
		$this->where('User.user_state', 'valid');
		if ($recentlyActive)
		{
			$this->isRecentlyActive();
		}
		return $this;
	}

	/**
	 * @param int $days
	 *
	 * @return $this
	 */
	public function isRecentlyActive(int $days = 180): GroupMemberFinder
	{
		$this->where('User.last_activity', '>', time() - ($days * 86400));
		return $this;
	}

	/**
	 * @param string $direction
	 * @return $this
	 */
	public function orderUsername(string $direction = 'ASC'): GroupMemberFinder
	{
		$expression = $this->columnUtf8('User.username');
		$this->order($expression, $direction);

		return $this;
	}

	/**
	 * @return $this
	 * @throws \InvalidArgumentException
	 */
	public function useDefaultOrder(): GroupMemberFinder
	{
		$defaultOrder = \XF::app()->options()->dbtechSocialMemberListDefaultOrder ?: 'username';
		$defaultDirection = $defaultOrder == 'username' ? 'asc' : 'desc';

		if ($defaultOrder == 'username')
		{
			$defaultOrder = $this->columnUtf8('User.username');
		}

		$this->setDefaultOrder([
			['is_supervisor', 'DESC'],
			[$defaultOrder, $defaultDirection],
		]);

		return $this;
	}
}