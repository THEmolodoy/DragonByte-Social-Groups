<?php

/** @noinspection PhpFullyQualifiedNameUsageInspection */

namespace DBTech\SocialGroups\Finder;

use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Entity\Section;
use DBTech\SocialGroups\Repository\DiscussionRepository;
use XF\Entity\User;
use XF\Mvc\Entity\AbstractCollection;
use XF\Mvc\Entity\Finder;

/**
 * @method AbstractCollection<\DBTech\SocialGroups\Entity\Discussion> fetch(?int $limit = null, ?int $offset = null)
 * @method AbstractCollection<\DBTech\SocialGroups\Entity\Discussion> fetchDeferred(?int $limit = null, ?int $offset = null)
 * @method \DBTech\SocialGroups\Entity\Discussion|null fetchOne(?int $offset = null)
 * @extends Finder<\DBTech\SocialGroups\Entity\Discussion>
 */
class DiscussionFinder extends Finder
{
	/**
	 * @param Group $group
	 * @param array $limits
	 *
	 * @return $this
	 */
	public function inGroup(Group $group, array $limits = []): DiscussionFinder
	{
		$limits = array_replace([
			'visibility' => true,
			'allowOwnPending' => false,
		], $limits);

		$this->where('group_id', $group->group_id);

		$this->applyGroupDefaultOrder($group);

		if ($limits['visibility'])
		{
			$this->applyVisibilityChecksInGroup($group, $limits['allowOwnPending']);
		}

		return $this;
	}

	/**
	 * @param Section $section
	 * @param array $limits
	 *
	 * @return $this
	 */
	public function inSection(Section $section, array $limits = []): DiscussionFinder
	{
		$limits = array_replace([
			'visibility' => true,
			'allowOwnPending' => false,
		], $limits);

		$this->where('section_id', $section->section_id);

		$this->applySectionDefaultOrder($section);

		if ($limits['visibility'])
		{
			$this->applyVisibilityChecksInSection($section, $limits['allowOwnPending']);
		}

		return $this;
	}

	/**
	 * @param Group $group
	 * @param bool $allowOwnPending
	 *
	 * @return $this
	 */
	public function applyVisibilityChecksInGroup(
		Group $group,
		bool $allowOwnPending = false
	): DiscussionFinder
	{
		$conditions = [];
		$viewableStates = ['visible'];

		if ($group->canViewDeletedDiscussions())
		{
			$viewableStates[] = 'deleted';

			$this->with('DeletionLog');
		}

		$visitor = \XF::visitor();
		if ($group->canViewModeratedDiscussions())
		{
			$viewableStates[] = 'moderated';
		}
		else if ($visitor->user_id && $allowOwnPending)
		{
			$conditions[] = [
				'discussion_state' => 'moderated',
				'user_id' => $visitor->user_id,
			];
		}

		$conditions[] = ['discussion_state', $viewableStates];

		$this->whereOr($conditions);

		$visitor = \XF::visitor();
		if (!$visitor->hasDbtechSocialGroupsGroupPermission($group->group_id, 'viewOthers'))
		{
			if ($visitor->user_id)
			{
				$this->where('user_id', $visitor->user_id);
			}
			else
			{
				$this->whereSql('1=0'); // force false immediately
			}
		}

		return $this;
	}

	/**
	 * @param Section $section
	 * @param bool $allowOwnPending
	 *
	 * @return $this
	 */
	public function applyVisibilityChecksInSection(
		Section $section,
		bool $allowOwnPending = false
	): DiscussionFinder
	{
		$conditions = [];
		$viewableStates = ['visible'];

		if ($section->canViewDeletedDiscussions())
		{
			$viewableStates[] = 'deleted';

			$this->with('DeletionLog');
		}

		$visitor = \XF::visitor();
		if ($section->canViewModeratedDiscussions())
		{
			$viewableStates[] = 'moderated';
		}
		else if ($visitor->user_id && $allowOwnPending)
		{
			$conditions[] = [
				'discussion_state' => 'moderated',
				'user_id' => $visitor->user_id,
			];
		}

		$conditions[] = ['discussion_state', $viewableStates];

		$this->whereOr($conditions);

		$visitor = \XF::visitor();
		if (!$visitor->hasDbtechSocialGroupsGroupPermission($section->group_id, 'viewOthers'))
		{
			if ($visitor->user_id)
			{
				$this->where('user_id', $visitor->user_id);
			}
			else
			{
				$this->whereSql('1=0'); // force false immediately
			}
		}

		return $this;
	}

	/**
	 * @param Group $group
	 *
	 * @return $this
	 */
	public function applyGroupDefaultOrder(Group $group): DiscussionFinder
	{
		$this->setDefaultOrder($group->default_sort_order, $group->default_sort_direction);

		return $this;
	}

	/**
	 * @param Section $section
	 *
	 * @return $this
	 */
	public function applySectionDefaultOrder(Section $section): DiscussionFinder
	{
		$this->setDefaultOrder($section->default_sort_order, $section->default_sort_direction);

		return $this;
	}

	/**
	 * @param null $userId
	 *
	 * @return $this
	 */
	public function withReadData($userId = null): DiscussionFinder
	{
		if ($userId === null)
		{
			$userId = \XF::visitor()->user_id;
		}

		if ($userId)
		{
			$this->with([
				'Read|' . $userId,
				'Group.Read|' . $userId,
				'Section.Read|' . $userId,
			]);
		}

		return $this;
	}

	/**
	 * @param int|null $userId
	 *
	 * @return $this
	 */
	public function unreadOnly(?int $userId = null): DiscussionFinder
	{
		if ($userId === null)
		{
			$userId = \XF::visitor()->user_id;
		}
		if (!$userId)
		{
			// no user, no read tracking
			return $this;
		}

		$discussionReadExpression = $this->expression(
			'%s > COALESCE(%s, 0)',
			'last_message_date',
			'Read|' . $userId . '.discussion_read_date'
		);

		$groupReadExpression = $this->expression(
			'%s > COALESCE(%s, 0)',
			'last_message_date',
			'Group.Read|' . $userId . '.group_read_date'
		);

		$sectionReadExpression = $this->expression(
			'%s > COALESCE(%s, 0)',
			'last_message_date',
			'Section.Read|' . $userId . '.section_read_date'
		);

		$this->where(
			'last_message_date',
			'>',
			\XF::app()->repository(DiscussionRepository::class)
				->getReadMarkingCutOff()
		)
			->where($discussionReadExpression)
			->where($groupReadExpression)
			->where($sectionReadExpression);

		return $this;
	}

	/**
	 * @param null $userId
	 *
	 * @return $this
	 */
	public function watchedOnly($userId = null): DiscussionFinder
	{
		if ($userId === null)
		{
			$userId = \XF::visitor()->user_id;
		}
		if (!$userId)
		{
			// no user, just ignore
			return $this;
		}

		$this->whereOr(
			['Watch|' . $userId . '.user_id', '!=', null],
			['Group.Watch|' . $userId . '.user_id', '!=', null],
			['Section.Watch|' . $userId . '.user_id', '!=', null]
		);

		return $this;
	}

	/**
	 * @param User|null $user
	 *
	 * @return $this
	 */
	public function skipIgnored(?User $user = null): DiscussionFinder
	{
		if (!$user)
		{
			$user = \XF::visitor();
		}

		if (!$user->user_id)
		{
			return $this;
		}

		if ($user->Profile && $user->Profile->ignored)
		{
			$this->where('user_id', '<>', array_keys($user->Profile->ignored));
		}

		return $this;
	}
}