<?php

/** @noinspection PhpFullyQualifiedNameUsageInspection */

namespace DBTech\SocialGroups\Finder;

use DBTech\SocialGroups\Entity\Group;
use XF\Entity\User;
use XF\Mvc\Entity\AbstractCollection;
use XF\Mvc\Entity\Finder;

/**
 * @method AbstractCollection<\DBTech\SocialGroups\Entity\GroupInvite> fetch(?int $limit = null, ?int $offset = null)
 * @method AbstractCollection<\DBTech\SocialGroups\Entity\GroupInvite> fetchDeferred(?int $limit = null, ?int $offset = null)
 * @method \DBTech\SocialGroups\Entity\GroupInvite|null fetchOne(?int $offset = null)
 * @extends Finder<\DBTech\SocialGroups\Entity\GroupInvite>
 */
class GroupInviteFinder extends Finder
{
	/**
	 * @return $this
	 */
	public function inGroup(Group $group): GroupInviteFinder
	{
		$this->where('group_id', $group->group_id);
		return $this;
	}

	/**
	 * @return $this
	 */
	public function forUser(User $user): GroupInviteFinder
	{
		$this->where('user_id', $user->user_id);
		return $this;
	}

	/**
	 * @return $this
	 */
	public function isValidGroup(): GroupInviteFinder
	{
		$this->where('Group.group_state', 'visible');
		return $this;
	}
}