<?php

/** @noinspection PhpFullyQualifiedNameUsageInspection */

namespace DBTech\SocialGroups\Finder;

use XF\Mvc\Entity\AbstractCollection;
use XF\Mvc\Entity\Finder;

/**
 * @method AbstractCollection<\DBTech\SocialGroups\Entity\DiscussionReplyBan> fetch(?int $limit = null, ?int $offset = null)
 * @method AbstractCollection<\DBTech\SocialGroups\Entity\DiscussionReplyBan> fetchDeferred(?int $limit = null, ?int $offset = null)
 * @method \DBTech\SocialGroups\Entity\DiscussionReplyBan|null fetchOne(?int $offset = null)
 * @extends Finder<\DBTech\SocialGroups\Entity\DiscussionReplyBan>
 */
class DiscussionReplyBanFinder extends Finder
{
}