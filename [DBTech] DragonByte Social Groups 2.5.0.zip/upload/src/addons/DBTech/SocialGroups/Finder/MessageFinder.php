<?php

/** @noinspection PhpFullyQualifiedNameUsageInspection */

namespace DBTech\SocialGroups\Finder;

use DBTech\SocialGroups\Entity\Discussion;
use XF\Entity\User;
use XF\Mvc\Entity\AbstractCollection;
use XF\Mvc\Entity\Finder;

use function intval;

/**
 * @method AbstractCollection<\DBTech\SocialGroups\Entity\Message> fetch(?int $limit = null, ?int $offset = null)
 * @method AbstractCollection<\DBTech\SocialGroups\Entity\Message> fetchDeferred(?int $limit = null, ?int $offset = null)
 * @method \DBTech\SocialGroups\Entity\Message|null fetchOne(?int $offset = null)
 * @extends Finder<\DBTech\SocialGroups\Entity\Message>
 */
class MessageFinder extends Finder
{
	/**
	 * @param Discussion $discussion
	 * @param array $limits
	 *
	 * @return $this
	 */
	public function inDiscussion(Discussion $discussion, array $limits = []): MessageFinder
	{
		$limits = array_replace([
			'visibility' => true,
			'allowOwnPending' => true,
		], $limits);

		$this->where('discussion_id', $discussion->discussion_id);

		if ($limits['visibility'])
		{
			$this->applyVisibilityChecksInDiscussion($discussion, $limits['allowOwnPending']);
		}

		return $this;
	}

	/**
	 * @param Discussion $discussion
	 * @param bool $allowOwnPending
	 *
	 * @return $this
	 */
	public function applyVisibilityChecksInDiscussion(
		Discussion $discussion,
		bool $allowOwnPending = true
	): MessageFinder
	{
		$conditions = [];
		$viewableStates = ['visible'];

		if ($discussion->canViewDeletedMessages())
		{
			$viewableStates[] = 'deleted';

			$this->with('DeletionLog');
		}

		$visitor = \XF::visitor();
		if ($discussion->canViewModeratedMessages())
		{
			$viewableStates[] = 'moderated';
		}
		else if ($visitor->user_id && $allowOwnPending)
		{
			$conditions[] = [
				'message_state' => 'moderated',
				'user_id' => $visitor->user_id,
			];
		}

		$conditions[] = ['message_state', $viewableStates];

		$this->whereOr($conditions);

		return $this;
	}

	/**
	 * @param int $page
	 * @param int|null $perPage
	 *
	 * @return $this
	 */
	public function onPage(int $page, ?int $perPage = null): MessageFinder
	{
		$page = max(1, $page);
		if ($perPage === null)
		{
			$perPage = \XF::app()->options()->messagesPerPage;
		}
		$perPage = max(1, intval($perPage));

		$start = ($page - 1) * $perPage;
		$end = $start + $perPage;

		$this->where('position', '>=', $start)->where('position', '<', $end);

		return $this;
	}

	/**
	 * @param int $date
	 *
	 * @return $this
	 */
	public function newerThan(int $date): MessageFinder
	{
		$this->where('message_date', '>', $date);

		return $this;
	}

	/**
	 * @param string $direction
	 *
	 * @return $this
	 */
	public function orderByDate(string $direction = 'ASC'): MessageFinder
	{
		$this->setDefaultOrder([
			['position', $direction],
			['message_date', $direction],
		]);

		return $this;
	}

	/**
	 * @param User|null $user
	 *
	 * @return $this
	 */
	public function skipIgnored(?User $user = null): MessageFinder
	{
		if (!$user)
		{
			$user = \XF::visitor();
		}

		if (!$user->user_id)
		{
			return $this;
		}

		if ($user->Profile && $user->Profile->ignored)
		{
			$this->where('user_id', '<>', array_keys($user->Profile->ignored));
		}

		return $this;
	}

	/**
	 * @return $this
	 */
	public function isNotFirstMessage(): MessageFinder
	{
		$this->where($this->expression(
			'%s <> %s',
			'Discussion.first_message_id',
			'message_id'
		));

		return $this;
	}
}