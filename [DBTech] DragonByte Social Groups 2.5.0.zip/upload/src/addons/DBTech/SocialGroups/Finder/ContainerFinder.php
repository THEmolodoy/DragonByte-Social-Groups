<?php

/** @noinspection PhpFullyQualifiedNameUsageInspection */

namespace DBTech\SocialGroups\Finder;

use XF\Mvc\Entity\AbstractCollection;
use XF\Mvc\Entity\Finder;

/**
 * @method AbstractCollection<\DBTech\SocialGroups\Entity\Container> fetch(?int $limit = null, ?int $offset = null)
 * @method AbstractCollection<\DBTech\SocialGroups\Entity\Container> fetchDeferred(?int $limit = null, ?int $offset = null)
 * @method \DBTech\SocialGroups\Entity\Container|null fetchOne(?int $offset = null)
 * @extends Finder<\DBTech\SocialGroups\Entity\Container>
 */
class ContainerFinder extends Finder
{
}