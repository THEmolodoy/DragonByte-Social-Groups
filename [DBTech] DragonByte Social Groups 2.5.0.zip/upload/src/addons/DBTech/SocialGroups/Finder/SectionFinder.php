<?php

/** @noinspection PhpUnnecessaryFullyQualifiedNameInspection,PhpFullyQualifiedNameUsageInspection */

namespace DBTech\SocialGroups\Finder;

use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Entity\Section;
use DBTech\SocialGroups\Repository\SectionRepository;
use XF\Mvc\Entity\AbstractCollection;
use XF\Mvc\Entity\Finder;

/**
 * @method AbstractCollection<\DBTech\SocialGroups\Entity\Section> fetch(?int $limit = null, ?int $offset = null)
 * @method AbstractCollection<\DBTech\SocialGroups\Entity\Section> fetchDeferred(?int $limit = null, ?int $offset = null)
 * @method \DBTech\SocialGroups\Entity\Section|null fetchOne(?int $offset = null)
 * @extends Finder<\DBTech\SocialGroups\Entity\Section>
 */
class SectionFinder extends Finder
{
	/**
	 * @param Group $group
	 * @param array $limits
	 *
	 * @return $this
	 */
	public function inGroup(Group $group, array $limits = []): SectionFinder
	{
		$limits = array_replace([
			'visibility' => true,
		], $limits);

		$this->where('group_id', $group->group_id);

		if ($limits['visibility'])
		{
			$visitor = \XF::visitor();
			if (!$visitor->is_staff && !$visitor->isSupervisorOfSocialGroup($group))
			{
				$this->where('staff_only', false);
			}
		}

		$this->setDefaultOrder('display_order');

		return $this;
	}

	/**
	 * @param Section $section
	 *
	 * @return $this
	 */
	public function descendantOf(Section $section): SectionFinder
	{
		$this->where('lft', '>', $section->lft)
			->where('rgt', '<', $section->rgt);

		return $this;
	}

	/**
	 * @param null $userId
	 *
	 * @return $this
	 */
	public function withReadData($userId = null): SectionFinder
	{
		if ($userId === null)
		{
			$userId = \XF::visitor()->user_id;
		}

		if ($userId)
		{
			$this->with([
				'Read|' . $userId,
			]);
		}

		return $this;
	}

	/**
	 * @param int|null $userId
	 *
	 * @return $this
	 */
	public function unreadOnly(?int $userId = null): SectionFinder
	{
		if ($userId === null)
		{
			$userId = \XF::visitor()->user_id;
		}
		if (!$userId)
		{
			// no user, no read tracking
			return $this;
		}

		$sectionReadExpression = $this->expression(
			'%s > COALESCE(%s, 0)',
			'last_message_date',
			'Read|' . $userId . '.section_read_date'
		);

		$this->where(
			'last_message_date',
			'>',
			\XF::app()->repository(SectionRepository::class)
				->getReadMarkingCutOff()
		)
			->where($sectionReadExpression);

		return $this;
	}

	/**
	 * @param null $userId
	 *
	 * @return $this
	 * @throws \InvalidArgumentException
	 */
	public function watchedOnly($userId = null): SectionFinder
	{
		if ($userId === null)
		{
			$userId = \XF::visitor()->user_id;
		}
		if (!$userId)
		{
			// no user, just ignore
			return $this;
		}

		$this->where('Watch|' . $userId . '.user_id', '!=', null);

		return $this;
	}

	/**
	 * @param string $match
	 * @param bool $caseSensitive
	 * @param bool $prefixMatch
	 * @param bool $exactMatch
	 *
	 * @return $this
	 */
	public function searchText(
		string $match,
		bool $caseSensitive = false,
		bool $prefixMatch = false,
		bool $exactMatch = false
	): SectionFinder
	{
		if ($match)
		{
			//			$expression = 'MasterTitle.phrase_text';
			$expression = 'title';
			if ($caseSensitive)
			{
				$expression = $this->expression('BINARY %s', $expression);
			}

			if ($exactMatch)
			{
				$this->where($expression, $match);
			}
			else
			{
				$this->where($expression, 'LIKE', $this->escapeLike($match, $prefixMatch ? '?%' : '%?%'));
			}
		}

		return $this;
	}

	/**
	 * @param string $direction
	 * @return $this
	 */
	public function orderTitle(string $direction = 'ASC'): SectionFinder
	{
		//		$expression = $this->columnUtf8('MasterTitle.phrase_text');
		$expression = $this->columnUtf8('title');
		$this->order($expression, $direction);

		return $this;
	}

	/**
	 * @return $this
	 * @throws \InvalidArgumentException
	 */
	public function useDefaultOrder(): SectionFinder
	{
		$defaultOrder = \XF::app()->options()->dbtechSocialListDefaultOrder ?: 'last_message_date';
		$defaultDir = $defaultOrder == 'title' ? 'asc' : 'desc';

		if ($defaultOrder == 'random')
		{
			$this->setDefaultOrder($this->expression('RAND()'));
			//			$this->setDefaultOrder([['featured', 'DESC'], $this->expression('RAND()')]);
		}
		else
		{
			$this->setDefaultOrder($defaultOrder, $defaultDir);
			//			$this->setDefaultOrder([['featured', 'DESC'], [$defaultOrder, $defaultDir]]);
		}

		return $this;
	}
}