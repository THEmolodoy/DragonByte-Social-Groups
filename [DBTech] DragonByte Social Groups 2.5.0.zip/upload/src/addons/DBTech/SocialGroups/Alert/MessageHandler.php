<?php

namespace DBTech\SocialGroups\Alert;

use DBTech\SocialGroups\Entity\Message;
use XF\Alert\AbstractHandler;

/**
 * @extends AbstractHandler<Message>
 */
class MessageHandler extends AbstractHandler
{
	public function getEntityWith(): array
	{
		$visitor = \XF::visitor();

		return [
			'Discussion',
			'Discussion.Group',
			'Discussion.Group.Permissions|' . $visitor->permission_combination_id,
		];
	}

	public function getOptOutActions(): array
	{
		return [
			'groupwatch_insert',
			'insert',
			'quote',
			'mention',
			'reaction',
		];
	}

	public function getOptOutDisplayOrder(): int
	{
		return 101;
	}
}