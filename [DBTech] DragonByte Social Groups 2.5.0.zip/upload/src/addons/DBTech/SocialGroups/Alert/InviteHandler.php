<?php

namespace DBTech\SocialGroups\Alert;

use DBTech\SocialGroups\Entity\GroupInvite;
use XF\Alert\AbstractHandler;

/**
 * @extends AbstractHandler<GroupInvite>
 */
class InviteHandler extends AbstractHandler
{
	public function getEntityWith(): array
	{
		$visitor = \XF::visitor();

		return [
			'Group',
			'Group.Permissions|' . $visitor->permission_combination_id,
		];
	}

	public function getOptOutDisplayOrder(): int
	{
		return 101;
	}
}