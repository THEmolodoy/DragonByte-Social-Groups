<?php

namespace DBTech\SocialGroups\Alert;

use DBTech\SocialGroups\Entity\Discussion;
use XF\Alert\AbstractHandler;

/**
 * @extends AbstractHandler<Discussion>
 */
class DiscussionHandler extends AbstractHandler
{
	public function getEntityWith(): array
	{
		$visitor = \XF::visitor();

		return ['Group', 'Group.Permissions|' . $visitor->permission_combination_id];
	}

	public function getOptOutDisplayOrder(): int
	{
		return 101;
	}
}