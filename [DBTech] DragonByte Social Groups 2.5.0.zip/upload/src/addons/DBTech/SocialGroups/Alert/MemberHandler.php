<?php

namespace DBTech\SocialGroups\Alert;

use DBTech\SocialGroups\Entity\GroupMember;
use XF\Alert\AbstractHandler;

/**
 * @extends AbstractHandler<GroupMember>
 */
class MemberHandler extends AbstractHandler
{
	public function getEntityWith(): array
	{
		$visitor = \XF::visitor();

		return [
			'User',
			'Group',
			'Group.Permissions|' . $visitor->permission_combination_id,
		];
	}

	public function getOptOutDisplayOrder(): int
	{
		return 101;
	}
}