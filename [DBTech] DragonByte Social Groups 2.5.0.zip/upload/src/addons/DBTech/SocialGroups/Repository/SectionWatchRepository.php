<?php

namespace DBTech\SocialGroups\Repository;

use DBTech\SocialGroups\Entity\Section;
use DBTech\SocialGroups\Entity\SectionWatch;
use XF\Entity\User;
use XF\Mvc\Entity\Repository;
use XF\PrintableException;

class SectionWatchRepository extends Repository
{
	/**
	 * @param Section $section
	 * @param User $user
	 * @param string|null $notifyType
	 * @param bool|null $sendAlert
	 * @param bool|null $sendEmail
	 *
	 * @throws PrintableException
	 */
	public function setWatchState(
		Section $section,
		User $user,
		?string $notifyType = null,
		?bool $sendAlert = null,
		?bool $sendEmail = null
	): void
	{
		if (!$section->section_id || !$user->user_id)
		{
			throw new \InvalidArgumentException("Invalid social group or user");
		}

		$watch = \XF::app()->em()->find(SectionWatch::class, [
			'section_id' => $section->section_id,
			'user_id' => $user->user_id,
		]);

		switch ($notifyType)
		{
			case 'message':
			case 'discussion':
			case '':
			case null:
				if (!$watch)
				{
					$watch = \XF::app()->em()->create(SectionWatch::class);
					$watch->section_id = $section->section_id;
					$watch->user_id = $user->user_id;
				}
				if ($notifyType !== null)
				{
					$watch->notify_on = $notifyType;
				}
				if ($sendAlert !== null)
				{
					$watch->send_alert = $sendAlert;
				}
				if ($sendEmail !== null)
				{
					$watch->send_email = $sendEmail;
				}
				$watch->save();
				break;

			case 'delete':
				if ($watch)
				{
					$watch->delete();
				}
				break;

			default:
				throw new \InvalidArgumentException("Unknown notify type '$notifyType'");
		}
	}

	/**
	 * @param User $user
	 * @param string $state
	 *
	 * @return int
	 */
	public function setWatchStateForAll(User $user, string $state): int
	{
		if (!$user->user_id)
		{
			throw new \InvalidArgumentException("Invalid user");
		}

		$db = $this->db();

		return match ($state)
		{
			'watch_email', 'email' => $db->update(
				'xf_dbtech_social_groups_section_watch',
				['send_email' => 1],
				'user_id = ?',
				$user->user_id
			),
			'watch_no_email', 'no_email' => $db->update(
				'xf_dbtech_social_groups_section_watch',
				['send_email' => 0],
				'user_id = ?',
				$user->user_id
			),
			'watch_alert', 'alert' => $db->update(
				'xf_dbtech_social_groups_section_watch',
				['send_alert' => 1],
				'user_id = ?',
				$user->user_id
			),
			'watch_no_alert', 'no_alert' => $db->update(
				'xf_dbtech_social_groups_section_watch',
				['send_alert' => 0],
				'user_id = ?',
				$user->user_id
			),
			'delete', 'stop', '' => $db->delete(
				'xf_dbtech_social_groups_section_watch',
				'user_id = ?',
				$user->user_id
			),
			default => throw new \InvalidArgumentException("Unknown state '$state'"),
		};
	}

	/**
	 * @param string $state
	 *
	 * @return bool
	 */
	public function isValidWatchState(string $state): bool
	{
		return match ($state)
		{
			'watch_email', 'email', 'watch_no_email', 'no_email', 'watch_alert', 'alert', 'watch_no_alert', 'no_alert', 'delete', 'stop', '' => true,
			default => false,
		};
	}
}