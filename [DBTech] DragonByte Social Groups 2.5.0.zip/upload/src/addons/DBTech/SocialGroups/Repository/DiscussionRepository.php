<?php

namespace DBTech\SocialGroups\Repository;

use DBTech\SocialGroups\Entity\Discussion;
use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Entity\Section;
use DBTech\SocialGroups\Finder\DiscussionFinder;
use XF\Db\DeadlockException;
use XF\Db\Exception as DbException;
use XF\Entity\User;
use XF\Mvc\Entity\Repository;
use XF\Repository\ActivityLogRepository;
use XF\Repository\UserAlertRepository;

class DiscussionRepository extends Repository
{
	/**
	 * @param Group $group
	 * @param array $limits
	 *
	 * @return DiscussionFinder
	 */
	public function findDiscussionsForGroupView(
		Group $group,
		array $limits = []
	): DiscussionFinder
	{
		return \XF::app()->finder(DiscussionFinder::class)
			->inGroup($group, $limits)
			->with('full')
		;
	}

	/**
	 * @param Group|null $group
	 *
	 * @return DiscussionFinder
	 */
	public function findDiscussionsForRssFeed(
		?Group $group = null
	): DiscussionFinder
	{
		$finder = \XF::app()->finder(DiscussionFinder::class);

		$finder->where('discussion_state', 'visible')
			->setDefaultOrder('last_message_date', 'DESC')
			->where('discussion_type', '!=', 'redirect')
			->with(['Group', 'User', 'FirstMessage']);

		if ($group)
		{
			$finder->where('group_id', $group->group_id);
		}
		else
		{
			$finder->where('Group.find_new', 1)
				->where('last_message_date', '>', $this->getReadMarkingCutOff());
		}

		return $finder;
	}

	/**
	 * @param Section|null $section
	 *
	 * @return DiscussionFinder
	 */
	public function findDiscussionsForSectionRssFeed(
		?Section $section = null
	): DiscussionFinder
	{
		$finder = \XF::app()->finder(DiscussionFinder::class)
			->where('discussion_state', 'visible')
			->setDefaultOrder('last_message_date', 'DESC')
			->where('discussion_type', '!=', 'redirect')
			->with(['Group', 'User', 'FirstMessage']);

		if ($section)
		{
			$finder->where('section_id', $section->section_id);
		}
		else
		{
			$finder->where('Group.find_new', 1)
				->where('last_message_date', '>', $this->getReadMarkingCutOff());
		}

		return $finder;
	}

	/**
	 * @param bool|false $unreadOnly
	 *
	 * @return DiscussionFinder
	 */
	public function findDiscussionsForWatchedList(bool $unreadOnly = false): DiscussionFinder
	{
		$visitor = \XF::visitor();
		$userId = $visitor->user_id;

		$finder = \XF::app()->finder(DiscussionFinder::class)
			->with('fullGroup')
			->with('Watch|' . $userId, true)
			->where('discussion_state', 'visible')
			->setDefaultOrder('last_message_date', 'DESC');

		if ($unreadOnly)
		{
			$finder->unreadOnly($userId);
		}

		return $finder;
	}

	/**
	 * @param int $userId
	 *
	 * @return DiscussionFinder
	 */
	public function findDiscussionsStartedByUser(int $userId): DiscussionFinder
	{
		return \XF::app()->finder(DiscussionFinder::class)
			->with('fullGroup')
			->with(['Group', 'User'])
			->where('user_id', $userId)
			->where('discussion_type', '<>', 'redirect')
			->setDefaultOrder('last_message_date', 'DESC')
		;
	}

	/**
	 * @param int $userId
	 *
	 * @return DiscussionFinder
	 */
	public function findDiscussionsWithMessagesByUser(int $userId): DiscussionFinder
	{
		return \XF::app()->finder(DiscussionFinder::class)
			->with('fullGroup')
			->with(['Group', 'User'])
			->exists('UserMessages|' . $userId)
			->where('discussion_type', '<>', 'redirect')
			->setDefaultOrder('last_message_date', 'DESC')
		;
	}

	/**
	 * @return DiscussionFinder
	 */
	public function findDiscussionsWithNoReplies(): DiscussionFinder
	{
		return \XF::app()->finder(DiscussionFinder::class)
			->with('fullGroup')
			->with(['Group', 'User'])
			->where('reply_count', 0)
			->where('discussion_type', '<>', 'redirect')
			->where('last_message_date', '>', $this->getReadMarkingCutOff()) // for performance reasons
			->order('last_message_date', 'DESC')
			->indexHint('FORCE', 'last_message_date')
		;
	}

	/**
	 * @return DiscussionFinder
	 */
	public function findLatestDiscussions(): DiscussionFinder
	{
		return \XF::app()->finder(DiscussionFinder::class)
			->with(['Group', 'User'])
			->where('discussion_state', 'visible')
			->where('discussion_type', '<>', 'redirect')
			->order('message_date', 'DESC')
		;
	}

	/**
	 * @param bool $includeReadMarkingCutOff
	 *
	 * @return DiscussionFinder
	 */
	public function findDiscussionsWithLatestMessages(bool $includeReadMarkingCutOff = true): DiscussionFinder
	{
		$discussionFinder = \XF::app()->finder(DiscussionFinder::class)
			->with(['Group', 'User'])
			->where('Group.find_new', true)
			->where('discussion_state', 'visible')
			->where('discussion_type', '<>', 'redirect')
			->order('last_message_date', 'DESC')
			->indexHint('FORCE', 'last_message_date');

		if ($includeReadMarkingCutOff)
		{
			$discussionFinder->where('last_message_date', '>', $this->getReadMarkingCutOff());
		}

		return $discussionFinder;
	}

	/**
	 * @param int|null $userId
	 *
	 * @return DiscussionFinder
	 */
	public function findDiscussionsWithUnreadMessages(?int $userId = null): DiscussionFinder
	{
		$discussionFinder = $this->findDiscussionsWithLatestMessages();

		$userId = $userId ?: \XF::visitor()->user_id;

		if (!$userId)
		{
			return $discussionFinder;
		}

		return $discussionFinder->unreadOnly($userId);
	}

	/**
	 * @param Group|null $group If provided, applies group-specific limits
	 *
	 * @return DiscussionFinder
	 */
	public function findDiscussionsForApi(
		?Group $group = null
	): DiscussionFinder
	{
		$discussionFinder = \XF::app()->finder(DiscussionFinder::class)
			->with('api')
			->where('discussion_type', '!=', 'redirect');

		if ($group)
		{
			$limits = [];
			if (\XF::isApiBypassingPermissions())
			{
				$limits['visibility'] = false;
			}

			$discussionFinder->inGroup($group, $limits);
		}
		else
		{
			$discussionFinder->where('Group.find_new', 1)
				->setDefaultOrder('last_message_date', 'DESC');

			if (\XF::isApiCheckingPermissions())
			{
				$groups = \XF::app()->repository(GroupRepository::class)->getViewableGroups();
				$discussionFinder->where('group_id', $groups->keys())
					->where('discussion_state', 'visible');
			}
		}

		return $discussionFinder;
	}

	/**
	 * @param Discussion $discussion
	 *
	 * @throws DbException
	 */
	public function logDiscussionView(Discussion $discussion): void
	{
		$this->db()->query("
			-- XFDB=noForceAllWrite
			INSERT INTO xf_dbtech_social_groups_discussion_view
				(discussion_id, total)
			VALUES
				(? , 1)
			ON DUPLICATE KEY UPDATE
				total = total + 1
		", $discussion->discussion_id);
	}

	/**
	 * @throws DbException
	 */
	public function batchUpdateDiscussionViews(): void
	{
		$db = $this->db();
		$db->query("
			UPDATE xf_dbtech_social_groups_discussion AS t
			INNER JOIN xf_dbtech_social_groups_discussion_view AS tv ON (t.discussion_id = tv.discussion_id)
			SET t.view_count = t.view_count + tv.total
		");

		$viewMetrics = $db->fetchAll(
			'SELECT discussion.discussion_id AS content_id,
					discussion.message_date AS content_date,
					discussion.group_id AS content_container_id,
					discussion_view.total AS view_count
				FROM xf_dbtech_social_groups_discussion_view AS discussion_view
				INNER JOIN xf_dbtech_social_groups_discussion AS discussion
					ON (discussion.discussion_id = discussion_view.discussion_id)'
		);
		foreach ($viewMetrics AS &$viewMetric)
		{
			$viewMetric['log_date'] = \XF::$time;
		}

		$activityLogRepo = \XF::repository(ActivityLogRepository::class);
		$activityLogRepo->bulkLog('dbtech_social_discussion', $viewMetrics);

		$db->emptyTable('xf_dbtech_social_groups_discussion_view');
	}

	/**
	 * @param Discussion $discussion
	 * @param User $user
	 * @param int|null $newRead
	 *
	 * @return bool
	 * @throws DeadlockException
	 */
	public function markDiscussionReadByUser(
		Discussion $discussion,
		User $user,
		?int $newRead = null
	): bool
	{
		if (!$user->user_id)
		{
			return false;
		}

		if ($newRead === null)
		{
			$newRead = max(\XF::$time, $discussion->last_message_date);
		}

		$cutOff = $this->getReadMarkingCutOff();
		if ($newRead <= $cutOff)
		{
			return false;
		}

		$readDate = $discussion->getUserReadDate($user);
		if ($newRead <= $readDate)
		{
			return false;
		}

		$this->db()->insert('xf_dbtech_social_groups_discussion_read', [
			'discussion_id' => $discussion->discussion_id,
			'user_id' => $user->user_id,
			'discussion_read_date' => $newRead,
		], false, 'discussion_read_date = VALUES(discussion_read_date)');

		if ($newRead < $discussion->last_message_date)
		{
			// discussion not fully viewed
			return false;
		}

		if ($discussion->Group && !$this->countUnreadDiscussionsInGroupForUser($discussion->Group, $user))
		{
			\XF::app()->repository(GroupRepository::class)
				->markGroupReadByUser($discussion->Group, $user->user_id)
			;
		}

		if ($discussion->Section && !$this->countUnreadDiscussionsInSectionForUser($discussion->Section, $user))
		{
			\XF::app()->repository(SectionRepository::class)
				->markSectionReadByUser($discussion->Section, $user->user_id)
			;
		}

		return true;
	}

	/**
	 * @param Discussion $discussion
	 * @param int|null $newRead
	 *
	 * @return bool
	 * @throws DeadlockException
	 */
	public function markDiscussionReadByVisitor(
		Discussion $discussion,
		?int $newRead = null
	): bool
	{
		$visitor = \XF::visitor();
		return $this->markDiscussionReadByUser($discussion, $visitor, $newRead);
	}

	/**
	 * @param int|null $cutOff
	 */
	public function pruneDiscussionReadLogs(?int $cutOff = null): void
	{
		if ($cutOff === null)
		{
			$cutOff = $this->getReadMarkingCutOff();
		}

		$this->db()->delete(
			'xf_dbtech_social_groups_discussion_read',
			'discussion_read_date < ?',
			$cutOff
		);
	}

	/**
	 * @param Group $group
	 * @param User $user
	 *
	 * @return int
	 */
	public function countUnreadDiscussionsInGroupForUser(
		Group $group,
		User $user
	): int
	{
		$userId = $user->user_id;
		if (!$userId)
		{
			return 0;
		}

		$read = $group->Read[$userId];
		$cutOff = $this->getReadMarkingCutOff();

		$readDate = $read ? max($read->group_read_date, $cutOff) : $cutOff;

		$finder = \XF::app()->finder(DiscussionFinder::class);
		$finder
			->where('group_id', $group->group_id)
			->where('last_message_date', '>', $readDate)
			->where('discussion_state', 'visible')
			->where('discussion_type', '<>', 'redirect')
			->whereOr(
				['Read|' . $userId . '.discussion_id', null],
				[$finder->expression('%s > %s', 'last_message_date', 'Read|' . $userId . '.discussion_read_date')]
			)
			->skipIgnored();

		return $finder->total();
	}

	/**
	 * @param Section $section
	 * @param User $user
	 *
	 * @return int
	 */
	public function countUnreadDiscussionsInSectionForUser(
		Section $section,
		User $user
	): int
	{
		$userId = $user->user_id;
		if (!$userId)
		{
			return 0;
		}

		$read = $section->Read[$userId];
		$cutOff = $this->getReadMarkingCutOff();

		$readDate = $read ? max($read->section_read_date, $cutOff) : $cutOff;

		$finder = \XF::app()->finder(DiscussionFinder::class);
		$finder
			->where('section_id', $section->section_id)
			->where('last_message_date', '>', $readDate)
			->where('discussion_state', 'visible')
			->where('discussion_type', '<>', 'redirect')
			->whereOr(
				['Read|' . $userId . '.discussion_id', null],
				[$finder->expression('%s > %s', 'last_message_date', 'Read|' . $userId . '.discussion_read_date')]
			)
			->skipIgnored();

		return $finder->total();
	}

	/**
	 * @param Group $group
	 *
	 * @return int
	 */
	public function countUnreadDiscussionsInGroup(Group $group): int
	{
		$visitor = \XF::visitor();
		return $this->countUnreadDiscussionsInGroupForUser($group, $visitor);
	}

	/**
	 * @param Section $section
	 *
	 * @return int
	 */
	public function countUnreadDiscussionsInSection(Section $section): int
	{
		$visitor = \XF::visitor();
		return $this->countUnreadDiscussionsInSectionForUser($section, $visitor);
	}

	/**
	 * @return int
	 */
	public function getReadMarkingCutOff(): int
	{
		return \XF::$time - \XF::app()->options()->readMarkingDataLifetime * 86400;
	}

	/**
	 * @param int $discussionId
	 *
	 * @throws DbException
	 */
	public function rebuildDiscussionUserMessageCounters(int $discussionId): void
	{
		$db = $this->db();

		$db->beginTransaction();
		$db->delete('xf_dbtech_social_groups_discussion_user_message', 'discussion_id = ?', $discussionId);
		$db->query("
			INSERT INTO xf_dbtech_social_groups_discussion_user_message (discussion_id, user_id, message_count)
			SELECT discussion_id, user_id, COUNT(*)
			FROM xf_dbtech_social_groups_message
			WHERE discussion_id = ?
				AND message_state = 'visible'
				AND user_id > 0
			GROUP BY user_id
		", $discussionId);
		$db->commit();
	}

	/**
	 * @param int $discussionId
	 *
	 * @throws DbException
	 */
	public function rebuildDiscussionMessagePositions(int $discussionId): void
	{
		$db = $this->db();
		$db->query('SET @position := -1');
		$db->query("
			UPDATE xf_dbtech_social_groups_message
			SET position = (@position := IF(message_state = 'visible', @position + 1, GREATEST(@position, 0)))
			WHERE discussion_id = ?
			ORDER BY message_date, message_id
		", $discussionId);
	}

	/**
	 * @param Discussion $discussion
	 * @param string $action
	 * @param string $reason
	 * @param array $extra
	 *
	 * @return bool
	 */
	public function sendModeratorActionAlert(
		Discussion $discussion,
		string $action,
		string $reason = '',
		array $extra = []
	): bool
	{
		if (!$discussion->user_id || !$discussion->User)
		{
			return false;
		}

		$extra = array_merge([
			'title' => $discussion->title,
			'group' => $discussion->Group ? $discussion->Group->title : '',
			//			'prefix_id' => $discussion->prefix_id,
			'link' => \XF::app()->router('public')->buildLink('nopath:dbtech-social/discussions', $discussion),
			'reason' => $reason,
		], $extra);

		\XF::app()->repository(UserAlertRepository::class)
			->alert(
				$discussion->User,
				0,
				'',
				'user',
				$discussion->user_id,
				"dbt_soc_disc_" . $action,
				$extra
			)
		;

		return true;
	}

	/**
	 * @param string $url
	 * @param string|null $type
	 * @param $error
	 *
	 * @return Discussion|null
	 */
	public function getDiscussionFromUrl(
		string $url,
		?string $type = null,
		&$error = null
	): ?Discussion
	{
		$routePath = \XF::app()->request()->getRoutePathFromUrl($url);
		$routeMatch = \XF::app()->router($type)->routeToController($routePath);
		$params = $routeMatch->getParameterBag();

		if (!$params->discussion_id)
		{
			$error = \XF::phrase('dbtech_social_groups_no_discussion_id_could_be_found_from_that_url');
			return null;
		}

		$discussion = \XF::app()->em()->find(Discussion::class, $params->discussion_id);
		if (!$discussion)
		{
			$error = \XF::phrase(
				'dbtech_social_groups_no_discussion_could_be_found_with_id_x',
				['discussion_id' => $params->discussion_id]
			);
			return null;
		}

		return $discussion;
	}

	/**
	 * Returns a map of keys -> discussion entity columns.
	 *
	 * Printable version of the keys are expected to exist as phrases in the form "group_sort.$key".
	 * For example: group_sort.last_message_date
	 *
	 * @param bool $forAdminConfig If true, this is called in the context of the admin configuring a group default sort
	 *
	 * @return array
	 */
	public function getDefaultDiscussionListSortOptions(bool $forAdminConfig): array
	{
		$options = [
			'last_message_date' => 'last_message_date',
			'message_date' => 'message_date',
			'title' => 'title',
			'reply_count' => 'reply_count',
			'view_count' => 'view_count',
			'first_message_reaction_score' => 'first_message_reaction_score',
		];

		if ($forAdminConfig)
		{
			unset($options['view_count'], $options['first_message_reaction_score']);
		}

		return $options;
	}

	/**
	 * Returns a map of keys -> discussion entity columns.
	 *
	 * Printable version of the keys are expected to exist as phrases in the form "discussion_sort.$key".
	 * For example: discussion_sort.message_date
	 *
	 * @return array
	 */
	public function getDefaultMessageListSortOptions(): array
	{
		return [
			'message_date' => [
				['position', 'ASC'],
				['message_date', 'ASC'],
			],
		];
	}
}