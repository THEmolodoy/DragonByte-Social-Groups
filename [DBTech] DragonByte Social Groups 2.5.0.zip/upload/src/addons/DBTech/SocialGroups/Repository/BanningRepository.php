<?php

namespace DBTech\SocialGroups\Repository;

use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Entity\GroupBan;
use DBTech\SocialGroups\Entity\GroupMember;
use DBTech\SocialGroups\Finder\GroupBanFinder;
use DBTech\SocialGroups\Job\GroupActionCleanUp;
use XF\Db\DuplicateKeyException;
use XF\Entity\User;
use XF\Mvc\Entity\Repository;
use XF\PrintableException;
use XF\Service\UpdatePermissionsService;

use function time;

class BanningRepository extends Repository
{
	/**
	 * @param Group $group
	 *
	 * @return GroupBanFinder
	 */
	public function findGroupBansForList(Group $group): GroupBanFinder
	{
		return \XF::app()->finder(GroupBanFinder::class)
			->with('User')
			->inGroup($group)
			->setDefaultOrder([['ban_date', 'DESC'], ['User.username']]);
	}

	/**
	 * @param User $user
	 * @param Group $group
	 * @param int $endDate
	 * @param string $reason
	 * @param mixed|null $error
	 * @param User|null $banBy
	 *
	 * @return bool
	 * @throws PrintableException
	 * @noinspection PhpRedundantCatchClauseInspection
	 */
	public function banUserFromGroup(
		User                   $user,
		Group $group,
		int                               $endDate,
		string                            $reason,
		mixed                             &$error = null,
		?User $banBy = null
	): bool
	{
		if ($endDate < time() && $endDate !== 0)
		{ // 0 === permanent
			$error = \XF::phraseDeferred('please_enter_a_date_in_the_future');
			return false;
		}

		$banBy = $banBy ?: \XF::visitor();

		$groupBan = \XF::app()->em()->find(GroupBan::class, [
			'user_id' => $user->user_id,
			'group_id' => $group->group_id,
		]);
		if (!$groupBan)
		{
			$groupBan = \XF::app()->em()->create(GroupBan::class);
			$groupBan->user_id = $user->user_id;
			$groupBan->group_id = $group->group_id;
		}

		$isNewBan = $groupBan->isInsert();

		if ($isNewBan)
		{
			if ($banBy !== \XF::visitor())
			{
				// This would only happen in a controlled environment such as CLI
				$groupBan->setOption('admin_edit', true);
			}

			$groupBan->ban_user_id = $banBy->user_id;
		}

		$groupBan->end_date = $endDate;
		if ($groupBan->isChanged('end_date'))
		{
			$groupBan->triggered = false;
		}
		$groupBan->user_reason = $reason;

		if (!$groupBan->preSave())
		{
			$errors = $groupBan->getErrors();
			$error = reset($errors);
			return false;
		}

		try
		{
			$groupBan->save(false);
		}
		catch (DuplicateKeyException $e)
		{
		} // likely a race condition, keep the old value and accept

		if ($isNewBan)
		{
			if (\XF::app()->options()->dbtechSocialMediaGalleryBanAction === 'unlink')
			{
				\XF::app()->jobManager()->enqueue(
					GroupActionCleanUp::class,
					[
						'groupId' => $group->group_id,
						'title' => $group->title,
						'userId' => $user->user_id,
					]
				);
			}

			// Clean up pending invites
			$this->db()->delete(
				'xf_dbtech_social_groups_group_invite',
				'group_id = ? AND user_id = ?',
				[$group->group_id, $user->user_id]
			);
		}

		/** @var GroupMember $groupMember */
		$groupMember = $groupBan->GroupMember;
		if ($groupMember)
		{
			if ($reason)
			{
				\XF::app()->repository(GroupMemberRepository::class)
					->logAction($groupMember, 'ban_reason', [
						'reason' => $reason,
					], \XF::visitor())
				;
			}
			else
			{
				\XF::app()->repository(GroupMemberRepository::class)
					->logAction($groupMember, 'ban', [], \XF::visitor())
				;
			}

			\XF::app()->repository(GroupRepository::class)
				->sendModeratorActionAlert(
					$group,
					'ban',
					$reason,
					['expiry' => $endDate],
					$user
				);
		}

		return true;
	}

	/**
	 * @param int|null $cutOff
	 *
	 * @return void
	 * @throws PrintableException
	 */
	public function deleteExpiredGroupBans(?int $cutOff = null): void
	{
		foreach ($this->findExpiredGroupBans($cutOff)->fetch() AS $groupBan)
		{
			/** @var GroupBan $groupBan */

			/** @var GroupMember $groupMember */
			$groupMember = $groupBan->GroupMember;
			if ($groupMember)
			{
				\XF::app()->repository(GroupMemberRepository::class)
					->logAction($groupMember, 'unban', [], \XF::visitor())
				;
			}

			\XF::app()->repository(GroupRepository::class)
				->sendModeratorActionAlert(
					$groupBan->Group,
					'unban',
					'',
					[],
					$groupBan->User
				)
			;

			$groupBan->delete();
		}
	}

	/**
	 * @param int|null $cutOff
	 *
	 * @return GroupBanFinder
	 */
	public function findExpiredGroupBans(?int $cutOff = null): GroupBanFinder
	{
		if ($cutOff === null)
		{
			$cutOff = time();
		}

		return \XF::app()->finder(GroupBanFinder::class)
			->where('end_date', '>', 0)
			->where('end_date', '<=', $cutOff);
	}

	/**
	 * @param Group $group
	 * @param User $user
	 *
	 * @return void
	 */
	public function applyGroupBanPermissionsToUser(Group $group, User $user): void
	{
		$permissionUpdater = \XF::app()->service(UpdatePermissionsService::class);
		$permissionUpdater->setUser($user);
		$permissionUpdater->setContent('dbtech_social_group', $group->group_id);
		$permissionUpdater->updatePermissions([
			'dbtechSocial' => [
				'viewGroup' => 'deny',
			],
		]);
	}

	/**
	 * @param Group $group
	 * @param User $user
	 *
	 * @return void
	 */
	public function removeGroupBanPermissionsFromUser(Group $group, User $user): void
	{
		$permissionUpdater = \XF::app()->service(UpdatePermissionsService::class);
		$permissionUpdater->setUser($user);
		$permissionUpdater->setContent('dbtech_social_group', $group->group_id);
		$permissionUpdater->updatePermissions([
			'dbtechSocial' => [
				'viewGroup' => 'unset',
			],
		]);
	}
}