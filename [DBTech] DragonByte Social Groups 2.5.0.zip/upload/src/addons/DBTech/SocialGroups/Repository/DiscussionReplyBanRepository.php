<?php

namespace DBTech\SocialGroups\Repository;

use DBTech\SocialGroups\Entity\Discussion;
use DBTech\SocialGroups\Finder\DiscussionReplyBanFinder;
use XF\Mvc\Entity\Repository;

class DiscussionReplyBanRepository extends Repository
{
	/**
	 * @return DiscussionReplyBanFinder
	 */
	public function findReplyBansForList(): DiscussionReplyBanFinder
	{
		return \XF::app()->finder(DiscussionReplyBanFinder::class)
			->setDefaultOrder('ban_date', 'DESC')
			->with('Discussion', true);
	}

	/**
	 * @param Discussion $discussion
	 *
	 * @return DiscussionReplyBanFinder
	 */
	public function findReplyBansForDiscussion(
		Discussion $discussion
	): DiscussionReplyBanFinder
	{
		return $this->findReplyBansForList()
			->where('discussion_id', $discussion->discussion_id)
			->with(['User', 'BannedBy']);
	}

	/**
	 * @param int|null $cutOff
	 */
	public function cleanUpExpiredBans(?int $cutOff = null): void
	{
		if ($cutOff === null)
		{
			$cutOff = time();
		}
		$this->db()->delete(
			'xf_dbtech_social_groups_discussion_reply_ban',
			'expiry_date > 0 AND expiry_date < ?',
			$cutOff
		);
	}
}