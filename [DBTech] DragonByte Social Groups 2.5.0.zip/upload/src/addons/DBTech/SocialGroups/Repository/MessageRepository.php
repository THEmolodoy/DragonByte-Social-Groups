<?php

namespace DBTech\SocialGroups\Repository;

use DBTech\SocialGroups\Entity\Discussion;
use DBTech\SocialGroups\Entity\Message;
use DBTech\SocialGroups\Finder\MessageFinder;
use XF\Mvc\Entity\Repository;
use XF\Repository\UserAlertRepository;

class MessageRepository extends Repository
{
	/**
	 * @param Discussion $discussion
	 * @param array $limits
	 *
	 * @return MessageFinder
	 */
	public function findMessagesForDiscussionView(
		Discussion $discussion,
		array $limits = []
	): MessageFinder
	{
		return \XF::app()->finder(MessageFinder::class)
			->inDiscussion($discussion, $limits)
			->orderByDate()
			->with('full');
	}

	/**
	 * @param Discussion $discussion
	 * @param array $messageIds
	 * @param array $limits
	 *
	 * @return MessageFinder
	 */
	public function findSpecificMessagesForDiscussionView(
		Discussion $discussion,
		array $messageIds,
		array $limits = []
	): MessageFinder
	{
		return \XF::app()->finder(MessageFinder::class)
			->inDiscussion($discussion, $limits)
			->where('message_id', $messageIds)
			->with('full')
		;
	}

	/**
	 * @param Discussion $discussion
	 * @param int $newerThan
	 * @param array $limits
	 *
	 * @return MessageFinder
	 */
	public function findNewestMessagesInDiscussion(
		Discussion $discussion,
		int $newerThan,
		array $limits = []
	): MessageFinder
	{
		return \XF::app()->finder(MessageFinder::class)
			->inDiscussion($discussion, $limits)
			->order(['message_date', 'message_id'], 'DESC')
			->newerThan($newerThan);
	}

	/**
	 * @param Discussion $discussion
	 * @param int $newerThan
	 * @param array $limits
	 *
	 * @return MessageFinder
	 */
	public function findNextMessagesInDiscussion(
		Discussion $discussion,
		int $newerThan,
		array $limits = []
	): MessageFinder
	{
		return \XF::app()->finder(MessageFinder::class)
			->inDiscussion($discussion, $limits)
			->order(['message_date', 'message_id'])
			->newerThan($newerThan);
	}

	/**
	 * @param Message $message
	 * @param string $action
	 * @param string $reason
	 * @param array $extra
	 *
	 * @return bool
	 */
	public function sendModeratorActionAlert(
		Message $message,
		string $action,
		string $reason = '',
		array $extra = []
	): bool
	{
		if (!$message->user_id || !$message->User)
		{
			return false;
		}

		$extra = array_merge([
			'title' => $message->Discussion->title,
			'group' => $message->Discussion->Group ? $message->Discussion->Group->title : '',
			//			'prefix_id' => $message->Discussion->prefix_id,
			'link' => $this->app()
				->router('public')
				->buildLink('nopath:dbtech-social/messages', $message)
			,
			'discussionLink' => $this->app()
				->router('public')
				->buildLink('nopath:dbtech-social/discussions', $message->Discussion)
			,
			'reason' => $reason,
		], $extra);

		\XF::app()->repository(UserAlertRepository::class)
			->alert(
				$message->User,
				0,
				'',
				'user',
				$message->user_id,
				"dbt_soc_msg_$action",
				$extra
			)
		;

		return true;
	}
}