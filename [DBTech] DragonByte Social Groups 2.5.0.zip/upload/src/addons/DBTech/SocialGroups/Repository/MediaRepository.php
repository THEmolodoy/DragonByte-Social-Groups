<?php

namespace DBTech\SocialGroups\Repository;

use DBTech\SocialGroups\Entity\Group;
use XF\Mvc\Entity\Repository;
use XFMG\Finder\MediaItem;
use XFMG\Repository\Category;

use function in_array, is_array;

class MediaRepository extends Repository
{
	/**
	 * @param Group $group
	 *
	 * @return MediaItem
	 */
	public function findMediaInGroupForWidget(Group $group): MediaItem
	{
		return \XF::app()->finder(MediaItem::class)
			->with('Album.SocialGroupAlbum', true)
			->where('Album.SocialGroupAlbum.group_id', $group->group_id)
			->where('media_state', 'visible')
		;
	}

	/**
	 * @param bool $includeEmpty
	 * @param string|string[]|null $enableTypes
	 * @param string|null $type
	 * @param bool $checkPerms
	 *
	 * @return array|array[]
	 */
	public function getCategoryOptionsData(
		bool              $includeEmpty = true,
		array|string|null $enableTypes = null,
		?string           $type = null,
		bool              $checkPerms = false
	): array
	{
		$choices = [];
		if ($includeEmpty)
		{
			$choices = [
				0 => ['_type' => 'option', 'value' => 0, 'label' => \XF::phrase('(none)')],
			];
		}

		$categoryRepo = \XF::app()->repository(Category::class);
		$categories = $categoryRepo->findCategoryList()->fetch();

		if ($checkPerms)
		{
			$categories = $categories->filterViewable();
		}

		foreach ($categoryRepo->createCategoryTree($categories)->getFlattened() AS $entry)
		{
			/** @var \XFMG\Entity\Category $category */
			$category = $entry['record'];

			if ($entry['depth'])
			{
				$prefix = str_repeat('--', $entry['depth']) . ' ';
			}
			else
			{
				$prefix = '';
			}

			$choices[$category->category_id] = [
				'value' => $category->category_id,
				'label' => $prefix . $category->title,
			];
			if ($enableTypes !== null)
			{
				if (!is_array($enableTypes))
				{
					$enableTypes = [$enableTypes];
				}
				$choices[$category->category_id]['disabled'] = in_array($category->category_type, $enableTypes)
					? false
					: 'disabled'
				;
			}
			if ($type !== null)
			{
				$choices[$category->category_id]['_type'] = $type;
			}
		}

		return $choices;
	}
}