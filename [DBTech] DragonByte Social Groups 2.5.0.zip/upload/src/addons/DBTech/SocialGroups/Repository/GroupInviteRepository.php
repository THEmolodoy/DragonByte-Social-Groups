<?php

namespace DBTech\SocialGroups\Repository;

use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Entity\GroupInvite;
use DBTech\SocialGroups\Finder\GroupInviteFinder;
use XF\Entity\User;
use XF\Mvc\Entity\Repository;
use XF\PrintableException;
use XF\Repository\UserAlertRepository;

class GroupInviteRepository extends Repository
{
	/**
	 * @param Group $group
	 *
	 * @return GroupInviteFinder
	 */
	public function findGroupInvitesForList(Group $group): GroupInviteFinder
	{
		return \XF::app()->finder(GroupInviteFinder::class)
			->with('User')
			->inGroup($group)
			->setDefaultOrder([['invite_date', 'DESC'], ['User.username']]);
	}

	/**
	 * @param User $user
	 *
	 * @return GroupInviteFinder
	 */
	public function findGroupInvitesForUser(User $user): GroupInviteFinder
	{
		return \XF::app()->finder(GroupInviteFinder::class)
			->with('User')
			->forUser($user)
			->isValidGroup()
			->setDefaultOrder([['invite_date', 'DESC'], ['User.username']]);
	}

	/**
	 * @param GroupInvite $invite
	 *
	 * @return void
	 * @throws PrintableException
	 */
	public function rejectInvite(GroupInvite $invite): void
	{
		$this->sendInviteRejectAlert($invite);
		$invite->delete();

		$groupMember = $invite->Group->getNewMember();
		$groupMember->user_id = $invite->user_id;
		$groupMember->hydrateRelation('User', $invite->User);

		\XF::app()->repository(GroupMemberRepository::class)
			->logAction($groupMember, 'invite_reject')
		;

		unset($groupMember);
	}

	/**
	 * @param GroupInvite $invite
	 *
	 * @return bool
	 */
	public function sendInviteAlert(GroupInvite $invite): bool
	{
		$recipient = $invite->User;

		if (!$recipient)
		{
			return false;
		}

		return \XF::app()->repository(UserAlertRepository::class)
			->alert(
				$recipient,
				$invite->invited_by_user_id,
				$invite->InviteUser ? $invite->InviteUser->username : \XF::phrase('unknown')->render('raw'),
				'dbtech_social_invite',
				$invite->group_invite_id,
				'invite'
			)
		;
	}

	/**
	 * @param GroupInvite $invite
	 *
	 * @return bool
	 */
	public function sendInviteAcceptAlert(GroupInvite $invite): bool
	{
		$recipient = $invite->InviteUser;
		if (!$recipient)
		{
			return false;
		}

		$group = $invite->Group;

		$extra = [
			'title' => $group->title,
			//			'prefix_id' => $group->prefix_id,
			'link' => \XF::app()->router('public')->buildLink('nopath:dbtech-social', $group),
			'username' => $invite->User->username,
			'depends_on_addon_id' => 'DBTech/SocialGroups',
		];

		\XF::app()->repository(UserAlertRepository::class)
			->alert(
				$recipient,
				0,
				'',
				'user',
				$recipient->user_id,
				"dbt_soc_invite_accept",
				$extra
			)
		;

		return true;
	}

	/**
	 * @param GroupInvite $invite
	 *
	 * @return bool
	 */
	public function sendInviteRejectAlert(GroupInvite $invite): bool
	{
		$recipient = $invite->InviteUser;
		if (!$recipient)
		{
			return false;
		}

		$group = $invite->Group;

		$extra = [
			'title' => $group->title,
			//			'prefix_id' => $group->prefix_id,
			'link' => \XF::app()->router('public')->buildLink('nopath:dbtech-social', $group),
			'username' => $invite->User->username,
			'depends_on_addon_id' => 'DBTech/SocialGroups',
		];

		\XF::app()->repository(UserAlertRepository::class)
			->alert(
				$recipient,
				0,
				'',
				'user',
				$recipient->user_id,
				"dbt_soc_invite_reject",
				$extra
			)
		;

		return true;
	}
}