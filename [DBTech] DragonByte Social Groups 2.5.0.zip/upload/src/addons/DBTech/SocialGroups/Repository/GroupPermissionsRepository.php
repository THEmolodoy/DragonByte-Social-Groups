<?php

namespace DBTech\SocialGroups\Repository;

use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Entity\GroupMember;
use XF\Entity\User;
use XF\Mvc\Entity\Repository;
use XF\PrintableException;

class GroupPermissionsRepository extends Repository
{
	/**
	 * @param User $user
	 * @param Group $group
	 * @param bool $sendAlert
	 *
	 * @return void
	 * @throws PrintableException
	 */
	public function deleteModeratorPermissionsForUserInGroup(User $user, Group $group, bool $sendAlert = true): void
	{
		$groupMember = \XF::app()->em()->findOne(
			GroupMember::class,
			[
				'group_id'   => $group->group_id,
				'user_id'    => $user->user_id,
			]
		);
		if ($groupMember)
		{
			$groupMember->setOption('send_alert', $sendAlert);
			$groupMember->is_supervisor = false;
			$groupMember->permissions = [];
			$groupMember->save();
		}
	}

	/**
	 * @param User $user
	 * @param Group $group
	 *
	 * @throws PrintableException
	 */
	public function addOwnerPermissionsForGroup(
		User $user,
		Group $group
	): void
	{
		$defaultPermissions = \json_decode(
			\XF::options()->dbtechSocialDefaultPermissions['groupOwner'],
			true
		);
		$groupMember = \XF::app()->em()->findOne(
			GroupMember::class,
			[
				'group_id'   => $group->group_id,
				'user_id'    => $user->user_id,
			]
		);
		if ($groupMember)
		{
			$groupMember->setOption('send_alert', false);
			$groupMember->is_supervisor = true;
			$groupMember->permissions = $defaultPermissions;
			$groupMember->save();
		}
	}

	/**
	 * @param User $user
	 * @param Group $group
	 * @param array $permissions
	 *
	 * @throws PrintableException
	 */
	public function addModeratorPermissionsForGroup(
		User $user,
		Group $group,
		array $permissions
	): void
	{
		$groupMember = \XF::app()->em()->findOne(
			GroupMember::class,
			[
				'group_id'   => $group->group_id,
				'user_id'    => $user->user_id,
			]
		);
		if ($groupMember)
		{
			$groupMember->is_supervisor = true;
			$groupMember->permissions = $permissions;
			$groupMember->save();
		}
	}
}