<?php

namespace DBTech\SocialGroups\Repository;

use DBTech\SocialGroups\Entity\Discussion;
use DBTech\SocialGroups\Entity\DiscussionWatch;
use XF\Db\DuplicateKeyException;
use XF\Entity\User;
use XF\Mvc\Entity\Repository;
use XF\PrintableException;

class DiscussionWatchRepository extends Repository
{
	/**
	 * @param Discussion $discussion
	 * @param User $user
	 * @param false $onCreation
	 *
	 * @return DiscussionWatch|null
	 * @throws PrintableException
	 */
	public function autoWatchDiscussion(
		Discussion $discussion,
		User $user,
		bool $onCreation = false
	): ?DiscussionWatch
	{
		$userField = $onCreation ? 'creation_watch_state' : 'interaction_watch_state';

		if (!$discussion->discussion_id || !$user->user_id || !$user->Option->getValue($userField))
		{
			return null;
		}

		$watch = \XF::app()->em()->find(DiscussionWatch::class, [
			'discussion_id' => $discussion->discussion_id,
			'user_id' => $user->user_id,
		]);
		if ($watch)
		{
			return null;
		}

		$watch = \XF::app()->em()->create(DiscussionWatch::class);
		$watch->discussion_id = $discussion->discussion_id;
		$watch->user_id = $user->user_id;
		$watch->email_subscribe = ($user->Option->getValue($userField) == 'watch_email');

		try
		{
			$watch->save();
		}
		/** @noinspection PhpRedundantCatchClauseInspection */
		catch (DuplicateKeyException $e)
		{
			return null;
		}

		return $watch;
	}

	/**
	 * @param Discussion $discussion
	 * @param User $user
	 * @param string $state
	 *
	 * @throws PrintableException
	 */
	public function setWatchState(
		Discussion $discussion,
		User $user,
		string $state
	): void
	{
		if (!$discussion->discussion_id || !$user->user_id)
		{
			throw new \InvalidArgumentException("Invalid discussion or user");
		}

		$watch = \XF::app()->em()->find(DiscussionWatch::class, [
			'discussion_id' => $discussion->discussion_id,
			'user_id' => $user->user_id,
		]);

		switch ($state)
		{
			case 'watch_email':
			case 'watch_no_email':
			case 'no_email':
				if (!$watch)
				{
					$watch = \XF::app()->em()->create(DiscussionWatch::class);
					$watch->discussion_id = $discussion->discussion_id;
					$watch->user_id = $user->user_id;
				}
				$watch->email_subscribe = ($state == 'watch_email');
				try
				{
					$watch->save();
				}
				/** @noinspection PhpRedundantCatchClauseInspection */
				catch (DuplicateKeyException $e)
				{
				}
				break;

			case 'delete':
			case 'stop':
			case '':
				if ($watch)
				{
					$watch->delete();
				}
				break;

			default:
				throw new \InvalidArgumentException("Unknown state '$state'");
		}
	}

	/**
	 * @param User $user
	 * @param $state
	 *
	 * @return int
	 */
	public function setWatchStateForAll(User $user, $state): int
	{
		if (!$user->user_id)
		{
			throw new \InvalidArgumentException("Invalid user");
		}

		$db = $this->db();

		return match ($state)
		{
			'watch_email' => $db->update(
				'xf_dbtech_social_groups_discussion_watch',
				['email_subscribe' => 1],
				'user_id = ?',
				$user->user_id
			),
			'watch_no_email', 'no_email' => $db->update(
				'xf_dbtech_social_groups_discussion_watch',
				['email_subscribe' => 0],
				'user_id = ?',
				$user->user_id
			),
			'delete', 'stop', '' => $db->delete(
				'xf_dbtech_social_groups_discussion_watch',
				'user_id = ?',
				$user->user_id
			),
			default => throw new \InvalidArgumentException("Unknown state '$state'"),
		};
	}

	/**
	 * @param string $state
	 *
	 * @return bool
	 */
	public function isValidWatchState(string $state): bool
	{
		return match ($state)
		{
			'watch_email', 'watch_no_email', 'no_email', 'delete', 'stop', '' => true,
			default => false,
		};
	}
}