<?php

namespace DBTech\SocialGroups\Repository;

use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Entity\Section;
use DBTech\SocialGroups\Finder\SectionFinder;
use XF\Db\AbstractAdapter;
use XF\Db\DeadlockException;
use XF\Mvc\Entity\AbstractCollection;
use XF\Mvc\Entity\Repository;
use XF\SubTree;
use XF\Tree;

class SectionRepository extends Repository
{
	/**
	 * @param Group $group
	 * @param Section|null $withinSection
	 *
	 * @return SectionFinder
	 */
	public function findSectionsInGroup(
		Group    $group,
		?Section $withinSection = null
	): SectionFinder
	{
		$finder = \XF::app()->finder(SectionFinder::class)
			->inGroup($group)
		;

		if ($withinSection)
		{
			$finder->descendantOf($withinSection);
		}

		return $finder;
	}

	/**
	 * @param AbstractCollection<Section> $sections
	 * @param int $rootId
	 *
	 * @return Tree
	 */
	public function createSectionTree(AbstractCollection $sections, int $rootId = 0): Tree
	{
		return new Tree($sections, 'parent_section_id', $rootId);
	}

	/**
	 * @param Section $section
	 *
	 * @return SectionFinder
	 */
	public function findSiblings(Section $section): SectionFinder
	{
		return \XF::app()->finder(SectionFinder::class)
			->where('parent_section_id', $section->parent_section_id)
			->setDefaultOrder('lft');
	}

	/**
	 * @param Section $section
	 *
	 * @return SectionFinder
	 */
	public function findChildren(Section $section): SectionFinder
	{
		return \XF::app()->finder(SectionFinder::class)
			->where('parent_section_id', $section->section_id)
			->setDefaultOrder('lft');
	}

	/**
	 * @param Section $section
	 *
	 * @return SectionFinder
	 */
	public function findDescendants(Section $section): SectionFinder
	{
		return \XF::app()->finder(SectionFinder::class)
			->descendantOf($section)
			->setDefaultOrder('lft')
		;
	}

	/**
	 * @param Tree $sectionTree
	 *
	 * @return array
	 */
	public function getSectionListExtras(Tree $sectionTree): array
	{
		$finalOutput = [];
		$f = function (Section $section, array $children) use (&$f, &$finalOutput)
		{
			$childOutput = [];
			foreach ($children AS $id => $child)
			{
				/** @var SubTree $child */
				$childOutput[$id] = $f($child->record, $child->children());
			}

			$output = $this->mergeSectionListExtras($section->getSectionListExtras(), $childOutput);
			$finalOutput[$section->section_id] = $output;

			return $output;
		};

		foreach ($sectionTree AS $id => $subTree)
		{
			$f($subTree->record, $subTree->children());
		}

		return $finalOutput;
	}

	public function mergeSectionListExtras(array $extras, array $childExtras)
	{
		$output = array_merge([
			'discussion_count' => 0,
			'message_count' => 0,
			'hasNew' => false,
			'privateInfo' => false,
			'childCount' => 0,
			'last_message_id' => 0,
			'last_message_date' => 0,
			'last_message_user_id' => 0,
			'last_message_username' => '',
			'last_discussion_id' => 0,
			'last_discussion_title' => '',
			'last_discussion_prefix_id' => 0,
			'LastDiscussion' => null,
			'LastMessageUser' => null,
		], $extras);

		foreach ($childExtras AS $child)
		{
			if (!empty($child['discussion_count']))
			{
				$output['discussion_count'] += $child['discussion_count'];
			}

			if (!empty($child['message_count']))
			{
				$output['message_count'] += $child['message_count'];
			}

			if (!empty($child['last_message_date']) && $child['last_message_date'] > $output['last_message_date'])
			{
				$output['last_message_id'] = $child['last_message_id'];
				$output['last_message_date'] = $child['last_message_date'];
				$output['last_message_user_id'] = $child['last_message_user_id'];
				$output['last_message_username'] = $child['last_message_username'];
				$output['last_discussion_id'] = $child['last_discussion_id'];
				$output['last_discussion_title'] = $child['last_discussion_title'];
				$output['last_discussion_prefix_id'] = $child['last_discussion_prefix_id'];
				$output['LastMessageUser'] = $child['LastMessageUser'];
				$output['LastDiscussion'] = $child['LastDiscussion'];
			}

			if (!empty($child['hasNew']))
			{
				// one child has new stuff
				$output['hasNew'] = true;
			}

			$output['childCount'] += 1 + (!empty($child['childCount']) ? $child['childCount'] : 0);
		}

		return $output;
	}

	/**
	 * @param array $where
	 * @param array $with
	 *
	 * @return AbstractCollection
	 */
	public function getFullSectionList(array $where = [], array $with = []): AbstractCollection
	{
		$visitor = \XF::visitor();

		$sectionFinder = \XF::app()->finder(SectionFinder::class)
			->order('title')
		;

		if ($where)
		{
			$sectionFinder->where($where);
		}
		if ($with)
		{
			$sectionFinder->with($with);
		}

		return $sectionFinder->fetch();
	}

	/**
	 * @param Section $section
	 * @param int $userId
	 * @param int|null $newRead
	 *
	 * @return bool
	 * @throws DeadlockException
	 */
	public function markSectionReadByUser(
		Section $section,
		int $userId,
		?int $newRead = null
	): bool
	{
		if (!$userId)
		{
			return false;
		}

		if ($newRead === null)
		{
			$newRead = max(\XF::$time, $section->last_message_date);
		}

		$cutOff = \XF::$time - \XF::app()->options()->readMarkingDataLifetime * 86400;
		if ($newRead <= $cutOff)
		{
			return false;
		}

		$read = $section->Read[$userId];
		if ($read && $newRead <= $read->section_read_date)
		{
			return false;
		}

		\XF::db()->executeTransaction(function (AbstractAdapter $db) use ($section, $userId, $newRead)
		{
			$db->insert('xf_dbtech_social_groups_section_read', [
				'section_id' => $section->section_id,
				'user_id' => $userId,
				'section_read_date' => $newRead,
			], false, 'section_read_date = VALUES(section_read_date)');
		}, AbstractAdapter::ALLOW_DEADLOCK_RERUN);

		return true;
	}

	/**
	 * @param Section $section
	 * @param int|null $newRead
	 *
	 * @return bool
	 * @throws DeadlockException
	 */
	public function markSectionReadByVisitor(Section $section, ?int $newRead = null): bool
	{
		$userId = \XF::visitor()->user_id;
		return $this->markSectionReadByUser($section, $userId, $newRead);
	}

	/**
	 * @param Section $section
	 * @param int|null $newRead
	 *
	 * @return bool
	 * @throws DeadlockException
	 */
	public function markSectionReadIfPossible(Section $section, ?int $newRead = null): bool
	{
		$userId = \XF::visitor()->user_id;
		if (!$userId)
		{
			return false;
		}

		$discussionRepo = \XF::app()->repository(DiscussionRepository::class);
		$unread = $discussionRepo->countUnreadDiscussionsInSection($section);
		if ($unread)
		{
			return false;
		}

		return $this->markSectionReadByVisitor($section, $newRead);
	}

	/**
	 * @throws DeadlockException
	 */
	public function markSectionTreeReadByVisitor(?Section $baseSection = null, ?int $newRead = null): array
	{
		$userId = \XF::visitor()->user_id;
		if (!$userId)
		{
			return [];
		}

		if ($newRead === null)
		{
			$newRead = \XF::$time;
		}

		$cutOff = \XF::$time - \XF::app()->options()->readMarkingDataLifetime * 86400;
		if ($newRead <= $cutOff)
		{
			return [];
		}

		$with = [
			'Group.Permissions|' . \XF::visitor()->permission_combination_id,
			'Read|' . $userId,
		];

		if ($baseSection)
		{
			$childNodes = $this->findDescendants($baseSection)
				->with($with)
				->fetch();
			$sections = $childNodes->unshift($baseSection);
		}
		else
		{
			$sections = $this->getFullSectionList([], $with);
		}

		$markedRead = [];
		$inserts = [];

		foreach ($sections AS $section)
		{
			/** @var Section $section */
			if (!$section->canView())
			{
				continue;
			}

			$read = $section->Read[$userId];
			if ($read && $newRead <= $read->section_read_date)
			{
				continue;
			}

			$inserts[] = [
				'section_id' => $section->section_id,
				'user_id' => $userId,
				'section_read_date' => $newRead,
			];
			$markedRead[] = $section->section_id;
		}

		if ($inserts)
		{
			\XF::db()->executeTransaction(function (AbstractAdapter $db) use ($inserts)
			{
				$this->db()->insertBulk(
					'xf_dbtech_social_groups_section_read',
					$inserts,
					false,
					'section_read_date = VALUES(section_read_date)'
				);
			}, AbstractAdapter::ALLOW_DEADLOCK_RERUN);
		}

		return $markedRead;
	}

	/**
	 * @param int|null $cutOff
	 */
	public function pruneSectionReadLogs(?int $cutOff = null): void
	{
		if ($cutOff === null)
		{
			$cutOff = \XF::$time - (\XF::app()->options()->readMarkingDataLifetime * 86400);
		}

		$this->db()->delete('xf_dbtech_social_groups_section_read', 'section_read_date < ?', $cutOff);
	}

	/**
	 * @return int
	 */
	public function getReadMarkingCutOff(): int
	{
		return \XF::$time - \XF::app()->options()->readMarkingDataLifetime * 86400;
	}
}