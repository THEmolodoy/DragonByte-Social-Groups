<?php

namespace DBTech\SocialGroups\Repository;

use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Finder\GroupFinder;
use DBTech\SocialGroups\Finder\GroupMemberFinder;
use DBTech\SocialGroups\XF\Entity\User as ExtendedUserEntity;
use XF\Db\AbstractAdapter;
use XF\Db\DeadlockException;
use XF\Db\Exception as DbException;
use XF\Entity\User;
use XF\Finder\TagFinder;
use XF\Mvc\Entity\AbstractCollection;
use XF\Mvc\Entity\Repository;
use XF\Repository\UserAlertRepository;

class GroupRepository extends Repository
{
	public const GROUP_PRIVACY_LEVELS = [
		'public'  => 10,
		'closed'  => 20,
		'private' => 30,
		'hidden'  => 40,
	];

	/**
	 * @param string $newLevel
	 * @param string $oldLevel
	 *
	 * @return bool
	 */
	public function isLowerPrivacy(string $newLevel, string $oldLevel): bool
	{
		return (self::GROUP_PRIVACY_LEVELS[$newLevel] < self::GROUP_PRIVACY_LEVELS[$oldLevel]);
	}

	/**
	 * @param array $limits
	 *
	 * @return GroupFinder
	 * @throws \InvalidArgumentException
	 */
	public function findGroupsForOverviewList(array $limits = []): GroupFinder
	{
		$limits = array_replace([
			'visibility' => true,
			'allowOwnPending' => false,
		], $limits);

		$groupFinder = \XF::app()->finder(GroupFinder::class)
			->with('full')
			->useDefaultOrder()
		;

		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		if (!$visitor->canEditAnyDbtechSocialGroups())
		{
			$groupFinder->whereOr(
				['group_type', '!=', 'hidden'],
				['group_id' => $visitor->dbtech_social_groups_group_ids]
			);
		}

		if ($limits['visibility'])
		{
			$groupFinder->applyGlobalVisibilityChecks($limits['allowOwnPending']);
		}

		return $groupFinder;
	}

	/**
	 * @return GroupFinder
	 * @throws \InvalidArgumentException
	 */
	public function findFeaturedGroups(): GroupFinder
	{
		return \XF::app()->finder(GroupFinder::class)
			->with('full')
			->where('group_state', 'visible')
			->where('featured', true)
			->order('last_update_date', 'desc')
		;
	}

	/**
	 * @return GroupFinder
	 * @throws \InvalidArgumentException
	 */
	public function findRandomGroups(): GroupFinder
	{
		$groupFinder = \XF::app()->finder(GroupFinder::class);

		return $groupFinder
			->with('full')
			->where('group_state', 'visible')
			->order($groupFinder->expression('RAND()'));
	}

	/**
	 * @return GroupFinder
	 * @throws \InvalidArgumentException
	 */
	public function findNewGroups(): GroupFinder
	{
		return \XF::app()->finder(GroupFinder::class)
			->with('full')
			->where('group_state', 'visible')
			->order('creation_date', 'desc')
		;
	}

	/**
	 * @return GroupFinder
	 * @throws \InvalidArgumentException
	 */
	public function findOwnedGroups(): GroupFinder
	{
		return \XF::app()->finder(GroupFinder::class)
			->with('full')
			->where('group_state', 'visible')
			->where('user_id', \XF::visitor()->user_id)
			->order('last_update_date', 'desc');
	}

	/**
	 * @return GroupFinder
	 * @throws \InvalidArgumentException
	 */
	public function findJoinedGroups(): GroupFinder
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		return \XF::app()->finder(GroupFinder::class)
			->with('full')
			->where('group_state', 'visible')
			->where('user_id', $visitor->dbtech_social_groups_group_ids)
			->order('last_update_date', 'desc');
	}

	/**
	 * @param Group $group
	 * @param string $action
	 * @param string $reason
	 * @param array $extra
	 * @param User|null $forceUser
	 *
	 * @return bool
	 */
	public function sendModeratorActionAlert(
		Group $group,
		string $action,
		string $reason = '',
		array $extra = [],
		?User $forceUser = null
	): bool
	{
		if (!$forceUser)
		{
			if (!$group->user_id || !$group->User)
			{
				return false;
			}

			$forceUser = $group->User;
		}

		$extra = array_merge([
			'title' => $group->title,
			//			'prefix_id' => $group->prefix_id,
			'link' => \XF::app()->router('public')->buildLink('nopath:dbtech-social', $group),
			'reason' => $reason,
			'depends_on_addon_id' => 'DBTech/SocialGroups',
		], $extra);

		\XF::app()->repository(UserAlertRepository::class)
			->alert(
				$forceUser,
				0,
				'',
				'user',
				$forceUser->user_id,
				"dbt_soc_group_$action",
				$extra
			)
		;

		return true;
	}

	/**
	 * @return GroupFinder
	 */
	public function findGroupsForList(): GroupFinder
	{
		return \XF::app()->finder(GroupFinder::class)
			->order('title');
	}

	/**
	 * @return AbstractCollection
	 */
	public function getJoinedGroups(): AbstractCollection
	{
		/** @var ExtendedUserEntity $user */
		$visitor = \XF::visitor();

		if (!$visitor->user_id)
		{
			return \XF::app()->em()->getEmptyCollection();
		}

		/** @var GroupMemberFinder $finder */
		$finder = $visitor->getRelationFinder('SocialGroupMemberships');

		$finder->applyGlobalGroupVisibilityChecks()
			->with('Group.full')
			->with('Group.Moderators|' . $visitor->user_id)
		;

		return $finder->fetch();
	}

	/**
	 * @param array $where
	 * @param array $with
	 *
	 * @return AbstractCollection<Group>
	 */
	public function getFullGroupList(array $where = [], array $with = []): AbstractCollection
	{
		$visitor = \XF::visitor();

		$groupFinder = \XF::app()->finder(GroupFinder::class)
			->with('Permissions|' . $visitor->permission_combination_id)
			->order('title')
		;

		if ($where)
		{
			$groupFinder->where($where);
		}
		if ($with)
		{
			$groupFinder->with($with);
		}

		return $groupFinder->fetch();
	}

	/**
	 * @param array $where
	 * @param array $with
	 *
	 * @return AbstractCollection<Group>
	 */
	public function getViewableGroups(array $where = [], array $with = []): AbstractCollection
	{
		return $this->getFullGroupList($where, $with)
			->filterViewable()
		;
	}

	/**
	 * @param string $cacheKey
	 * @param array $with
	 *
	 * @return AbstractCollection<Group>
	 */
	public function getFullGroupListCached(string $cacheKey, array $with = []): AbstractCollection
	{
		static $groupListCache = [];

		if (isset($groupListCache[$cacheKey]))
		{
			return $groupListCache[$cacheKey];
		}

		$groups = $this->getFullGroupList($with);
		$groupListCache[$cacheKey] = $groups;

		return $groups;
	}

	/**
	 * @param bool $includeEmpty
	 * @param bool $checkPerms
	 *
	 * @return array|array[]
	 */
	public function getGroupOptionsData(bool $includeEmpty = true, bool $checkPerms = false): array
	{
		$choices = [];
		if ($includeEmpty)
		{
			$choices = [
				0 => ['_type' => 'option', 'value' => 0, 'label' => \XF::phrase('(none)')],
			];
		}

		if ($checkPerms)
		{
			$groupList = $this->getViewableGroups();
		}
		else
		{
			$groupList = $this->getFullGroupList();
		}

		/** @var Group $group */
		foreach ($groupList AS $group)
		{
			$choices[$group->group_id] = [
				'value' => $group->group_id,
				'label' => $group->title,
			];
		}

		return $choices;
	}

	/**
	 * @param Group $group
	 * @param int $userId
	 * @param int|null $newRead
	 *
	 * @return bool
	 * @throws DeadlockException
	 */
	public function markGroupReadByUser(
		Group $group,
		int $userId,
		?int $newRead = null
	): bool
	{
		if (!$userId)
		{
			return false;
		}

		if ($newRead === null)
		{
			$newRead = max(\XF::$time, $group->last_message_date);
		}

		$cutOff = \XF::$time - \XF::app()->options()->readMarkingDataLifetime * 86400;
		if ($newRead <= $cutOff)
		{
			return false;
		}

		$read = $group->Read[$userId];
		if ($read && $newRead <= $read->group_read_date)
		{
			return false;
		}

		\XF::db()->executeTransaction(function (AbstractAdapter $db) use ($group, $userId, $newRead)
		{
			$db->insert('xf_dbtech_social_groups_group_read', [
				'group_id' => $group->group_id,
				'user_id' => $userId,
				'group_read_date' => $newRead,
			], false, 'group_read_date = VALUES(group_read_date)');
		}, AbstractAdapter::ALLOW_DEADLOCK_RERUN);

		return true;
	}

	/**
	 * @param int $userId
	 * @param int|null $newRead
	 *
	 * @return array
	 * @throws DeadlockException
	 */
	public function markAllGroupsReadByUser(
		int $userId,
		?int $newRead = null
	): array
	{
		if (!$userId)
		{
			return [];
		}

		if ($newRead === null)
		{
			$newRead = \XF::$time;
		}

		$cutOff = \XF::$time - \XF::app()->options()->readMarkingDataLifetime * 86400;
		if ($newRead <= $cutOff)
		{
			return [];
		}

		$groups = $this->getFullGroupList();

		$markedRead = [];
		$inserts = [];

		foreach ($groups AS $group)
		{
			/** @var Group $group */
			if (!$group->canView())
			{
				continue;
			}

			$read = $group->Read[$userId];
			if ($read && $newRead <= $read->group_read_date)
			{
				continue;
			}

			$inserts[] = [
				'group_id' => $group->group_id,
				'user_id' => $userId,
				'group_read_date' => $newRead,
			];
			$markedRead[] = $group->group_id;
		}

		if ($inserts)
		{
			\XF::db()->executeTransaction(function (AbstractAdapter $db) use ($inserts)
			{
				$db->insertBulk(
					'xf_dbtech_social_groups_group_read',
					$inserts,
					false,
					'group_read_date = VALUES(group_read_date)'
				);
			}, AbstractAdapter::ALLOW_DEADLOCK_RERUN);
		}

		return $markedRead;
	}

	/**
	 * @param Group $group
	 * @param int|null $newRead
	 *
	 * @return bool
	 * @throws DeadlockException
	 */
	public function markGroupReadByVisitor(Group $group, ?int $newRead = null): bool
	{
		$userId = \XF::visitor()->user_id;
		return $this->markGroupReadByUser($group, $userId, $newRead);
	}

	/**
	 * @param int|null $newRead
	 *
	 * @return array
	 * @throws DeadlockException
	 */
	public function markAllGroupsReadByVisitor(?int $newRead = null): array
	{
		$userId = \XF::visitor()->user_id;
		return $this->markAllGroupsReadByUser($userId, $newRead);
	}

	/**
	 * @param Group $group
	 * @param int|null $newRead
	 *
	 * @return bool
	 * @throws DeadlockException
	 */
	public function markGroupReadIfPossible(Group $group, ?int $newRead = null): bool
	{
		$userId = \XF::visitor()->user_id;
		if (!$userId)
		{
			return false;
		}

		$discussionRepo = \XF::app()->repository(DiscussionRepository::class);
		$unread = $discussionRepo->countUnreadDiscussionsInGroup($group);
		if ($unread)
		{
			return false;
		}

		return $this->markGroupReadByVisitor($group, $newRead);
	}

	/**
	 * @param int|null $cutOff
	 */
	public function pruneGroupReadLogs(?int $cutOff = null): void
	{
		if ($cutOff === null)
		{
			$cutOff = \XF::$time - (\XF::app()->options()->readMarkingDataLifetime * 86400);
		}

		$this->db()->delete('xf_dbtech_social_groups_group_read', 'group_read_date < ?', $cutOff);
	}

	/**
	 * @param Group $group
	 *
	 * @return void
	 * @throws DbException
	 */
	public function logGroupView(Group $group): void
	{
		$this->db()->query("
			-- XFDB=noForceAllWrite
			INSERT INTO xf_dbtech_social_groups_group_view
				(group_id, total)
			VALUES
				(? , 1)
			ON DUPLICATE KEY UPDATE
				total = total + 1
		", $group->group_id);
	}

	/**
	 * @return void
	 * @throws DbException
	 */
	public function batchUpdateGroupViews(): void
	{
		$db = $this->db();
		$db->query("
			UPDATE xf_dbtech_social_groups_group AS g
			INNER JOIN xf_dbtech_social_groups_group_view AS gv ON (g.group_id = gv.group_id)
			SET g.view_count = g.view_count + gv.total
		");
		$db->emptyTable('xf_dbtech_social_groups_group_view');
	}

	/**
	 * @return array|false
	 */
	public function getGroupCounterTotals(): bool|array
	{
		return $this->db()->fetchRow("
			SELECT COUNT(*) AS dbtechSocialGroupsGroups, 
			    SUM(discussion_count) AS dbtechSocialGroupsDiscussions,
				SUM(message_count) AS dbtechSocialGroupsMessages
			FROM xf_dbtech_social_groups_group
		");
	}

	/**
	 * @return GroupFinder
	 */
	public function findEntriesForPermissionList(): GroupFinder
	{
		return $this->findGroupsForList();
	}

	/**
	 * @param int $limit
	 * @param int $minUses
	 *
	 * @return array
	 */
	public function getGroupTagsForCloud(int $limit, int $minUses = 1): array
	{
		$db = $this->db();
		$ids = $db->fetchAllColumn($db->limit("
			SELECT tag_id
			FROM xf_tag
			WHERE use_count >= ?
				AND tag_id IN(SELECT tag_id FROM xf_tag_content WHERE content_type = 'dbtech_social_group')
			ORDER BY use_count DESC
		", $limit), $minUses);
		if (!$ids)
		{
			return [];
		}

		return \XF::app()->finder(TagFinder::class)
			->where('tag_id', $ids)
			->order('tag')
			->fetch()
			->toArray()
		;
	}

	/**
	 * @return GroupFinder
	 */
	public function findValidGroups(): GroupFinder
	{
		return \XF::app()->finder(GroupFinder::class)
			->isValidGroup()
		;
	}

	/**
	 * @return null|Group
	 * @noinspection PhpIncompatibleReturnTypeInspection
	 */
	public function getLatestValidGroup(): ?Group
	{
		return $this->findValidGroups()
			->order('creation_date', 'DESC')
			->fetchOne()
		;
	}

	/**
	 * @return int
	 */
	public function getReadMarkingCutOff(): int
	{
		return \XF::$time - \XF::app()->options()->readMarkingDataLifetime * 86400;
	}
}