<?php

namespace DBTech\SocialGroups\Repository;

use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Entity\GroupMember;
use DBTech\SocialGroups\Finder\GroupMemberFinder;
use DBTech\SocialGroups\Finder\GroupMemberLogFinder;
use DBTech\SocialGroups\Job\GroupActionCleanUp;
use DBTech\SocialGroups\XF\Logger;
use XF\Db\DuplicateKeyException;
use XF\Entity\User;
use XF\Mvc\Entity\Repository;
use XF\PrintableException;
use XF\Repository\UserAlertRepository;

class GroupMemberRepository extends Repository
{
	/**
	 * @param User $user
	 *
	 * @return GroupMemberFinder
	 */
	public function getGroupMembershipsForUser(User $user): GroupMemberFinder
	{
		return $user->getRelationFinder('SocialGroupMemberships')
			->applyGlobalGroupVisibilityChecks()
			->where('member_state', 'valid')
		;
	}

	/**
	 * @param User $user
	 *
	 * @return GroupMemberFinder
	 */
	public function getUnapprovedGroupMembershipsForUser(User $user): GroupMemberFinder
	{
		return $user->getRelationFinder('SocialGroupMemberships')
			->applyGlobalGroupVisibilityChecks()
			->where('member_state', 'moderated')
		;
	}

	/**
	 * @param User $user
	 *
	 * @return GroupMemberFinder
	 */
	public function getBannedGroupMembershipsForUser(User $user): GroupMemberFinder
	{
		return $user->getRelationFinder('SocialGroupMemberships')
			->applyGlobalGroupVisibilityChecks()
			->where('member_state', 'banned')
		;
	}

	/**
	 * @param Group $group
	 *
	 * @return GroupMemberFinder
	 */
	public function getUnapprovedMembersInGroup(Group $group): GroupMemberFinder
	{
		return \XF::app()->finder(GroupMemberFinder::class)
			->inGroup($group)
			->where('member_state', 'moderated');
	}

	/**
	 * @param Group $group
	 * @param int|null $limit
	 *
	 * @return GroupMemberFinder
	 */
	public function getLatestMembersInGroup(Group $group, ?int $limit = null): GroupMemberFinder
	{
		$limit = $limit ?: \XF::app()->options()->membersPerPage;

		return \XF::app()->finder(GroupMemberFinder::class)
			->with('User')
			->inGroup($group)
			->isValidMember()
			->order('join_date', 'DESC')
			->limit($limit)
		;
	}

	/**
	 * @param Group $group
	 * @param User $user
	 * @param bool $newTransaction
	 * @param string $reason
	 *
	 * @return void
	 * @throws PrintableException
	 */
	public function joinGroup(
		Group $group,
		User $user,
		bool $newTransaction = true,
		string $reason = ''
	): void
	{
		$groupMember = $group->getNewMember();
		$groupMember->user_id = $user->user_id;

		if ($reason)
		{
			$groupMember->reason = $reason;
		}

		try
		{
			$groupMember->save(true, $newTransaction);
		}
		/** @noinspection PhpRedundantCatchClauseInspection */
		catch (DuplicateKeyException $e)
		{
			// we can ignore a duplicate as it indicates a race condition, trust the previous value inserted
		}

		$group->clearCache('Members');

		if ($groupMember->member_state === 'moderated')
		{
			// Membership request
			if ($reason)
			{
				$this
					->logAction($groupMember, 'join_request_reason', [
						'reason' => $reason,
					])
				;
			}
			else
			{
				$this
					->logAction($groupMember, 'join_request')
				;
			}
		}
		else
		{
			// Standard join
			if ($reason)
			{
				$this
					->logAction($groupMember, 'join_reason', [
						'reason' => $reason,
					])
				;
			}
			else
			{
				$this
					->logAction($groupMember, 'join')
				;
			}
		}
	}

	/**
	 * @param GroupMember $groupMember
	 * @param string $reason
	 *
	 * @return void
	 * @throws PrintableException
	 */
	public function kickMember(GroupMember $groupMember, string $reason = ''): void
	{
		$groupMember->delete();

		if (\XF::app()->options()->dbtechSocialMediaGalleryKickAction === 'unlink')
		{
			\XF::app()->jobManager()->enqueue(
				GroupActionCleanUp::class,
				[
					'groupId' => $groupMember->Group->group_id,
					'title' => $groupMember->Group->title,
					'userId' => $groupMember->user_id,
				]
			);
		}

		\XF::app()->repository(GroupRepository::class)->sendModeratorActionAlert(
			$groupMember->Group,
			'kick',
			$reason,
			[],
			$groupMember->User
		);

		if ($reason)
		{
			$this
				->logAction($groupMember, 'kick_reason', [
					'reason' => $reason,
				], \XF::visitor())
			;
		}
		else
		{
			$this
				->logAction($groupMember, 'kick', [], \XF::visitor())
			;
		}
	}

	/**
	 * @param User $recipient
	 * @param GroupMember $groupMember

	 * @param array $extra
	 *
	 * @return bool
	 */
	public function sendMemberApprovalAlert(
		User $recipient,
		GroupMember $groupMember,
		array $extra = []
	): bool
	{
		$extra = array_merge([
			'reason' => $groupMember->reason,
		], $extra);

		return \XF::app()->repository(UserAlertRepository::class)
			->alert(
				$recipient,
				0,
				'',
				'dbtech_social_member',
				$groupMember->group_member_id,
				'approval',
				$extra
			)
		;
	}

	/**
	 * @param GroupMember $groupMember
	 * @param string $action
	 * @param string $reason
	 * @param array $extra
	 * @param User|null $forceUser
	 *
	 * @return bool
	 */
	public function sendModeratorActionAlert(
		GroupMember $groupMember,
		string $action,
		string $reason = '',
		array $extra = [],
		?User $forceUser = null
	): bool
	{
		if (!$forceUser)
		{
			if (!$groupMember->user_id || !$groupMember->User)
			{
				return false;
			}

			$forceUser = $groupMember->User;
		}

		$extra = array_merge([
			'title' => $groupMember->Group->title,
			'link' => \XF::app()->router('public')->buildLink('nopath:dbtech-social', $groupMember->Group),
			'reason' => $reason,
			'depends_on_addon_id' => 'DBTech/SocialGroups',
		], $extra);

		\XF::app()->repository(UserAlertRepository::class)
			->alert(
				$forceUser,
				0,
				'',
				'user',
				$groupMember->user_id,
				'dbt_soc_member_' . $action,
				$extra
			)
		;

		return true;
	}

	/**
	 * @param GroupMember $groupMember
	 * @param string $action
	 * @param array $params
	 * @param User|null $actor
	 * @param bool|string $ip
	 *
	 * @throws PrintableException
	 */
	public function logAction(
		GroupMember $groupMember,
		string $action,
		array $params = [],
		?User $actor = null,
		bool|string $ip = true
	): void
	{
		if (!$groupMember->User)
		{
			return;
		}

		if ($ip === true)
		{
			$ip = \XF::app()->request()->getIp();
		}

		/** @var Logger $logger */
		$logger = \XF::app()->logger();
		$logger->logDbtechSocialGroupMember(
			$groupMember,
			$action,
			$params,
			true,
			$actor ?: $groupMember->User,
			$ip
		);
	}

	/**
	 * @param Group $group
	 *
	 * @return GroupMemberLogFinder
	 */
	public function findLogsForListInGroup(Group $group): GroupMemberLogFinder
	{
		return \XF::app()->finder(GroupMemberLogFinder::class)
			->inGroup($group)
			->with(['User', 'Actor'])
			->setDefaultOrder('log_date', 'DESC');
	}

	/**
	 * @param Group $group
	 *
	 * @return array
	 */
	public function getActorsInLogForGroup(Group $group): array
	{
		return $this->db()->fetchPairs("
			SELECT user.user_id, user.username
			FROM (
				SELECT DISTINCT actor_id FROM xf_dbtech_social_groups_group_member_log WHERE group_id = ?
			) AS log
			INNER JOIN xf_user AS user ON (log.actor_id = user.user_id)
			ORDER BY user.username
		", $group->group_id);
	}

	/**
	 * @param Group $group
	 *
	 * @return array
	 */
	public function getUsersInLogForGroup(Group $group): array
	{
		return $this->db()->fetchPairs("
			SELECT user.user_id, user.username
			FROM (
				SELECT DISTINCT user_id FROM xf_dbtech_social_groups_group_member_log WHERE group_id = ?
			) AS log
			INNER JOIN xf_user AS user ON (log.user_id = user.user_id)
			ORDER BY user.username
		", $group->group_id);
	}
}