<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\InlineMod\Message;

use DBTech\SocialGroups\Entity\Message;
use DBTech\SocialGroups\Service\Message\DeleterService;
use XF\Http\Request;
use XF\InlineMod\AbstractAction;
use XF\InputFilterer;
use XF\Mvc\Controller;
use XF\Mvc\Entity\AbstractCollection;
use XF\Mvc\Entity\Entity;
use XF\Mvc\Reply\AbstractReply;
use XF\Phrase;
use XF\PrintableException;

use function count;

/**
 * @extends AbstractAction<Message>
 */
class Delete extends AbstractAction
{
	/**
	 * @return Phrase
	 */
	public function getTitle()
	{
		return \XF::phrase('dbtech_social_groups_delete_messages...');
	}

	/**
	 * @param Entity $entity
	 * @param array $options
	 * @param $error
	 *
	 * @return bool
	 */
	protected function canApplyToEntity(Entity $entity, array $options, &$error = null)
	{
		/** @var Message $entity */
		return $entity->canDelete($options['type'], $error);
	}

	/**
	 * @param AbstractCollection $entities
	 * @param array $options
	 *
	 * @throws PrintableException
	 */
	protected function applyInternal(AbstractCollection $entities, array $options)
	{
		$skipped = [];

		/** @var Message $entity */
		foreach ($entities AS $entity)
		{
			if (!empty($skipped[$entity->discussion_id]))
			{
				continue;
			}

			$this->applyToEntity($entity, $options);

			$discussion = $entity->Discussion;
			if ($options['type'] == 'hard' && $entity->message_id == $discussion->first_message_id)
			{
				// all messages in this discussion have been removed, so skip them
				$skipped[$discussion->discussion_id] = true;
			}
		}
	}

	/**
	 * @param Entity $entity
	 * @param array $options
	 *
	 * @throws PrintableException
	 */
	protected function applyToEntity(Entity $entity, array $options)
	{
		/** @var Message $entity */

		$deleter = \XF::app()->service(DeleterService::class, $entity);

		if ($options['alert'])
		{
			$deleter->setSendAlert(true, $options['alert_reason']);
		}

		$deleter->delete($options['type'], $options['reason']);

		if ($deleter->wasDiscussionDeleted())
		{
			$this->returnUrl = $this->app()
				->router('public')
				->buildLink('dbtech-social', $entity->Discussion->Group)
			;
		}
	}

	/**
	 * @return array
	 */
	public function getBaseOptions()
	{
		return [
			'type' => 'soft',
			'reason' => '',
			'alert' => false,
			'alert_reason' => '',
		];
	}

	/**
	 * @param AbstractCollection $entities
	 * @param Controller $controller
	 *
	 * @return AbstractReply
	 */
	public function renderForm(AbstractCollection $entities, Controller $controller)
	{
		$firstMessageCount = 0;

		/** @var Message $message */
		foreach ($entities AS $message)
		{
			if ($message->message_id == $message->Discussion->first_message_id)
			{
				$firstMessageCount++;
			}
		}

		$viewParams = [
			'messages' => $entities,
			'firstMessageCount' => $firstMessageCount,
			'total' => count($entities),
			'canHardDelete' => $this->canApply($entities, ['type' => 'hard']),
		];
		return $controller->view(
			'DBTech\SocialGroups:Public:InlineMod\Message\Delete',
			'dbtech_social_groups_inline_mod_message_delete',
			$viewParams
		);
	}

	/**
	 * @param AbstractCollection $entities
	 * @param Request $request
	 *
	 * @return array
	 */
	public function getFormOptions(AbstractCollection $entities, Request $request)
	{
		return [
			'type' => $request->filter('hard_delete', InputFilterer::BOOLEAN) ? 'hard' : 'soft',
			'reason' => $request->filter('reason', InputFilterer::STRING),
			'alert' => $request->filter('author_alert', InputFilterer::BOOLEAN),
			'alert_reason' => $request->filter('author_alert_reason', InputFilterer::STRING),
		];
	}
}