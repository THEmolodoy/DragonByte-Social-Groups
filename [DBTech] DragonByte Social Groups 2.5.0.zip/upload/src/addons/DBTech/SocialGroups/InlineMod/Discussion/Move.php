<?php

namespace DBTech\SocialGroups\InlineMod\Discussion;

use DBTech\SocialGroups\Entity\Discussion;
use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Entity\Section;
use DBTech\SocialGroups\Repository\SectionRepository;
use DBTech\SocialGroups\Service\Discussion\MoverService;
use XF\Db\DeadlockException;
use XF\Http\Request;
use XF\InlineMod\AbstractAction;
use XF\InputFilterer;
use XF\Mvc\Controller;
use XF\Mvc\Entity\AbstractCollection;
use XF\Mvc\Entity\Entity;
use XF\Mvc\Reply\AbstractReply;
use XF\Phrase;
use XF\PrintableException;

use function count;

/**
 * @extends AbstractAction<Discussion>
 */
class Move extends AbstractAction
{
	protected Group $group;
	protected int $groupId;
	protected ?Section $targetSection = null;
	protected ?int $targetSectionId = 0;

	public function getTitle(): Phrase
	{
		return \XF::phrase('dbtech_social_groups_move_discussions...');
	}

	/**
	 * @param AbstractCollection<Discussion> $entities
	 * @param array $options
	 * @param $error
	 *
	 * @return bool
	 */
	public function canApply(AbstractCollection $entities, array $options = [], &$error = null): bool
	{
		if (!\XF::options()->dbtechSocialGroupsEnableSections)
		{
			return false;
		}

		return parent::canApply($entities, $options, $error);
	}

	/**
	 * @param AbstractCollection<Discussion> $entities
	 * @param array $options
	 * @param $error
	 *
	 * @return bool
	 */
	protected function canApplyInternal(AbstractCollection $entities, array $options, &$error): bool
	{
		$result = parent::canApplyInternal($entities, $options, $error);

		if ($result)
		{
			/** @var Discussion $firstDiscussion */
			$firstDiscussion = $entities->first();

			// Store these for comparison to all other discussions
			$this->group = $firstDiscussion->Group;
			$this->groupId = $firstDiscussion->group_id;

			$allSame = true;
			foreach ($entities AS $entity)
			{
				/** @var Discussion $entity */
				if ($entity->group_id != $firstDiscussion->group_id)
				{
					$allSame = false;
					break;
				}
			}

			if (!$allSame)
			{
				$error = \XF::phraseDeferred('dbtech_social_groups_not_all_discussions_same_group');
				return false;
			}

			if ($options['target_section_id'])
			{
				$section = $this->getTargetSection($options['target_section_id']);
				if (!$section)
				{
					return false;
				}

				if ($options['check_section_viewable'] && !$section->canView($error))
				{
					return false;
				}

				if ($section->group_id !== $this->groupId)
				{
					$error = \XF::phraseDeferred('dbtech_social_groups_target_section_not_same_group');
					return false;
				}
			}

			if ($options['check_all_same_section'] && $options['target_section_id'] !== null)
			{
				$allSame = true;
				foreach ($entities AS $entity)
				{
					/** @var Discussion $entity */
					if ($entity->section_id != $options['target_section_id'])
					{
						$allSame = false;
						break;
					}
				}

				if ($allSame)
				{
					$error = \XF::phraseDeferred('dbtech_social_groups_all_discussions_in_destination_section');
					return false;
				}
			}
		}

		return $result;
	}

	/**
	 * @param Discussion $entity
	 * @param array $options
	 * @param $error
	 *
	 * @return bool
	 */
	protected function canApplyToEntity(Entity $entity, array $options, &$error = null): bool
	{
		return $entity->canMove($error);
	}

	/**
	 * @param AbstractCollection<Discussion> $entities
	 * @param array $options
	 *
	 * @return void
	 */
	protected function applyInternal(AbstractCollection $entities, array $options): void
	{
		if ($options['alert'])
		{
			// we must do this here since the service only moves a single discussion at a time
			$contentIds = [$options['target_section_id']];
			$permissionCombinationIds = [];
			foreach ($entities AS $entity)
			{
				if (!$entity->user_id || !$entity->User)
				{
					continue;
				}

				$contentIds[] = $entity->group_id;
				$permissionCombinationIds[] = $entity->User->permission_combination_id;
			}

			MoverService::cacheContentPermissions(
				'dbtech_social_group',
				$contentIds,
				$permissionCombinationIds
			);
		}

		parent::applyInternal($entities, $options);
	}

	/**
	 * @param Discussion $entity
	 * @param array $options
	 *
	 * @return void
	 * @throws PrintableException
	 * @throws DeadlockException
	 */
	protected function applyToEntity(Entity $entity, array $options): void
	{
		$section = $this->getTargetSection($options['target_section_id']);

		$mover = \XF::app()->service(MoverService::class, $entity);

		if ($options['alert'])
		{
			$mover->setSendAlert(true, $options['alert_reason']);
		}

		if ($options['notify_watchers'])
		{
			$mover->setNotifyWatchers();
		}

		//		if ($options['redirect'] && $entity->discussion_type != 'redirect')
		//		{
		//			$mover->setRedirect(true, $options['redirect_length']);
		//		}
		//
		//		if ($options['prefix_id'] !== null)
		//		{
		//			$mover->setPrefix($options['prefix_id']);
		//		}

		$mover->move($section);

		$router = \XF::app()->router('public');
		$this->returnUrl = $section
			? $router->buildLink('dbtech-social/sections', $section)
			: $router->buildLink('dbtech-social/discussions/list', $this->group)
		;
	}

	public function getBaseOptions(): array
	{
		return [
			'target_section_id' => null,
			'check_section_viewable' => true,
			'check_all_same_section' => true,
			//			'prefix_id' => null,
			'redirect' => false,
			'redirect_length' => 0,
			'notify_watchers' => false,
			'alert' => false,
			'alert_reason' => '',
		];
	}

	public function renderForm(AbstractCollection $entities, Controller $controller): ?AbstractReply
	{
		$sectionRepo = \XF::app()->repository(SectionRepository::class);
		$sections = $sectionRepo->findSectionsInGroup($this->group)->fetch()->filterViewable();

		//		$prefixes = \XF::app()->finder(\XF\Finder\ThreadPrefix::class)
		//			->order('materialized_order')
		//			->fetch();

		$viewParams = [
			'discussions' => $entities,
			//			'prefixes' => $prefixes->groupBy('prefix_group_id'),
			'total' => count($entities),
			'sectionTree' => $sectionRepo->createSectionTree($sections),
			'first' => $entities->first(),
		];
		return $controller->view(
			'DBTech\SocialGroups:Public:InlineMod\Thread\Move',
			'dbtech_social_groups_inline_mod_discussion_move',
			$viewParams
		);
	}

	public function getFormOptions(AbstractCollection $entities, Request $request): array
	{
		$options = [
			'target_section_id' => $request->filter('target_section_id', InputFilterer::UNSIGNED),
			//			'apply_discussion_prefix' => $request->filter('apply_discussion_prefix', InputFilterer::BOOLEAN),
			//			'prefix_id' => $request->filter('prefix_id', InputFilterer::UNSIGNED),
			'notify_watchers' => $request->filter('notify_watchers', InputFilterer::BOOLEAN),
			'alert' => $request->filter('starter_alert', InputFilterer::BOOLEAN),
			'alert_reason' => $request->filter('starter_alert_reason', InputFilterer::STRING),
		];
		//		if (!$options['apply_discussion_prefix'])
		//		{
		//			$options['prefix_id'] = null;
		//		}

		$redirectType = $request->filter('redirect_type', InputFilterer::STRING);
		if ($redirectType == 'permanent')
		{
			$options['redirect'] = true;
			$options['redirect_length'] = 0;
		}
		else if ($redirectType == 'temporary')
		{
			$options['redirect'] = true;
			$options['redirect_length'] = $request->filter('redirect_length', InputFilterer::TIME_OFFSET);
		}
		else
		{
			$options['redirect'] = false;
			$options['redirect_length'] = 0;
		}

		return $options;
	}

	/**
	 * @param int $sectionId
	 *
	 * @return null|Section
	 */
	protected function getTargetSection(int $sectionId): ?Section
	{
		if ($this->targetSectionId && $this->targetSectionId === $sectionId)
		{
			return $this->targetSection;
		}
		if (!$sectionId)
		{
			return null;
		}

		$section = \XF::app()->em()->find(Section::class, $sectionId);
		if (!$section)
		{
			throw new \InvalidArgumentException("Invalid target section ($sectionId)");
		}

		$this->targetSectionId = $sectionId;
		$this->targetSection = $section;

		return $this->targetSection;
	}
}