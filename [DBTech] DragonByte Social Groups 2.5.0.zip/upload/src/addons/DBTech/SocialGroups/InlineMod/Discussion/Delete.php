<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\InlineMod\Discussion;

use DBTech\SocialGroups\Entity\Discussion;
use DBTech\SocialGroups\Service\Discussion\DeleterService;
use XF\Http\Request;
use XF\InlineMod\AbstractAction;
use XF\InputFilterer;
use XF\Mvc\Controller;
use XF\Mvc\Entity\AbstractCollection;
use XF\Mvc\Entity\Entity;
use XF\Mvc\Reply\AbstractReply;
use XF\Phrase;
use XF\PrintableException;

use function count;

/**
 * @extends AbstractAction<Discussion>
 */
class Delete extends AbstractAction
{
	/**
	 * @return Phrase
	 */
	public function getTitle()
	{
		return \XF::phrase('dbtech_social_groups_delete_discussions...');
	}

	/**
	 * @param Entity $entity
	 * @param array $options
	 * @param $error
	 *
	 * @return bool
	 */
	protected function canApplyToEntity(Entity $entity, array $options, &$error = null)
	{
		/** @var Discussion $entity */
		return $entity->canDelete($options['type'], $error);
	}

	/**
	 * @param Entity $entity
	 * @param array $options
	 *
	 * @throws PrintableException
	 */
	protected function applyToEntity(Entity $entity, array $options)
	{
		$deleter = \XF::app()->service(DeleterService::class, $entity);

		if ($options['alert'])
		{
			$deleter->setSendAlert(true, $options['alert_reason']);
		}

		$deleter->delete($options['type'], $options['reason']);

		if ($options['type'] == 'hard')
		{
			$this->returnUrl = \XF::app()->router('public')->buildLink('dbtech-social', $entity->Group);
		}
	}

	/**
	 * @return array
	 */
	public function getBaseOptions()
	{
		return [
			'type' => 'soft',
			'reason' => '',
			'alert' => false,
			'alert_reason' => '',
		];
	}

	/**
	 * @param AbstractCollection $entities
	 * @param Controller $controller
	 *
	 * @return AbstractReply
	 */
	public function renderForm(AbstractCollection $entities, Controller $controller)
	{
		$viewParams = [
			'discussions' => $entities,
			'total' => count($entities),
			'canHardDelete' => $this->canApply($entities, ['type' => 'hard']),
		];
		return $controller->view(
			'DBTech\SocialGroups:Public:InlineMod\Discussion\Delete',
			'dbtech_social_groups_inline_mod_discussion_delete',
			$viewParams
		);
	}

	/**
	 * @param AbstractCollection $entities
	 * @param Request $request
	 *
	 * @return array
	 */
	public function getFormOptions(AbstractCollection $entities, Request $request)
	{
		return [
			'type' => $request->filter('hard_delete', InputFilterer::BOOLEAN) ? 'hard' : 'soft',
			'reason' => $request->filter('reason', InputFilterer::STRING),
			'alert' => $request->filter('starter_alert', InputFilterer::BOOLEAN),
			'alert_reason' => $request->filter('starter_alert_reason', InputFilterer::STRING),
		];
	}
}