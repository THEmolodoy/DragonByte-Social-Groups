<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\InlineMod;

use DBTech\SocialGroups\Entity\Discussion;
use DBTech\SocialGroups\InlineMod\Discussion\Delete;
use DBTech\SocialGroups\InlineMod\Discussion\Move;
use DBTech\SocialGroups\Service\Discussion\ApproverService;
use XF\InlineMod\AbstractHandler;

/**
 * @extends AbstractHandler<Discussion>
 */
class DiscussionHandler extends AbstractHandler
{
	/**
	 * @return array
	 */
	public function getPossibleActions()
	{
		$actions = [];

		$actions['delete'] = $this->getActionHandler(Delete::class);

		$actions['undelete'] = $this->getSimpleActionHandler(
			\XF::phrase('dbtech_social_groups_undelete_discussions'),
			'canUndelete',
			function (Discussion $entity)
			{
				if ($entity->discussion_state == 'deleted')
				{
					$entity->discussion_state = 'visible';
					$entity->save();
				}
			}
		);

		$actions['approve'] = $this->getSimpleActionHandler(
			\XF::phrase('dbtech_social_groups_approve_discussions'),
			'canApproveUnapprove',
			function (Discussion $entity)
			{
				if ($entity->discussion_state == 'moderated')
				{
					$approver = \XF::app()->service(ApproverService::class, $entity);
					$approver->setNotifyRunTime(1); // may be a lot happening
					$approver->approve();
				}
			}
		);

		$actions['unapprove'] = $this->getSimpleActionHandler(
			\XF::phrase('dbtech_social_groups_unapprove_discussions'),
			'canApproveUnapprove',
			function (Discussion $entity)
			{
				if ($entity->discussion_state == 'visible')
				{
					$entity->discussion_state = 'moderated';
					$entity->save();
				}
			}
		);

		$actions['stick'] = $this->getSimpleActionHandler(
			\XF::phrase('dbtech_social_groups_stick_discussions'),
			'canStickUnstick',
			function (Discussion $entity)
			{
				$entity->sticky = true;
				$entity->save();
			}
		);

		$actions['unstick'] = $this->getSimpleActionHandler(
			\XF::phrase('dbtech_social_groups_unstick_discussions'),
			'canStickUnstick',
			function (Discussion $entity)
			{
				$entity->sticky = false;
				$entity->save();
			}
		);

		$actions['lock'] = $this->getSimpleActionHandler(
			\XF::phrase('dbtech_social_groups_lock_discussions'),
			'canLockUnlock',
			function (Discussion $entity)
			{
				$entity->discussion_open = false;
				$entity->save();
			}
		);

		$actions['unlock'] = $this->getSimpleActionHandler(
			\XF::phrase('dbtech_social_groups_unlock_discussions'),
			'canLockUnlock',
			function (Discussion $entity)
			{
				$entity->discussion_open = true;
				$entity->save();
			}
		);

		$actions['move'] = $this->getActionHandler(Move::class);
		//		$actions['merge'] = $this->getActionHandler(\DBTech\SocialGroups\InlineMod\Discussion\Merge::class);

		return $actions;
	}

	/**
	 * @return string[]
	 */
	public function getEntityWith()
	{
		$visitor = \XF::visitor();

		return [
			'Group',
			'Group.Permissions|' . $visitor->permission_combination_id,
		];
	}
}