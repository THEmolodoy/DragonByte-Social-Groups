<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\InlineMod;

use DBTech\SocialGroups\Entity\Message;
use DBTech\SocialGroups\InlineMod\Message\Delete;
use DBTech\SocialGroups\Service\Message\ApproverService;
use XF\InlineMod\AbstractHandler;

/**
 * @extends AbstractHandler<Message>
 */
class MessageHandler extends AbstractHandler
{
	/**
	 * @return array
	 */
	public function getPossibleActions()
	{
		$actions = [];

		$actions['delete'] = $this->getActionHandler(Delete::class);

		$actions['undelete'] = $this->getSimpleActionHandler(
			\XF::phrase('dbtech_social_groups_undelete_messages'),
			'canUndelete',
			function (Message $entity)
			{
				if ($entity->message_state == 'deleted')
				{
					$entity->message_state = 'visible';
					$entity->save();
				}
			}
		);

		$actions['approve'] = $this->getSimpleActionHandler(
			\XF::phrase('dbtech_social_groups_approve_messages'),
			'canApproveUnapprove',
			function (Message $entity)
			{
				if ($entity->isFirstMessage())
				{
					if ($entity->Discussion->discussion_state == 'moderated')
					{
						$entity->Discussion->discussion_state = 'visible';
						$entity->Discussion->save();
					}
				}
				else if ($entity->message_state == 'moderated')
				{
					$approver = \XF::app()->service(ApproverService::class, $entity);
					$approver->setNotifyRunTime(1); // may be a lot happening
					$approver->approve();
				}
			}
		);

		$actions['unapprove'] = $this->getSimpleActionHandler(
			\XF::phrase('dbtech_social_groups_unapprove_messages'),
			'canApproveUnapprove',
			function (Message $entity)
			{
				if ($entity->isFirstMessage())
				{
					if ($entity->Discussion->discussion_state == 'visible')
					{
						$entity->Discussion->discussion_state = 'moderated';
						$entity->Discussion->save();
					}
				}
				else if ($entity->message_state == 'visible')
				{
					$entity->message_state = 'moderated';
					$entity->save();
				}
			}
		);

		return $actions;
	}

	/**
	 * @return string[]
	 */
	public function getEntityWith()
	{
		$visitor = \XF::visitor();

		return [
			'Discussion',
			'Discussion.Group',
			'Discussion.Group.Permissions|' . $visitor->permission_combination_id,
		];
	}
}