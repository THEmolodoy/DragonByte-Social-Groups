<?php

namespace DBTech\SocialGroups\InlineMod\Thread;

use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Entity\Section;
use DBTech\SocialGroups\Job\ThreadImportProcess;
use DBTech\SocialGroups\Repository\GroupRepository;
use DBTech\SocialGroups\XF\Entity\User as ExtendedUserEntity;
use XF\Entity\Thread;
use XF\Http\Request;
use XF\InlineMod\AbstractAction;
use XF\InputFilterer;
use XF\Mvc\Controller;
use XF\Mvc\Entity\AbstractCollection;
use XF\Mvc\Entity\Entity;
use XF\Mvc\Reply\AbstractReply;
use XF\Phrase;

use function count;

/**
 * @extends AbstractAction<Thread>
 */
class Import extends AbstractAction
{
	protected Group $targetGroup;
	protected int $targetGroupId = 0;

	protected Section $targetSection;
	protected int $targetSectionId = 0;


	public function getTitle(): Phrase
	{
		return \XF::phrase('dbtech_social_groups_import_threads_to_social_group...');
	}

	/**
	 * @param AbstractCollection<Thread> $entities
	 * @param array $options
	 * @param $error
	 *
	 * @return bool
	 */
	protected function canApplyInternal(AbstractCollection $entities, array $options, &$error): bool
	{
		$visitor = \XF::visitor();

		if (!(
			$visitor->user_id
			&& $visitor->canImportThreadsToDbtechSocialGroups($error)
		))
		{
			return false;
		}

		return parent::canApplyInternal($entities, $options, $error);
	}

	/**
	 * @param Thread $entity
	 * @param array $options
	 * @param $error
	 *
	 * @return bool
	 */
	protected function canApplyToEntity(Entity $entity, array $options, &$error = null): bool
	{
		return $entity->canCopy($error);
	}

	/**
	 * @param Thread $entity
	 * @param array $options
	 *
	 * @return void
	 */
	protected function applyToEntity(Entity $entity, array $options): void
	{
		$group = $this->getTargetGroup($options['target_group_id']);
		if ($group === null)
		{
			throw new \InvalidArgumentException('No target social group specified');
		}

		$section = $this->getTargetSection($options['target_section_id']);
		if ($section !== null && $section->group_id !== $group->group_id)
		{
			throw new \InvalidArgumentException("Target section's group does not match the target group");
		}

		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		if (!$visitor->canDeleteThreadsImportedToDbtechSocialGroups() && $options['cleanup_type'] !== 'do_nothing')
		{
			throw new \LogicException("You don't have permission to delete the imported threads");
		}

		if (!$visitor->canDeleteThreadsImportedToDbtechSocialGroups('hard') && $options['cleanup_type'] === 'hard')
		{
			throw new \LogicException("You don't have permission to hard-delete the imported threads");
		}

		$jobManager = \XF::app()->jobManager();
		$jobManager->enqueueAutoBlocking(ThreadImportProcess::class, [
			'actorId' => $visitor->user_id,
			'threadId' => $entity->thread_id,
			'threadTitle' => $entity->title,
			'userId' => $entity->FirstPost->user_id,
			'username' => $entity->FirstPost->username,
			'groupId' => $group->group_id,
			'sectionId' => $section?->section_id,

			'cleanUpType' => $options['cleanup_type'],
			'reason' => $options['reason'],
		]);
		$jobManager->setAutoBlockingMessage(\XF::phrase('dbtech_social_groups_processing_thread_import...'));

		$router = \XF::app()->router('public');
		if ($section)
		{
			$this->returnUrl = $router->buildLink('dbtech-social/sections', $section);
		}
		else
		{
			$this->returnUrl = $router->buildLink('dbtech-social/discussions/list', $group);
		}
	}

	public function getBaseOptions(): array
	{
		return [
			'target_group_id' => 0,
			'target_section_id' => 0,
			'cleanup_type' => 'do_nothing',
			'reason' => '',
		];
	}

	/**
	 * @param AbstractCollection<Thread> $entities
	 * @param Controller $controller
	 *
	 * @return AbstractReply|null
	 */
	public function renderForm(AbstractCollection $entities, Controller $controller): ?AbstractReply
	{
		$groups = \XF::repository(GroupRepository::class)
			->getFullGroupList()
			->filter(fn (Group $group) => $group->canImportThreads())
		;

		$viewParams = [
			'threads' => $entities,
			'total' => count($entities),
			'first' => $entities->first(),
			'groups' => $groups,
			'canDelete' => \XF::visitor()->canDeleteThreadsImportedToDbtechSocialGroups(),
			'canHardDelete' => \XF::visitor()->canDeleteThreadsImportedToDbtechSocialGroups('hard'),
		];

		return $controller->view(
			'XF:Public:InlineMod\Thread\Import',
			'dbtech_social_groups_inline_mod_thread_import',
			$viewParams
		);
	}

	/**
	 * @param AbstractCollection<Thread> $entities
	 * @param Request $request
	 *
	 * @return array
	 */
	public function getFormOptions(AbstractCollection $entities, Request $request): array
	{
		return [
			'target_group_id' => $request->filter('target_group_id', InputFilterer::UINT),
			'target_section_id' => $request->filter('target_section_id', InputFilterer::UINT),
			'cleanup_type' => $request->filter('cleanup_type', InputFilterer::STRING),
			'reason' => $request->filter('reason', InputFilterer::STRING),
		];
	}

	protected function getTargetGroup(int $groupId): ?Group
	{
		if ($groupId === 0)
		{
			return null;
		}
		if ($this->targetGroupId === $groupId)
		{
			return $this->targetGroup;
		}

		$group = \XF::em()->find(Group::class, $groupId);
		if ($group === null)
		{
			throw new \InvalidArgumentException("Invalid target social group ($groupId)");
		}

		$this->targetGroupId = $groupId;
		$this->targetGroup = $group;

		return $this->targetGroup;
	}

	protected function getTargetSection(int $sectionId): ?Section
	{
		if ($sectionId === 0)
		{
			return null;
		}
		if ($this->targetSectionId === $sectionId)
		{
			return $this->targetSection;
		}

		$section = \XF::em()->find(Section::class, $sectionId);
		if ($section === null)
		{
			throw new \InvalidArgumentException("Invalid target social group section ($sectionId)");
		}

		$this->targetSectionId = $sectionId;
		$this->targetSection = $section;

		return $this->targetSection;
	}
}