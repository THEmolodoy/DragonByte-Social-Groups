<?php

namespace DBTech\SocialGroups\Seed;

use TickTackk\Seeder\Seed\AbstractContentReaction;

class SocialGroupMessageReaction extends AbstractContentReaction
{
	protected function getEntityShortName(): string
	{
		return 'DBTech\SocialGroups:Message';
	}

	protected function getUserIdColumn(): string
	{
		return 'user_id';
	}

	protected function getReactionRelationName(): string
	{
		return 'Reactions';
	}
}