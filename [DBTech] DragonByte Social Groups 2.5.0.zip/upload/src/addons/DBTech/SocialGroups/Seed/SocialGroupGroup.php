<?php

namespace DBTech\SocialGroups\Seed;

use DBTech\SocialGroups\Entity\Group;
use TickTackk\Seeder\Seed\AbstractSeed;
use XF\PrintableException;

class SocialGroupGroup extends AbstractSeed
{
	/**
	 * @param array $params
	 *
	 * @return array
	 */
	protected function getGroupInput(array $params = []): array
	{
		$faker = $this->faker();

		switch ($faker->numberBetween(0, 3))
		{
			default:
			case 0:
				$groupType = 'public';
				break;

			case 1:
				$groupType = 'closed';
				break;

			case 2:
				$groupType = 'private';
				break;

			case 3:
				$groupType = 'hidden';
				break;
		}

		$input = [
			'title' => ucwords($faker->words(3, true)),
			'tagline' => $faker->text,
			'description' => $faker->paragraph,
			'rules' => $faker->paragraph,
			'group_type' => $groupType,
			'group_state' => !empty($params['onlyVisible']) ? 'visible' : ($faker->boolean ? 'visible' : 'moderated'),
			'allow_posting' => $faker->boolean,
			'allow_discussions' => $faker->boolean,
			'allow_poll' => $faker->boolean,
			'allow_members' => $faker->boolean,
			'moderate_members' => $faker->boolean,
			'find_new' => $faker->boolean,
			'allowed_watch_notifications' => 'all',
			'default_sort_order' => 'last_message_date',
			'default_sort_direction' => 'desc',
		];

		if (!(\XF::options()->dbtechSocialEnabledGroupOwnerFeatures['moderation'] ?? true))
		{
			$input['moderate_discussions'] = false;
			$input['moderate_replies'] = false;
		}
		else
		{
			$input['moderate_discussions'] = $faker->boolean;
			$input['moderate_replies'] = $faker->boolean;
		}

		if (!(\XF::options()->dbtechSocialEnabledGroupOwnerFeatures['min_tags'] ?? true))
		{
			$input['min_tags'] = 0;
		}
		else
		{
			$input['min_tags'] = $faker->numberBetween(0, 100);
		}

		if (!(\XF::options()->dbtechSocialEnabledGroupOwnerFeatures['list_date_limit_days'] ?? true))
		{
			$input['list_date_limit_days'] = 0;
		}
		else
		{
			$input['list_date_limit_days'] = $faker->numberBetween(0, 3650);
		}

		return $input;
	}

	/**
	 * @param array $params
	 *
	 * @return bool
	 * @throws PrintableException
	 */
	protected function seed(array $params = []): bool
	{
		$group = \XF::app()->em()->create(Group::class);
		$group->user_id = \XF::visitor()->user_id;
		$group->username = \XF::visitor()->username;
		$group->setOption('admin_edit', true);

		$form = \XF::app()->formAction();
		$form->basicEntitySave($group, $this->getGroupInput($params));

		if (!$form->run())
		{
			return false;
		}

		return true;
	}

	public function postSeed(): void
	{
		\XF::app()->jobManager()->runUnique('permissionRebuild', $this->config('jobMaxRunTime'));
	}
}