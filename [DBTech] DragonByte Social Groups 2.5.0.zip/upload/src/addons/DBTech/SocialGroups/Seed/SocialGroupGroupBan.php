<?php

namespace DBTech\SocialGroups\Seed;

use DBTech\SocialGroups\Finder\GroupFinder;
use DBTech\SocialGroups\Repository\BanningRepository;
use TickTackk\Seeder\Seed\AbstractSeed;
use XF\Entity\User as UserEntity;
use XF\Finder\User;
use XF\Finder\User as UserFinder;
use XF\Mvc\Entity\Finder;
use XF\PrintableException;

class SocialGroupGroupBan extends AbstractSeed
{
	/**
	 * @param User $userFinder
	 *
	 * @return User
	 */
	protected function setupVisitorFinder(UserFinder $userFinder): UserFinder
	{
		return $userFinder
			->where('is_admin', false)
			->where('is_moderator', false)
			->where('is_staff', false)
			->where('is_banned', false)
		;
	}

	/**
	 * @return UserEntity
	 * @noinspection PhpIncompatibleReturnTypeInspection
	 */
	protected function findRandomModOrAdmin(): UserEntity
	{
		return \XF::app()->finder(UserFinder::class)
			->order(Finder::ORDER_RANDOM)
			->whereOr(['is_admin', true], ['is_moderator', true])
			->fetchOne();
	}

	/**
	 * @param array $params
	 *
	 * @return bool
	 * @throws PrintableException
	 */
	protected function seed(array $params = []): bool
	{
		$randomGroup = \XF::app()->finder(GroupFinder::class)
			->order(Finder::ORDER_RANDOM)
			->where('group_state', 'visible')
			->fetchOne()
		;
		if (!$randomGroup)
		{
			return false;
		}

		$faker = $this->faker();
		$error = null;

		$retval = \XF::app()->repository(BanningRepository::class)->banUserFromGroup(
			\XF::visitor(),
			$randomGroup,
			$faker->boolean ? $faker->dateTimeInInterval('+' . $faker->numberBetween(1, 10) . ' years')->getTimestamp() : 0,
			$faker->boolean ? $faker->text : '',
			$error,
			$this->findRandomModOrAdmin()
		);

		if (!$retval)
		{
			echo $error;
		}

		return $retval;
	}
}