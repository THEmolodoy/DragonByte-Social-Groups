<?php

namespace DBTech\SocialGroups\Seed;

use DBTech\SocialGroups\Finder\GroupFinder;
use DBTech\SocialGroups\Repository\DiscussionRepository;
use DBTech\SocialGroups\Repository\DiscussionWatchRepository;
use DBTech\SocialGroups\Service\Discussion\CreatorService;
use Faker\Provider\Lorem;
use TickTackk\Seeder\Seed\AbstractSeed;
use XF\Db\DeadlockException;
use XF\Mvc\Entity\Finder;
use XF\PrintableException;

class SocialGroupDiscussion extends AbstractSeed
{
	/**
	 * @param array $params
	 *
	 * @return bool
	 * @throws DeadlockException
	 * @throws PrintableException
	 */
	protected function seed(array $params = []): bool
	{
		$randomGroup = \XF::app()->finder(GroupFinder::class)
			->order(Finder::ORDER_RANDOM)
			->where('group_state', 'visible')
			->fetchOne()
		;
		if (!$randomGroup)
		{
			return false;
		}

		$faker = $this->faker();

		$discussionCreator = \XF::app()->service(
			CreatorService::class,
			$randomGroup
		);
		$discussionCreator->setIsAutomated();

		if ($faker->boolean)
		{
			$discussionCreator->logIp($faker->boolean ? $faker->ipv6 : $faker->ipv4);
		}

		/*
		if ($faker->boolean)
		{
			$prefixIds = $randomGroup->getPrefixes()->keys();
			if ($prefixIds)
			{
				$discussionCreator->setPrefix($prefixIds[array_rand($prefixIds)]);
			}
		}
		*/

		$discussionCreator->setTags($faker->words($faker->numberBetween(10, 15)));
		$discussionCreator->setContent(Lorem::sentence(), $faker->text);
		if (!$discussionCreator->validate($errors))
		{
			return false;
		}

		if (!$discussionCreator->save())
		{
			return false;
		}

		$discussionWatchRepo = \XF::app()->repository(DiscussionWatchRepository::class);
		$discussionRepo = \XF::app()->repository(DiscussionRepository::class);

		$discussion = $discussionCreator->getDiscussion();
		$visitor = \XF::visitor();

		if ($this->faker()->boolean)
		{
			if ($this->faker()->boolean)
			{
				$watchState = $this->faker()->boolean ? 'watch_email' : 'watch_no_email';
				$discussionWatchRepo->setWatchState($discussion, $visitor, $watchState);
			}
		}
		else
		{
			// use user preferences
			$discussionWatchRepo->autoWatchDiscussion($discussion, $visitor, true);
		}

		$discussionRepo->markDiscussionReadByVisitor($discussion, $discussion->message_date);

		return true;
	}
}