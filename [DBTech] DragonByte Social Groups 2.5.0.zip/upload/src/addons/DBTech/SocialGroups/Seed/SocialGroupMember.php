<?php

namespace DBTech\SocialGroups\Seed;

use DBTech\SocialGroups\Finder\GroupFinder;
use DBTech\SocialGroups\Repository\GroupMemberRepository;
use DBTech\SocialGroups\XF\Entity\User as ExtendedUserEntity;
use TickTackk\Seeder\Seed\AbstractSeed;
use XF\Mvc\Entity\Finder;
use XF\PrintableException;

class SocialGroupMember extends AbstractSeed
{
	/**
	 * @param array $params
	 *
	 * @return bool
	 * @throws PrintableException
	 */
	protected function seed(array $params = []): bool
	{
		$randomGroup = \XF::app()->finder(GroupFinder::class)
			->order(Finder::ORDER_RANDOM)
			->fetchOne()
		;
		if (!$randomGroup)
		{
			return false;
		}

		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();
		if ($visitor->SocialGroupMemberships[$randomGroup->group_id])
		{
			return false;
		}

		$faker = $this->faker();

		\XF::app()->repository(GroupMemberRepository::class)
			->joinGroup(
				$randomGroup,
				\XF::visitor(),
				true,
				$faker->boolean ? $faker->text : ''
			)
		;

		return true;
	}
}