<?php

namespace DBTech\SocialGroups\Seed;

use DBTech\SocialGroups\Finder\GroupFinder;
use DBTech\SocialGroups\Repository\GroupMemberRepository;
use DBTech\SocialGroups\Repository\GroupPermissionsRepository;
use DBTech\SocialGroups\XF\Entity\User as ExtendedUserEntity;
use TickTackk\Seeder\Seed\AbstractSeed;
use XF\Mvc\Entity\Finder;
use XF\PrintableException;

class SocialGroupSupervisor extends AbstractSeed
{
	/**
	 * @param array $params
	 *
	 * @return bool
	 * @throws PrintableException
	 */
	protected function seed(array $params = []): bool
	{
		$randomGroup = \XF::app()->finder(GroupFinder::class)
			->order(Finder::ORDER_RANDOM)
			->fetchOne()
		;
		if (!$randomGroup)
		{
			return false;
		}

		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();
		if (!$visitor->SocialGroupMemberships[$randomGroup->group_id])
		{
			$faker = $this->faker();

			\XF::app()->repository(GroupMemberRepository::class)
				->joinGroup(
					$randomGroup,
					\XF::visitor(),
					true,
					$faker->boolean ? $faker->text : ''
				)
			;
		}
		else if ($visitor->SocialGroupMemberships[$randomGroup->group_id]->is_supervisor)
		{
			return false;
		}

		$maximumPermissions = \json_decode(
			\XF::app()->options()->dbtechSocialDefaultPermissions['groupModerators'] ?: '[]',
			true
		);

		\XF::app()->repository(GroupPermissionsRepository::class)->addModeratorPermissionsForGroup(
			$visitor,
			$randomGroup,
			$maximumPermissions
		);

		return true;
	}

	public function postSeed(): void
	{
		\XF::app()->jobManager()->runUnique('permissionRebuild', $this->config('jobMaxRunTime'));
	}
}