<?php

namespace DBTech\SocialGroups\Seed;

use DBTech\SocialGroups\Finder\DiscussionFinder;
use DBTech\SocialGroups\Repository\DiscussionWatchRepository;
use DBTech\SocialGroups\Service\Discussion\ReplierService;
use TickTackk\Seeder\Seed\AbstractSeed;
use XF\Mvc\Entity\Finder;
use XF\PrintableException;

class SocialGroupMessage extends AbstractSeed
{
	/**
	 * @param array $params
	 *
	 * @return bool
	 * @throws PrintableException
	 */
	protected function seed(array $params = []): bool
	{
		$randomDiscussion = \XF::app()->finder(DiscussionFinder::class)
			->order(Finder::ORDER_RANDOM)
			->fetchOne()
		;
		if (!$randomDiscussion)
		{
			return false;
		}

		$faker = $this->faker();

		$discussionReplier = \XF::app()->service(
			ReplierService::class,
			$randomDiscussion
		);
		$discussionReplier->setIsAutomated();

		if ($faker->boolean)
		{
			$discussionReplier->logIp($faker->boolean ? $faker->ipv6 : $faker->ipv4);
		}

		$discussionReplier->setMessageContent($faker->text);

		if (!$discussionReplier->validate())
		{
			return false;
		}

		$discussionReplier->save();
		$discussionReplier->sendNotifications();

		if ($this->faker()->boolean)
		{
			$discussionWatchRepo = \XF::app()->repository(DiscussionWatchRepository::class);
			$visitor = \XF::visitor();

			if ($this->faker()->boolean)
			{
				$watchState = $this->faker()->boolean ? 'watch_no_email' : 'watch_email';
				$discussionWatchRepo->setWatchState($randomDiscussion, $visitor, $watchState);
			}
			else
			{
				// use user preferences
				$discussionWatchRepo->autoWatchDiscussion($randomDiscussion, $visitor);
			}
		}

		return true;
	}
}