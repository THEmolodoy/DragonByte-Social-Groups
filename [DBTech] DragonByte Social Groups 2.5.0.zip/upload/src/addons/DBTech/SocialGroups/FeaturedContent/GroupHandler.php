<?php

namespace DBTech\SocialGroups\FeaturedContent;

use DBTech\SocialGroups\Entity\Group;
use XF\FeaturedContent\AbstractHandler;
use XF\Mvc\Entity\Entity;

/**
 * @extends AbstractHandler<Group>
 */
class GroupHandler extends AbstractHandler
{
	public function getContentContainerId(Entity $content): int
	{
		return 0;
	}

	public function getContentImage(Entity $content, ?string $sizeCode = null): ?string
	{
		return $content->getIconUrl($sizeCode ?? 'o');
	}

	public function getContentSnippet(Entity $content): string
	{
		return $this->getSnippetFromString($content->description ?? null);
	}

	/**
	 * @throws \Exception
	 */
	public function getContentStructuredData(Entity $content): array
	{
		return $content->getStructuredData();
	}

	public function getEntityWith(): array
	{
		$visitor = \XF::visitor();

		return [
			'full',
		];
	}
}