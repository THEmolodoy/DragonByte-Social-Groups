<?php

namespace DBTech\SocialGroups\Entity;

use XF\Entity\User;
use XF\Mvc\Entity\Entity;
use XF\Mvc\Entity\Structure;

/**
 * COLUMNS
 * @property int|null $discussion_read_id
 * @property int $user_id
 * @property int $discussion_id
 * @property int $discussion_read_date
 *
 * RELATIONS
 * @property-read User|null $User
 * @property-read Discussion|null $Discussion
 */
class DiscussionRead extends Entity
{
	/**
	 * @param Structure $structure
	 *
	 * @return Structure
	 */
	public static function getStructure(Structure $structure): Structure
	{
		$structure->table = 'xf_dbtech_social_groups_discussion_read';
		$structure->shortName = 'DBTech\SocialGroups:DiscussionRead';
		$structure->primaryKey = 'discussion_read_id';
		$structure->columns = [
			'discussion_read_id' => ['type' => self::UINT, 'autoIncrement' => true, 'nullable' => true],
			'user_id' => ['type' => self::UINT, 'required' => true],
			'discussion_id' => ['type' => self::UINT, 'required' => true],
			'discussion_read_date' => ['type' => self::UINT, 'required' => true],
		];
		$structure->getters = [];
		$structure->relations = [
			'User' => [
				'entity' => User::class,
				'type' => self::TO_ONE,
				'conditions' => 'user_id',
				'primary' => true,
			],
			'Discussion' => [
				'entity' => Discussion::class,
				'type' => self::TO_ONE,
				'conditions' => 'discussion_id',
				'primary' => true,
			],
		];

		return $structure;
	}
}