<?php

namespace DBTech\SocialGroups\Entity;

use DBTech\SocialGroups\Repository\GroupRepository;
use DBTech\SocialGroups\XF\Entity\User as ExtendedUserEntity;
use XF\Mvc\Entity\Entity;
use XF\Mvc\Entity\Structure;
use XF\PrintableException;
use XFMG\Entity\Album;
use XFMG\Entity\Category;
use XFMG\Service\Album\Mover;

/**
 * COLUMNS
 * @property int $group_id
 * @property int $album_id
 * @property int $existing_category_id
 *
 * RELATIONS
 * @property-read Group|null $Group
 * @property-read Album|null $Album
 * @property-read Category|null $ExistingCategory
 */
class GroupAlbum extends Entity
{
	/**
	 * @return void
	 */
	protected function _preSave(): void
	{
		/** @var Album $album */
		$album = $this->Album;

		if ($album && !$this->getOption('initialCreate'))
		{
			$this->existing_category_id = $album->category_id;
		}
	}

	/**
	 * @return void
	 * @throws PrintableException
	 */
	protected function _postSave(): void
	{
		/** @var Album $album */
		$album = $this->Album;

		if ($album)
		{
			if (!$this->getOption('initialCreate'))
			{
				$categoryId = \XF::options()->dbtechSocialMediaGalleryCategoryId;
				$category = $categoryId ? \XF::app()->em()->find(Category::class, $categoryId) : null;

				\XF::runLater(function () use ($album, $category)
				{
					$mover = \XF::app()->service(Mover::class, $album);
					$mover->move($category);
				});
			}

			if ($album->User && $album->user_id !== \XF::visitor()->user_id)
			{
				\XF::app()->repository(GroupRepository::class)
					->sendModeratorActionAlert(
						$this->Group,
						'link',
						'',
						[
							'album' => $album->title,
							'albumLink' => \XF::app()->router('public')->buildLink('nopath:media/albums', $album),
						],
						$album->User
					)
				;
			}

			if ($album->isVisible() && $this->getOption('updateMembership'))
			{
				/** @var ExtendedUserEntity $user */
				$user = $album->User;

				/** @var GroupMember $groupMembership */
				$groupMembership = $user->SocialGroupMemberships[$this->group_id];

				if ($groupMembership)
				{
					$groupMembership->albumAdded($album);
					$groupMembership->save();
				}
			}
		}
	}

	/**
	 * @return void
	 * @throws PrintableException
	 */
	protected function _postDelete(): void
	{
		/** @var Album $album */
		$album = $this->Album;

		if ($album)
		{
			if ($album->exists())
			{
				// Check exists in case this album is being deleted

				$categoryId = $this->existing_category_id;
				$category = $categoryId ? \XF::app()->em()->find(Category::class, $categoryId) : null;

				if ($category && $category->category_type !== 'album')
				{
					$category = null;
				}

				$mover = \XF::app()->service(Mover::class, $album);
				$mover->addExtraSetup(function (Album $album, ?Category $category)
				{
					$album->view_privacy = 'private';
					$album->add_privacy = 'private';
				});
				$mover->move($category);

				if ($album->User && $album->user_id !== \XF::visitor()->user_id)
				{
					\XF::app()->repository(GroupRepository::class)
						->sendModeratorActionAlert(
							$this->Group,
							'unlink',
							'',
							[
								'album' => $album->title,
								'albumLink' => \XF::app()->router('public')->buildLink('nopath:media/albums', $album),
							],
							$album->User
						)
					;
				}
			}

			if ($album->isVisible() && $this->getOption('updateMembership'))
			{
				/** @var ExtendedUserEntity $user */
				$user = $album->User;

				/** @var GroupMember $groupMembership */
				$groupMembership = $user->SocialGroupMemberships[$this->group_id];

				if ($groupMembership)
				{
					$groupMembership->albumRemoved($album);
					$groupMembership->save();
				}
			}
		}
	}

	/**
	 * @param Structure $structure
	 *
	 * @return Structure
	 */
	public static function getStructure(Structure $structure): Structure
	{
		$structure->table = 'xf_dbtech_social_groups_group_album';
		$structure->shortName = 'DBTech\SocialGroups:GroupAlbum';
		$structure->primaryKey = ['group_id', 'album_id'];
		$structure->columns = [
			'group_id'             => ['type' => self::UINT, 'required' => true],
			'album_id'             => ['type' => self::UINT, 'required' => true],
			'existing_category_id' => ['type' => self::UINT, 'default' => 0],
		];
		$structure->getters = [];
		$structure->relations = [
			'Group' => [
				'entity'     => Group::class,
				'type'       => self::TO_ONE,
				'conditions' => 'group_id',
				'primary'    => true,
			],
			'Album' => [
				'entity'     => Album::class,
				'type'       => self::TO_ONE,
				'conditions' => 'album_id',
				'primary'    => true,
			],
			'ExistingCategory' => [
				'entity'     => Category::class,
				'type'       => self::TO_ONE,
				'conditions' => [
					['category_id', '=', '$existing_category_id'],
				],
				'primary'    => true,
			],
		];
		$structure->options = [
			'initialCreate' => false,
			'updateMembership' => true,
		];

		return $structure;
	}
}