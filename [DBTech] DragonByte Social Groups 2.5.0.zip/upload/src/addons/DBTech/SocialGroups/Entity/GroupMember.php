<?php

namespace DBTech\SocialGroups\Entity;

use DBTech\SocialGroups\Repository\GroupInviteRepository;
use DBTech\SocialGroups\Repository\GroupMemberRepository;
use DBTech\SocialGroups\XF\Entity\User as ExtendedUserEntity;
use NF\Calendar\Entity\Event;
use XF\Entity\ApprovalQueue;
use XF\Entity\User;
use XF\Entity\ViewableInterface;
use XF\Mvc\Entity\Entity;
use XF\Mvc\Entity\Structure;
use XF\PrintableException;
use XF\Repository\UserAlertRepository;
use XFMG\Entity\Album;
use XFMG\Entity\MediaItem;

/**
 * COLUMNS
 * @property int|null $group_member_id
 * @property int $user_id
 * @property int $group_id
 * @property int $join_date
 * @property int $last_activity_date
 * @property int $last_message_date
 * @property int $last_media_upload_date
 * @property int $last_event_creation_date
 * @property bool $is_supervisor
 * @property string $member_state
 * @property int $message_count
 * @property int $album_count
 * @property int $media_count
 * @property int $event_count
 * @property array|null $permissions
 * @property string $reason
 *
 * RELATIONS
 * @property-read Group|null $Group
 * @property-read User|null $User
 * @property-read GroupInvite|null $Invitation
 * @property-read ApprovalQueue|null $ApprovalQueue
 */
class GroupMember extends Entity implements ViewableInterface
{
	/**
	 * @return bool
	 */
	public function canView(): bool
	{
		$group = $this->Group;
		if (!$group)
		{
			return false;
		}

		return (
			($this->isValid() || $this->canApproveUnapprove())
			&& $group->canViewMemberList()
		);
	}

	/**
	 * @return bool
	 */
	public function canViewLastActivity(): bool
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		if (!$this->last_activity_date)
		{
			return false;
		}

		if ($this->Group->isGroupOwner() || $visitor->isSupervisorOfSocialGroup($this->Group))
		{
			return true;
		}

		if ($this->User->visible || $this->user_id === $visitor->user_id)
		{
			return true;
		}

		return $visitor->canBypassUserPrivacy();
	}

	/**
	 * @return bool
	 */
	public function isValid(): bool
	{
		return $this->member_state === 'valid';
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canApproveUnapprove(&$error = null): bool
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();
		return ($visitor->user_id
			&& $visitor->hasDbtechSocialGroupsGroupPermission($this->group_id, 'approveRejectMembers')
		);
	}

	/**
	 * @return bool
	 */
	public function rebuildCounters(): bool
	{
		$this->rebuildMessageCount();
		$this->rebuildAlbumCount();
		$this->rebuildMediaCount();
		$this->rebuildEventCount();

		$this->rebuildLastMessageDate();
		$this->rebuildLastMediaUploadDate();
		$this->rebuildLastEventCreationDate();

		$this->rebuildLastActivityDate();

		return true;
	}

	public function rebuildMessageCount(): int
	{
		$this->message_count = (int) $this->db()->fetchOne("
			SELECT COUNT(*) AS message_count
			FROM xf_dbtech_social_groups_message AS message
			LEFT JOIN xf_dbtech_social_groups_discussion AS discussion USING(discussion_id)
			WHERE discussion.group_id = ?
				AND message.user_id = ?
				AND message.message_state = 'visible'
		", [$this->group_id, $this->user_id]);

		return $this->message_count;
	}

	/**
	 * @return int
	 */
	public function rebuildAlbumCount(): int
	{
		if (\XF::isAddOnActive('XFMG'))
		{
			$this->album_count = (int) $this->db()->fetchOne("
				SELECT COUNT(*) AS album_count
				FROM xf_mg_album AS mg_album
				LEFT JOIN xf_dbtech_social_groups_group_album AS group_album USING(album_id)
				WHERE group_album.group_id = ?
					AND mg_album.user_id = ?
					AND mg_album.album_state = 'visible'
			", [$this->group_id, $this->user_id]);

			return $this->album_count;
		}

		return 0;
	}

	/**
	 * @return int
	 */
	public function rebuildMediaCount(): int
	{
		if (\XF::isAddOnActive('XFMG'))
		{
			$this->media_count = (int) $this->db()->fetchOne("
				SELECT COUNT(*) AS media_count
				FROM xf_mg_media_item AS mg_item
				LEFT JOIN xf_mg_album AS mg_album USING(album_id)
				LEFT JOIN xf_dbtech_social_groups_group_album AS group_album USING(album_id)
				WHERE group_album.group_id = ?
					AND mg_item.user_id = ?
					AND mg_item.media_state = 'visible'
					AND mg_album.album_state = 'visible'
			", [$this->group_id, $this->user_id]);

			return $this->media_count;
		}

		return 0;
	}

	public function rebuildEventCount(): int
	{
		if (\XF::isAddOnActive('NF/Calendar', 2060070)
			&& $this->Group->calendar_id
		)
		{
			$this->event_count = (int) $this->db()->fetchOne("
			SELECT COUNT(*) AS event_count
			FROM xf_nf_calendar_event AS calendar_event
			WHERE calendar_event.category_id = ?
				AND calendar_event.user_id = ?
				AND calendar_event.event_state = 'visible'
		", [$this->Group->calendar_id, $this->user_id]);

			return $this->event_count;
		}

		return 0;
	}

	public function rebuildLastMessageDate(): int
	{
		$this->last_message_date = (int) $this->db()->fetchOne("
			SELECT MAX(message.message_date) AS last_message_date
			FROM xf_dbtech_social_groups_message AS message
			LEFT JOIN xf_dbtech_social_groups_discussion AS discussion USING(discussion_id)
			WHERE discussion.group_id = ?
				AND message.user_id = ?
				AND message.message_state = 'visible'
		", [$this->group_id, $this->user_id]);

		return $this->last_message_date;
	}

	public function rebuildLastMediaUploadDate(): int
	{
		if (\XF::isAddOnActive('XFMG'))
		{
			$this->last_media_upload_date = (int) $this->db()->fetchOne("
				SELECT MAX(media_date) AS last_media_upload_date
				FROM xf_mg_media_item AS mg_item
				LEFT JOIN xf_mg_album AS mg_album USING(album_id)
				LEFT JOIN xf_dbtech_social_groups_group_album AS group_album USING(album_id)
				WHERE group_album.group_id = ?
					AND mg_item.user_id = ?
					AND mg_item.media_state = 'visible'
					AND mg_album.album_state = 'visible'
			", [$this->group_id, $this->user_id]);

			return $this->last_media_upload_date;
		}

		return 0;
	}

	public function rebuildLastEventCreationDate(): int
	{
		if (\XF::isAddOnActive('NF/Calendar', 2060070)
			&& $this->Group->calendar_id
		)
		{
			$this->last_event_creation_date = (int) $this->db()->fetchOne("
			SELECT MAX(created_date) AS last_event_creation_date
			FROM xf_nf_calendar_event AS calendar_event
			WHERE calendar_event.category_id = ?
				AND calendar_event.user_id = ?
				AND calendar_event.event_state = 'visible'
		", [$this->Group->calendar_id, $this->user_id]);

			return $this->last_event_creation_date;
		}

		return 0;
	}

	/**
	 * @return int
	 */
	public function rebuildLastActivityDate(): int
	{
		$this->last_activity_date = max(
			$this->last_activity_date,
			$this->join_date,
			$this->last_message_date,
			$this->last_media_upload_date,
			$this->last_event_creation_date
		);

		return $this->last_activity_date;
	}

	/**
	 * @param Message $message
	 */
	public function messageAdded(Message $message): void
	{
		$this->message_count++;
	}

	/**
	 * @param Message $message
	 */
	public function messageRemoved(Message $message): void
	{
		$this->message_count--;
	}

	/**
	 * @param Album $album
	 */
	public function albumAdded(Album $album): void
	{
		$this->album_count++;
	}

	/**
	 * @param Album $album
	 */
	public function albumRemoved(Album $album): void
	{
		$this->album_count--;
	}

	/**
	 * @param MediaItem $mediaItem
	 */
	public function mediaItemAdded(MediaItem $mediaItem): void
	{
		$this->media_count++;

		if ($mediaItem->isInsert())
		{
			$this->last_media_upload_date = \XF::$time;
		}
	}

	/**
	 * @param MediaItem $mediaItem
	 */
	public function mediaItemRemoved(MediaItem $mediaItem): void
	{
		$this->media_count--;
	}

	/**
	 * @param Event $event
	 */
	public function eventAdded(Event $event): void
	{
		$this->event_count++;

		if ($event->isInsert())
		{
			$this->last_event_creation_date = \XF::$time;
		}
	}

	/**
	 * @param Event $event
	 */
	public function eventRemoved(Event $event): void
	{
		$this->event_count--;
	}

	/**
	 * @throws PrintableException
	 */
	protected function updateGroupRecord(): void
	{
		if (!$this->Group || !$this->Group->exists())
		{
			return;
		}

		/** @var Group $group */
		$group = $this->Group;

		// check for member entering/leaving visible
		$visibilityChange = $this->isStateChanged('member_state', 'valid');
		if ($visibilityChange == 'enter')
		{
			$group->memberAdded($this);
			$group->save();
		}
		else if ($visibilityChange == 'leave')
		{
			$group->memberRemoved($this);
			$group->save();
		}
	}

	/**
	 *
	 */
	protected function _preSave(): void
	{
		$groupMember = \XF::app()->em()->findOne(GroupMember::class, [
			'user_id' => $this->user_id,
			'group_id' => $this->group_id,
		]);
		if ($groupMember && $groupMember !== $this)
		{
			$this->error(\XF::phrase('all_x_values_must_be_unique', ['key' => 'user_id']));
			return;
		}

		if (!$this->Group)
		{
			$this->error(\XF::phrase('dbtech_social_groups_requested_group_not_found'), 'group_id');
			return;
		}

		if ($this->isInsert())
		{
			// Always run this on insert just in case of leave/rejoin
			$this->rebuildCounters();

			if ($this->user_id === $this->Group->user_id)
			{
				$this->is_supervisor = true;
			}
			else if (
				!$this->isChanged('member_state')
				&& !$this->Invitation
			)
			{
				$this->member_state = $this->Group->moderate_members ? 'moderated' : 'valid';
			}
		}
	}

	/**
	 * @return void
	 * @throws PrintableException
	 * @throws \Exception
	 */
	protected function _postSave(): void
	{
		$groupMemberRepo = \XF::app()->repository(GroupMemberRepository::class);
		$approvalChange = $this->isStateChanged('member_state', 'moderated');

		if ($this->isUpdate())
		{
			if ($this->User && $this->isChanged('member_state'))
			{
				/** @var ExtendedUserEntity $user */
				$user = $this->User;
				$user->updateDbtechSocialGroupCounters();
				$user->save();
			}

			if ($this->getOption('send_alert'))
			{
				$supervisorChange = $this->isStateChanged('is_supervisor', true);
				if ($supervisorChange == 'enter')
				{
					$groupMemberRepo->sendModeratorActionAlert($this, 'modadd');
				}

				if ($supervisorChange == 'leave')
				{
					$groupMemberRepo->sendModeratorActionAlert($this, 'modremove');
				}
			}

			if ($approvalChange == 'leave' && $this->ApprovalQueue)
			{
				$this->ApprovalQueue->delete();
			}
		}
		else if ($this->Invitation)
		{
			\XF::app()->repository(GroupInviteRepository::class)
				->sendInviteAcceptAlert($this->Invitation)
			;

			$this->Invitation->delete();
		}

		if ($this->isInsert() && $this->User)
		{
			$socialGroupIds = $this->User->dbtech_social_groups_group_ids ?? [];
			$socialGroupIds = \array_merge($socialGroupIds, [$this->group_id]);

			$this->User->dbtech_social_groups_group_ids = $socialGroupIds;
			$this->User->save();
		}

		if ($approvalChange == 'enter')
		{
			foreach ($this->Group->Supervisors AS $supervisor)
			{
				$canApproveUnapprove = \XF::asVisitor(
					$supervisor->User,
					function ()
					{
						return $this->canApproveUnapprove();
					}
				);
				if ($canApproveUnapprove)
				{
					$groupMemberRepo->sendMemberApprovalAlert($supervisor->User, $this);
				}
			}
		}
		else if ($approvalChange == 'leave')
		{
			\XF::app()->repository(UserAlertRepository::class)
				->fastDeleteAlertsFromUser(
					$this->user_id,
					'dbtech_social_member',
					$this->group_member_id,
					'approval'
				)
			;
		}

		$this->updateGroupRecord();
	}

	/**
	 * @return void
	 * @throws PrintableException
	 */
	protected function _postDelete(): void
	{
		if ($this->member_state == 'moderated' && $this->ApprovalQueue)
		{
			$this->ApprovalQueue->delete();
		}

		if ($this->Group && $this->member_state == 'valid')
		{
			$this->Group->memberRemoved($this);
			$this->Group->save();
		}

		if ($this->User)
		{
			$socialGroupIds = $this->User->dbtech_social_groups_group_ids ?? [];
			$key = \array_search($this->group_id, $socialGroupIds);
			if ($key !== false)
			{
				unset($socialGroupIds[$key]);

				$this->User->dbtech_social_groups_group_ids = $socialGroupIds;
				$this->User->save();
			}
		}

		\XF::app()->repository(UserAlertRepository::class)
			->fastDeleteAlertsForContent('dbtech_social_member', $this->group_member_id)
		;
	}

	/**
	 * @param Structure $structure
	 *
	 * @return Structure
	 */
	public static function getStructure(Structure $structure): Structure
	{
		$structure->table = 'xf_dbtech_social_groups_group_member';
		$structure->shortName = 'DBTech\SocialGroups:GroupMember';
		$structure->primaryKey = 'group_member_id';
		$structure->columns = [
			'group_member_id'          => ['type' => self::UINT, 'autoIncrement' => true, 'nullable' => true],
			'user_id'                  => ['type' => self::UINT, 'required' => true],
			'group_id'                 => ['type' => self::UINT, 'required' => true],
			'join_date'                => ['type' => self::UINT, 'default' => \XF::$time],
			'last_activity_date'       => ['type' => self::UINT, 'default' => \XF::$time],
			'last_message_date'        => ['type' => self::UINT, 'default' => 0],
			'last_media_upload_date'   => ['type' => self::UINT, 'default' => 0],
			'last_event_creation_date' => ['type' => self::UINT, 'default' => 0],
			'is_supervisor'            => ['type' => self::BOOL, 'default' => false],
			'member_state'             => [
				'type'          => self::STR, 'default' => 'valid',
				'allowedValues' => [
					'valid', 'moderated', 'banned',
				],
			],
			'message_count'            => ['type' => self::UINT, 'default' => 0, 'forced' => true],
			'album_count'              => ['type' => self::UINT, 'default' => 0, 'forced' => true],
			'media_count'              => ['type' => self::UINT, 'default' => 0, 'forced' => true],
			'event_count'              => ['type' => self::UINT, 'default' => 0, 'forced' => true],
			'permissions'              => ['type' => self::JSON_ARRAY, 'default' => [], 'nullable' => true],
			'reason'                   => ['type' => self::STR, 'maxLength' => 255, 'default' => ''],
		];

		$structure->getters = [];

		$structure->options = [
			'send_alert' => true,
		];

		$structure->relations = [
			'Group'         => [
				'entity'     => Group::class,
				'type'       => self::TO_ONE,
				'conditions' => 'group_id',
				'primary'    => true,
			],
			'User'          => [
				'entity'     => User::class,
				'type'       => self::TO_ONE,
				'conditions' => 'user_id',
				'primary'    => true,
			],
			'Invitation'    => [
				'entity'     => GroupInvite::class,
				'type'       => self::TO_ONE,
				'conditions' => [
					['user_id', '=', '$user_id'],
					['group_id', '=', '$group_id'],
				],
			],
			'ApprovalQueue' => [
				'entity'     => ApprovalQueue::class,
				'type'       => self::TO_ONE,
				'conditions' => [
					['content_type', '=', 'dbtech_social_member'],
					['content_id', '=', '$group_member_id'],
				],
				'primary'    => true,
			],
		];

		return $structure;
	}
}