<?php

namespace DBTech\SocialGroups\Entity;

use XF\Mvc\Entity\Entity;
use XF\Mvc\Entity\Structure;

/**
 * COLUMNS
 * @property int $group_id
 * @property int $total
 *
 * RELATIONS
 * @property-read Group|null $Group
 */
class GroupView extends Entity
{
	/**
	 * @param Structure $structure
	 *
	 * @return Structure
	 */
	public static function getStructure(Structure $structure): Structure
	{
		$structure->table = 'xf_dbtech_social_groups_group_view';
		$structure->shortName = 'DBTech\SocialGroups:GroupView';
		$structure->primaryKey = 'group_id';
		$structure->columns = [
			'group_id' => ['type' => self::UINT, 'required' => true],
			'total'    => ['type' => self::UINT, 'default' => 0],
		];
		$structure->getters = [];
		$structure->relations = [
			'Group' => [
				'entity'     => Group::class,
				'type'       => self::TO_ONE,
				'conditions' => 'group_id',
				'primary'    => true,
			],
		];

		return $structure;
	}
}