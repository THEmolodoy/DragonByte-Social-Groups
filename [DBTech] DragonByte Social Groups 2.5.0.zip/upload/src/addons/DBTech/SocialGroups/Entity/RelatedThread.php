<?php

namespace DBTech\SocialGroups\Entity;

use XF\Entity\Thread;
use XF\Entity\ViewableInterface;
use XF\Mvc\Entity\Entity;
use XF\Mvc\Entity\Structure;

/**
 * COLUMNS
 * @property int $group_id
 * @property int $thread_id
 * @property int $display_order
 *
 * RELATIONS
 * @property-read Group|null $Group
 * @property-read Thread|null $Thread
 */
class RelatedThread extends Entity implements ViewableInterface
{
	/**
	 * @return bool
	 */
	public function canView(): bool
	{
		return $this->Thread->canView();
	}

	/**
	 * @param Structure $structure
	 *
	 * @return Structure
	 */
	public static function getStructure(Structure $structure): Structure
	{
		$structure->table = 'xf_dbtech_social_groups_related_thread';
		$structure->shortName = 'DBTech\SocialGroups:RelatedThread';
		$structure->primaryKey = ['group_id', 'thread_id'];
		$structure->columns = [
			'group_id'      => ['type' => self::UINT, 'required' => true],
			'thread_id'     => ['type' => self::UINT, 'required' => true],
			'display_order' => ['type' => self::UINT, 'default' => 10],
		];
		$structure->getters = [];
		$structure->relations = [
			'Group' => [
				'entity'     => Group::class,
				'type'       => self::TO_ONE,
				'conditions' => 'group_id',
				'primary'    => true,
			],
			'Thread' => [
				'entity'     => Thread::class,
				'type'       => self::TO_ONE,
				'conditions' => 'thread_id',
				'primary'    => true,
			],
		];

		return $structure;
	}
}