<?php

namespace DBTech\SocialGroups\Entity;

use DBTech\SocialGroups\XF\Entity\User as ExtendedUserEntity;
use XF\Api\Result\EntityResult;
use XF\Db\Exception as DbException;
use XF\Entity\ApprovalQueue;
use XF\Entity\ContainableInterface;
use XF\Entity\ContainableTrait;
use XF\Entity\CoverImageTrait;
use XF\Entity\DatableInterface;
use XF\Entity\DatableTrait;
use XF\Entity\DeletionLog;
use XF\Entity\Draft;
use XF\Entity\EmbedResolverTrait;
use XF\Entity\LinkableInterface;
use XF\Entity\Poll;
use XF\Entity\User;
use XF\Entity\ViewableInterface;
use XF\Mvc\Entity\AbstractCollection;
use XF\Mvc\Entity\Entity;
use XF\Mvc\Entity\Structure;
use XF\Phrase;
use XF\PrintableException;
use XF\Repository\ActivityLogRepository;
use XF\Repository\AttachmentRepository;
use XF\Repository\ReactionRepository;
use XF\Repository\UserAlertRepository;
use XF\Spam\ContentChecker;
use XF\Util\Arr;

use function is_int;

/**
 * COLUMNS
 * @property int|null $discussion_id
 * @property int $group_id
 * @property int $section_id
 * @property string $title
 * @property string $title_
 * @property int $reply_count
 * @property int $view_count
 * @property int $user_id
 * @property string $username
 * @property int $message_date
 * @property bool $sticky
 * @property string $discussion_state
 * @property bool $discussion_open
 * @property string $discussion_type
 * @property int $first_message_id
 * @property int $last_message_date
 * @property int $last_message_id
 * @property int $last_message_user_id
 * @property string $last_message_username
 * @property int $first_message_reaction_score
 * @property array|null $first_message_reactions
 * @property array|null $tags
 *
 * GETTERS
 * @property-read \XF\Draft $draft_reply
 * @property-read array $message_ids
 * @property-read array $last_message_cache
 *
 * RELATIONS
 * @property-read Group|null $Group
 * @property-read Section|null $Section
 * @property-read User|null $User
 * @property-read Message|null $FirstMessage
 * @property-read Message|null $LastMessage
 * @property-read User|null $LastPoster
 * @property-read AbstractCollection<DiscussionRead> $Read
 * @property-read AbstractCollection<DiscussionWatch> $Watch
 * @property-read AbstractCollection<DiscussionUserMessage> $UserMessages
 * @property-read DeletionLog|null $DeletionLog
 * @property-read AbstractCollection<Draft> $DraftReplies
 * @property-read ApprovalQueue|null $ApprovalQueue
 * @property-read AbstractCollection<DiscussionReplyBan> $ReplyBans
 * @property-read Poll|null $Poll
 */
class Discussion extends Entity implements ContainableInterface, DatableInterface, LinkableInterface, ViewableInterface
{
	use ContainableTrait;
	use CoverImageTrait;
	use DatableTrait;
	use EmbedResolverTrait;

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canView(&$error = null): bool
	{
		if (!$this->Group || !$this->Group->canView($error))
		{
			return false;
		}

		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();
		$groupId = $this->group_id;

		if (!$this->Group->canViewDiscussions($error))
		{
			return false;
		}

		if ($this->Section && !$this->Section->canViewDiscussions($error))
		{
			return false;
		}

		if ($this->Group->group_type === 'closed'
			&& !$visitor->isMemberOfSocialGroup($this->Group, true)
			&& !$visitor->canEditAnyDbtechSocialGroups()
		)
		{
			$error = \XF::phraseDeferred('dbtech_social_groups_not_member_or_need_approval');
			return false;
		}

		if (!$visitor->hasDbtechSocialGroupsGroupPermission($groupId, 'viewGroup'))
		{
			return false;
		}
		if (!$visitor->hasDbtechSocialGroupsGroupPermission($groupId, 'viewOthers') && $visitor->user_id != $this->user_id)
		{
			return false;
		}
		if (!$visitor->hasDbtechSocialGroupsGroupPermission($groupId, 'viewContent'))
		{
			return false;
		}

		if ($this->discussion_state == 'moderated')
		{
			if (
				!$visitor->hasDbtechSocialGroupsGroupPermission($groupId, 'viewModerated')
				&& (!$visitor->user_id || $visitor->user_id != $this->user_id)
			)
			{
				$error = \XF::phraseDeferred('dbtech_social_groups_requested_discussion_not_found');
				return false;
			}
		}
		else if ($this->discussion_state == 'deleted')
		{
			if (!$visitor->hasDbtechSocialGroupsGroupPermission($groupId, 'viewDeleted'))
			{
				$error = \XF::phraseDeferred('dbtech_social_groups_requested_discussion_not_found');
				return false;
			}
		}

		return true;
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canPreview(&$error = null): bool
	{
		// assumes view check has already been run
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();
		$groupId = $this->group_id;

		return (
			$this->first_message_id
			&& \XF::app()->options()->discussionPreview
			&& $visitor->hasDbtechSocialGroupsGroupPermission($groupId, 'viewContent')
		);
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canEdit(&$error = null): bool
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();
		if (!$visitor->user_id)
		{
			return false;
		}

		$groupId = $this->group_id;

		if ($visitor->hasDbtechSocialGroupsGroupPermission($groupId, 'manageAnyDiscussion'))
		{
			return true;
		}

		if (!$this->discussion_open && !$this->canLockUnlock())
		{
			$error = \XF::phraseDeferred('you_may_not_perform_this_action_because_discussion_is_closed');
			return false;
		}

		if ($this->user_id == $visitor->user_id && $visitor->hasDbtechSocialGroupsGroupPermission($groupId, 'editOwnMessage'))
		{
			$editLimit = $visitor->hasDbtechSocialGroupsGroupPermission($groupId, 'editOwnMessageTimeLimit');
			if ($editLimit != -1 && (!$editLimit || $this->message_date < \XF::$time - 60 * $editLimit))
			{
				$error = \XF::phraseDeferred('message_edit_time_limit_expired', ['minutes' => $editLimit]);
				return false;
			}

			if (!$this->Group || !$this->Group->allow_discussions)
			{
				$error = \XF::phraseDeferred('dbtech_social_groups_you_may_not_perform_this_action_because_group_does_not_allow_posting');
				return false;
			}

			if ($this->Section && !$this->Section->allow_discussions)
			{
				$error = \XF::phraseDeferred('dbtech_social_groups_you_may_not_perform_this_action_because_section_does_not_allow_posting');
				return false;
			}

			return (bool) $visitor->hasDbtechSocialGroupsGroupPermission($groupId, 'editOwnDiscussionTitle');
		}

		return false;
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canCreatePoll(&$error = null): bool
	{
		if ($this->discussion_type != '')
		{
			return false;
		}

		if (!$this->Group->canCreatePoll($error))
		{
			return false;
		}

		if ($this->Section && !$this->Section->canCreatePoll($error))
		{
			return false;
		}

		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();
		if (!$visitor->user_id)
		{
			return false;
		}

		if (!$this->discussion_open && !$this->canLockUnlock())
		{
			$error = \XF::phraseDeferred('you_may_not_perform_this_action_because_discussion_is_closed');
			return false;
		}

		$groupId = $this->group_id;

		if ($visitor->hasDbtechSocialGroupsGroupPermission($groupId, 'manageAnyDiscussion'))
		{
			return true;
		}

		if ($this->user_id == $visitor->user_id && $visitor->hasDbtechSocialGroupsGroupPermission($groupId, 'editOwnMessage'))
		{
			$editLimit = $visitor->hasDbtechSocialGroupsGroupPermission($groupId, 'editOwnMessageTimeLimit');
			if ($editLimit != -1 && (!$editLimit || $this->message_date < \XF::$time - 60 * $editLimit))
			{
				$error = \XF::phraseDeferred('message_edit_time_limit_expired', ['minutes' => $editLimit]);
				return false;
			}

			if (!$this->Group || !$this->Group->allow_discussions)
			{
				$error = \XF::phraseDeferred('dbtech_social_groups_you_may_not_perform_this_action_because_group_does_not_allow_posting');
				return false;
			}

			if ($this->Section && !$this->Section->allow_discussions)
			{
				$error = \XF::phraseDeferred('dbtech_social_groups_you_may_not_perform_this_action_because_section_does_not_allow_posting');
				return false;
			}

			return true;
		}

		return false;
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canReply(&$error = null): bool
	{
		if (!$this->Group)
		{
			return false;
		}

		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		if ($visitor->canEditAnyDbtechSocialGroups())
		{
			return true;
		}

		if (!$this->Group->isGroupOwner() && !$visitor->canEditAnyDbtechSocialGroups())
		{
			if ($this->discussion_state == 'deleted')
			{
				return false;
			}

			if (!$this->discussion_open && !$this->canLockUnlock())
			{
				$error = \XF::phraseDeferred(
					'you_may_not_perform_this_action_because_discussion_is_closed'
				);
				return false;
			}

			if (!$this->Group->allow_posting)
			{
				$error = \XF::phraseDeferred(
					'dbtech_social_groups_you_may_not_perform_this_action_because_group_does_not_allow_posting'
				);
				return false;
			}

			if ($this->Section && !$this->Section->allow_posting)
			{
				$error = \XF::phraseDeferred(
					'dbtech_social_groups_you_may_not_perform_this_action_because_section_does_not_allow_posting'
				);
				return false;
			}
		}

		if (!$visitor->hasDbtechSocialGroupsGroupPermission($this->group_id, 'postReply'))
		{
			return false;
		}

		if ($visitor->user_id)
		{
			$replyBans = $this->ReplyBans;
			if ($replyBans)
			{
				if (isset($replyBans[$visitor->user_id]))
				{
					$replyBan = $replyBans[$visitor->user_id];
					$isBanned = ($replyBan && (!$replyBan->expiry_date || $replyBan->expiry_date > time()));
					if ($isBanned)
					{
						return false;
					}
				}
			}
		}

		return true;
	}

	/**
	 * @return bool
	 */
	public function canReplyPreReg(): bool
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		if ($visitor->user_id || $this->canReply())
		{
			// quick bypass with the user ID check, then ensure that this can only return true if the visitor
			// can't take the "normal" action
			return false;
		}

		return \XF::canPerformPreRegAction(
			function ()
			{
				return $this->canReply();
			}
		);
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canEditTags(&$error = null): bool
	{
		/** @var Group $group */
		$group = $this->Group;
		return $group && $group->canEditTags($this, $error);
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canUseInlineModeration(&$error = null): bool
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();
		return ($visitor->user_id
			&& $visitor->hasDbtechSocialGroupsGroupPermission($this->group_id, 'inlineMod')
		);
	}

	/**
	 * @param string $type
	 * @param $error
	 *
	 * @return bool
	 */
	public function canDelete(string $type = 'soft', &$error = null): bool
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();
		if (!$visitor->user_id)
		{
			return false;
		}

		$groupId = $this->group_id;

		if ($type != 'soft' && !$visitor->hasDbtechSocialGroupsGroupPermission($groupId, 'hardDeleteAnyDiscussion'))
		{
			return false;
		}

		if (!$this->discussion_open && !$this->canLockUnlock())
		{
			$error = \XF::phraseDeferred('you_may_not_perform_this_action_because_discussion_is_closed');
			return false;
		}

		if ($visitor->hasDbtechSocialGroupsGroupPermission($groupId, 'deleteAnyDiscussion'))
		{
			return true;
		}

		if ($this->user_id == $visitor->user_id && $visitor->hasDbtechSocialGroupsGroupPermission($groupId, 'deleteOwnDiscussion'))
		{
			$editLimit = $visitor->hasDbtechSocialGroupsGroupPermission($groupId, 'editOwnMessageTimeLimit');
			if ($editLimit != -1 && (!$editLimit || $this->message_date < \XF::$time - 60 * $editLimit))
			{
				$error = \XF::phraseDeferred('message_edit_time_limit_expired', ['minutes' => $editLimit]);
				return false;
			}

			if (!$this->Group || !$this->Group->allow_discussions)
			{
				$error = \XF::phraseDeferred('dbtech_social_groups_you_may_not_perform_this_action_because_group_does_not_allow_posting');
				return false;
			}

			if ($this->Section && !$this->Section->allow_discussions)
			{
				$error = \XF::phraseDeferred('dbtech_social_groups_you_may_not_perform_this_action_because_section_does_not_allow_posting');
				return false;
			}

			return true;
		}

		return false;
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canUndelete(&$error = null): bool
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();
		return ($visitor->user_id
			&& $visitor->hasDbtechSocialGroupsGroupPermission($this->group_id, 'undelete')
		);
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canLockUnlock(&$error = null): bool
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();
		return ($visitor->user_id
			&& $visitor->hasDbtechSocialGroupsGroupPermission($this->group_id, 'lockUnlockDiscussion')
		);
	}

	/**
	 * @return bool
	 */
	public function canViewDeletedMessages(): bool
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		return (bool) $visitor->hasDbtechSocialGroupsGroupPermission($this->group_id, 'viewDeleted');
	}

	/**
	 * @return bool
	 */
	public function canViewModeratedMessages(): bool
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		return (bool) $visitor->hasDbtechSocialGroupsGroupPermission($this->group_id, 'viewModerated');
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canApproveUnapprove(&$error = null): bool
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();
		return ($visitor->user_id
			&& $visitor->hasDbtechSocialGroupsGroupPermission($this->group_id, 'approveUnapprove')
		);
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canStickUnstick(&$error = null): bool
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();
		return ($visitor->user_id
			&& $visitor->hasDbtechSocialGroupsGroupPermission($this->group_id, 'stickUnstickDiscussion')
		);
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canMove(&$error = null): bool
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();
		return (
			$visitor->user_id
			&& $visitor->hasDbtechSocialGroupsGroupPermission($this->group_id, 'manageAnyDiscussion')
		);
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canCopy(&$error = null): bool
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();
		return (
			$visitor->user_id
			&& $visitor->hasDbtechSocialGroupsGroupPermission($this->group_id, 'manageAnyDiscussion')
		);
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canMerge(&$error = null): bool
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();
		return (
			$visitor->user_id
			&& $visitor->hasDbtechSocialGroupsGroupPermission($this->group_id, 'manageAnyDiscussion')
		);
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canViewAttachments(&$error = null): bool
	{
		if (!$this->Group)
		{
			return false;
		}

		if ($this->Group->canViewOtherContent())
		{
			return true;
		}

		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		return (bool) $visitor->hasDbtechSocialGroupsGroupPermission($this->group_id, 'viewAttachment');
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canWatch(&$error = null): bool
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		return (bool) $visitor->user_id;
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canReplyBan(&$error = null): bool
	{
		if (!$this->discussion_open)
		{
			$error = \XF::phraseDeferred('you_may_not_perform_this_action_because_discussion_is_closed');
			return false;
		}

		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();
		return $visitor->user_id && $visitor->hasDbtechSocialGroupsGroupPermission($this->group_id, 'discussionReplyBan');
	}

	/**
	 * @return bool
	 */
	public function canSendModeratorActionAlert(): bool
	{
		return $this->FirstMessage && $this->FirstMessage->canSendModeratorActionAlert();
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canViewModeratorLogs(&$error = null): bool
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();
		return ($visitor->user_id
			&& $visitor->hasDbtechSocialGroupsGroupPermission($this->group_id, 'viewModeratorLogs')
		);
	}

	/**
	 * @return bool
	 */
	public function isVisible(): bool
	{
		return ($this->discussion_state == 'visible');
	}

	public function isSearchEngineIndexable(): bool
	{
		$group = $this->Group;
		if (!$group)
		{
			return false;
		}

		return true;

		/*
		if ($group->allow_index == 'criteria')
		{
			$criteria = $group->index_criteria;

			if (
				!empty($criteria['max_days_message']) &&
				$this->message_date < \XF::$time - $criteria['max_days_message'] * 86400
			) {
				return false;
			}

			if (
				!empty($criteria['max_days_last_message']) &&
				$this->last_message_date < \XF::$time - $criteria['max_days_last_message'] * 86400
			) {
				return false;
			}

			if (
				!empty($criteria['min_replies']) &&
				$this->reply_count < $criteria['min_replies']
			) {
				return false;
			}

			if (
				isset($criteria['min_reaction_score']) &&
				$this->first_message_reaction_score < $criteria['min_reaction_score']
			) {
				return false;
			}

			return true;
		}

		return ($group->allow_index == 'allow');
		*/
	}

	/**
	 * @return bool
	 */
	public function isUnread(): bool
	{
		if ($this->discussion_state == 'deleted')
		{
			return false;
		}

		$readDate = $this->getVisitorReadDate();
		if ($readDate === null)
		{
			return false;
		}

		return $readDate < $this->last_message_date;
	}

	/**
	 * @return bool
	 */
	public function isIgnored(): bool
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		return $visitor->isIgnoring($this->user_id);
	}

	/**
	 * @return bool
	 */
	public function isWatched(): bool
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		return isset($this->Watch[$visitor->user_id]);
	}

	/**
	 * @param int|User|null $user
	 *
	 * @return int
	 */
	public function getUserMessageCount(int|User|null $user = null): int
	{
		if ($user === null)
		{
			$userId = \XF::visitor()->user_id;
		}
		else if (is_int($user))
		{
			$userId = $user;
		}
		else if ($user instanceof User)
		{
			$userId = $user->user_id;
		}
		else
		{
			throw new \InvalidArgumentException("User must be provided as null, ID, or entity");
		}

		if (!$userId)
		{
			return 0;
		}

		return isset($this->UserMessages[$userId]) ? $this->UserMessages[$userId]->message_count : 0;
	}

	/**
	 * @param User $user
	 *
	 * @return int
	 */
	public function getUserReadDate(User $user): int
	{
		$discussionRead = $this->Read[$user->user_id];
		$groupRead = $this->Group ? $this->Group->Read[$user->user_id] : null;
		$sectionRead = $this->Section ? $this->Section->Read[$user->user_id] : null;

		$dates = [\XF::$time - \XF::app()->options()->readMarkingDataLifetime * 86400];
		if ($discussionRead)
		{
			$dates[] = $discussionRead->discussion_read_date;
		}
		if ($groupRead)
		{
			$dates[] = $groupRead->group_read_date;
		}
		if ($sectionRead)
		{
			$dates[] = $sectionRead->section_read_date;
		}

		return max($dates);
	}

	/**
	 * @return int|null
	 */
	public function getVisitorReadDate(): ?int
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();
		if (!$visitor->user_id)
		{
			return null;
		}

		return $this->getUserReadDate($visitor);
	}

	/**
	 * @return \XF\Draft
	 */
	public function getDraftReply(): \XF\Draft
	{
		return \XF\Draft::createFromEntity($this, 'DraftReplies');
	}

	/**
	 * @return string|null
	 */
	public function getCoverImage(): ?string
	{
		$firstMessage = $this->FirstMessage;
		if (!$firstMessage)
		{
			return null;
		}

		$attachments = $firstMessage->attach_count
			? $firstMessage->Attachments
			: $this->_em->getEmptyCollection();

		return $this->getCoverImageInternal(
			$attachments,
			$this->canViewAttachments(),
			$firstMessage->embed_metadata,
			$firstMessage->message
		);
	}

	/**
	 * @return Message
	 */
	public function getNewMessage(): Message
	{
		$message = \XF::app()->em()->create(Message::class);
		$message->discussion_id = $this->_getDeferredValue(function ()
		{
			return $this->discussion_id;
		}, 'save');

		return $message;
	}

	/**
	 * @return array
	 */
	public function getMessageIds(): array
	{
		return $this->db()->fetchAllColumn("
			SELECT message_id
			FROM xf_dbtech_social_groups_message
			WHERE discussion_id = ?
			ORDER BY message_date
		", $this->discussion_id);
	}

	/**
	 * @return array
	 */
	public function getLastMessageCache(): array
	{
		return [
			'message_id' => $this->last_message_id,
			'user_id' => $this->last_message_user_id,
			'username' => $this->last_message_username,
			'message_date' => $this->last_message_date,
		];
	}

	/**
	 * @param Message $firstDisplayedMessage
	 * @param int $page
	 * @param array $extraData
	 *
	 * @return array
	 */
	public function getLdStructuredData(Message $firstDisplayedMessage, int $page, array $extraData = []): array
	{
		$this->getContentUrl(true, [
			'page' => $page,
		]);
		$router = \XF::app()->router('public');
		$pageLink = $router->buildLink('canonical:dbtech-social/discussions', $this, [
			'page' => $page,
		]);
		$discussionLink = $this->getContentUrl(true);
		$userLink = $this->User ? $this->User->getContentUrl(true) : null;

		$mainEntity = [
			'@type' => 'DiscussionForumPosting',
			'@id' => $discussionLink,
			'headline' => $this->title,
			'datePublished' => gmdate('c', $this->message_date),
			'keywords' => $this->tags
				? implode(', ', array_column($this->tags, 'tag'))
				: null,
			'url' => $discussionLink,
			'articleSection' => $this->Group->title,
			'author' => [
				'@type' => 'Person',
				'@id' => $userLink,
				'name' => $this->User->username ?? $this->username,
				'url' => $userLink,
			],
			'interactionStatistic' => [
				[
					'@type' => 'InteractionCounter',
					'interactionType' => 'https://schema.org/ViewAction',
					'userInteractionCount' => $this->view_count,
				],
				[
					'@type' => 'InteractionCounter',
					'interactionType' => 'https://schema.org/CommentAction',
					'userInteractionCount' => $this->reply_count,
				],
			],
		];

		if ($page === 1)
		{
			$mainEntity['dateModified'] =  $this->FirstMessage->last_edit_date
				? gmdate('c', $this->FirstMessage->last_edit_date)
				: null;
			$mainEntity['image'] = $this->getLdImage(
				$this,
				$firstDisplayedMessage,
				$extraData
			);
			$mainEntity['articleBody'] = $this->getLdSnippet($this->FirstMessage->message, 0)
				?: $this->title;

			$mainEntity['interactionStatistic'][] = [
				'@type' => 'InteractionCounter',
				'interactionType' => 'https://schema.org/LikeAction',
				'userInteractionCount' => $this->first_message_reaction_score,
			];
		}

		$structuredData = [
			'@context' => 'https://schema.org',
			'@type' => 'WebPage',
			'url' => $pageLink,
			'mainEntity' => $mainEntity,
			'publisher' => $this->getLdPublisher($this->getLdMetadataLogo()),
		];

		return Arr::filterNull($structuredData, true);
	}

	/**
	 * @param string $message
	 * @param int|null $length
	 *
	 * @return string
	 */
	protected function getLdSnippet(string $message, ?int $length = null): string
	{
		if ($length === null)
		{
			$length = 250;
		}

		return \XF::app()->stringFormatter()->snippetString($message, $length, ['stripBbCode' => true]);
	}

	/**
	 * @return string|null
	 */
	protected function getLdMetadataLogo(): ?string
	{
		$style = \XF::app()->templater()->getStyle();
		if (!$style)
		{
			return null;
		}

		$metadataLogo = $style->getProperty('publicMetadataLogoUrl');
		if ($metadataLogo)
		{
			$pather = \XF::app()['request.pather'];
			$metadataLogo = $pather($metadataLogo, 'canonical');
		}

		return $metadataLogo ?: null;
	}

	/**
	 * @param string|null $logo
	 *
	 * @return array
	 */
	protected function getLdPublisher(?string $logo = null): array
	{
		$options = \XF::options();

		return [
			'@type' => 'Organization',
			'name' => $options->boardTitle,
			'alternateName' => $options->boardShortTitle ?: null,
			'description' => $options->boardDescription ?: null,
			'url' => $options->boardUrl,
			'logo' => $logo,
		];
	}

	/**
	 * @param Discussion $discussion
	 * @param Message $firstDisplayedMessage
	 * @param array $extraData
	 *
	 * @return string|null
	 */
	protected function getLdImage(Discussion $discussion, Message $firstDisplayedMessage, array $extraData = []): ?string
	{
		$firstMessage = $discussion->FirstMessage;
		if (!$firstMessage)
		{
			return null;
		}

		if (!$firstMessage->isRelationHydrated('Attachments'))
		{
			return null;
		}

		return $discussion->getCoverImage();
	}

	/**
	 * @param Discussion $discussion
	 *
	 * @return string
	 */
	public function getMicrodataType(Discussion $discussion): string
	{
		return 'DiscussionForumPosting';
	}

	/**
	 * @param Discussion $discussion
	 *
	 * @return string
	 */
	public function getReplyMicrodataType(Discussion $discussion): string
	{
		return 'Comment';
	}

	/**
	 * @param bool $includeSelf
	 *
	 * @return array
	 */
	public function getBreadcrumbs(bool $includeSelf = true): array
	{
		if ($this->Section)
		{
			$breadcrumbs = $this->Section->getBreadcrumbs();
		}
		else if ($this->Group)
		{
			$breadcrumbs = $this->Group->getBreadcrumbs();

			$breadcrumbs[] = [
				'href' => \XF::app()->router('public')->buildLink('dbtech-social/discussions/list', $this->Group),
				'value' => \XF::phrase('dbtech_social_groups_discussions_nav'),
			];
		}
		else
		{
			$breadcrumbs = [];

			$breadcrumbs[] = [
				'href' => \XF::app()->router('public')->buildLink('dbtech-social/discussions/list', $this->Group),
				'value' => \XF::phrase('dbtech_social_groups_discussions_nav'),
			];
		}

		if ($includeSelf)
		{
			$breadcrumbs[] = [
				'href' => \XF::app()->router('public')->buildLink('dbtech-social/discussions', $this),
				'value' => $this->title,
			];
		}

		return $breadcrumbs;
	}

	/**
	 * @return bool
	 */
	public function rebuildCounters(): bool
	{
		$this->rebuildFirstMessageInfo();
		$this->rebuildLastMessageInfo();
		$this->rebuildReplyCount();

		return true;
	}

	/**
	 * @return bool
	 */
	public function rebuildFirstMessageInfo(): bool
	{
		$firstMessage = $this->db()->fetchRow("
			SELECT message_id, message_date, user_id, username, reaction_score, reactions
			FROM xf_dbtech_social_groups_message
			WHERE discussion_id = ?
			ORDER BY message_date
			LIMIT 1
		", $this->discussion_id);
		if (!$firstMessage)
		{
			return false;
		}

		$this->first_message_id = $firstMessage['message_id'];
		$this->message_date = $firstMessage['message_date'];
		$this->user_id = $firstMessage['user_id'];
		$this->username = $firstMessage['username'] ?: '-';
		$this->first_message_reaction_score = $firstMessage['reaction_score'];
		$this->first_message_reactions = json_decode($firstMessage['reactions'], true) ?: [];

		return true;
	}

	/**
	 * @return bool
	 */
	public function rebuildLastMessageInfo(): bool
	{
		$lastMessage = $this->db()->fetchRow("
			SELECT message_id, message_date, user_id, username
			FROM xf_dbtech_social_groups_message
			WHERE discussion_id = ?
				AND message_state = 'visible'
			ORDER BY message_date DESC
			LIMIT 1
		", $this->discussion_id);
		if (!$lastMessage)
		{
			return false;
		}

		$this->last_message_id = $lastMessage['message_id'];
		$this->last_message_date = $lastMessage['message_date'];
		$this->last_message_user_id = $lastMessage['user_id'];
		$this->last_message_username = $lastMessage['username'] ?: '-';

		return true;
	}

	/**
	 * @return int
	 */
	public function rebuildReplyCount(): int
	{
		$visibleMessages = $this->db()->fetchOne("
			SELECT COUNT(*)
			FROM xf_dbtech_social_groups_message
			WHERE discussion_id = ?
				AND message_state = 'visible'
		", $this->discussion_id);
		$this->reply_count = max(0, $visibleMessages - 1);

		return $this->reply_count;
	}

	/**
	 * @param Message $message
	 *
	 * @throws PrintableException
	 */
	public function messageAdded(Message $message): void
	{
		$this->Group->contentAdded($message);

		if ($this->Section)
		{
			$this->Section->contentAdded($message);
		}

		if (!$this->first_message_id)
		{
			$this->first_message_id = $message->message_id;
		}
		else
		{
			$this->reply_count++;

			$activityLogRepo = \XF::repository(ActivityLogRepository::class);
			$activityLogRepo->log($this, $message->message_date, [
				'reply_count' => 1,
			]);
		}

		/** @var GroupMember $groupMembership */
		$groupMembership = $message->User->SocialGroupMemberships[$this->group_id];
		if ($groupMembership)
		{
			$groupMembership->messageAdded($message);
			$groupMembership->save();
		}

		if ($message->message_date >= $this->last_message_date)
		{
			$this->last_message_date = $message->message_date;
			$this->last_message_id = $message->message_id;
			$this->last_message_user_id = $message->user_id;
			$this->last_message_username = $message->username;
		}

		unset($this->_getterCache['message_ids']);
	}

	/**
	 * @param Message $message
	 *
	 * @throws PrintableException
	 */
	public function messageRemoved(Message $message): void
	{
		$this->reply_count--;

		$activityLogRepo = \XF::repository(ActivityLogRepository::class);
		$activityLogRepo->log($this, $message->message_date, [
			'reply_count' => -1,
		]);

		if ($message->message_id == $this->first_message_id)
		{
			$this->rebuildFirstMessageInfo();
		}

		if ($message->message_id == $this->last_message_id)
		{
			$this->rebuildLastMessageInfo();
		}

		/** @var GroupMember $groupMembership */
		$groupMembership = $message->User?->SocialGroupMemberships[$this->group_id];
		if ($groupMembership)
		{
			$groupMembership->messageRemoved($message);
			$groupMembership->save();
		}

		unset($this->_getterCache['message_ids']);
	}

	/**
	 * @throws PrintableException
	 * @throws DbException
	 */
	protected function _postSave(): void
	{
		$visibilityChange = $this->isStateChanged('discussion_state', 'visible');
		$approvalChange = $this->isStateChanged('discussion_state', 'moderated');
		$deletionChange = $this->isStateChanged('discussion_state', 'deleted');

		if ($this->isUpdate())
		{
			if ($visibilityChange == 'enter')
			{
				$this->discussionMadeVisible();

				if ($approvalChange)
				{
					$this->submitHamData();
				}
			}
			else if ($visibilityChange == 'leave')
			{
				$this->discussionHidden();
			}

			if ($this->isChanged('section_id'))
			{
				/** @var ?Section $oldSection */
				$oldSection = $this->getExistingRelation('Section');

				$this->discussionMoved($oldSection, $this->Section);
			}

			if ($deletionChange == 'leave' && $this->DeletionLog)
			{
				$this->DeletionLog->delete();
			}

			if ($approvalChange == 'leave' && $this->ApprovalQueue)
			{
				$this->ApprovalQueue->delete();
			}
		}

		if ($approvalChange == 'enter')
		{
			$approvalQueue = $this->getRelationOrDefault('ApprovalQueue', false);
			$approvalQueue->content_date = $this->message_date;
			$approvalQueue->save();
		}
		else if ($deletionChange == 'enter' && !$this->DeletionLog)
		{
			$delLog = $this->getRelationOrDefault('DeletionLog', false);
			$delLog->setFromVisitor();
			$delLog->save();
		}

		$this->updateGroupRecord();
		$this->updateSectionRecord();

		if ($this->isUpdate() && $this->getOption('log_moderator'))
		{
			\XF::app()->logger()->logModeratorChanges('dbtech_social_discussion', $this);
		}
	}

	/**
	 * @throws DbException
	 */
	protected function discussionMadeVisible(): void
	{
		$this->adjustUserMessageCountIfNeeded(1);

		\XF::app()->repository(ReactionRepository::class)
			->recalculateReactionIsCounted('dbtech_social_message', $this->message_ids)
		;
	}

	/**
	 * @param bool $hardDelete
	 *
	 * @throws DbException
	 */
	protected function discussionHidden(bool $hardDelete = false): void
	{
		$this->adjustUserMessageCountIfNeeded(-1);

		if (!$hardDelete)
		{
			// on hard delete the reactions will be removed which will do this
			\XF::app()->repository(ReactionRepository::class)
				->fastUpdateReactionIsCounted('dbtech_social_message', $this->message_ids, false)
			;
		}

		\XF::app()->repository(UserAlertRepository::class)
			->fastDeleteAlertsForContent('dbtech_social_message', $this->message_ids)
		;
	}

	/**
	 *
	 */
	protected function submitHamData(): void
	{
		/** @var ContentChecker $submitter */
		$submitter = \XF::app()->container('spam.contentHamSubmitter');
		$submitter->submitHam('dbtech_social_discussion', $this->discussion_id);
	}

	/**
	 * @param ?Section $from
	 * @param ?Section $to
	 *
	 * @return void
	 * @throws DbException
	 */
	protected function discussionMoved(?Section $from, ?Section $to): void
	{
		if (!$this->isStateChanged('discussion_state', 'visible')
			&& $this->discussion_state == 'visible'
			&& $this->Group
		)
		{
			$group = $this->Group;

			$newCounts = $to ? $to->count_messages : $group->count_messages;
			$oldCounts = $from ? $from->count_messages : $group->count_messages;
			if ($newCounts != $oldCounts)
			{
				$this->adjustUserMessageCountIfNeeded($newCounts ? 1 : -1, true);
			}
		}
	}

	/**
	 * @param int $direction
	 * @param bool $forceChange
	 *
	 * @throws DbException
	 */
	protected function adjustUserMessageCountIfNeeded(int $direction, bool $forceChange = false): void
	{
		if (!$this->Group)
		{
			return;
		}

		if ($forceChange
			|| (
				$this->Group->doesMessageCount()
				&& (!$this->Section || $this->Section->doesMessageCount())
			)
		)
		{
			$updates = $this->db()->fetchPairs("
				SELECT user_id, COUNT(*)
				FROM xf_dbtech_social_groups_message
				WHERE discussion_id = ?
					AND user_id > 0
					AND message_state = 'visible'
				GROUP BY user_id
			", $this->discussion_id);

			$operator = $direction > 0 ? '+' : '-';
			foreach ($updates AS $userId => $adjust)
			{
				$this->db()->query("
					UPDATE xf_user
					SET message_count = GREATEST(0, CAST(message_count AS SIGNED) " . $operator . " ?)
					WHERE user_id = ?
				", [$adjust, $userId]);

				$userEntity = \XF::app()->em()->findCached(User::class, $userId);
				if ($userEntity)
				{
					$userEntity->setAsSaved('message_count', max(0, $userEntity->message_count + ($direction > 0 ? $adjust : -$adjust)));
				}
			}
		}
	}

	/**
	 * @throws PrintableException
	 */
	protected function updateGroupRecord(): void
	{
		if (!$this->Group)
		{
			return;
		}

		/** @var Group $group */
		$group = $this->Group;

		if ($this->isUpdate() && $this->isChanged('group_id'))
		{
			// discussion moved, trumps the rest
			if ($this->discussion_state == 'visible')
			{
				$group->discussionAdded($this);
				$group->save();
			}

			if ($this->getExistingValue('discussion_state') == 'visible')
			{
				/** @var Group $oldGroup */
				$oldGroup = $this->getExistingRelation('Group');
				if ($oldGroup)
				{
					$oldGroup->discussionRemoved($this);
					$oldGroup->save();
				}
			}

			return;
		}

		// check for discussion entering/leaving visible
		$visibilityChange = $this->isStateChanged('discussion_state', 'visible');
		if ($visibilityChange == 'enter')
		{
			$group->discussionAdded($this);
			$group->save();
			return;
		}
		else if ($visibilityChange == 'leave')
		{
			$group->discussionRemoved($this);
			$group->save();
			return;
		}

		// general data changes
		if ($this->discussion_state == 'visible'
			&& $this->isChanged(['last_message_date', 'reply_count', 'title', 'discussion_type'])
		)
		{
			$group->discussionDataChanged($this);
			$group->save();
		}
	}

	/**
	 * @throws PrintableException
	 */
	protected function updateSectionRecord(): void
	{
		if ($this->isUpdate() && $this->isChanged('section_id'))
		{
			// discussion moved, trumps the rest
			if ($this->discussion_state == 'visible')
			{
				/** @var Section $newSection */
				$newSection = $this->Section;
				if ($newSection)
				{
					$newSection->discussionAdded($this);
					$newSection->save();
				}
			}

			if ($this->getExistingValue('discussion_state') == 'visible')
			{
				/** @var Section $oldSection */
				$oldSection = $this->getExistingRelation('Section');
				if ($oldSection)
				{
					$oldSection->discussionRemoved($this);
					$oldSection->save();
				}
			}

			return;
		}

		/** @var Section $section */
		$section = $this->Section;

		if ($section)
		{
			// check for discussion entering/leaving visible
			$visibilityChange = $this->isStateChanged('discussion_state', 'visible');
			if ($visibilityChange == 'enter')
			{
				$section->discussionAdded($this);
				$section->save();
				return;
			}
			else if ($visibilityChange == 'leave')
			{
				$section->discussionRemoved($this);
				$section->save();
				return;
			}

			// general data changes
			if ($this->discussion_state == 'visible'
				&& $this->isChanged(['last_message_date', 'reply_count', 'title', 'discussion_type'])
			)
			{
				$section->discussionDataChanged($this);
				$section->save();
			}
		}
	}

	/**
	 * @throws PrintableException|DbException
	 */
	protected function _postDelete(): void
	{
		if ($this->discussion_state == 'visible')
		{
			$this->discussionHidden(true);
		}

		if ($this->Group && $this->discussion_state == 'visible')
		{
			$this->Group->discussionRemoved($this);
			$this->Group->save();
		}

		if ($this->Section && $this->discussion_state == 'visible')
		{
			$this->Section->discussionRemoved($this);
			$this->Section->save();
		}

		if ($this->discussion_state == 'deleted' && $this->DeletionLog)
		{
			$this->DeletionLog->delete();
		}

		if ($this->discussion_state == 'moderated' && $this->ApprovalQueue)
		{
			$this->ApprovalQueue->delete();
		}

		if ($this->getOption('log_moderator'))
		{
			\XF::app()->logger()->logModeratorAction('dbtech_social_discussion', $this, 'delete_hard');
		}

		$db = $this->db();

		$messageIds = $this->message_ids;
		if ($messageIds)
		{
			$this->_postDeleteMessages($messageIds);
		}

		$db->delete('xf_dbtech_social_groups_discussion_reply_ban', 'discussion_id = ?', $this->discussion_id);
	}

	/**
	 * @param array $messageIds
	 */
	protected function _postDeleteMessages(array $messageIds): void
	{
		$db = $this->db();

		\XF::app()->repository(AttachmentRepository::class)
			->fastDeleteContentAttachments('dbtech_social_message', $messageIds)
		;

		\XF::app()->repository(ReactionRepository::class)
			->fastDeleteReactions('dbtech_social_message', $messageIds)
		;

		$db->delete('xf_dbtech_social_groups_message', 'message_id IN (' . $db->quote($messageIds) . ')');

		$db->delete('xf_approval_queue', 'content_id IN (' . $db->quote($messageIds) . ') AND content_type = ?', 'dbtech_social_message');
		$db->delete('xf_deletion_log', 'content_id IN (' . $db->quote($messageIds) . ') AND content_type = ?', 'dbtech_social_message');
		$db->delete('xf_edit_history', 'content_id IN (' . $db->quote($messageIds) . ') AND content_type = ?', 'dbtech_social_message');
	}

	/**
	 * @param string $reason
	 * @param User|null $byUser
	 *
	 * @return bool
	 * @throws PrintableException
	 */
	public function softDelete(string $reason = '', ?User $byUser = null): bool
	{
		$byUser = $byUser ?: \XF::visitor();

		if ($this->discussion_state == 'deleted')
		{
			return false;
		}

		$this->discussion_state = 'deleted';

		/** @var DeletionLog $deletionLog */
		$deletionLog = $this->getRelationOrDefault('DeletionLog');
		$deletionLog->setFromUser($byUser);
		$deletionLog->delete_reason = $reason;

		$this->save();

		return true;
	}

	/**
	 * @param EntityResult $result
	 * @param int $verbosity
	 * @param array $options
	 *
	 * @api-out str $username
	 * @api-out bool $is_watching <cond> If accessing as a user, true if they are watching this discussion
	 * @api-out int $visitor_message_count <cond> If accessing as a user, the number of messages they have made in this discussion
	 * @api-out array $tags
	 * @api-out bool $can_edit
	 * @api-out bool $can_edit_tags
	 * @api-out bool $can_reply
	 * @api-out bool $can_soft_delete
	 * @api-out bool $can_hard_delete
	 * @api-out bool $can_view_attachments
	 * @api-out Group $Group <cond> If requested by context, the group this discussion was posted in.
	 */
	protected function setupApiResultData(
		EntityResult $result,
		$verbosity = self::VERBOSITY_NORMAL,
		array $options = []
	): void
	{
		$result->username = $this->User ? $this->User->username : $this->username;

		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		if ($visitor->user_id)
		{
			$result->is_watching = isset($this->Watch[$visitor->user_id]);
			$result->visitor_message_count = $this->getUserMessageCount();
		}

		if (!empty($options['skip_group']))
		{
			$result->skipRelation('Group');
		}

		$result->tags = array_column($this->tags, 'tag');

		$result->can_edit = $this->canEdit();
		$result->can_edit_tags = $this->canEditTags();
		$result->can_reply = $this->canReply();
		$result->can_soft_delete = $this->canDelete();
		$result->can_hard_delete = $this->canDelete('hard');
		$result->can_view_attachments = $this->canViewAttachments();
	}

	/**
	 * @return string
	 */
	public function getContentContainerIdColumn(): string
	{
		return 'group_id';
	}

	/**
	 * @return string
	 */
	public function getContentDateColumn(): string
	{
		return 'message_date';
	}

	/**
	 * @return string
	 */
	public function getContentContainerType(): string
	{
		return 'dbtech_social_group';
	}

	/**
	 * @param bool $canonical
	 * @param array $extraParams
	 * @param null $hash
	 *
	 * @return string
	 */
	public function getContentUrl(bool $canonical = false, array $extraParams = [], $hash = null): string
	{
		$route = $canonical ? 'canonical:dbtech-social/discussions' : 'dbtech-social/discussions';
		return \XF::app()->router('public')->buildLink($route, $this, $extraParams, $hash);
	}

	/**
	 * @return string
	 */
	public function getContentPublicRoute(): string
	{
		return 'dbtech-social/discussions';
	}

	public function getContentTitle(string $context = ''): Phrase|string
	{
		return \XF::phrase('dbtech_social_groups_discussion_x', ['title' => $this->title]);
	}

	/**
	 * @param Structure $structure
	 *
	 * @return Structure
	 */
	public static function getStructure(Structure $structure): Structure
	{
		$structure->table = 'xf_dbtech_social_groups_discussion';
		$structure->shortName = 'DBTech\SocialGroups:Discussion';
		$structure->contentType = 'dbtech_social_discussion';
		$structure->primaryKey = 'discussion_id';
		$structure->columns = [
			'discussion_id' => ['type' => self::UINT, 'autoIncrement' => true, 'nullable' => true],
			'group_id' => ['type' => self::UINT, 'required' => true, 'api' => true],
			'section_id' => ['type' => self::UINT, 'default' => 0, 'api' => true],
			'title' => ['type' => self::STR, 'maxLength' => 150,
				'required' => 'please_enter_valid_title',
				'censor' => true,
				'api' => true,
			],
			'reply_count' => ['type' => self::UINT, 'forced' => true, 'default' => 0, 'api' => true],
			'view_count' => ['type' => self::UINT, 'forced' => true, 'default' => 0, 'api' => true],
			'user_id' => ['type' => self::UINT, 'required' => true, 'api' => true],
			'username' => ['type' => self::STR, 'maxLength' => 50, 'required' => true, 'api' => true],
			'message_date' => ['type' => self::UINT, 'default' => 0, 'api' => true],
			'sticky' => ['type' => self::BOOL, 'default' => false, 'api' => true],
			'discussion_state' => ['type' => self::STR, 'default' => 'visible',
				'allowedValues' => ['visible', 'moderated', 'deleted'], 'api' => true,
			],
			'discussion_open' => ['type' => self::BOOL, 'default' => true, 'api' => true],
			'discussion_type' => ['type' => self::STR, 'maxLength' => 25, 'default' => '', 'api' => true],
			'first_message_id' => ['type' => self::UINT, 'default' => 0, 'api' => true],
			'last_message_date' => ['type' => self::UINT, 'default' => 0, 'api' => true],
			'last_message_id' => ['type' => self::UINT, 'default' => 0, 'api' => true],
			'last_message_user_id' => ['type' => self::UINT, 'default' => 0, 'api' => true],
			'last_message_username' => ['type' => self::STR, 'maxLength' => 50, 'default' => '', 'api' => true],
			'first_message_reaction_score' => ['type' => self::INT, 'default' => 0, 'api' => true],
			'first_message_reactions' => ['type' => self::JSON_ARRAY, 'default' => [], 'nullable' => true],
			'tags' => ['type' => self::JSON_ARRAY, 'default' => []],
		];
		$structure->behaviors = [
			'XF:Taggable' => ['stateField' => 'discussion_state'],
			'XF:Indexable' => [
				'checkForUpdates' => ['title', 'group_id', 'user_id', 'tags', 'discussion_state', 'first_message_id'],
			],
			'XF:IndexableContainer' => [
				'childContentType' => 'dbtech_social_message',
				'childIds' => function ($discussion)
				{
					return $discussion->message_ids;
				},
				'checkForUpdates' => ['group_id', 'discussion_state'],
			],
			'XF:NewsFeedPublishable' => [
				'usernameField' => 'username',
				'dateField' => 'message_date',
			],
		];
		$structure->getters = [
			'draft_reply' => true,
			'message_ids' => true,
			'last_message_cache' => true,
		];
		$structure->relations = [
			'Group' => [
				'entity' => Group::class,
				'type' => self::TO_ONE,
				'conditions' => 'group_id',
				'primary' => true,
				'api' => true,
			],
			'Section' => [
				'entity' => Section::class,
				'type' => self::TO_ONE,
				'conditions' => 'section_id',
				'primary' => true,
				'api' => true,
			],
			'User' => [
				'entity' => User::class,
				'type' => self::TO_ONE,
				'conditions' => 'user_id',
				'primary' => true,
				'api' => true,
			],
			'FirstMessage' => [
				'entity' => Message::class,
				'type' => self::TO_ONE,
				'conditions' => [['message_id', '=', '$first_message_id']],
				'primary' => true,
			],
			'LastMessage' => [
				'entity' => Message::class,
				'type' => self::TO_ONE,
				'conditions' => [['message_id', '=', '$last_message_id']],
				'primary' => true,
			],
			'LastPoster' => [
				'entity' => User::class,
				'type' => self::TO_ONE,
				'conditions' => [['user_id', '=', '$last_message_user_id']],
				'primary' => true,
			],
			'Read' => [
				'entity' => DiscussionRead::class,
				'type' => self::TO_MANY,
				'conditions' => 'discussion_id',
				'key' => 'user_id',
			],
			'Watch' => [
				'entity' => DiscussionWatch::class,
				'type' => self::TO_MANY,
				'conditions' => 'discussion_id',
				'key' => 'user_id',
			],
			'UserMessages' => [
				'entity' => DiscussionUserMessage::class,
				'type' => self::TO_MANY,
				'conditions' => 'discussion_id',
				'key' => 'user_id',
			],
			'DeletionLog' => [
				'entity' => DeletionLog::class,
				'type' => self::TO_ONE,
				'conditions' => [
					['content_type', '=', 'dbtech_social_discussion'],
					['content_id', '=', '$discussion_id'],
				],
				'primary' => true,
			],
			'DraftReplies' => [
				'entity' => Draft::class,
				'type' => self::TO_MANY,
				'conditions' => [
					['draft_key', '=', 'dbtech-social-discussion-', '$discussion_id'],
				],
				'key' => 'user_id',
			],
			'ApprovalQueue' => [
				'entity' => ApprovalQueue::class,
				'type' => self::TO_ONE,
				'conditions' => [
					['content_type', '=', 'dbtech_social_discussion'],
					['content_id', '=', '$discussion_id'],
				],
				'primary' => true,
			],
			'ReplyBans' => [
				'entity' => DiscussionReplyBan::class,
				'type' => self::TO_MANY,
				'conditions' => 'discussion_id',
				'key' => 'user_id',
			],
			'Poll' => [
				'entity' => Poll::class,
				'type' => self::TO_ONE,
				'conditions' => [
					['content_type', '=', 'dbtech_social_discussion'],
					['content_id', '=', '$discussion_id'],
				],
			],
		];

		$structure->options = [
			'log_moderator' => true,
		];

		$structure->withAliases = [
			'full' => [
				'User',
				'LastPoster',
				function ()
				{
					$userId = \XF::visitor()->user_id;
					if ($userId)
					{
						return [
							'Read|' . $userId,
							'UserMessages|' . $userId,
							'Watch|' . $userId,
						];
					}

					return null;
				},
			],
			'fullGroup' => [
				'full',
				'section',
				function ()
				{
					$with = ['Group'];

					$userId = \XF::visitor()->user_id;
					if ($userId)
					{
						$with[] = 'Group.Read|' . $userId;
						$with[] = 'Group.Watch|' . $userId;
					}

					return $with;
				},
			],
			'section' => [
				function ()
				{
					$with = ['Section'];

					$userId = \XF::visitor()->user_id;
					if ($userId)
					{
						$with[] = 'Section.Read|' . $userId;
						$with[] = 'Section.Watch|' . $userId;
					}

					return $with;
				},
			],
			'fullSection' => [
				'full',
				'section',
			],
			'api' => [
				'Group.api',
				'User.api',
				function ()
				{
					$userId = \XF::visitor()->user_id;
					if ($userId)
					{
						return [
							'UserMessages|' . $userId,
							'Watch|' . $userId,
							'ReplyBans|' . $userId,
						];
					}

					return [];
				},
			],
		];

		static::addEmbedResolverStructureElements($structure);

		return $structure;
	}
}