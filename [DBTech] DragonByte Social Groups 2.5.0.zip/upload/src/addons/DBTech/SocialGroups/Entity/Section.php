<?php

namespace DBTech\SocialGroups\Entity;

use DBTech\SocialGroups\Job\SectionDeleteCleanUp;
use DBTech\SocialGroups\XF\Entity\User as ExtendedUserEntity;
use XF\Entity\BookmarkItem;
use XF\Entity\BookmarkTrait;
use XF\Entity\Draft;
use XF\Entity\LinkableInterface;
use XF\Entity\User;
use XF\Entity\ViewableInterface;
use XF\Mvc\Entity\AbstractCollection;
use XF\Mvc\Entity\Entity;
use XF\Mvc\Entity\Structure;
use XF\Mvc\Router;
use XF\Phrase;
use XF\PrintableException;

/**
 * COLUMNS
 * @property int|null $section_id
 * @property string $title
 * @property string $description
 * @property int $group_id
 * @property int $parent_section_id
 * @property int $display_order
 * @property int $lft
 * @property int $rgt
 * @property int $depth
 * @property array|null $breadcrumb_data
 * @property int $discussion_count
 * @property int $message_count
 * @property int $last_update_date
 * @property int $last_message_id
 * @property int $last_message_date
 * @property int $last_message_user_id
 * @property string $last_message_username
 * @property int $last_discussion_id
 * @property string $last_discussion_title
 * @property bool $staff_only
 * @property bool $moderate_discussions
 * @property bool $moderate_replies
 * @property bool $allow_posting
 * @property bool $allow_discussions
 * @property bool $allow_poll
 * @property bool $count_messages
 * @property bool $find_new
 * @property string $allowed_watch_notifications
 * @property string $default_sort_order
 * @property string $default_sort_direction
 * @property int $list_date_limit_days
 * @property array|null $tags
 * @property int $min_tags
 *
 * GETTERS
 * @property-read \XF\Draft $draft_discussion
 * @property-read Phrase $discussion_prompt
 *
 * RELATIONS
 * @property-read Group|null $Group
 * @property-read AbstractCollection<SectionRead> $Read
 * @property-read AbstractCollection<SectionWatch> $Watch
 * @property-read AbstractCollection<Draft> $DraftDiscussions
 * @property-read Message|null $LastMessage
 * @property-read User|null $LastMessageUser
 * @property-read Discussion|null $LastDiscussion
 * @property-read AbstractCollection<BookmarkItem> $Bookmarks
 */
class Section extends Entity implements LinkableInterface, ViewableInterface
{
	use BookmarkTrait;


	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canView(&$error = null): bool
	{
		if (!$this->Group)
		{
			return false;
		}

		if (!$this->Group->canView())
		{
			return false;
		}

		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		return (!$this->staff_only
			|| $visitor->isSupervisorOfSocialGroup($this->Group)
			|| $visitor->canEditAnyDbtechSocialGroups()
		);
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canBookmarkContent(&$error = null): bool
	{
		return ($this->canView($error)
			&& $this->canViewDiscussions()
		);
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canStartDiscussion(&$error = null): bool
	{
		if (!$this->Group)
		{
			return false;
		}

		if (!$this->Group->isVisible())
		{
			return false;
		}

		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		if ($visitor->canEditAnyDbtechSocialGroups())
		{
			return true;
		}

		if (!$this->Group->isGroupOwner() && !$visitor->isSupervisorOfSocialGroup($this->Group))
		{
			if (!$this->allow_discussions)
			{
				$error = \XF::phraseDeferred(
					'dbtech_social_groups_you_may_not_perform_this_action_because_section_does_not_allow_posting'
				);

				return false;
			}
		}

		return $this->Group->hasPermission('startDiscussion');
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canCreatePoll(&$error = null): bool
	{
		return $this->allow_poll;
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canViewDiscussions(&$error = null): bool
	{
		if (!$this->Group)
		{
			return false;
		}

		return ($this->canView()
			&& $this->Group->canViewDiscussions($error)
		);
	}

	/**
	 * @return bool
	 */
	public function canViewDeletedDiscussions(): bool
	{
		if (!$this->Group)
		{
			return false;
		}

		return $this->Group->hasPermission('viewDeleted');
	}

	/**
	 * @return bool
	 */
	public function canViewModeratedDiscussions(): bool
	{
		if (!$this->Group)
		{
			return false;
		}

		return $this->Group->hasPermission('viewModerated');
	}

	/**
	 * @return bool
	 */
	public function canUploadAndManageAttachments(): bool
	{
		if (!$this->Group)
		{
			return false;
		}

		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		return ($visitor->user_id && $this->Group->hasPermission('uploadAttachment'));
	}



	/**
	 * @param Discussion|null $discussion
	 * @param $error
	 *
	 * @return bool
	 */
	public function canEditTags(?Discussion $discussion = null, &$error = null): bool
	{
		if (!\XF::app()->options()->enableTagging)
		{
			return false;
		}

		if (!$this->Group)
		{
			return false;
		}

		return $this->Group->canEditTags($discussion, $error);
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canWatch(&$error = null): bool
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		return ($visitor->user_id
			&& $this->canViewDiscussions()
		);
	}

	/**
	 * @return bool
	 */
	public function isUnread(): bool
	{
		if (!$this->discussion_count)
		{
			return false;
		}

		$cutOff = \XF::$time - \XF::app()->options()->readMarkingDataLifetime * 86400;
		if ($this->last_message_date < $cutOff)
		{
			return false;
		}

		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();
		if ($visitor->user_id)
		{
			$read = $this->Read[$visitor->user_id];

			return (!$read || $read->section_read_date < $this->last_message_date);
		}
		else
		{
			return true;
		}
	}

	public function hasChildren(): bool
	{
		return ($this->rgt - $this->lft) > 1;
	}

	/**
	 * @return bool
	 */
	public function isSearchEngineIndexable(): bool
	{
		/*
		if ($this->allow_index == 'deny')
		{
			return false;
		}
		*/

		return true;
	}

	/**
	 * @return bool
	 */
	public function doesMessageCount(): bool
	{
		if (!$this->Group)
		{
			return false;
		}

		return ($this->count_messages
			&& !(\XF::options()->dbtechSocialDisabledPostCounters[$this->Group->group_type] ?? false)
		);
	}

	/**
	 * @return \XF\Draft
	 */
	public function getDraftDiscussion(): \XF\Draft
	{
		return \XF\Draft::createFromEntity($this, 'DraftDiscussions');
	}

	/**
	 * @param bool $includeSelf
	 * @param string $linkType
	 *
	 * @return array
	 */
	public function getBreadcrumbs(bool $includeSelf = true, string $linkType = 'public'): array
	{
		if (!$this->Group)
		{
			return [];
		}

		$output = $this->Group->getBreadcrumbs($includeSelf, $linkType);

		/** @var Router $router */
		$router = \XF::app()->container('router.' . $linkType);

		$output[] = [
			'value' => \XF::phrase('dbtech_social_groups_discussions_nav'),
			'href' => $router->buildLink('dbtech-social/discussions/list', $this->Group),
		];

		if ($this->breadcrumb_data)
		{
			foreach ($this->breadcrumb_data AS $crumb)
			{
				$output[] = [
					'value' => $crumb['title'],
					'href' => $router->buildLink('dbtech-social/sections', $crumb),
					'section_id' => $crumb['section_id'],
				];
			}
		}

		if ($includeSelf)
		{
			$output[] = [
				'value' => $this->title,
				'href' => $router->buildLink('dbtech-social/sections', $this),
				'section_id' => $this->section_id,
			];
		}

		return $output;
	}

	/**
	 * @param int $depth
	 *
	 * @return string[]
	 */
	public function getSectionTemplateRenderer(int $depth): array
	{
		return [
			'template' => 'dbtech_social_groups_section_list_macros',
			'macro'    => $depth <= 2 ? 'depth' . $depth : 'depthN',
		];
	}

	/**
	 * @return array
	 */
	public function getSectionListExtras(): array
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		$output = [
			'discussion_count' => $this->discussion_count,
			'message_count'    => $this->message_count,
		];

		if ($this->Group
			&& $this->Group->hasPermission('viewOthers')
			&& $this->canViewDiscussions()
		)
		{
			$output['hasNew'] = $this->isUnread();

			if ($this->last_message_date)
			{
				$output['last_message_id'] = $this->last_message_id;
				$output['last_message_date'] = $this->last_message_date;
				$output['last_message_user_id'] = $this->last_message_user_id;
				$output['last_message_username'] = $this->last_message_username;
				$output['last_discussion_id'] = $this->last_discussion_id;
				$output['last_discussion_title'] = \XF::app()->stringFormatter()->censorText($this->last_discussion_title);
				$output['LastMessageUser'] = $this->LastMessageUser;
				$output['LastDiscussion'] = $this->LastDiscussion;
			}
		}
		else
		{
			$output['privateInfo'] = true;
		}

		return $output;
	}

	/**
	 * @return Phrase
	 */
	public function getDiscussionPrompt(): Phrase
	{
		static $phraseName; // always return the same phrase for the same section instance

		if (!$phraseName)
		{
			//			if ($this->prompt_cache)
			//			{
			//				$phraseName = 'dbtech_social_groups_discussion_prompt.' . \array_rand($this->prompt_cache);
			//			}
			//			else
			//			{
			$phraseName = 'dbtech_social_groups_discussion_prompt.default';
			//			}
		}

		return \XF::phrase($phraseName);
	}

	/**
	 * @param Discussion|null $discussion
	 *
	 * @return string
	 */
	public function getNewContentState(?Discussion $discussion = null): string
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		if ($visitor->user_id && $this->Group && $this->Group->hasPermission('approveUnapprove'))
		{
			return 'visible';
		}

		if ($visitor->canEditAnyDbtechSocialGroups())
		{
			return 'visible';
		}

		if (!$visitor->hasPermission('general', 'submitWithoutApproval'))
		{
			return 'moderated';
		}

		if ($discussion)
		{
			return $this->moderate_replies ? 'moderated' : 'visible';
		}
		else
		{
			return $this->moderate_discussions ? 'moderated' : 'visible';
		}
	}

	/**
	 * @param Entity $entity
	 */
	public function contentAdded(Entity $entity): void
	{
		$this->last_update_date = \XF::$time;
	}

	/**
	 * @return Discussion
	 */
	public function getNewDiscussion(): Discussion
	{
		$discussion = \XF::app()->em()->create(Discussion::class);
		$discussion->group_id = $this->group_id;
		$discussion->section_id = $this->section_id;

		return $discussion;
	}

	/**
	 * @param Discussion $discussion
	 */
	public function discussionAdded(Discussion $discussion): void
	{
		if ($discussion->discussion_type == 'redirect')
		{
			return;
		}

		$this->contentAdded($discussion);

		$this->discussion_count++;
		$this->message_count += 1 + $discussion->reply_count;

		if ($discussion->last_message_date >= $this->last_message_date)
		{
			$this->last_message_date = $discussion->last_message_date;
			$this->last_message_id = $discussion->last_message_id;
			$this->last_message_user_id = $discussion->last_message_user_id;
			$this->last_message_username = $discussion->last_message_username;
			$this->last_discussion_id = $discussion->discussion_id;
			$this->last_discussion_title = $discussion->title;
		}
	}

	/**
	 * @param Discussion $discussion
	 */
	public function discussionDataChanged(Discussion $discussion): void
	{
		$isRedirect = $discussion->discussion_type == 'redirect';
		$wasRedirect = $discussion->getExistingValue('discussion_type') == 'redirect';

		if ($isRedirect && !$wasRedirect)
		{
			// this is like the discussion being deleted for counter purposes
			$this->discussionRemoved($discussion);
		}
		else if (!$isRedirect && $wasRedirect)
		{
			// like being added
			$this->discussionAdded($discussion);
		}
		else if ($isRedirect)
		{
			return;
		}

		$this->message_count += $discussion->reply_count - $discussion->getExistingValue('reply_count');

		if ($discussion->last_message_date >= $this->last_message_date)
		{
			$this->last_message_date = $discussion->last_message_date;
			$this->last_message_id = $discussion->last_message_id;
			$this->last_message_user_id = $discussion->last_message_user_id;
			$this->last_message_username = $discussion->last_message_username;
			$this->last_discussion_id = $discussion->discussion_id;
			$this->last_discussion_title = $discussion->title;
		}
		else if ($discussion->getExistingValue('last_message_id') == $this->last_message_id)
		{
			$this->rebuildLastMessage();
		}
	}

	/**
	 * @param Discussion $discussion
	 */
	public function discussionRemoved(Discussion $discussion): void
	{
		if ($discussion->discussion_type == 'redirect')
		{
			// if this was changed, it used to count so we need to continue
			if (!$discussion->isChanged('discussion_type'))
			{
				return;
			}
		}

		$this->discussion_count--;
		$this->message_count -= 1 + $discussion->reply_count;

		if ($discussion->last_message_id == $this->last_message_id)
		{
			$this->rebuildLastMessage();
		}
	}

	/**
	 * @return bool
	 */
	public function rebuildCounters(): bool
	{
		$discussionCounters = $this->db()->fetchRow("
			SELECT COUNT(*) AS discussion_count,
				COUNT(*) + COALESCE(SUM(reply_count), 0) AS message_count
			FROM xf_dbtech_social_groups_discussion
			WHERE section_id = ?
				AND discussion_state = 'visible'
				AND discussion_type <> 'redirect'
		", $this->section_id);

		$this->discussion_count = $discussionCounters['discussion_count'];
		$this->message_count = $discussionCounters['message_count'];

		$this->rebuildLastMessage();

		return true;
	}

	/**
	 *
	 */
	public function rebuildLastMessage(): void
	{
		$discussion = $this->db()->fetchRow("
			SELECT *
			FROM xf_dbtech_social_groups_discussion
			WHERE section_id = ?
				AND discussion_state = 'visible'
				AND discussion_type <> 'redirect'
			ORDER BY last_message_date DESC
			LIMIT 1
		", $this->section_id);
		if ($discussion)
		{
			$this->last_message_id = $discussion['last_message_id'];
			$this->last_message_date = $discussion['last_message_date'];
			$this->last_message_user_id = $discussion['last_message_user_id'];
			$this->last_message_username = $discussion['last_message_username'];
			$this->last_discussion_id = $discussion['discussion_id'];
			$this->last_discussion_title = $discussion['title'];
		}
		else
		{
			$this->last_message_id = 0;
			$this->last_message_date = 0;
			$this->last_message_user_id = 0;
			$this->last_message_username = '';
			$this->last_discussion_id = 0;
			$this->last_discussion_title = '';
		}
	}

	/**
	 * @param bool $canonical
	 * @param array $extraParams
	 * @param null $hash
	 *
	 * @return string
	 */
	public function getContentUrl(bool $canonical = false, array $extraParams = [], $hash = null): string
	{
		$route = $canonical ? 'canonical:dbtech-social/sections' : 'dbtech-social/sections';
		return \XF::app()->router('public')->buildLink($route, $this, $extraParams, $hash);
	}

	/**
	 * @return string|null
	 */
	public function getContentPublicRoute(): ?string
	{
		return 'dbtech-social/sections';
	}

	/**
	 * @param string $context
	 *
	 * @return Phrase
	 */
	public function getContentTitle(string $context = ''): Phrase
	{
		return \XF::phrase(
			'dbtech_social_groups_section_x_in_group_y',
			[
				'title' => $this->title,
				'group' => $this->Group ? $this->Group->title : \XF::phrase('n_a'),
			]
		);
	}



	/**
	 * @throws PrintableException
	 */
	protected function updateGroupRecord(): void
	{
		if (!$this->Group || !$this->Group->exists())
		{
			return;
		}

		/** @var Group $group */
		$group = $this->Group;

		$group->sectionAdded($this);
		$group->save();
	}

	/**
	 * @return void
	 * @throws PrintableException
	 */
	protected function _postSave(): void
	{
		if ($this->isInsert())
		{
			$this->updateGroupRecord();
		}
	}

	/**
	 * @return void
	 * @throws PrintableException
	 */
	protected function _postDelete(): void
	{
		if ($this->Group)
		{
			$this->Group->sectionRemoved($this);
			$this->Group->save();
		}

		if ($this->getOption('enqueue_delete_cleanup'))
		{
			\XF::app()->jobManager()->enqueue(SectionDeleteCleanUp::class, [
				'sectionId' => $this->section_id,
				'title' => $this->title,
				'userId' => \XF::visitor()->user_id,
			]);
		}
	}

	/**
	 * @param Structure $structure
	 *
	 * @return Structure
	 */
	public static function getStructure(Structure $structure): Structure
	{
		$structure->table = 'xf_dbtech_social_groups_section';
		$structure->shortName = 'DBTech\SocialGroups:Section';
		$structure->contentType = 'dbtech_social_section';
		$structure->primaryKey = 'section_id';
		$structure->columns = [
			'section_id'                  => ['type' => self::UINT, 'autoIncrement' => true, 'nullable' => true],
			'title'                       => [
				'type'     => self::STR, 'maxLength' => 50,
				'required' => 'please_enter_valid_title', 'api' => true,
			],
			'description'                 => ['type' => self::STR, 'default' => '', 'api' => true],
			'group_id'                    => ['type' => self::UINT, 'required' => true],
			'parent_section_id'           => ['type' => self::UINT, 'default' => 0],
			'display_order'               => ['type' => self::UINT, 'forced' => true, 'default' => 10],
			'lft'                         => ['type' => self::UINT],
			'rgt'                         => ['type' => self::UINT],
			'depth'                       => ['type' => self::UINT],
			'breadcrumb_data'             => ['type' => self::JSON_ARRAY, 'default' => []],
			'discussion_count'            => ['type' => self::UINT, 'forced' => true, 'default' => 0],
			'message_count'               => ['type' => self::UINT, 'forced' => true, 'default' => 0],
			'last_update_date'            => ['type' => self::UINT, 'default' => 0],
			'last_message_id'             => ['type' => self::UINT, 'default' => 0],
			'last_message_date'           => ['type' => self::UINT, 'default' => 0],
			'last_message_user_id'        => ['type' => self::UINT, 'default' => 0],
			'last_message_username'       => ['type' => self::STR, 'maxLength' => 50, 'default' => ''],
			'last_discussion_id'          => ['type' => self::UINT, 'default' => 0],
			'last_discussion_title'       => ['type' => self::STR, 'maxLength' => 150, 'default' => ''],
			'staff_only'                  => ['type' => self::BOOL, 'default' => false],
			'moderate_discussions'        => ['type' => self::BOOL, 'default' => false],
			'moderate_replies'            => ['type' => self::BOOL, 'default' => false],
			'allow_posting'               => ['type' => self::BOOL, 'default' => true, 'api' => true],
			'allow_discussions'           => ['type' => self::BOOL, 'default' => true, 'api' => true],
			'allow_poll'                  => ['type' => self::BOOL, 'default' => true, 'api' => true],
			'count_messages'              => ['type' => self::BOOL, 'default' => true],
			'find_new'                    => ['type' => self::BOOL, 'default' => true],
			'allowed_watch_notifications' => [
				'type'          => self::STR, 'default' => 'all',
				'allowedValues' => ['all', 'discussion', 'none'],
			],
			'default_sort_order'          => [
				'type'          => self::STR, 'default' => 'last_message_date',
				'allowedValues' => ['title', 'message_date', 'reply_count', 'view_count', 'last_message_date'],
			],
			'default_sort_direction'      => [
				'type'          => self::STR, 'default' => 'desc',
				'allowedValues' => ['asc', 'desc'],
			],
			'list_date_limit_days'        => ['type' => self::UINT, 'default' => 0, 'max' => 3650],
			'tags'                        => ['type' => self::JSON_ARRAY, 'default' => []],
			'min_tags'                    => ['type' => self::UINT, 'default' => 0, 'max' => 100, 'api' => true],
		];
		$structure->getters = [
			'draft_discussion'  => true,
			'discussion_prompt' => true,
		];
		$structure->relations = [
			'Group' => [
				'entity'     => Group::class,
				'type'       => self::TO_ONE,
				'conditions' => 'group_id',
				'primary'    => true,
			],
			'Read'             => [
				'entity'     => SectionRead::class,
				'type'       => self::TO_MANY,
				'conditions' => 'section_id',
				'key'        => 'user_id',
			],
			'Watch'            => [
				'entity'     => SectionWatch::class,
				'type'       => self::TO_MANY,
				'conditions' => 'section_id',
				'key'        => 'user_id',
			],
			'DraftDiscussions' => [
				'entity'     => Draft::class,
				'type'       => self::TO_MANY,
				'conditions' => [
					['draft_key', '=', 'dbtech-social-groups-section-', '$section_id'],
				],
				'key'        => 'user_id',
			],
			'LastMessage'      => [
				'entity'     => Message::class,
				'type'       => self::TO_ONE,
				'conditions' => [['message_id', '=', '$last_message_id']],
				'primary'    => true,
			],
			'LastMessageUser'  => [
				'entity'     => User::class,
				'type'       => self::TO_ONE,
				'conditions' => [['user_id', '=', '$last_message_user_id']],
				'primary'    => true,
			],
			'LastDiscussion'   => [
				'entity'     => Discussion::class,
				'type'       => self::TO_ONE,
				'conditions' => [['discussion_id', '=', '$last_discussion_id']],
				'primary'    => true,
			],
		];

		$structure->behaviors = [
			'XF:TreeStructured' => [
				'parentField' => 'parent_section_id',
			],
		];

		$structure->options = [
			'enqueue_delete_cleanup' => true,
		];

		$structure->withAliases = [
			'full' => [
				function ()
				{
					$with = ['LastDiscussion'];

					$visitor = \XF::visitor();

					$userId = $visitor->user_id;
					if ($userId)
					{
						$with[] = 'Read|' . $userId;
						$with[] = 'Watch|' . $userId;
						$with[] = 'LastDiscussion.Read|' . $userId;
					}

					return $with;
				},
			],
			function ()
			{
				$userId = \XF::visitor()->user_id;
				if ($userId)
				{
					return [
						'Bookmarks|' . $userId,
					];
				}

				return null;
			},
		];

		static::addBookmarkableStructureElements($structure);

		return $structure;
	}
}