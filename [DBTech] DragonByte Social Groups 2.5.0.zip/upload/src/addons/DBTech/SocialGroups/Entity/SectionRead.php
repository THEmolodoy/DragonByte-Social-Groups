<?php

namespace DBTech\SocialGroups\Entity;

use XF\Entity\User;
use XF\Mvc\Entity\Entity;
use XF\Mvc\Entity\Structure;

/**
 * COLUMNS
 * @property int|null $section_read_id
 * @property int $user_id
 * @property int $section_id
 * @property int $section_read_date
 *
 * RELATIONS
 * @property-read User|null $User
 * @property-read Section|null $Section
 */
class SectionRead extends Entity
{
	/**
	 * @param Structure $structure
	 *
	 * @return Structure
	 */
	public static function getStructure(Structure $structure): Structure
	{
		$structure->table = 'xf_dbtech_social_groups_section_read';
		$structure->shortName = 'DBTech\SocialGroups:SectionRead';
		$structure->primaryKey = 'section_read_id';
		$structure->columns = [
			'section_read_id' => ['type' => self::UINT, 'autoIncrement' => true, 'nullable' => true],
			'user_id' => ['type' => self::UINT, 'required' => true],
			'section_id' => ['type' => self::UINT, 'required' => true],
			'section_read_date' => ['type' => self::UINT, 'required' => true],
		];
		$structure->getters = [];
		$structure->relations = [
			'User' => [
				'entity' => User::class,
				'type' => self::TO_ONE,
				'conditions' => 'user_id',
				'primary' => true,
			],
			'Section' => [
				'entity' => Section::class,
				'type' => self::TO_ONE,
				'conditions' => 'section_id',
				'primary' => true,
			],
		];

		return $structure;
	}
}