<?php

namespace DBTech\SocialGroups\Entity;

use DBTech\SocialGroups\Repository\GroupInviteRepository;
use XF\Entity\User;
use XF\Entity\ViewableInterface;
use XF\Mvc\Entity\Entity;
use XF\Mvc\Entity\Structure;
use XF\PrintableException;
use XF\Repository\UserAlertRepository;

/**
 * COLUMNS
 * @property int|null $group_invite_id
 * @property int $user_id
 * @property int $group_id
 * @property int $invited_by_user_id
 * @property int $invite_date
 * @property string $reason
 *
 * RELATIONS
 * @property-read Group|null $Group
 * @property-read User|null $User
 * @property-read User|null $InviteUser
 */
class GroupInvite extends Entity implements ViewableInterface
{
	/**
	 * @return bool
	 */
	public function canView(): bool
	{
		return $this->Group->canView();
	}

	/**
	 * @return void
	 * @throws PrintableException
	 */
	protected function _postSave(): void
	{
		if ($this->isInsert())
		{
			$this->User->updateDbtechSocialGroupInvitationCount();
			$this->User->save(true, false);

			\XF::app()->repository(GroupInviteRepository::class)
				->sendInviteAlert($this)
			;
		}
	}

	/**
	 * @return void
	 * @throws PrintableException
	 */
	protected function _postDelete(): void
	{
		$this->User->updateDbtechSocialGroupInvitationCount();
		$this->User->save(true, false);

		\XF::app()->repository(UserAlertRepository::class)
			->fastDeleteAlertsForContent('dbtech_social_invite', $this->group_invite_id)
		;
	}

	/**
	 * @param Structure $structure
	 *
	 * @return Structure
	 */
	public static function getStructure(Structure $structure): Structure
	{
		$structure->table = 'xf_dbtech_social_groups_group_invite';
		$structure->shortName = 'DBTech\SocialGroups:GroupInvite';
		$structure->primaryKey = 'group_invite_id';
		$structure->columns = [
			'group_invite_id'    => ['type' => self::UINT, 'autoIncrement' => true, 'nullable' => true],
			'user_id'            => ['type' => self::UINT, 'required' => true],
			'group_id'           => ['type' => self::UINT, 'required' => true],
			'invited_by_user_id' => ['type' => self::UINT, 'required' => true],
			'invite_date'        => ['type' => self::UINT, 'default' => \XF::$time],
			'reason'             => ['type' => self::STR, 'maxLength' => 255, 'default' => ''],
		];
		$structure->getters = [];
		$structure->relations = [
			'Group' => [
				'entity'     => Group::class,
				'type'       => self::TO_ONE,
				'conditions' => 'group_id',
				'primary'    => true,
			],
			'User'  => [
				'entity'     => User::class,
				'type'       => self::TO_ONE,
				'conditions' => 'user_id',
				'primary'    => true,
			],
			'InviteUser'  => [
				'entity'     => User::class,
				'type'       => self::TO_ONE,
				'conditions' => [
					['user_id', '=', '$invited_by_user_id'],
				],
				'primary'    => true,
			],
		];

		return $structure;
	}
}