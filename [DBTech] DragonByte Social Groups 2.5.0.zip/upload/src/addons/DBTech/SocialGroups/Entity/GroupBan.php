<?php

namespace DBTech\SocialGroups\Entity;

use DBTech\SocialGroups\Repository\BanningRepository;
use XF\Entity\User;
use XF\Mvc\Entity\Entity;
use XF\Mvc\Entity\Structure;
use XF\PrintableException;

/**
 * COLUMNS
 * @property int $user_id
 * @property int $group_id
 * @property int $ban_user_id
 * @property int $ban_date
 * @property int $end_date
 * @property string $user_reason
 * @property bool $triggered
 *
 * RELATIONS
 * @property-read User|null $User
 * @property-read Group|null $Group
 * @property-read GroupMember|null $GroupMember
 * @property-read User|null $BanUser
 */
class GroupBan extends Entity
{
	/**
	 * @return void
	 */
	protected function _preSave(): void
	{
		if ($this->isInsert())
		{
			if (!$this->getOption('admin_edit') && $this->user_id === \XF::visitor()->user_id)
			{
				$this->error(
					\XF::phraseDeferred('dbtech_social_groups_cannot_manage_own_ban'),
					'user_id'
				);
				return;
			}

			if (!$this->User
				|| $this->User->is_admin
				|| $this->User->is_moderator
				|| $this->Group->Moderators[$this->user_id]
			)
			{
				$this->error(
					\XF::phraseDeferred('this_user_is_an_admin_or_moderator_choose_another'),
					'user_id'
				);
				return;
			}

			/** @var GroupMember $groupMember */
			$groupMember = $this->GroupMember;
			if ($groupMember && $groupMember->is_supervisor)
			{
				$this->error(
					\XF::phraseDeferred('dbtech_social_groups_this_user_is_a_supervisor_choose_another'),
					'user_id'
				);
				return;
			}

			$existingRecord = \XF::app()->em()->find(GroupBan::class, [
				'user_id' => $this->user_id,
				'group_id' => $this->group_id,
			]);
			if ($existingRecord)
			{
				$this->error(
					\XF::phraseDeferred('this_user_is_already_banned'),
					'user_id'
				);
			}
		}
		else
		{
			if ($this->isChanged('user_id'))
			{
				throw new \LogicException("Cannot change user_id of a ban record");
			}
		}
	}

	/**
	 * @return void
	 * @throws PrintableException
	 */
	protected function _postSave(): void
	{
		if ($this->isInsert())
		{
			$this->setIsBanned(true);
		}
	}

	/**
	 * @return void
	 * @throws PrintableException
	 */
	protected function _postDelete(): void
	{
		$this->setIsBanned(false);
	}

	/**
	 * @param bool $isBanned
	 *
	 * @return void
	 * @throws PrintableException
	 */
	protected function setIsBanned(bool $isBanned): void
	{
		/** @var GroupMember $groupMember */
		$groupMember = $this->GroupMember;
		if ($groupMember)
		{
			$groupMember->member_state = $isBanned ? 'banned' : 'valid';
			$groupMember->save();
		}

		$banningRepo = \XF::app()->repository(BanningRepository::class);
		if ($isBanned)
		{
			$banningRepo->applyGroupBanPermissionsToUser($this->Group, $this->User);
		}
		else
		{
			$banningRepo->removeGroupBanPermissionsFromUser($this->Group, $this->User);
		}
	}

	/**
	 * @param Structure $structure
	 *
	 * @return Structure
	 */
	public static function getStructure(Structure $structure): Structure
	{
		$structure->table = 'xf_dbtech_social_groups_group_ban';
		$structure->shortName = 'DBTech\SocialGroups:GroupBan';
		$structure->primaryKey = ['user_id', 'group_id'];
		$structure->columns = [
			'user_id' => ['type' => self::UINT, 'required' => true],
			'group_id' => ['type' => self::UINT, 'required' => true],
			'ban_user_id' => ['type' => self::UINT, 'required' => true],
			'ban_date' => ['type' => self::UINT, 'default' => \XF::$time],
			'end_date' => ['type' => self::UINT, 'required' => true],
			'user_reason' => ['type' => self::STR, 'maxLength' => 255, 'forced' => true, 'default' => ''],
			'triggered' => ['type' => self::BOOL, 'default' => false],
		];
		$structure->getters = [];
		$structure->relations = [
			'User' => [
				'entity' => User::class,
				'type' => self::TO_ONE,
				'conditions' => 'user_id',
				'primary' => true,
			],
			'Group' => [
				'entity' => Group::class,
				'type' => self::TO_ONE,
				'conditions' => 'group_id',
				'primary' => true,
			],
			'GroupMember' => [
				'entity' => GroupMember::class,
				'type' => self::TO_ONE,
				'conditions' => [
					['user_id', '=', '$user_id'],
					['group_id', '=', '$group_id'],
				],
			],
			'BanUser' => [
				'entity' => User::class,
				'type' => self::TO_ONE,
				'conditions' => [
					['user_id', '=', '$ban_user_id'],
				],
				'primary' => true,
			],
		];

		$structure->options = [
			'admin_edit' => false,
		];

		$structure->defaultWith[] = 'User';
		$structure->defaultWith[] = 'Group';

		return $structure;
	}
}