<?php

namespace DBTech\SocialGroups\Entity;

use XF\Entity\User;
use XF\Mvc\Entity\Entity;
use XF\Mvc\Entity\Structure;

/**
 * COLUMNS
 * @property int|null $group_read_id
 * @property int $user_id
 * @property int $group_id
 * @property int $group_read_date
 *
 * RELATIONS
 * @property-read User|null $User
 * @property-read Group|null $Group
 */
class GroupRead extends Entity
{
	/**
	 * @param Structure $structure
	 *
	 * @return Structure
	 */
	public static function getStructure(Structure $structure): Structure
	{
		$structure->table = 'xf_dbtech_social_groups_group_read';
		$structure->shortName = 'DBTech\SocialGroups:GroupRead';
		$structure->primaryKey = 'group_read_id';
		$structure->columns = [
			'group_read_id' => ['type' => self::UINT, 'autoIncrement' => true, 'nullable' => true],
			'user_id' => ['type' => self::UINT, 'required' => true],
			'group_id' => ['type' => self::UINT, 'required' => true],
			'group_read_date' => ['type' => self::UINT, 'required' => true],
		];
		$structure->getters = [];
		$structure->relations = [
			'User' => [
				'entity' => User::class,
				'type' => self::TO_ONE,
				'conditions' => 'user_id',
				'primary' => true,
			],
			'Group' => [
				'entity' => Group::class,
				'type' => self::TO_ONE,
				'conditions' => 'group_id',
				'primary' => true,
			],
		];

		return $structure;
	}
}