<?php

namespace DBTech\SocialGroups\Entity;

use XF\Entity\User;
use XF\Mvc\Entity\Entity;
use XF\Mvc\Entity\Structure;

/**
 * COLUMNS
 * @property int $discussion_id
 * @property int $user_id
 * @property int $message_count
 *
 * RELATIONS
 * @property-read Discussion|null $Discussion
 * @property-read User|null $User
 */
class DiscussionUserMessage extends Entity
{
	/**
	 * @param Structure $structure
	 *
	 * @return Structure
	 */
	public static function getStructure(Structure $structure): Structure
	{
		$structure->table = 'xf_dbtech_social_groups_discussion_user_message';
		$structure->shortName = 'DBTech\SocialGroups:DiscussionUserMessage';
		$structure->primaryKey = ['discussion_id', 'user_id'];
		$structure->columns = [
			'discussion_id' => ['type' => self::UINT,  'required' => true],
			'user_id' => ['type' => self::UINT, 'required' => true],
			'message_count' => ['type' => self::UINT, 'default' => 0],
		];
		$structure->relations = [
			'Discussion' => [
				'entity' => Discussion::class,
				'type' => self::TO_ONE,
				'conditions' => 'discussion_id',
				'primary' => true,
			],
			'User' => [
				'entity' => User::class,
				'type' => self::TO_ONE,
				'conditions' => 'user_id',
				'primary' => true,
			],
		];

		return $structure;
	}
}