<?php

namespace DBTech\SocialGroups\Entity;

use XF\Api\Result\EntityResult;
use XF\BbCode\RenderableContentInterface;
use XF\Db\Exception as DbException;
use XF\Entity\ApprovalQueue;
use XF\Entity\Attachment;
use XF\Entity\BookmarkItem;
use XF\Entity\BookmarkTrait;
use XF\Entity\DatableInterface;
use XF\Entity\DatableTrait;
use XF\Entity\DeletionLog;
use XF\Entity\EmbedRendererTrait;
use XF\Entity\EmbedResolverTrait;
use XF\Entity\LinkableInterface;
use XF\Entity\QuotableInterface;
use XF\Entity\ReactionContent;
use XF\Entity\ReactionTrait;
use XF\Entity\User;
use XF\Entity\ViewableInterface;
use XF\Mvc\Entity\AbstractCollection;
use XF\Mvc\Entity\Entity;
use XF\Mvc\Entity\Structure;
use XF\Phrase;
use XF\PrintableException;
use XF\Repository\AttachmentRepository;
use XF\Repository\UserAlertRepository;
use XF\Spam\ContentChecker;

/**
 * COLUMNS
 * @property int|null $message_id
 * @property int $discussion_id
 * @property int $user_id
 * @property string $username
 * @property int $message_date
 * @property string $message
 * @property int $ip_id
 * @property string $message_state
 * @property int $attach_count
 * @property int $warning_id
 * @property string $warning_message
 * @property int $position
 * @property int $last_edit_date
 * @property int $last_edit_user_id
 * @property int $edit_count
 * @property array|null $embed_metadata
 * @property int $reaction_score
 * @property array|null $reactions_
 * @property array|null $reaction_users_
 *
 * GETTERS
 * @property-read array $Unfurls
 * @property mixed $reactions
 * @property mixed $reaction_users
 * @property-read array $Embeds
 *
 * RELATIONS
 * @property-read Discussion|null $Discussion
 * @property-read User|null $User
 * @property-read AbstractCollection<Attachment> $Attachments
 * @property-read DeletionLog|null $DeletionLog
 * @property-read ApprovalQueue|null $ApprovalQueue
 * @property-read AbstractCollection<ReactionContent> $Reactions
 * @property-read AbstractCollection<BookmarkItem> $Bookmarks
 */
class Message extends Entity implements DatableInterface, LinkableInterface, QuotableInterface, RenderableContentInterface, ViewableInterface
{
	use BookmarkTrait;
	use DatableTrait;
	use ReactionTrait;
	use EmbedRendererTrait;
	use EmbedResolverTrait;

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canView(&$error = null): bool
	{
		if (!$this->Discussion || !$this->Discussion->canView($error))
		{
			return false;
		}

		$visitor = \XF::visitor();
		$groupId = $this->Discussion->group_id;

		if ($this->message_state == 'moderated')
		{
			if (
				!$visitor->hasDbtechSocialGroupsGroupPermission($groupId, 'viewModerated')
				&& (!$visitor->user_id || $visitor->user_id != $this->user_id)
			)
			{
				$error = \XF::phraseDeferred('dbtech_social_groups_requested_message_not_found');
				return false;
			}
		}
		else if ($this->message_state == 'deleted')
		{
			if (!$visitor->hasDbtechSocialGroupsGroupPermission($groupId, 'viewDeleted'))
			{
				$error = \XF::phraseDeferred('dbtech_social_groups_requested_message_not_found');
				return false;
			}
		}

		return true;
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canEdit(&$error = null): bool
	{
		$discussion = $this->Discussion;
		$visitor = \XF::visitor();
		if (!$visitor->user_id || !$discussion)
		{
			return false;
		}

		if (!$discussion->discussion_open && !$discussion->canLockUnlock())
		{
			$error = \XF::phraseDeferred('you_may_not_perform_this_action_because_discussion_is_closed');
			return false;
		}

		$groupId = $discussion->group_id;

		if ($visitor->hasDbtechSocialGroupsGroupPermission($groupId, 'editAnyMessage'))
		{
			return true;
		}

		if ($this->user_id == $visitor->user_id && $visitor->hasDbtechSocialGroupsGroupPermission($groupId, 'editOwnMessage'))
		{
			$editLimit = $visitor->hasDbtechSocialGroupsGroupPermission($groupId, 'editOwnMessageTimeLimit');
			if ($editLimit != -1 && (!$editLimit || $this->message_date < \XF::$time - 60 * $editLimit))
			{
				$error = \XF::phraseDeferred('message_edit_time_limit_expired', ['minutes' => $editLimit]);
				return false;
			}

			if (!$discussion->Group || !$discussion->Group->allow_posting)
			{
				$error = \XF::phraseDeferred('dbtech_social_groups_you_may_not_perform_this_action_because_group_does_not_allow_posting');
				return false;
			}

			return true;
		}

		return false;
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canEditSilently(&$error = null): bool
	{
		$discussion = $this->Discussion;
		$visitor = \XF::visitor();
		if (!$visitor->user_id || !$discussion)
		{
			return false;
		}

		$groupId = $discussion->group_id;

		if ($visitor->hasDbtechSocialGroupsGroupPermission($groupId, 'editAnyMessage'))
		{
			return true;
		}

		return false;
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canUseInlineModeration(&$error = null): bool
	{
		return $this->Discussion->canUseInlineModeration($error);
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canViewHistory(&$error = null): bool
	{
		$visitor = \XF::visitor();
		if (!$visitor->user_id)
		{
			return false;
		}

		if (!\XF::app()->options()->editHistory['enabled'])
		{
			return false;
		}

		if ($visitor->hasDbtechSocialGroupsGroupPermission($this->Discussion->group_id, 'editAnyMessage'))
		{
			return true;
		}

		return false;
	}

	/**
	 * @param string $type
	 * @param $error
	 *
	 * @return bool
	 */
	public function canDelete(string $type = 'soft', &$error = null): bool
	{
		$discussion = $this->Discussion;
		$visitor = \XF::visitor();
		if (!$visitor->user_id || !$discussion)
		{
			return false;
		}

		$groupId = $discussion->group_id;

		if ($type != 'soft' && !$visitor->hasDbtechSocialGroupsGroupPermission($groupId, 'hardDeleteAnyMessage'))
		{
			return false;
		}

		if (!$discussion->discussion_open && !$discussion->canLockUnlock())
		{
			$error = \XF::phraseDeferred('you_may_not_perform_this_action_because_discussion_is_closed');
			return false;
		}

		if ($this->isFirstMessage())
		{
			return $discussion->canDelete($type, $error);
		}

		if ($visitor->hasDbtechSocialGroupsGroupPermission($groupId, 'deleteAnyMessage'))
		{
			return true;
		}

		if ($this->user_id == $visitor->user_id && $visitor->hasDbtechSocialGroupsGroupPermission($groupId, 'deleteOwnMessage'))
		{
			$editLimit = $visitor->hasDbtechSocialGroupsGroupPermission($groupId, 'editOwnMessageTimeLimit');
			if ($editLimit != -1 && (!$editLimit || $this->message_date < \XF::$time - 60 * $editLimit))
			{
				$error = \XF::phraseDeferred('message_edit_time_limit_expired', ['minutes' => $editLimit]);
				return false;
			}

			if (!$discussion->Group || !$discussion->Group->allow_posting)
			{
				$error = \XF::phraseDeferred('dbtech_social_groups_you_may_not_perform_this_action_because_group_does_not_allow_posting');
				return false;
			}

			return true;
		}

		return false;
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canUndelete(&$error = null): bool
	{
		$discussion = $this->Discussion;
		$visitor = \XF::visitor();
		if (!$visitor->user_id || !$discussion)
		{
			return false;
		}

		return (bool) $visitor->hasDbtechSocialGroupsGroupPermission($discussion->group_id, 'undelete');
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canApproveUnapprove(&$error = null): bool
	{
		if (!$this->Discussion)
		{
			return false;
		}

		return $this->Discussion->canApproveUnapprove();
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canWarn(&$error = null): bool
	{
		$visitor = \XF::visitor();

		if (!$this->user_id
			|| !$visitor->user_id
			|| $this->user_id == $visitor->user_id
			|| !$visitor->hasDbtechSocialGroupsGroupPermission($this->Discussion->group_id, 'warn')
		)
		{
			return false;
		}

		if ($this->warning_id)
		{
			$error = \XF::phraseDeferred('user_has_already_been_warned_for_this_content');
			return false;
		}

		return ($this->User && $this->User->isWarnable());
	}

	/**
	 * @param $error
	 * @param User|null $asUser
	 *
	 * @return bool
	 */
	public function canReport(&$error = null, ?User $asUser = null): bool
	{
		$asUser = $asUser ?: \XF::visitor();
		return $asUser->canReport($error);
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canReact(&$error = null): bool
	{
		$visitor = \XF::visitor();
		if (!$visitor->user_id)
		{
			return false;
		}

		if ($this->message_state != 'visible')
		{
			return false;
		}

		if ($this->user_id == $visitor->user_id)
		{
			$error = \XF::phraseDeferred('reacting_to_your_own_content_is_considered_cheating');
			return false;
		}

		if (!$this->Discussion)
		{
			return false;
		}

		return (bool) $visitor->hasDbtechSocialGroupsGroupPermission($this->Discussion->group_id, 'react');
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	protected function canBookmarkContent(&$error = null): bool
	{
		return $this->isVisible();
	}

	/**
	 * @return bool
	 */
	public function canCleanSpam(): bool
	{
		return (\XF::visitor()->canCleanSpam() && $this->User && $this->User->isPossibleSpammer());
	}

	/**
	 * @return bool
	 */
	public function canSendModeratorActionAlert(): bool
	{
		$visitor = \XF::visitor();

		if (!$visitor->user_id || $visitor->user_id == $this->user_id)
		{
			return false;
		}

		if ($this->message_state != 'visible')
		{
			return false;
		}

		return true;
	}

	/**
	 * @return bool
	 */
	public function isVisible(): bool
	{
		return (
			$this->message_state == 'visible'
			&& $this->Discussion
			&& $this->Discussion->discussion_state == 'visible'
		);
	}

	/**
	 * @return bool
	 */
	public function isFirstMessage(): bool
	{
		$discussion = $this->Discussion;
		if (!$discussion)
		{
			return false;
		}

		if ($this->message_id == $discussion->first_message_id)
		{
			return true;
		}

		// this can be called during an insert where the discussion hasn't actually been updated yet
		// just assume it's the first message
		if (!$discussion->discussion_id)
		{
			return true;
		}

		if (!$discussion->first_message_id && $this->message_date == $discussion->message_date)
		{
			return true;
		}

		return false;
	}

	/**
	 * @return bool
	 */
	public function isLastMessage(): bool
	{
		$discussion = $this->Discussion;
		if (!$discussion)
		{
			return false;
		}

		return ($this->message_id == $discussion->last_message_id);
	}

	/**
	 * @return bool
	 */
	public function isUnread(): bool
	{
		if (!$this->Discussion)
		{
			return false;
		}

		$readDate = $this->Discussion->getVisitorReadDate();
		if ($readDate === null)
		{
			return false;
		}

		return $readDate < $this->message_date;
	}

	/**
	 * @param $attachmentId
	 *
	 * @return bool
	 */
	public function isAttachmentEmbedded($attachmentId): bool
	{
		if (!$this->embed_metadata)
		{
			return false;
		}

		if ($attachmentId instanceof Attachment)
		{
			$attachmentId = $attachmentId->attachment_id;
		}

		return isset($this->embed_metadata['attachments'][$attachmentId]);
	}

	/**
	 * @return bool
	 */
	public function isIgnored(): bool
	{
		return \XF::visitor()->isIgnoring($this->user_id);
	}

	/**
	 * @param $inner
	 *
	 * @return string
	 */
	public function getQuoteWrapper($inner): string
	{
		return '[QUOTE="'
			. ($this->User ? $this->User->username : $this->username)
			. ', dbtech_social_message: ' . $this->message_id
			. ($this->User ? ", member: $this->user_id" : '')
			. '"]'
			. "\n" . $inner . "\n"
			. "[/QUOTE]\n";
	}

	/**
	 * @param $context
	 * @param $type
	 *
	 * @return array
	 */
	public function getBbCodeRenderOptions($context, $type): array
	{
		$renderOptions = [
			'entity' => $this,
			'user' => $this->User,
			'attachments' => $this->attach_count ? $this->Attachments : [],
			'viewAttachments' => $this->Discussion && $this->Discussion->canViewAttachments(),
			'unfurls' => $this->Unfurls ?: [],
			'images' => $this->embed_metadata['images'] ?? [],
		];

		$this->addEmbedRendererBbCodeOptions($renderOptions, $context, $type);

		return $renderOptions;
	}

	/**
	 * @return array
	 */
	public function getUnfurls(): mixed
	{
		return $this->_getterCache['Unfurls'] ?? [];
	}

	/**
	 * @param array $unfurls
	 */
	public function setUnfurls(array $unfurls): void
	{
		$this->_getterCache['Unfurls'] = $unfurls;
	}

	/**
	 * @throws DbException
	 * @throws PrintableException
	 */
	protected function _postSave(): void
	{
		$visibilityChange = $this->isStateChanged('message_state', 'visible');
		$approvalChange = $this->isStateChanged('message_state', 'moderated');
		$deletionChange = $this->isStateChanged('message_state', 'deleted');

		if ($this->isUpdate())
		{
			if ($visibilityChange == 'enter')
			{
				$this->messageMadeVisible();

				if ($approvalChange)
				{
					$this->submitHamData();
				}
			}
			else if ($visibilityChange == 'leave')
			{
				$this->messageHidden();
			}

			if ($deletionChange == 'leave' && $this->DeletionLog)
			{
				$this->DeletionLog->delete();
			}

			if ($approvalChange == 'leave' && $this->ApprovalQueue)
			{
				$this->ApprovalQueue->delete();
			}
		}
		else
		{
			// insert
			if ($this->message_state == 'visible')
			{
				$this->messageInsertedVisible();
			}
		}

		if ($approvalChange == 'enter')
		{
			/** @var ApprovalQueue $approvalQueue */
			$approvalQueue = $this->getRelationOrDefault('ApprovalQueue', false);
			$approvalQueue->content_date = $this->message_date;
			$approvalQueue->save();
		}
		else if ($deletionChange == 'enter' && !$this->DeletionLog)
		{
			$delLog = $this->getRelationOrDefault('DeletionLog', false);
			$delLog->setFromVisitor();
			$delLog->save();
		}

		$this->updateDiscussionRecord();

		if ($this->isUpdate() && $this->isFirstMessage())
		{
			if ($this->isChanged('reaction_score'))
			{
				$this->Discussion->first_message_reaction_score = $this->reaction_score;
			}
			if ($this->isChanged('reactions'))
			{
				$this->Discussion->first_message_reactions = $this->reactions;
			}
			$this->Discussion->save();
		}

		if ($this->isUpdate() && $this->getOption('log_moderator'))
		{
			\XF::app()->logger()->logModeratorChanges('dbtech_social_message', $this);
		}

		$this->_postSaveBookmarks();
	}

	/**
	 * @throws PrintableException
	 */
	protected function updateDiscussionRecord(): void
	{
		if (!$this->Discussion || !$this->Discussion->exists())
		{
			// inserting a discussion, don't try to write to it
			return;
		}

		$visibilityChange = $this->isStateChanged('message_state', 'visible');
		if ($visibilityChange == 'enter')
		{
			$this->Discussion->messageAdded($this);
			$this->Discussion->save();
		}
		else if ($visibilityChange == 'leave')
		{
			$this->Discussion->messageRemoved($this);
			$this->Discussion->save();
		}
	}

	protected function adjustUserMessageCountIfNeeded(int $amount): void
	{
		if ($this->user_id
			&& $this->User
			&& $this->Discussion->Group->doesMessageCount()
			&& $this->Discussion->discussion_state == 'visible'
		)
		{
			$this->User->fastUpdate('message_count', max(0, $this->User->message_count + $amount));
		}
	}

	/**
	 * @param int $amount
	 */
	protected function adjustDiscussionUserMessageCount(int $amount): void
	{
		if ($this->user_id)
		{
			$db = $this->db();

			if ($amount > 0)
			{
				$db->insert('xf_dbtech_social_groups_discussion_user_message', [
					'discussion_id' => $this->discussion_id,
					'user_id' => $this->user_id,
					'message_count' => $amount,
				], false, 'message_count = message_count + VALUES(message_count)');
			}
			else
			{
				$existingValue = $db->fetchOne("
					SELECT message_count
					FROM xf_dbtech_social_groups_discussion_user_message
					WHERE discussion_id = ?
						AND user_id = ?
				", [$this->discussion_id, $this->user_id]);
				if ($existingValue !== null)
				{
					$newValue = $existingValue + $amount;
					if ($newValue <= 0)
					{
						$this->db()->delete(
							'xf_dbtech_social_groups_discussion_user_message',
							'discussion_id = ? AND user_id = ?',
							[$this->discussion_id, $this->user_id]
						);
					}
					else
					{
						$this->db()->update(
							'xf_dbtech_social_groups_discussion_user_message',
							['message_count' => $newValue],
							'discussion_id = ? AND user_id = ?',
							[$this->discussion_id, $this->user_id]
						);
					}
				}
			}
		}
	}

	/**
	 *
	 */
	protected function messageInsertedVisible(): void
	{
		$this->adjustUserMessageCountIfNeeded(1);
		$this->adjustDiscussionUserMessageCount(1);
	}

	/**
	 * @throws DbException
	 */
	protected function messageMadeVisible(): void
	{
		if ($this->isChanged('position'))
		{
			// if we've updated the position, we need to trust what we had is accurate...
			$basePosition = $this->getExistingValue('position');
		}
		else
		{
			// ...otherwise, we should always double check the DB for the latest position since this function won't
			// update cached entities
			$basePosition = $this->db()->fetchOne("
				SELECT position
				FROM xf_dbtech_social_groups_message
				WHERE message_id = ?
			", $this->message_id);
			if ($basePosition === null || $basePosition === false)
			{
				$basePosition = $this->getExistingValue('position');
			}

			// also, since we haven't changed the position yet, we need to update that
			$this->fastUpdate('position', $basePosition + 1);
		}

		$this->db()->query("
			UPDATE xf_dbtech_social_groups_message
			SET position = position + 1
			WHERE discussion_id = ?
				AND (
					position > ?
					OR (position = ? AND message_date > ?)
				)
				AND message_id <> ?
		", [$this->discussion_id, $basePosition, $basePosition, $this->message_date, $this->message_id]);

		$this->adjustUserMessageCountIfNeeded(1);
		$this->adjustDiscussionUserMessageCount(1);
	}

	/**
	 * @param bool $hardDelete
	 *
	 * @throws DbException
	 */
	protected function messageHidden(bool $hardDelete = false): void
	{
		if ($hardDelete || $this->isChanged('position'))
		{
			// if we've deleted the message or updated the position, we need to trust what we had is accurate...
			$basePosition = $this->getExistingValue('position');
		}
		else
		{
			// ...otherwise, we should always double check the DB for the latest position since this function won't
			// update cached entities
			$basePosition = $this->db()->fetchOne("
				SELECT position
				FROM xf_dbtech_social_groups_message
				WHERE message_id = ?
			", $this->message_id);
			if ($basePosition === null || $basePosition === false)
			{
				$basePosition = $this->getExistingValue('position');
			}

			// also, since we haven't changed the position yet, we need to update that
			$this->fastUpdate('position', $basePosition - 1);
		}

		$this->db()->query("
			UPDATE xf_dbtech_social_groups_message
			SET position = IF(position > 0, position - 1, 0)
			WHERE discussion_id = ?
				AND position >= ?
				AND message_id <> ?
		", [$this->discussion_id, $basePosition, $this->message_id]);

		$this->adjustUserMessageCountIfNeeded(-1);
		$this->adjustDiscussionUserMessageCount(-1);

		\XF::app()->repository(UserAlertRepository::class)
			->fastDeleteAlertsForContent('dbtech_social_message', $this->message_id)
		;
	}

	/**
	 *
	 */
	protected function submitHamData(): void
	{
		/** @var ContentChecker $submitter */
		$submitter = \XF::app()->container('spam.contentHamSubmitter');
		$submitter->submitHam('dbtech_social_message', $this->message_id);
	}

	/**
	 *
	 */
	protected function _preDelete(): void
	{
		// if we're deleting multiple messages, the position value we base the position recalc on in messageHidden
		// will be from when the entity was originally loaded, rather than what is in the database.
		// we therefore need to check what the expected position is before the record is gone and ensure we use that.
		$expectedPosition = $this->db()->fetchOne('SELECT position FROM xf_dbtech_social_groups_message WHERE message_id = ?', $this->message_id);

		if ($expectedPosition != $this->position)
		{
			$this->setAsSaved('position', $expectedPosition);
		}
	}

	/**
	 * @throws DbException
	 * @throws PrintableException
	 */
	protected function _postDelete(): void
	{
		if ($this->message_state == 'visible')
		{
			$this->messageHidden(true);
		}

		if ($this->Discussion && $this->message_state == 'visible')
		{
			$this->Discussion->messageRemoved($this);
			$this->Discussion->save();
		}

		if ($this->message_state == 'deleted' && $this->DeletionLog)
		{
			$this->DeletionLog->delete();
		}

		if ($this->message_state == 'moderated' && $this->ApprovalQueue)
		{
			$this->ApprovalQueue->delete();
		}

		if ($this->getOption('log_moderator'))
		{
			\XF::app()->logger()->logModeratorAction('dbtech_social_message', $this, 'delete_hard');
		}

		$this->db()->delete('xf_edit_history', 'content_type = ? AND content_id = ?', ['dbtech_social_message', $this->message_id]);

		\XF::app()->repository(AttachmentRepository::class)
			->fastDeleteContentAttachments('dbtech_social_message', $this->message_id)
		;

		$this->_postDeleteBookmarks();
	}

	/**
	 * @param string $reason
	 * @param User|null $byUser
	 *
	 * @return bool
	 * @throws PrintableException
	 */
	public function softDelete(string $reason = '', ?User $byUser = null): bool
	{
		$byUser = $byUser ?: \XF::visitor();
		$discussion = $this->Discussion;

		if ($this->isFirstMessage())
		{
			return $discussion->softDelete($reason, $byUser);
		}
		else
		{
			if ($this->message_state == 'deleted')
			{
				return false;
			}

			$this->message_state = 'deleted';

			/** @var DeletionLog $deletionLog */
			$deletionLog = $this->getRelationOrDefault('DeletionLog');
			$deletionLog->setFromUser($byUser);
			$deletionLog->delete_reason = $reason;

			$this->save();

			return true;
		}
	}

	/**
	 * @param EntityResult $result
	 * @param int $verbosity
	 * @param array $options
	 *
	 * @api-out str $username
	 * @api-out bool $is_first_message
	 * @api-out bool $is_last_message
	 * @api-out bool $can_edit
	 * @api-out bool $can_soft_delete
	 * @api-out bool $can_hard_delete
	 * @api-out bool $can_react
	 * @api-out bool $can_view_attachments
	 * @api-out Discussion $Discussion <cond> If requested by context, the discussion this message is part of.
	 * @api-out Attachment[] $Attachments <cond> Attachments to this message, if it has any.
	 * @api-see XF\Entity\ReactionTrait::addReactionStateToApiResult
	 */
	protected function setupApiResultData(
		EntityResult $result,
		$verbosity = self::VERBOSITY_NORMAL,
		array $options = []
	): void
	{
		$result->username = $this->User ? $this->User->username : $this->username;

		if (!empty($options['with_discussion']))
		{
			$result->includeRelation('Discussion');
		}

		if ($this->attach_count)
		{
			// note that we allow viewing of thumbs and metadata, regardless of permissions, when viewing the
			// content an attachment is connected to
			$result->includeRelation('Attachments');
		}

		$this->addReactionStateToApiResult($result);

		$result->is_first_message = $this->isFirstMessage();
		$result->is_last_message = $this->isLastMessage();
		$result->can_edit = $this->canEdit();
		$result->can_soft_delete = $this->canDelete();
		$result->can_hard_delete = $this->canDelete('hard');
		$result->can_react = $this->canReact();

		// this is repeated, mostly because attachments are message associated, even if the permission comes from above
		$result->can_view_attachments = $this->Discussion->canViewAttachments();
	}

	/**
	 * @return string
	 */
	public function getContentDateColumn(): string
	{
		return 'message_date';
	}

	/**
	 * @param bool $canonical
	 * @param array $extraParams
	 * @param null $hash
	 *
	 * @return string
	 */
	public function getContentUrl(bool $canonical = false, array $extraParams = [], $hash = null): string
	{
		$route = $canonical ? 'canonical:dbtech-social/messages' : 'dbtech-social/messages';
		return \XF::app()->router('public')->buildLink($route, $this, $extraParams, $hash);
	}

	/**
	 * @return string
	 */
	public function getContentPublicRoute(): string
	{
		return 'dbtech-social/messages';
	}

	/**
	 * @param string $context
	 *
	 * @return string|Phrase
	 */
	public function getContentTitle(string $context = ''): Phrase|string
	{
		if ($this->isFirstMessage())
		{
			return $this->Discussion->getContentTitle($context);
		}

		return \XF::phrase('dbtech_social_groups_message_in_discussion_x', ['title' => $this->Discussion->title]);
	}

	/**
	 * @param Structure $structure
	 *
	 * @return Structure
	 */
	public static function getStructure(Structure $structure): Structure
	{
		$structure->table = 'xf_dbtech_social_groups_message';
		$structure->shortName = 'DBTech\SocialGroups:Message';
		$structure->contentType = 'dbtech_social_message';
		$structure->primaryKey = 'message_id';
		$structure->columns = [
			'message_id'        => ['type' => self::UINT, 'autoIncrement' => true, 'nullable' => true],
			'discussion_id'     => ['type' => self::UINT, 'required' => true, 'api' => true],
			'user_id'           => ['type' => self::UINT, 'required' => true, 'api' => true],
			'username'          => [
				'type'     => self::STR, 'maxLength' => 50,
				'required' => 'please_enter_valid_name', 'api' => true,
			],
			'message_date'      => ['type' => self::UINT, 'required' => true, 'default' => \XF::$time, 'api' => true],
			'message'           => [
				'type'     => self::STR,
				'required' => 'please_enter_valid_message', 'api' => true,
			],
			'ip_id'             => ['type' => self::UINT, 'default' => 0],
			'message_state'     => [
				'type'          => self::STR, 'default' => 'visible',
				'allowedValues' => ['visible', 'moderated', 'deleted'], 'api' => true,
			],
			'attach_count'      => ['type' => self::UINT, 'max' => 65535, 'forced' => true, 'default' => 0, 'api' => true],
			'warning_id'        => ['type' => self::UINT, 'default' => 0],
			'warning_message'   => ['type' => self::STR, 'default' => '', 'maxLength' => 255, 'api' => true],
			'position'          => ['type' => self::UINT, 'forced' => true, 'api' => true],
			'last_edit_date'    => ['type' => self::UINT, 'default' => 0, 'api' => true],
			'last_edit_user_id' => ['type' => self::UINT, 'default' => 0],
			'edit_count'        => ['type' => self::UINT, 'forced' => true, 'default' => 0],
			'embed_metadata'    => ['type' => self::JSON_ARRAY, 'nullable' => true, 'default' => null],
		];
		$structure->behaviors = [
			'XF:Reactable'           => ['stateField' => 'message_state'],
			'XF:Indexable'           => [
				'checkForUpdates' => ['message', 'user_id', 'discussion_id', 'message_date', 'message_state'],
			],
			'XF:NewsFeedPublishable' => [
				'usernameField' => 'username',
				'dateField'     => 'message_date',
			],
		];
		$structure->getters = [
			'Unfurls' => true,
		];
		$structure->relations = [
			'Discussion'    => [
				'entity'     => Discussion::class,
				'type'       => self::TO_ONE,
				'conditions' => 'discussion_id',
				'primary'    => true,
				'with'       => 'Group',
			],
			'User'          => [
				'entity'     => User::class,
				'type'       => self::TO_ONE,
				'conditions' => 'user_id',
				'primary'    => true,
				'api'        => true,
			],
			'Attachments'   => [
				'entity'     => Attachment::class,
				'type'       => self::TO_MANY,
				'conditions' => [
					['content_type', '=', 'dbtech_social_message'],
					['content_id', '=', '$message_id'],
				],
				'with'       => 'Data',
				'order'      => 'attach_date',
			],
			'DeletionLog'   => [
				'entity'     => DeletionLog::class,
				'type'       => self::TO_ONE,
				'conditions' => [
					['content_type', '=', 'dbtech_social_message'],
					['content_id', '=', '$message_id'],
				],
				'primary'    => true,
			],
			'ApprovalQueue' => [
				'entity'     => ApprovalQueue::class,
				'type'       => self::TO_ONE,
				'conditions' => [
					['content_type', '=', 'dbtech_social_message'],
					['content_id', '=', '$message_id'],
				],
				'primary'    => true,
			],
		];
		$structure->options = [
			'log_moderator' => true,
		];

		$structure->withAliases = [
			'full' => [
				'User',
				'User.Option',
				'User.Profile',
				'User.Privacy',
				function ()
				{
					if (\XF::options()->showMessageOnlineStatus)
					{
						return 'User.Activity';
					}

					return null;
				},
				function ()
				{
					$userId = \XF::visitor()->user_id;
					if ($userId)
					{
						return [
							'Reactions|' . $userId,
							'Bookmarks|' . $userId,
						];
					}

					return null;
				},
			],
			'api'  => [
				'User',
				'User.api',
				function ($withParams)
				{
					if (!empty($withParams['discussion']))
					{
						return ['Discussion.api'];
					}

					return [];
				},
			],
		];

		static::addReactableStructureElements($structure);
		static::addBookmarkableStructureElements($structure);
		static::addEmbedRendererStructureElements($structure);
		static::addEmbedResolverStructureElements($structure);

		return $structure;
	}
}