<?php

namespace DBTech\SocialGroups\Entity;

use XF\Entity\User;
use XF\Entity\ViewableInterface;
use XF\Mvc\Entity\Entity;
use XF\Mvc\Entity\Structure;

/**
 * COLUMNS
 * @property int $user_id
 * @property int $group_id
 * @property string $notify_on
 * @property bool $send_alert
 * @property bool $send_email
 *
 * RELATIONS
 * @property-read Group|null $Group
 * @property-read User|null $User
 */
class GroupWatch extends Entity implements ViewableInterface
{
	/**
	 * @return bool
	 */
	public function canView(): bool
	{
		if (!$this->Group)
		{
			return false;
		}

		return $this->Group->canView();
	}

	/**
	 * @param Structure $structure
	 *
	 * @return Structure
	 */
	public static function getStructure(Structure $structure): Structure
	{
		$structure->table = 'xf_dbtech_social_groups_group_watch';
		$structure->shortName = 'DBTech\SocialGroups:GroupWatch';
		$structure->primaryKey = ['user_id', 'group_id'];
		$structure->columns = [
			'user_id' => ['type' => self::UINT, 'required' => true],
			'group_id' => ['type' => self::UINT, 'required' => true],
			'notify_on' => ['type' => self::STR, 'default' => '',
				'allowedValues' => ['', 'discussion', 'message'],
			],
			'send_alert' => ['type' => self::BOOL, 'default' => false],
			'send_email' => ['type' => self::BOOL, 'default' => false],
		];
		$structure->getters = [];
		$structure->relations = [
			'Group' => [
				'entity' => Group::class,
				'type' => self::TO_ONE,
				'conditions' => 'group_id',
				'primary' => true,
			],
			'User' => [
				'entity' => User::class,
				'type' => self::TO_ONE,
				'conditions' => 'user_id',
				'primary' => true,
			],
		];

		return $structure;
	}
}