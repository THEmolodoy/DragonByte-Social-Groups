<?php

namespace DBTech\SocialGroups\Entity;

use XF\Entity\User;
use XF\Mvc\Entity\Entity;
use XF\Mvc\Entity\Structure;
use XF\Phrase;

/**
 * COLUMNS
 * @property int|null $group_member_log_id
 * @property int $group_id
 * @property int $log_date
 * @property int $actor_id
 * @property string $actor_username
 * @property int $user_id
 * @property string $username
 * @property string $ip_address
 * @property int $group_member_id
 * @property string $action
 * @property array|null $action_params
 *
 * RELATIONS
 * @property-read GroupMember|null $GroupMember
 * @property-read User|null $Actor
 * @property-read User|null $User
 */
class GroupMemberLog extends Entity
{
	/**
	 * @return Phrase
	 */
	public function getActionPhrase(): Phrase
	{
		return \XF::phrase('dbtech_security_watcher_action.' . $this->action);
	}

	/**
	 * @param Structure $structure
	 *
	 * @return Structure
	 */
	public static function getStructure(Structure $structure): Structure
	{
		$structure->table = 'xf_dbtech_social_groups_group_member_log';
		$structure->shortName = 'DBTech\SocialGroups:GroupMemberLog';
		$structure->primaryKey = 'group_member_log_id';
		$structure->columns = [
			'group_member_log_id' => ['type' => self::UINT, 'autoIncrement' => true, 'nullable' => true],
			'group_id' => ['type' => self::UINT, 'required' => true],
			'log_date' => ['type' => self::UINT, 'default' => \XF::$time],
			'actor_id' => ['type' => self::UINT, 'default' => 0],
			'actor_username' => ['type' => self::STR, 'maxLength' => 50, 'default' => ''],
			'user_id' => ['type' => self::UINT, 'default' => 0],
			'username' => ['type' => self::STR, 'maxLength' => 50, 'default' => ''],
			'ip_address' => ['type' => self::BINARY, 'maxLength' => 16, 'default' => ''],
			'group_member_id' => ['type' => self::UINT, 'default' => 0],
			'action' => ['type' => self::STR, 'maxLength' => 25, 'required' => true],
			'action_params' => ['type' => self::JSON_ARRAY, 'default' => ''],
		];
		$structure->relations = [
			'GroupMember' => [
				'entity' => GroupMember::class,
				'type' => self::TO_ONE,
				'conditions' => 'group_member_id',
				'primary' => true,
			],
			'Actor' => [
				'entity' => User::class,
				'type' => self::TO_ONE,
				'conditions' => [
					['user_id', '=', '$actor_id'],
				],
				'primary' => true,
			],
			'User' => [
				'entity' => User::class,
				'type' => self::TO_ONE,
				'conditions' => 'user_id',
				'primary' => true,
			],
		];
		return $structure;
	}
}