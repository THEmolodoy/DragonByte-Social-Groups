<?php

namespace DBTech\SocialGroups\Entity;

use XF\Entity\AbstractNode;
use XF\Entity\Node;
use XF\Mvc\Entity\Structure;

/**
 * COLUMNS
 * @property int $node_id
 *
 * GETTERS
 * @property-read string|null $node_name
 * @property-read string|null $title
 * @property-read string|null $description
 * @property-read int $depth
 *
 * RELATIONS
 * @property-read Node|null $Node
 */
class Container extends AbstractNode
{
	/**
	 * @return bool
	 */
	public function isSearchEngineIndexable(): bool
	{
		return false;
	}

	/**
	 * @param $depth
	 *
	 * @return string[]
	 */
	public function getNodeTemplateRenderer($depth): array
	{
		return [
			'template' => 'dbtech_social_groups_node_list_container',
			'macro' => 'depth1',
		];
	}

	public function getContainerAnchor(): string
	{
		return \XF::app()->router('public')->prepareStringForUrl($this->title, true) . '.' . $this->node_id;
	}

	/**
	 * @param Structure $structure
	 *
	 * @return Structure
	 */
	public static function getStructure(Structure $structure): Structure
	{
		$structure->table = 'xf_dbtech_social_groups_container';
		$structure->shortName = 'DBTech\SocialGroups:Container';
		$structure->primaryKey = 'node_id';
		$structure->columns = [
			'node_id' => ['type' => self::UINT, 'required' => true],
		];
		$structure->getters = [];
		$structure->relations = [];

		static::addDefaultNodeElements($structure);

		return $structure;
	}
}