<?php

namespace DBTech\SocialGroups\Entity;

use XF\Entity\User;
use XF\Mvc\Entity\Entity;
use XF\Mvc\Entity\Structure;

/**
 * COLUMNS
 * @property int $user_id
 * @property int $discussion_id
 * @property bool $email_subscribe
 *
 * RELATIONS
 * @property-read Discussion|null $Discussion
 * @property-read User|null $User
 */
class DiscussionWatch extends Entity
{
	/**
	 * @param Structure $structure
	 *
	 * @return Structure
	 */
	public static function getStructure(Structure $structure): Structure
	{
		$structure->table = 'xf_dbtech_social_groups_discussion_watch';
		$structure->shortName = 'DBTech\SocialGroups:DiscussionWatch';
		$structure->primaryKey = ['user_id', 'discussion_id'];
		$structure->columns = [
			'user_id' => ['type' => self::UINT, 'required' => true],
			'discussion_id' => ['type' => self::UINT, 'required' => true],
			'email_subscribe' => ['type' => self::BOOL, 'default' => false],
		];
		$structure->getters = [];
		$structure->relations = [
			'Discussion' => [
				'entity' => Discussion::class,
				'type' => self::TO_ONE,
				'conditions' => 'discussion_id',
				'primary' => true,
			],
			'User' => [
				'entity' => User::class,
				'type' => self::TO_ONE,
				'conditions' => 'user_id',
				'primary' => true,
			],
		];

		return $structure;
	}
}