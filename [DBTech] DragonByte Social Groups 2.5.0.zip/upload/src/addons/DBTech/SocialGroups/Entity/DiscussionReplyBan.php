<?php

namespace DBTech\SocialGroups\Entity;

use XF\Entity\User;
use XF\Mvc\Entity\Entity;
use XF\Mvc\Entity\Structure;
use XF\Repository\UserAlertRepository;

/**
 * COLUMNS
 * @property int|null $discussion_reply_ban_id
 * @property int $discussion_id
 * @property int $user_id
 * @property int $ban_date
 * @property int|null $expiry_date
 * @property string $reason
 * @property int $ban_user_id
 *
 * RELATIONS
 * @property-read Discussion|null $Discussion
 * @property-read User|null $User
 * @property-read User|null $BannedBy
 */
class DiscussionReplyBan extends Entity
{
	/**
	 *
	 */
	protected function _preSave(): void
	{
		$ban = \XF::app()->em()->findOne(DiscussionReplyBan::class, [
			'discussion_id' => $this->discussion_id,
			'user_id' => $this->user_id,
		]);
		if ($ban && $ban !== $this)
		{
			$this->error(\XF::phrase('dbtech_social_groups_this_user_is_already_reply_banned_from_this_discussion'));
		}
	}

	/**
	 *
	 */
	protected function _postDelete(): void
	{
		\XF::app()->repository(UserAlertRepository::class)
			->fastDeleteAlertsToUser(
				$this->user_id,
				'dbtech_social_discussion',
				$this->discussion_id,
				'reply_ban'
			)
		;

		\XF::app()->logger()->logModeratorAction(
			'dbtech_social_discussion',
			$this->Discussion,
			'reply_ban_delete',
			['name' => $this->User->username]
		);
	}

	/**
	 * @param Structure $structure
	 *
	 * @return Structure
	 */
	public static function getStructure(Structure $structure): Structure
	{
		$structure->table = 'xf_dbtech_social_groups_discussion_reply_ban';
		$structure->shortName = 'DBTech\SocialGroups:DiscussionReplyBan';
		$structure->primaryKey = 'discussion_reply_ban_id';
		$structure->columns = [
			'discussion_reply_ban_id' => ['type' => self::UINT, 'autoIncrement' => true, 'nullable' => true],
			'discussion_id' => ['type' => self::UINT, 'required' => true],
			'user_id' => ['type' => self::UINT, 'required' => true],
			'ban_date' => ['type' => self::UINT, 'default' => \XF::$time],
			'expiry_date' => ['type' => self::UINT, 'required' => true, 'nullable' => true],
			'reason' => ['type' => self::STR, 'default' => '', 'maxLength' => 100],
			'ban_user_id' => ['type' => self::UINT, 'required' => true],
		];
		$structure->getters = [];
		$structure->relations = [
			'Discussion' => [
				'entity' => Discussion::class,
				'type' => self::TO_ONE,
				'conditions' => 'discussion_id',
				'primary' => true,
			],
			'User' => [
				'entity' => User::class,
				'type' => self::TO_ONE,
				'conditions' => 'user_id',
				'primary' => true,
			],
			'BannedBy' => [
				'entity' => User::class,
				'type' => self::TO_ONE,
				'conditions' => [['user_id', '=', '$ban_user_id']],
				'primary' => true,
			],
		];

		return $structure;
	}
}