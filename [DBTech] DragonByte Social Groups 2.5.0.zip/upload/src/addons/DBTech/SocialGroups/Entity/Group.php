<?php

namespace DBTech\SocialGroups\Entity;

use DBTech\SocialGroups\Job\GroupDeleteCleanUp;
use DBTech\SocialGroups\Job\GroupMembershipRebuild;
use DBTech\SocialGroups\Job\GroupSoftDeleteCleanUp;
use DBTech\SocialGroups\Job\GroupSoftDeleteUndelete;
use DBTech\SocialGroups\Repository\GroupMemberRepository;
use DBTech\SocialGroups\Repository\GroupPermissionsRepository;
use DBTech\SocialGroups\Repository\GroupRepository;
use DBTech\SocialGroups\Service\Group\BannerService;
use DBTech\SocialGroups\Service\Group\CalendarCreatorService;
use DBTech\SocialGroups\Service\Group\IconService;
use DBTech\SocialGroups\XF\Entity\User as ExtendedUserEntity;
use NF\Calendar\Entity\Calendar;
use NF\Calendar\Entity\Event;
use XF\Api\Result\EntityResult;
use XF\Behavior\Featurable;
use XF\Behavior\Indexable;
use XF\Behavior\PermissionRebuildable;
use XF\Data\Language;
use XF\Entity\ApprovalQueue;
use XF\Entity\BookmarkItem;
use XF\Entity\BookmarkTrait;
use XF\Entity\DatableInterface;
use XF\Entity\DatableTrait;
use XF\Entity\DeletionLog;
use XF\Entity\Draft;
use XF\Entity\EmbedResolverTrait;
use XF\Entity\FeaturedContent;
use XF\Entity\FeatureTrait;
use XF\Entity\LinkableInterface;
use XF\Entity\ModeratorContent;
use XF\Entity\PermissionCacheContent;
use XF\Entity\Thread;
use XF\Entity\User;
use XF\Entity\ViewableInterface;
use XF\Mvc\Entity\AbstractCollection;
use XF\Mvc\Entity\Entity;
use XF\Mvc\Entity\Structure;
use XF\Phrase;
use XF\PrintableException;
use XF\Util\Arr;
use XFMG\Entity\Album;

use function array_key_exists, intval;

/**
 * COLUMNS
 * @property int|null $group_id
 * @property string $title
 * @property string $tagline
 * @property string $description
 * @property string $group_type
 * @property string $group_state
 * @property bool $sticky
 * @property bool $featured
 * @property int $member_count
 * @property int $section_count
 * @property int $discussion_count
 * @property int $message_count
 * @property int $view_count
 * @property int $user_id
 * @property string $username
 * @property int $creation_date
 * @property int $last_update_date
 * @property int $last_message_id
 * @property int $last_message_date
 * @property int $last_message_user_id
 * @property string $last_message_username
 * @property int $last_discussion_id
 * @property string $last_discussion_title
 * @property int $icon_date
 * @property string $icon_hash
 * @property int $icon_width
 * @property int $icon_height
 * @property bool $icon_highdpi
 * @property int $icon_crop_x
 * @property int $icon_crop_y
 * @property int $banner_date
 * @property string $banner_hash
 * @property int|null $banner_position_y
 * @property string $language_code
 * @property string $text_direction
 * @property bool $allow_members
 * @property bool $moderate_members
 * @property bool $moderate_discussions
 * @property bool $moderate_replies
 * @property bool $allow_posting
 * @property bool $allow_discussions
 * @property bool $allow_poll
 * @property bool $count_messages
 * @property bool $enable_calendar
 * @property int $calendar_id
 * @property string $event_creation
 * @property bool $find_new
 * @property string $allowed_watch_notifications
 * @property string $default_sort_order
 * @property string $default_sort_direction
 * @property int $list_date_limit_days
 * @property array|null $tags
 * @property int $min_tags
 * @property string $rules
 *
 * GETTERS
 * @property-read \XF\Draft $draft_discussion
 * @property-read Phrase $discussion_prompt
 * @property-read Phrase|null $locale
 * @property-read array $structured_data
 *
 * RELATIONS
 * @property-read User|null $User
 * @property-read AbstractCollection<GroupRead> $Read
 * @property-read AbstractCollection<GroupWatch> $Watch
 * @property-read AbstractCollection<Draft> $DraftDiscussions
 * @property-read Message|null $LastMessage
 * @property-read User|null $LastMessageUser
 * @property-read Discussion|null $LastDiscussion
 * @property-read AbstractCollection<PermissionCacheContent> $Permissions
 * @property-read AbstractCollection<ModeratorContent> $Moderators
 * @property-read AbstractCollection<GroupMember> $Supervisors
 * @property-read AbstractCollection<GroupMember> $Members
 * @property-read AbstractCollection<GroupInvite> $Invites
 * @property-read AbstractCollection<GroupBan> $Bans
 * @property-read AbstractCollection<RelatedThread> $RelatedThreads
 * @property-read DeletionLog|null $DeletionLog
 * @property-read ApprovalQueue|null $ApprovalQueue
 * @property-read Calendar|null $Calendar
 * @property-read AbstractCollection<BookmarkItem> $Bookmarks
 * @property-read FeaturedContent|null $Feature
 */
class Group extends Entity implements DatableInterface, LinkableInterface, ViewableInterface
{
	use BookmarkTrait;
	use DatableTrait;
	use EmbedResolverTrait;
	use FeatureTrait;

	/**
	 * @param string $size
	 *
	 * @return string
	 */
	public function getAbstractedCustomIconPath(string $size): string
	{
		$groupId = $this->group_id;
		$filename = $this->icon_hash ?: $groupId;

		return sprintf(
			'data://dbtechSocial/icons/%s/%d/%s.jpg',
			$size,
			floor($groupId / 1000),
			$filename
		);
	}

	/**
	 * @return string
	 */
	public function getIconType(): string
	{
		if ($this->icon_date)
		{
			return 'custom';
		}
		else
		{
			return 'default';
		}
	}

	/**
	 * @param string $sizeCode
	 * @param bool $canonical
	 *
	 * @return string|null
	 */
	public function getIconUrl(string $sizeCode, bool $canonical = false): ?string
	{
		$app = $this->app();

		$sizeMap = $app->container('avatarSizeMap');
		if (!isset($sizeMap[$sizeCode]))
		{
			// Always fallback to 's' in the event of an unknown size (e.g. 'xs', 'xxs' etc.)
			$sizeCode = 's';
		}

		if ($this->icon_date)
		{
			$group = \floor($this->group_id / 1000);
			$filename = $this->icon_hash ?: $this->group_id;

			return $app->applyExternalDataUrl(
				\sprintf(
					'dbtechSocial/icons/%s/%d/%s.jpg?%d',
					$sizeCode,
					$group,
					$filename,
					$this->icon_date
				),
				$canonical
			);
		}
		else
		{
			return null;
		}
	}

	/**
	 * @param string $sizeCode
	 * @param bool $canonical
	 *
	 * @return string|null
	 */
	public function getIconUrl2x(string $sizeCode, bool $canonical = false): ?string
	{
		$sizeMap = \XF::app()->container('avatarSizeMap');

		switch ($sizeCode)
		{
			case 'xs':
			case 's':
				if ($this->iconSupportsSize($sizeMap['m']))
				{
					return $this->getIconUrl('m', $canonical);
				}
				break;

			case 'm':
				if ($this->iconSupportsSize($sizeMap['l']))
				{
					return $this->getIconUrl('l', $canonical);
				}
				break;

			case 'l':
				if ($this->icon_highdpi)
				{
					return $this->getIconUrl('h', $canonical);
				}
				break;
		}

		return '';
	}

	/**
	 * @param string $size
	 *
	 * @return bool
	 */
	protected function iconSupportsSize(string $size): bool
	{
		return ($this->icon_date && $this->icon_width >= $size && $this->icon_height >= $size);
	}

	/**
	 * @param string $size
	 *
	 * @return string
	 */
	public function getAbstractedBannerPath(string $size): string
	{
		$groupId = $this->group_id;
		$filename = $this->banner_hash ?: $groupId;

		return sprintf(
			'data://dbtechSocial/banners/%s/%d/%s.jpg',
			$size,
			floor($groupId / 1000),
			$filename
		);
	}

	/**
	 * @param string $sizeCode
	 * @param bool $canonical
	 *
	 * @return string|null
	 */
	public function getBannerUrl(string $sizeCode, bool $canonical = false): ?string
	{
		$app = $this->app();

		$sizeMap = $app->container('profileBannerSizeMap');
		if (!isset($sizeMap[$sizeCode]))
		{
			// Always fallback to 'l' by default in the event of an unknown size (most common)
			$sizeCode = 'l';
		}

		if ($this->banner_date)
		{
			$group = floor($this->group_id / 1000);
			$filename = $this->banner_hash ?: $this->group_id;

			return $app->applyExternalDataUrl(
				\sprintf(
					'dbtechSocial/banners/%s/%d/%s.jpg?%d',
					$sizeCode,
					$group,
					$filename,
					$this->banner_date
				),
				$canonical
			);
		}
		else
		{
			return null;
		}
	}

	/**
	 * @param string $permission
	 * @return bool
	 */
	public function hasPermission(string $permission): bool
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();
		return $visitor->hasDbtechSocialGroupsGroupPermission($this->group_id, $permission);
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canView(&$error = null): bool
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		if ($visitor->canEditAnyDbtechSocialGroups())
		{
			return true;
		}

		if ($visitor->user_id && $this->Moderators[$visitor->user_id])
		{
			return true;
		}

		if ($this->group_state === 'deleted'
			&& !$visitor->canViewDeletedDbtechSocialGroups()
		)
		{
			$error = \XF::phraseDeferred('do_not_have_permission');
			return false;
		}

		if (!$this->hasPermission('viewGroup'))
		{
			$error = \XF::phraseDeferred('do_not_have_permission');
			return false;
		}

		if ($visitor->user_id && $this->Bans[$visitor->user_id])
		{
			$error = \XF::phraseDeferred('you_have_been_banned');
			return false;
		}

		if (\XF::app()->repository(GroupRepository::class)
			->isLowerPrivacy($this->group_type, 'hidden')
		)
		{
			return true;
		}
		/*
		if ($this->group_type !== 'hidden')
		{
			return true;
		}
		*/

		if (!$visitor->isMemberOfSocialGroup($this, true, true))
		{
			$error = \XF::phraseDeferred('dbtech_social_groups_not_member_or_need_approval');
			return false;
		}

		return true;
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canJoin(&$error = null): bool
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		if (!$visitor->user_id)
		{
			$error = \XF::phraseDeferred('login_required');
			return false;
		}

		if (!$this->allow_members && !$this->Invites[$visitor->user_id])
		{
			$error = \XF::phraseDeferred('dbtech_social_groups_you_are_not_permitted_join_this_group');
			return false;
		}

		if (!$this->hasPermission('joinGroup'))
		{
			$error = \XF::phraseDeferred('dbtech_social_groups_you_are_not_permitted_join_this_group');
			return false;
		}

		$maxJoinedGroups = $visitor->hasPermission('dbtechSocial', 'maxJoinedGroups');
		if ($maxJoinedGroups != -1 && $visitor->dbtech_social_groups_group_joined_count >= $maxJoinedGroups)
		{
			$error = \XF::phraseDeferred('dbtech_social_groups_you_have_reached_limit_x_joined_groups', [
				'limit' => $maxJoinedGroups,
			]);
			return false;
		}

		if ($visitor->user_id && $this->Bans[$visitor->user_id])
		{
			$error = \XF::phraseDeferred('you_have_been_banned');
			return false;
		}

		return true;
	}

	/**
	 * @return bool
	 */
	public function canRejectInvite(): bool
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		return ($visitor->user_id
			&& $this->Invites[$visitor->user_id]
		);
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canApproveUnapprove(&$error = null): bool
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();
		return ($visitor->user_id
			&& $visitor->hasPermission('dbtechSocial', 'approveUnapproveGroups')
		);
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canApproveRejectMembers(&$error = null): bool
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();
		return ($visitor->user_id
			&& $visitor->hasDbtechSocialGroupsGroupPermission($this->group_id, 'approveRejectMembers')
		);
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canManageRelatedThreads(&$error = null): bool
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();
		return (
			$this->isGroupOwner()
			|| (
				$visitor->user_id
				&& $visitor->hasDbtechSocialGroupsGroupPermission($this->group_id, 'manageRelatedThreads')
			)
		);
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canBookmarkContent(&$error = null): bool
	{
		return ($this->canView($error)
			&& $this->canViewDiscussions()
		);
	}

	/**
	 * @return bool
	 */
	public function canUploadIcon(): bool
	{
		return $this->hasPermission('uploadIcon');
	}

	/**
	 * @return bool
	 */
	public function canUploadBanner(): bool
	{
		return $this->hasPermission('uploadBanner');
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canAddMedia(&$error = null): bool
	{
		if (!$this->isVisible())
		{
			return false;
		}

		return $this->hasPermission('addMedia');
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canCreateAlbum(&$error = null): bool
	{
		if (!$this->canAddMedia())
		{
			$error = \XF::phraseDeferred('do_not_have_permission');
			return false;
		}

		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		if (!$visitor->isMemberOfSocialGroup($this, true))
		{
			$error = \XF::phraseDeferred('dbtech_social_groups_not_member_or_need_approval');
			return false;
		}

		$maxAlbumsPerGroup = $visitor->hasPermission('dbtechSocial', 'maxAlbumsPerGroup');
		if (
			$maxAlbumsPerGroup !== -1
			&& $visitor->SocialGroupMemberships[$this->group_id]->album_count >= $maxAlbumsPerGroup
		)
		{
			$error = \XF::phraseDeferred('dbtech_social_groups_reached_max_x_albums_this_group', [
				'albums' => $maxAlbumsPerGroup,
			]);
			return false;
		}

		return true;
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canCreateCalendarEvent(&$error = null): bool
	{
		if (!$this->canViewCalendar())
		{
			$error = \XF::phraseDeferred('do_not_have_permission');
			return false;
		}

		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		return match ($this->event_creation)
		{
			'group_owner' => $this->isGroupOwner(),
			'group_staff' => $this->isGroupOwner() || $visitor->isSupervisorOfSocialGroup($this),
			default => $visitor->isMemberOfSocialGroup($this),
		};
	}

	/**
	 * @param Event $event
	 * @param $error
	 *
	 * @return bool
	 */
	public function canViewCalendarEvent(Event $event, &$error = null): bool
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		return match ($event->type_data_['event_privacy'] ?? 'members')
		{
			'group_owner' => $this->isGroupOwner(),
			'group_staff' => $this->isGroupOwner() || $visitor->isSupervisorOfSocialGroup($this),
			'members' => $visitor->isMemberOfSocialGroup($this),
			default => true,
		};
	}

	/**
	 * @return bool
	 */
	public function canEditAnyAlbum(): bool
	{
		return $this->hasPermission('editAnyAlbum');
	}

	/**
	 * @return bool
	 */
	public function canUnlinkAnyAlbum(): bool
	{
		return $this->hasPermission('unlinkAnyAlbum');
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canFeatureUnfeature(&$error = null): bool
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		return (
			$visitor->user_id
			&& $visitor->canFeatureUnfeatureDbtechSocialGroups()
		);
	}

	/**
	 * @param User $user
	 * @param $error
	 *
	 * @return bool
	 * @throws \Exception
	 */
	public function canInviteUser(User $user, &$error = null): bool
	{
		if (!$this->isVisible())
		{
			return false;
		}

		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		if (!$user->user_id || $user->user_id == $visitor->user_id)
		{
			return false;
		}

		if (!$this->canInvite())
		{
			return false;
		}

		$canJoin = \XF::asVisitor($user, function () use ($error)
		{
			/** @var ExtendedUserEntity $visitor */
			$visitor = \XF::visitor();

			if (!$this->hasPermission('joinGroup'))
			{
				$error = \XF::phraseDeferred('dbtech_social_groups_you_are_not_permitted_join_this_group');
				return false;
			}

			if (!\XF::options()->dbtechSocialInviteBypassMaxJoined)
			{
				$maxJoinedGroups = $visitor->hasPermission('dbtechSocial', 'maxJoinedGroups');
				if ($maxJoinedGroups != -1 && $visitor->dbtech_social_groups_group_joined_count >= $maxJoinedGroups)
				{
					$error = \XF::phraseDeferred('dbtech_social_groups_you_have_reached_limit_x_joined_groups', [
						'limit' => $maxJoinedGroups,
					]);
					return false;
				}
			}

			if ($visitor->user_id && $this->Bans[$visitor->user_id])
			{
				$error = \XF::phraseDeferred('you_have_been_banned');
				return false;
			}

			return true;
		});
		if (!$canJoin)
		{
			return false;
		}

		return true;
	}

	/**
	 * @param User $user
	 * @param $error
	 *
	 * @return bool
	 */
	public function canBanUser(User $user, &$error = null): bool
	{
		if (!$this->isVisible())
		{
			return false;
		}

		$visitor = \XF::visitor();

		if (!$user->user_id || $user->user_id == $visitor->user_id)
		{
			return false;
		}

		if ($user->canEditAnyDbtechSocialGroups())
		{
			$error = \XF::phraseDeferred('this_user_is_an_admin_or_moderator_choose_another');
			return false;
		}

		if (!$this->canBan())
		{
			return false;
		}

		// For performance reasons, don't include this check here.
		// This check will be performed in the controller.
		//		if ($this->Moderators[$user->user_id])
		//		{
		//			$error = \XF::phraseDeferred('this_user_is_an_admin_or_moderator_choose_another');
		//			return false;
		//		}

		return true;
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canManageSections(&$error = null): bool
	{
		return (\XF::options()->dbtechSocialGroupsEnableSections
			&& $this->canEdit($error)
		);
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canAddSection(&$error = null): bool
	{
		$maxSections = \XF::visitor()->hasPermission('dbtechSocial', 'maxCreatedSections');

		if ($maxSections != -1 && $this->section_count >= $maxSections)
		{
			$error = \XF::phraseDeferred('dbtech_social_groups_you_can_create_max_x_sections_created_y', [
				'max' => $maxSections,
				'created' => $this->section_count,
			]);
			return false;
		}

		return true;
	}

	/**
	 * @return bool
	 */
	public function canAddNestedSection(): bool
	{
		return $this->hasPermission('createNestedSections');
	}

	/**
	 * @return bool
	 */
	public function canAddSupervisor(): bool
	{
		if (!$this->isVisible())
		{
			return false;
		}

		return $this->canManage();
	}

	/**
	 * @param GroupMember $groupMember
	 *
	 * @return bool
	 */
	public function canEditSupervisor(GroupMember $groupMember): bool
	{
		if (!$this->isVisible())
		{
			return false;
		}

		if ($groupMember->user_id === $this->user_id)
		{
			return false;
		}

		return $this->canManage();
	}

	/**
	 * @param GroupMember $groupMember
	 *
	 * @return bool
	 */
	public function canRemoveSupervisor(GroupMember $groupMember): bool
	{
		if ($groupMember->user_id === $this->user_id)
		{
			return false;
		}

		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		if ($groupMember->user_id === $visitor->user_id)
		{
			return true;
		}

		return $this->canManage();
	}

	/**
	 * @param User $user
	 * @param $error
	 *
	 * @return bool
	 */
	public function canKickUser(User $user, &$error = null): bool
	{
		if (!$this->isVisible())
		{
			return false;
		}

		$visitor = \XF::visitor();

		if (!$user->user_id || $user->user_id == $visitor->user_id)
		{
			return false;
		}

		if ($user->canEditAnyDbtechSocialGroups())
		{
			$error = \XF::phraseDeferred('this_user_is_an_admin_or_moderator_choose_another');
			return false;
		}

		if (!$this->canKick())
		{
			return false;
		}

		// For performance reasons, don't include this check here.
		// This check will be performed in the controller.
		//		if ($this->Moderators[$user->user_id])
		//		{
		//			$error = \XF::phraseDeferred('this_user_is_an_admin_or_moderator_choose_another');
		//			return false;
		//		}

		return true;
	}

	/**
	 * @return bool
	 */
	public function canKick(): bool
	{
		return $this->hasPermission('kickUser');
	}

	/**
	 * @return bool
	 */
	public function canBan(): bool
	{
		if (!$this->isVisible())
		{
			return false;
		}

		return $this->hasPermission('banUser');
	}

	/**
	 * @return bool
	 */
	public function canInvite(): bool
	{
		if (!$this->isVisible())
		{
			return false;
		}

		return $this->hasPermission('inviteUser');
	}

	/**
	 * @param string|null $type
	 * @param $error
	 *
	 * @return bool
	 * @noinspection PhpUnusedParameterInspection
	 */
	public function canDelete(?string $type = 'soft', &$error = null): bool
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		$visitor = \XF::visitor();
		if (!$visitor->user_id)
		{
			return false;
		}

		if ($visitor->hasPermission('dbtechSocial', ($type === 'soft' ? 'deleteAny' : 'hardDeleteAny')))
		{
			// Global "(hard) delete any group" moderator permission
			return true;
		}

		// Per-group "(hard) delete group"
		return $this->hasPermission($type === 'soft' ? 'delete' : 'hardDelete');
	}

	/**
	 * @return bool
	 */
	public function canUndelete(): bool
	{
		return $this->canDelete();
	}

	/**
	 * @param string $reason
	 * @param ExtendedUserEntity|null $byUser
	 *
	 * @return bool
	 * @throws PrintableException
	 */
	public function softDelete(string $reason = '', ?User $byUser = null): bool
	{
		/** @var ExtendedUserEntity $byUser */
		$byUser = $byUser ?: \XF::visitor();

		$db = $this->db();
		$db->beginTransaction();

		$rawGroup = $db->fetchRow("
            SELECT *
            FROM xf_dbtech_social_groups_group
            WHERE group_id = ?
            FOR UPDATE
        ", $this->group_id);

		if ($rawGroup['group_state'] === 'deleted')
		{
			$db->commit();
			return false;
		}

		$this->group_state = 'deleted';

		/** @var DeletionLog $deletionLog */
		$deletionLog = $this->getRelationOrDefault('DeletionLog');
		$deletionLog->setFromUser($byUser);
		$deletionLog->delete_reason = $reason;

		$this->save(true, false);

		$db->commit();

		\XF::app()->jobManager()->enqueue(GroupMembershipRebuild::class, [
			'groupId' => $this->group_id,
		]);

		if ($this->getOption('enqueue_soft_delete_cleanup'))
		{
			\XF::app()->jobManager()->enqueue(GroupSoftDeleteCleanUp::class, [
				'groupId' => $this->group_id,
				'title' => $this->title,
				'userId' => \XF::visitor()->user_id,
				'unlink' => $this->getOption('unlink_albums_on_delete'),
			]);
		}

		return true;
	}

	/**
	 * @param ExtendedUserEntity|null $byUser
	 *
	 * @return bool
	 * @throws \LogicException
	 * @throws \Exception
	 * @throws PrintableException
	 * @noinspection PhpUnusedParameterInspection
	 */
	public function unDelete(?User $byUser = null): bool
	{
		if ($this->group_state == 'visible')
		{
			return false;
		}

		$this->group_state = 'visible';
		$this->save();

		\XF::app()->jobManager()->enqueue(GroupMembershipRebuild::class, [
			'groupId' => $this->group_id,
		]);

		return true;
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canViewOtherContent(&$error = null): bool
	{
		if (!$this->canView($error))
		{
			return false;
		}

		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		if ($visitor->user_id && $this->Moderators[$visitor->user_id])
		{
			return true;
		}

		if ($visitor->user_id && $this->Bans[$visitor->user_id])
		{
			$error = \XF::phraseDeferred('you_have_been_banned');
			return false;
		}

		if (\XF::app()->repository(GroupRepository::class)->isLowerPrivacy($this->group_type, 'private'))
		{
			return true;
		}

		if ($visitor->canEditAnyDbtechSocialGroups())
		{
			return true;
		}

		if (!$visitor->isMemberOfSocialGroup($this, true))
		{
			$error = \XF::phraseDeferred('dbtech_social_groups_not_member_or_need_approval');
			return false;
		}

		return true;
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canViewMemberList(&$error = null): bool
	{
		if (!$this->canViewOtherContent())
		{
			$error = \XF::phraseDeferred('dbtech_social_groups_member_list_only_viewable_to_members');
			return false;
		}

		return true;
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canStartDiscussion(&$error = null): bool
	{
		if (!$this->isVisible())
		{
			return false;
		}

		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		if ($visitor->canEditAnyDbtechSocialGroups())
		{
			return true;
		}

		if (!$this->isGroupOwner() && !$visitor->isSupervisorOfSocialGroup($this))
		{
			if (!$this->allow_discussions)
			{
				$error = \XF::phraseDeferred(
					'dbtech_social_groups_you_may_not_perform_this_action_because_group_does_not_allow_posting'
				);

				return false;
			}
		}

		return $this->hasPermission('startDiscussion');
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canCreatePoll(&$error = null): bool
	{
		return $this->allow_poll;
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canViewDiscussions(&$error = null): bool
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		if (!$this->canView($error))
		{
			return false;
		}

		if ($visitor->user_id && $this->Moderators[$visitor->user_id])
		{
			return true;
		}

		if (\XF::app()->repository(GroupRepository::class)->isLowerPrivacy($this->group_type, 'private'))
		{
			return true;
		}

		if ($visitor->canEditAnyDbtechSocialGroups())
		{
			return true;
		}

		if (!$visitor->isMemberOfSocialGroup($this, true))
		{
			$error = \XF::phraseDeferred('dbtech_social_groups_not_member_or_need_approval');
			return false;
		}

		return true;
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canViewMedia(&$error = null): bool
	{
		if (!$this->canView($error))
		{
			return false;
		}

		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		if ($visitor->canEditAnyDbtechSocialGroups())
		{
			return true;
		}

		if ($visitor->user_id && $this->Moderators[$visitor->user_id])
		{
			return true;
		}

		if ($visitor->isMemberOfSocialGroup($this, true))
		{
			return true;
		}

		if ($this->group_type === 'closed'
			&& !$visitor->isMemberOfSocialGroup($this, true)
		)
		{
			$error = \XF::phraseDeferred('dbtech_social_groups_not_member_or_need_approval');
			return false;
		}

		return $this->group_type === 'public';
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canViewCalendar(&$error = null): bool
	{
		if (!$this->canView($error))
		{
			return false;
		}

		if (!(\XF::options()->dbtechSocialEnableCalendar ?? false) || !$this->enable_calendar)
		{
			return false;
		}

		return $this->canViewOtherContent($error);
	}

	/**
	 * @return bool
	 */
	public function canViewDeletedDiscussions(): bool
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		if ($visitor->user_id && $this->Moderators[$visitor->user_id])
		{
			return true;
		}

		return $this->hasPermission('viewDeleted');
	}

	/**
	 * @return bool
	 */
	public function canViewModeratedDiscussions(): bool
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		if ($visitor->user_id && $this->Moderators[$visitor->user_id])
		{
			return true;
		}

		return $this->hasPermission('viewModerated');
	}

	/**
	 * @return bool
	 */
	public function canViewBannedUsers(): bool
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		if ($visitor->user_id && $this->Moderators[$visitor->user_id])
		{
			return true;
		}

		return ($this->hasPermission('viewBanned')
			|| $this->canBan()
		);
	}

	/**
	 * @return bool
	 */
	public function canUploadAndManageAttachments(): bool
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		return ($visitor->user_id && $this->hasPermission('uploadAttachment'));
	}

	/**
	 * @return bool
	 */
	public function canUploadVideos(): bool
	{
		$options = \XF::app()->options();

		if (empty($options->allowVideoUploads['enabled']))
		{
			return false;
		}

		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		return $this->hasPermission('uploadVideo');
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canEditGroupTags(&$error = null): bool
	{
		if (!\XF::app()->options()->enableTagging)
		{
			return false;
		}

		$visitor = \XF::visitor();

		if (!$this->exists())
		{
			// This is on create

			if ($visitor->hasPermission('dbtechSocial', 'tagOwnGroup'))
			{
				return true;
			}

			return (
				$visitor->hasPermission('dbtechSocial', 'tagAnyGroup')
				|| $visitor->hasPermission('dbtechSocial', 'manageAnyTag')
			);
		}

		if ($this->user_id === $visitor->user_id)
		{
			if ($this->hasPermission('tagOwnGroup'))
			{
				return true;
			}
		}

		return (
			$this->hasPermission('tagAnyGroup')
			|| $this->hasPermission('manageAnyTag')
		);
	}

	/**
	 * @param Discussion|null $discussion
	 * @param $error
	 *
	 * @return bool
	 */
	public function canEditTags(?Discussion $discussion = null, &$error = null): bool
	{
		if (!\XF::app()->options()->enableTagging)
		{
			return false;
		}

		if ($discussion)
		{
			if (!$discussion->discussion_open && !$discussion->canLockUnlock())
			{
				$error = \XF::phraseDeferred('you_may_not_perform_this_action_because_discussion_is_closed');

				return false;
			}
		}

		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		// if no discussion, assume the discussion will be owned by this person
		if (!$discussion || $discussion->user_id == $visitor->user_id)
		{
			if ($this->hasPermission('tagOwnDiscussion'))
			{
				return true;
			}
		}

		if (
			$this->hasPermission('tagAnyDiscussion')
			|| $this->hasPermission('manageAnyTag')
		)
		{
			return true;
		}

		return false;
	}

	/**
	 * @param $error
	 * @return bool
	 */
	public function canEdit(&$error = null): bool
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		if (!$visitor->user_id)
		{
			return false;
		}

		if ($visitor->canEditAnyDbtechSocialGroups($error))
		{
			return true;
		}

		return (
			$this->isGroupOwner()
			//			&& $this->hasPermission('updateOwn')
		);
	}

	/**
	 * @param $error
	 * @return bool
	 */
	public function canManage(&$error = null): bool
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		if (!$visitor->user_id)
		{
			return false;
		}

		if ($visitor->hasPermission('dbtechSocial', 'manageAnyGroup'))
		{
			return true;
		}

		return $this->isGroupOwner();
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canWatch(&$error = null): bool
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		return ($visitor->user_id
			&& $this->canViewDiscussions()
		);
	}

	/**
	 * @param $error
	 * @param User|null $asUser
	 *
	 * @return bool
	 */
	public function canReport(&$error = null, ?User $asUser = null): bool
	{
		$asUser = $asUser ?: \XF::visitor();
		return $asUser->canReport($error);
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canImportThreads(&$error = null): bool
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();
		return ($visitor->user_id
			&& $visitor->canImportThreadsToDbtechSocialGroups($error)
		);
	}

	/**
	 * @return bool
	 */
	public function verifyCheckPrivacy(): bool
	{
		if (!$this->exists())
		{
			return true;
		}

		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		return (!\XF::app()->options()->dbtechSocialAllowPrivacyDowngrade
			&& !$visitor->hasPermission('dbtechSocial', 'editAny')
		);
	}

	/**
	 * @param string $level
	 *
	 * @return bool
	 */
	public function isPrivacyLevelAtLeast(string $level): bool
	{
		return \XF::repository(GroupRepository::class)
			->isLowerPrivacy($level, $this->group_type)
		;
	}

	/**
	 * @return bool
	 */
	public function isUnread(): bool
	{
		if (!$this->discussion_count)
		{
			return false;
		}

		$cutOff = \XF::$time - \XF::app()->options()->readMarkingDataLifetime * 86400;
		if ($this->last_message_date < $cutOff)
		{
			return false;
		}

		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();
		if ($visitor->user_id)
		{
			$read = $this->Read[$visitor->user_id];

			return (!$read || $read->group_read_date < $this->last_message_date);
		}
		else
		{
			return true;
		}
	}

	/**
	 * @return bool
	 */
	public function isIgnored(): bool
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		return $visitor->isIgnoring($this->user_id);
	}

	/**
	 * @return bool
	 */
	public function isVisible(): bool
	{
		return ($this->group_state == 'visible');
	}

	/**
	 * @return bool
	 */
	public function isGroupOwner(): bool
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		return ($this->user_id
			&& $visitor->user_id === $this->user_id
		);
	}

	/**
	 * @return bool
	 */
	public function isSearchEngineIndexable(): bool
	{
		/*
		if ($this->allow_index == 'deny')
		{
			return false;
		}
		*/

		return true;
	}

	/**
	 * @return bool
	 */
	public function doesMessageCount(): bool
	{
		return ($this->count_messages
			&& !(\XF::options()->dbtechSocialDisabledPostCounters[$this->group_type] ?? false)
		);
	}

	/**
	 * @return \XF\Draft
	 */
	public function getDraftDiscussion(): \XF\Draft
	{
		return \XF\Draft::createFromEntity($this, 'DraftDiscussions');
	}

	/**
	 * @return array
	 * @throws \Exception
	 */
	public function getStructuredData(): array
	{
		$options = $this->app()->options();
		$router = $this->app()->router('public');
		$strFormatter = $this->app()->stringFormatter();
		$groupLink = $this->getContentUrl(true);
		$userLink = $this->User ? $this->User->getContentUrl(true) : null;

		$mainEntity = [
			'@type' => 'Organization',
			'@id' => $router->buildLink('canonical:dbtech-social', $this),
			'name' => $this->title,
			'disambiguatingDescription' => $this->tagline,
			'description' => $strFormatter->snippetString($this->description, 250),
			'identifier' => $this->group_id,
			'foundingDate' => \XF::language()->date($this->creation_date, 'c'),
		];

		if ($this->icon_date)
		{
			$mainEntity['image'] = [
				$this->getIconUrl('s', true),
				$this->getIconUrl('m', true),
				$this->getIconUrl('l', true),
			];
		}

		$logo = null;
		$style = \XF::app()->templater()->getStyle();
		if ($style)
		{
			$logo = $style->getProperty('publicMetadataLogoUrl') ?: null;
			if ($logo)
			{
				$pather = \XF::app()['request.pather'];
				$logo = $pather($logo, 'canonical');
			}
		}

		$structuredData = [
			'@context' => 'https://schema.org',
			'@type' => 'WebPage',
			'url' => $groupLink,
			'mainEntity' => $mainEntity,
			'parentOrganization' => [
				'@type' => 'Organization',
				'name' => $options->boardTitle,
				'alternateName' => $options->boardShortTitle ?: null,
				'description' => $options->boardDescription ?: null,
				'url' => $options->boardUrl,
				'logo' => $logo,
			],
		];

		return Arr::filterNull($structuredData, true);
	}

	/**
	 * @param bool $includeSelf
	 * @param string $linkType
	 *
	 * @return array
	 */
	public function getBreadcrumbs(bool $includeSelf = true, string $linkType = 'public'): array
	{
		$breadcrumbs = [];
		if ($includeSelf)
		{
			$breadcrumbs[] = [
				'href' => \XF::app()->router($linkType)->buildLink('dbtech-social', $this),
				'value' => $this->title,
			];
		}

		return $breadcrumbs;
	}

	/**
	 * @return array|bool[]
	 */
	public function getGroupListExtras(): array
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		$output = [
			'view_count'       => $this->view_count,
			'member_count'     => $this->member_count,
			'section_count'    => $this->section_count,
			'discussion_count' => $this->discussion_count,
			'message_count'    => $this->message_count,
		];

		if ($this->hasPermission('viewOthers')
			&& $this->canViewDiscussions()
		)
		{
			$output['hasNew'] = $this->isUnread();

			if ($this->last_message_date)
			{
				$output['last_message_id'] = $this->last_message_id;
				$output['last_message_date'] = $this->last_message_date;
				$output['last_message_user_id'] = $this->last_message_user_id;
				$output['last_message_username'] = $this->last_message_username;
				$output['last_discussion_id'] = $this->last_discussion_id;
				$output['last_discussion_title'] = \XF::app()->stringFormatter()->censorText($this->last_discussion_title);
				$output['LastMessageUser'] = $this->LastMessageUser;
				$output['LastDiscussion'] = $this->LastDiscussion;
			}
		}
		else
		{
			$output['privateInfo'] = true;
		}

		return $output;
	}

	/**
	 * @return Phrase
	 */
	public function getPrivacyState(): Phrase
	{
		return match ($this->group_type)
		{
			'public' => \XF::phrase('public'),
			'closed' => \XF::phrase('closed'),
			'private' => \XF::phrase('private'),
			'hidden' => \XF::phrase('dbtech_social_groups_group_privacy_hidden'),
			default => \XF::phrase('n_a'),
		};

	}

	/**
	 * @return Phrase
	 */
	public function getDiscussionPrompt(): Phrase
	{
		static $phraseName; // always return the same phrase for the same group instance

		if (!$phraseName)
		{
			//			if ($this->prompt_cache)
			//			{
			//				$phraseName = 'dbtech_social_groups_discussion_prompt.' . \array_rand($this->prompt_cache);
			//			}
			//			else
			//			{
			$phraseName = 'dbtech_social_groups_discussion_prompt.default';
			//			}
		}

		return \XF::phrase($phraseName);
	}

	/**
	 * @param Discussion|null $discussion
	 *
	 * @return string
	 */
	public function getNewContentState(?Discussion $discussion = null): string
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		if ($visitor->user_id && $this->hasPermission('approveUnapprove'))
		{
			return 'visible';
		}

		if ($visitor->canEditAnyDbtechSocialGroups())
		{
			return 'visible';
		}

		if (!$visitor->hasPermission('general', 'submitWithoutApproval'))
		{
			return 'moderated';
		}

		if ($discussion)
		{
			return $this->moderate_replies ? 'moderated' : 'visible';
		}
		else
		{
			return $this->moderate_discussions ? 'moderated' : 'visible';
		}
	}

	/**
	 * @param Entity $entity
	 */
	public function contentAdded(Entity $entity): void
	{
		$this->last_update_date = \XF::$time;
	}

	/**
	 * @return GroupMember
	 */
	public function getNewMember(): GroupMember
	{
		$groupMember = \XF::app()->em()->create(GroupMember::class);
		$groupMember->group_id = $this->group_id;

		return $groupMember;
	}

	/**
	 * @param Album|int|null $albumId
	 *
	 * @return GroupAlbum
	 */
	public function getNewAlbum(Album|int|null $albumId = null): GroupAlbum
	{
		$groupAlbum = \XF::app()->em()->create(GroupAlbum::class);
		$groupAlbum->group_id = $this->group_id;

		if ($albumId === null)
		{
			$albumId = 0;
		}
		else if ($albumId instanceof Album)
		{
			$albumId = $albumId->album_id;
		}

		$groupAlbum->album_id = $albumId;

		return $groupAlbum;
	}

	/**
	 * @param int|Thread|null $threadId
	 *
	 * @return RelatedThread
	 */
	public function getNewRelatedThread(int|Thread|null $threadId = null): RelatedThread
	{
		$relatedThread = \XF::app()->em()->create(RelatedThread::class);
		$relatedThread->group_id = $this->group_id;

		if ($threadId === null)
		{
			$threadId = 0;
		}
		else if ($threadId instanceof Thread)
		{
			$threadId = $threadId->thread_id;
		}

		$relatedThread->thread_id = $threadId;
		$relatedThread->display_order = intval($this->db()->fetchOne('
			SELECT MAX(`display_order`) 
			FROM `xf_dbtech_social_groups_related_thread` 
			WHERE `group_id` = ?
		', $this->group_id)) + 10;

		return $relatedThread;
	}

	/**
	 * @return Calendar
	 */
	public function getNewCalendar(): Calendar
	{
		$calendar = \XF::app()->em()->create(Calendar::class);
		$calendar->calendar_type_id = 'dbtech_social_group';

		return $calendar;
	}

	/**
	 * @return Discussion
	 */
	public function getNewDiscussion(): Discussion
	{
		$discussion = \XF::app()->em()->create(Discussion::class);
		$discussion->group_id = $this->group_id;

		return $discussion;
	}

	/**
	 * @param Discussion $discussion
	 */
	public function discussionAdded(Discussion $discussion): void
	{
		if ($discussion->discussion_type == 'redirect')
		{
			return;
		}

		$this->contentAdded($discussion);

		$this->discussion_count++;
		$this->message_count += 1 + $discussion->reply_count;

		if ($discussion->last_message_date >= $this->last_message_date)
		{
			$this->last_message_date = $discussion->last_message_date;
			$this->last_message_id = $discussion->last_message_id;
			$this->last_message_user_id = $discussion->last_message_user_id;
			$this->last_message_username = $discussion->last_message_username;
			$this->last_discussion_id = $discussion->discussion_id;
			$this->last_discussion_title = $discussion->title;
		}
	}

	/**
	 * @param Discussion $discussion
	 */
	public function discussionDataChanged(Discussion $discussion): void
	{
		$isRedirect = $discussion->discussion_type == 'redirect';
		$wasRedirect = $discussion->getExistingValue('discussion_type') == 'redirect';

		if ($isRedirect && !$wasRedirect)
		{
			// this is like the discussion being deleted for counter purposes
			$this->discussionRemoved($discussion);
		}
		else if (!$isRedirect && $wasRedirect)
		{
			// like being added
			$this->discussionAdded($discussion);
		}
		else if ($isRedirect)
		{
			return;
		}

		$this->message_count += $discussion->reply_count - $discussion->getExistingValue('reply_count');

		if ($discussion->last_message_date >= $this->last_message_date)
		{
			$this->last_message_date = $discussion->last_message_date;
			$this->last_message_id = $discussion->last_message_id;
			$this->last_message_user_id = $discussion->last_message_user_id;
			$this->last_message_username = $discussion->last_message_username;
			$this->last_discussion_id = $discussion->discussion_id;
			$this->last_discussion_title = $discussion->title;
		}
		else if ($discussion->getExistingValue('last_message_id') == $this->last_message_id)
		{
			$this->rebuildLastMessage();
		}
	}

	/**
	 * @param Discussion $discussion
	 */
	public function discussionRemoved(Discussion $discussion): void
	{
		if ($discussion->discussion_type == 'redirect')
		{
			// if this was changed, it used to count so we need to continue
			if (!$discussion->isChanged('discussion_type'))
			{
				return;
			}
		}

		$this->discussion_count--;
		$this->message_count -= 1 + $discussion->reply_count;

		if ($discussion->last_message_id == $this->last_message_id)
		{
			$this->rebuildLastMessage();
		}
	}

	/**
	 * @param GroupMember $groupMember
	 */
	public function memberAdded(GroupMember $groupMember): void
	{
		$this->member_count++;
	}

	/**
	 * @param GroupMember $groupMember
	 */
	public function memberRemoved(GroupMember $groupMember): void
	{
		$this->member_count--;
	}

	/**
	 * @param Section $section
	 */
	public function sectionAdded(Section $section): void
	{
		$this->section_count++;
	}

	/**
	 * @param Section $section
	 */
	public function sectionRemoved(Section $section): void
	{
		$this->section_count--;
	}

	/**
	 * @return bool
	 */
	public function rebuildCounters(): bool
	{
		$discussionCounters = $this->db()->fetchRow("
			SELECT COUNT(*) AS discussion_count,
				COUNT(*) + COALESCE(SUM(reply_count), 0) AS message_count
			FROM xf_dbtech_social_groups_discussion
			WHERE group_id = ?
				AND discussion_state = 'visible'
				AND discussion_type <> 'redirect'
		", $this->group_id);

		$this->discussion_count = $discussionCounters['discussion_count'];
		$this->message_count = $discussionCounters['message_count'];

		$memberCounters = $this->db()->fetchRow("
			SELECT COUNT(*) AS member_count
			FROM xf_dbtech_social_groups_group_member
			WHERE group_id = ?
				AND member_state = 'valid'
		", $this->group_id);

		$this->member_count = $memberCounters['member_count'];

		$sectionCounters = $this->db()->fetchRow("
			SELECT COUNT(*) AS section_count
			FROM xf_dbtech_social_groups_section
			WHERE group_id = ?
		", $this->group_id);

		$this->section_count = $sectionCounters['section_count'];

		$this->rebuildLastMessage();

		return true;
	}

	/**
	 *
	 */
	public function rebuildLastMessage(): void
	{
		$discussion = $this->db()->fetchRow("
			SELECT *
			FROM xf_dbtech_social_groups_discussion
			WHERE group_id = ?
				AND discussion_state = 'visible'
				AND discussion_type <> 'redirect'
			ORDER BY last_message_date DESC
			LIMIT 1
		", $this->group_id);
		if ($discussion)
		{
			$this->last_message_id = $discussion['last_message_id'];
			$this->last_message_date = $discussion['last_message_date'];
			$this->last_message_user_id = $discussion['last_message_user_id'];
			$this->last_message_username = $discussion['last_message_username'];
			$this->last_discussion_id = $discussion['discussion_id'];
			$this->last_discussion_title = $discussion['title'];
		}
		else
		{
			$this->last_message_id = 0;
			$this->last_message_date = 0;
			$this->last_message_user_id = 0;
			$this->last_message_username = '';
			$this->last_discussion_id = 0;
			$this->last_discussion_title = '';
		}
	}

	/**
	 * @return string
	 */
	public function getContentDateColumn(): string
	{
		return 'creation_date';
	}

	/**
	 * @param bool $canonical
	 * @param array $extraParams
	 * @param null $hash
	 *
	 * @return string
	 */
	public function getContentUrl(bool $canonical = false, array $extraParams = [], $hash = null): string
	{
		$route = $canonical ? 'canonical:dbtech-social' : 'dbtech-social';
		return \XF::app()->router('public')->buildLink($route, $this, $extraParams, $hash);
	}

	/**
	 * @return string|null
	 */
	public function getContentPublicRoute(): ?string
	{
		return 'dbtech-social';
	}

	/**
	 * @param string $context
	 *
	 * @return Phrase
	 */
	public function getContentTitle(string $context = ''): Phrase
	{
		return \XF::phrase('dbtech_social_groups_social_group_x', ['title' => $this->title]);
	}

	/**
	 * @return Phrase|null
	 */
	public function getLocale(): ?Phrase
	{
		if (!$this->language_code)
		{
			return null;
		}

		$locales = \XF::app()->data(Language::class)->getLocaleList();
		if (!array_key_exists($this->language_code, $locales))
		{
			return null;
		}

		return $locales[$this->language_code];
	}

	/**
	 * @param string $languageCode
	 *
	 * @return bool
	 */
	protected function verifyLanguageCode(string $languageCode): bool
	{
		if (!$languageCode)
		{
			return true;
		}

		$languageData = \XF::app()->data(Language::class);
		if (!array_key_exists($languageCode, $languageData->getLocaleList()))
		{
			$this->error(\XF::phrase('dbtech_social_groups_please_select_valid_language'), 'parent_id');
			return false;
		}

		return true;
	}

	/**
	 *
	 */
	protected function _preSave(): void
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		$approvalChange = $this->isStateChanged('group_state', 'moderated');
		if ($this->isInsert() || $approvalChange == 'leave')
		{
			$this->last_update_date = \XF::$time;
		}

		if ($this->isInsert() && !$this->isChanged('group_state'))
		{
			$this->group_state = !$visitor->hasPermission('dbtechSocial', 'createWithoutApproval')
				? 'moderated'
				: 'visible'
			;
		}

		if (
			($this->isInsert() || $this->isChanged('group_type'))
			&& !$this->getOption('admin_edit')
		)
		{
			switch ($this->group_type)
			{
				case 'closed':
					if (!$visitor->hasPermission('dbtechSocial', 'createClosedGroup'))
					{
						$this->error(
							\XF::phrase('dbtech_social_groups_cannot_create_group_this_privacy_level'),
							'group_type'
						);
					}
					break;

				case 'private':
					if (!$visitor->hasPermission('dbtechSocial', 'createPrivateGroup'))
					{
						$this->error(
							\XF::phrase('dbtech_social_groups_cannot_create_group_this_privacy_level'),
							'group_type'
						);
					}
					break;

				case 'hidden':
					if (!$visitor->hasPermission('dbtechSocial', 'createHiddenGroup'))
					{
						$this->error(
							\XF::phrase('dbtech_social_groups_cannot_create_group_this_privacy_level'),
							'group_type'
						);
					}
					break;
			}
		}
	}

	/**
	 * @return void
	 * @throws PrintableException
	 */
	protected function _postSave(): void
	{
		$this->_postSaveBookmarks();

		if ($this->isInsert())
		{
			$user = $this->User;

			if (!$user->isMemberOfSocialGroup($this))
			{
				$groupMemberRepo = \XF::app()->repository(GroupMemberRepository::class);
				$groupMemberRepo->joinGroup($this, $user);
			}

			$permissionsRepo = \XF::app()->repository(GroupPermissionsRepository::class);
			$permissionsRepo->addOwnerPermissionsForGroup($user, $this);
		}

		$approvalChange = $this->isStateChanged('group_state', 'moderated');
		$deletionChange = $this->isStateChanged('group_state', 'deleted');

		if ($this->isUpdate())
		{
			if ($deletionChange == 'enter' || $deletionChange == 'leave')
			{
				\XF::app()->jobManager()->enqueueUnique(
					'dbtSGGroupSoftDelete' . $this->group_id,
					GroupSoftDeleteUndelete::class,
					[
						'group_id' => $this->group_id,
					]
				);
			}

			if ($deletionChange == 'leave' && $this->DeletionLog)
			{
				$this->DeletionLog->delete();
			}

			if ($approvalChange == 'leave' && $this->ApprovalQueue)
			{
				$this->ApprovalQueue->delete();
			}
		}

		if ($approvalChange == 'enter')
		{
			/** @var ApprovalQueue $approvalQueue */
			$approvalQueue = $this->getRelationOrDefault('ApprovalQueue', false);
			$approvalQueue->content_date = $this->creation_date;
			$approvalQueue->save();
		}
		else if ($deletionChange == 'enter' && !$this->DeletionLog)
		{
			$delLog = $this->getRelationOrDefault('DeletionLog', false);
			$delLog->setFromVisitor();
			$delLog->save();
		}

		if ($this->enable_calendar
			&& (!$this->calendar_id || !$this->Calendar)
		)
		{
			\XF::runLater(function ()
			{
				$calendarCreatorSvc = \XF::app()->service(CalendarCreatorService::class, $this);
				if ($calendarCreatorSvc->validate($errors))
				{
					$calendarCreatorSvc->save();
				}
				else if (\XF::$debugMode)
				{
					foreach ($errors AS $error)
					{
						\XF::logError($error);
					}
				}
			});
		}
	}

	/**
	 * @return void
	 * @throws PrintableException
	 */
	protected function _postDelete(): void
	{
		$icon = \XF::app()->service(IconService::class, $this);
		$icon->deleteIconForGroupDelete();

		$banner = \XF::app()->service(BannerService::class, $this);
		$banner->deleteBannerForGroupDelete();

		if ($this->getOption('enqueue_delete_cleanup'))
		{
			\XF::app()->jobManager()->enqueue(GroupDeleteCleanUp::class, [
				'groupId' => $this->group_id,
				'title' => $this->title,
				'userId' => \XF::visitor()->user_id,
				'unlink' => $this->getOption('unlink_albums_on_delete'),
			]);
		}

		$this->_postDeleteBookmarks();

		if ($this->group_state == 'deleted' && $this->DeletionLog)
		{
			$this->DeletionLog->delete();
		}

		if ($this->group_state == 'moderated' && $this->ApprovalQueue)
		{
			$this->ApprovalQueue->delete();
		}
	}

	/**
	 * @param EntityResult $result
	 * @param int $verbosity
	 * @param array $options
	 *
	 * @return EntityResult
	 */
	protected function setupApiResultData(
		EntityResult $result,
		$verbosity = self::VERBOSITY_NORMAL,
		array $options = []
	): EntityResult
	{
		$result->username = $this->User ? $this->User->username : $this->username;

		if ($this->hasPermission('viewOthers'))
		{
			$result->includeExtra([
				'view_count'            => $this->view_count,
				'member_count'          => $this->member_count,
				'section_count'         => $this->section_count,
				'discussion_count'      => $this->discussion_count,
				'message_count'         => $this->message_count,
				'last_update_date'      => $this->last_update_date,
				'last_message_id'       => $this->last_message_id,
				'last_message_date'     => $this->last_message_date,
				'last_message_username' => $this->last_message_username,
				'last_discussion_id'    => $this->last_discussion_id,
				'last_discussion_title' => \XF::app()->stringFormatter()->censorText($this->last_discussion_title),
			]);
		}

		$result->tags = \array_column($this->tags, 'tag');

		$result->can_edit_tags = $this->canEditGroupTags();
		$result->can_create_discussion = $this->canStartDiscussion();
		$result->can_upload_attachment = $this->canUploadAndManageAttachments();

		return $result;
	}

	public function requiresSearchIndexUpdate(): bool
	{
		if ($this->isChanged([
			'title',
			'description',
			'user_id',
			'tags',
			'group_type',
			'group_state',
			'last_update_date',
		]))
		{
			return true;
		}

		return false;
	}

	/**
	 * @param Structure $structure
	 *
	 * @return Structure
	 */
	public static function getStructure(Structure $structure): Structure
	{
		$structure->table = 'xf_dbtech_social_groups_group';
		$structure->shortName = 'DBTech\SocialGroups:Group';
		$structure->contentType = 'dbtech_social_group';
		$structure->primaryKey = 'group_id';
		$structure->columns = [
			'group_id'                    => ['type' => self::UINT, 'autoIncrement' => true, 'nullable' => true],
			'title'                       => [
				'type'     => self::STR, 'maxLength' => 50,
				'required' => 'please_enter_valid_title', 'api' => true,
			],
			'tagline'                     => [
				'type'     => self::STR, 'maxLength' => 250,
				'required' => 'dbtech_social_groups_please_enter_tagline', 'api' => true,
			],
			'description'                 => ['type' => self::STR, 'default' => '', 'api' => true],
			'group_type'                  => [
				'type'          => self::STR, 'default' => 'public',
				'allowedValues' => ['public', 'closed', 'private', 'hidden'], 'api' => true,
			],
			'group_state'                 => [
				'type'          => self::STR, 'default' => 'visible',
				'allowedValues' => ['visible', 'moderated', 'deleted'], 'api' => true,
			],
			'sticky'                      => ['type' => self::BOOL, 'default' => false],
			'featured'                    => ['type' => self::BOOL, 'default' => false],
			'member_count'                => ['type' => self::UINT, 'forced' => true, 'default' => 1],
			'section_count'               => ['type' => self::UINT, 'forced' => true, 'default' => 0],
			'discussion_count'            => ['type' => self::UINT, 'forced' => true, 'default' => 0],
			'message_count'               => ['type' => self::UINT, 'forced' => true, 'default' => 0],
			'view_count'                  => ['type' => self::UINT, 'default' => 0, 'api' => true],
			'user_id'                     => ['type' => self::UINT, 'required' => true, 'api' => true],
			'username'                    => ['type' => self::STR, 'maxLength' => 50, 'required' => true, 'api' => true],
			'creation_date'               => ['type' => self::UINT, 'default' => \XF::$time],
			'last_update_date'            => ['type' => self::UINT, 'default' => 0],
			'last_message_id'             => ['type' => self::UINT, 'default' => 0],
			'last_message_date'           => ['type' => self::UINT, 'default' => 0],
			'last_message_user_id'        => ['type' => self::UINT, 'default' => 0],
			'last_message_username'       => ['type' => self::STR, 'maxLength' => 50, 'default' => ''],
			'last_discussion_id'          => ['type' => self::UINT, 'default' => 0],
			'last_discussion_title'       => ['type' => self::STR, 'maxLength' => 150, 'default' => ''],
			'icon_date'                   => ['type' => self::UINT, 'default' => 0],
			'icon_hash'                   => ['type' => self::STR, 'maxLength' => 32, 'default' => ''],
			'icon_width'                  => ['type' => self::UINT, 'max' => 65535, 'default' => 0],
			'icon_height'                 => ['type' => self::UINT, 'max' => 65535, 'default' => 0],
			'icon_highdpi'                => ['type' => self::BOOL, 'default' => false],
			'icon_crop_x'                 => ['type' => self::UINT, 'default' => 0],
			'icon_crop_y'                 => ['type' => self::UINT, 'default' => 0],
			'banner_date'                 => ['type' => self::UINT, 'default' => 0],
			'banner_hash'                 => ['type' => self::STR, 'maxLength' => 32, 'default' => ''],
			'banner_position_y'           => ['type' => self::UINT, 'max' => 100, 'default' => null, 'nullable' => true],
			'language_code'               => ['type' => self::STR, 'maxLength' => 25, 'default' => ''],
			'text_direction'              => [
				'type'          => self::STR, 'default' => 'LTR',
				'allowedValues' => ['LTR', 'RTL'],
			],
			'allow_members'               => ['type' => self::BOOL, 'default' => true],
			'moderate_members'            => ['type' => self::BOOL, 'default' => false],
			'moderate_discussions'        => ['type' => self::BOOL, 'default' => false],
			'moderate_replies'            => ['type' => self::BOOL, 'default' => false],
			'allow_posting'               => ['type' => self::BOOL, 'default' => true, 'api' => true],
			'allow_discussions'           => ['type' => self::BOOL, 'default' => true, 'api' => true],
			'allow_poll'                  => ['type' => self::BOOL, 'default' => true, 'api' => true],
			'count_messages'              => ['type' => self::BOOL, 'default' => true],
			'enable_calendar'             => ['type' => self::BOOL, 'default' => false],
			'calendar_id'                 => ['type' => self::UINT, 'default' => 0],
			'event_creation'              => [
				'type'          => self::STR, 'default' => 'group_owner',
				'allowedValues' => ['group_owner', 'group_staff', 'members'],
			],
			'find_new'                    => ['type' => self::BOOL, 'default' => true],
			'allowed_watch_notifications' => [
				'type'          => self::STR, 'default' => 'all',
				'allowedValues' => ['all', 'discussion', 'none'],
			],
			'default_sort_order'          => [
				'type'          => self::STR, 'default' => 'last_message_date',
				'allowedValues' => ['title', 'message_date', 'reply_count', 'view_count', 'last_message_date'],
			],
			'default_sort_direction'      => [
				'type'          => self::STR, 'default' => 'desc',
				'allowedValues' => ['asc', 'desc'],
			],
			'list_date_limit_days'        => ['type' => self::UINT, 'default' => 0, 'max' => 3650],
			'tags'                        => ['type' => self::JSON_ARRAY, 'default' => []],
			'min_tags'                    => ['type' => self::UINT, 'default' => 0, 'max' => 100, 'api' => true],
			'rules'                       => ['type' => self::STR, 'default' => '', 'api' => true],
		];
		$structure->behaviors = [
			Indexable::class             => [
				'checkForUpdates' => null,
			],
			Featurable::class => [
				'stateField' => 'group_state',
			],
			PermissionRebuildable::class => [
				'permissionContentType' => $structure->contentType,
			],
		];
		$structure->getters = [
			'draft_discussion'  => true,
			'discussion_prompt' => true,
			'locale'            => true,
			'structured_data'   => true,
		];
		$structure->relations = [
			'User'             => [
				'entity'     => User::class,
				'type'       => self::TO_ONE,
				'conditions' => 'user_id',
				'primary'    => true,
				'api'        => true,
			],
			'Read'             => [
				'entity'     => GroupRead::class,
				'type'       => self::TO_MANY,
				'conditions' => 'group_id',
				'key'        => 'user_id',
			],
			'Watch'            => [
				'entity'     => GroupWatch::class,
				'type'       => self::TO_MANY,
				'conditions' => 'group_id',
				'key'        => 'user_id',
			],
			'DraftDiscussions' => [
				'entity'     => Draft::class,
				'type'       => self::TO_MANY,
				'conditions' => [
					['draft_key', '=', 'dbtech-social-groups-group-', '$group_id'],
				],
				'key'        => 'user_id',
			],
			'LastMessage'      => [
				'entity'     => Message::class,
				'type'       => self::TO_ONE,
				'conditions' => [['message_id', '=', '$last_message_id']],
				'primary'    => true,
			],
			'LastMessageUser'  => [
				'entity'     => User::class,
				'type'       => self::TO_ONE,
				'conditions' => [['user_id', '=', '$last_message_user_id']],
				'primary'    => true,
			],
			'LastDiscussion'   => [
				'entity'     => Discussion::class,
				'type'       => self::TO_ONE,
				'conditions' => [['discussion_id', '=', '$last_discussion_id']],
				'primary'    => true,
			],
			'Permissions'      => [
				'entity'     => PermissionCacheContent::class,
				'type'       => self::TO_MANY,
				'conditions' => [
					['content_type', '=', 'dbtech_social_group'],
					['content_id', '=', '$group_id'],
				],
				'key'        => 'permission_combination_id',
				'proxy'      => true,
			],
			'Moderators'       => [
				'entity'     => ModeratorContent::class,
				'type'       => self::TO_MANY,
				'conditions' => [
					['content_type', '=', 'dbtech_social_group'],
					['content_id', '=', '$group_id'],
				],
				'with'       => 'User',
				'key'        => 'user_id',
			],
			'Supervisors'      => [
				'entity'     => GroupMember::class,
				'type'       => self::TO_MANY,
				'conditions' => [
					['group_id', '=', '$group_id'],
					['is_supervisor', '=', '1'],
				],
				'with'       => 'User',
				'key'        => 'user_id',
			],
			'Members'          => [
				'entity'     => GroupMember::class,
				'type'       => self::TO_MANY,
				'conditions' => 'group_id',
				'key'        => 'user_id',
			],
			'Invites'          => [
				'entity'     => GroupInvite::class,
				'type'       => self::TO_MANY,
				'conditions' => 'group_id',
				'key'        => 'user_id',
			],
			'Bans'             => [
				'entity'     => GroupBan::class,
				'type'       => self::TO_MANY,
				'conditions' => 'group_id',
				'key'        => 'user_id',
			],
			'RelatedThreads'   => [
				'entity'     => RelatedThread::class,
				'type'       => self::TO_MANY,
				'conditions' => 'group_id',
				'key'        => 'thread_id',
				'order'      => ['display_order', 'ASC'],
			],
			'DeletionLog'      => [
				'entity'     => DeletionLog::class,
				'type'       => self::TO_ONE,
				'conditions' => [
					['content_type', '=', 'dbtech_social_group'],
					['content_id', '=', '$group_id'],
				],
				'primary'    => true,
			],
			'ApprovalQueue'    => [
				'entity'     => ApprovalQueue::class,
				'type'       => self::TO_ONE,
				'conditions' => [
					['content_type', '=', 'dbtech_social_group'],
					['content_id', '=', '$group_id'],
				],
				'primary'    => true,
			],
			'Calendar'    => [
				'entity'     => Calendar::class,
				'type'       => self::TO_ONE,
				'conditions' => [['category_id', '=', '$calendar_id']],
				'primary'    => true,
			],
		];

		$structure->options = [
			'admin_edit'                  => false,
			'enqueue_delete_cleanup'      => true,
			'enqueue_soft_delete_cleanup' => true,
			'unlink_albums_on_delete'     => false,
		];

		$structure->withAliases = [
			'api'  => [
				'User.api',
				function ()
				{
					return 'Permissions|' . \XF::visitor()->permission_combination_id;
				},
			],
			'full' => [
				function ()
				{
					$with = ['User', 'LastDiscussion'];

					$visitor = \XF::visitor();
					$with[] = 'Permissions|' . $visitor->permission_combination_id;

					$userId = $visitor->user_id;
					if ($userId)
					{
						$with[] = 'Invites|' . $userId;
						$with[] = 'Read|' . $userId;
						$with[] = 'Watch|' . $userId;
						$with[] = 'Bans|' . $userId;
						$with[] = 'LastDiscussion.Read|' . $userId;
						$with[] = 'LastDiscussion.Section.Read|' . $userId;
					}

					return $with;
				},
			],
			function ()
			{
				$userId = \XF::visitor()->user_id;
				if ($userId)
				{
					return [
						'Bookmarks|' . $userId,
					];
				}

				return null;
			},
		];

		static::addBookmarkableStructureElements($structure);
		static::addFeaturableStructureElements($structure);
		static::addEmbedResolverStructureElements($structure);

		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		if ($visitor->user_id)
		{
			$structure->defaultWith[] = 'Moderators|' . $visitor->user_id;
			$structure->defaultWith[] = 'Bans|' . $visitor->user_id;
		}

		return $structure;
	}

	/**
	 * @return string[]
	 */
	public static function getListedWith(): array
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();
		$with = ['LastMessageUser', 'LastDiscussion'];

		if ($visitor->user_id)
		{
			$with[] = "Read|" . $visitor->user_id;
			$with[] = "LastDiscussion.Read|" . $visitor->user_id;
		}

		return $with;
	}
}