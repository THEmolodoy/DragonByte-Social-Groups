<?php

namespace DBTech\SocialGroups\EventType;

use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Entity\GroupMember;
use DBTech\SocialGroups\Pub\View\Group\EventDatesView;
use DBTech\SocialGroups\Pub\View\Group\EventEditView;
use DBTech\SocialGroups\Pub\View\Group\EventFieldView;
use DBTech\SocialGroups\Pub\View\Group\EventResponsesView;
use DBTech\SocialGroups\Pub\View\Group\EventTooltipView;
use DBTech\SocialGroups\Pub\View\Group\EventView;
use NF\Calendar\Entity\Event;
use NF\Calendar\EventType\AbstractHandler;
use XF\Api\Result\EntityResult;
use XF\Http\Request;
use XF\InputFilterer;
use XF\Mvc\Entity\ArrayValidator;
use XF\Mvc\Entity\Entity;
use XF\Phrase;
use XF\PrintableException;

class SocialGroupHandler extends AbstractHandler
{
	/**
	 * @inheritDoc
	 */
	public function getTypeTitle(): Phrase
	{
		return \XF::phrase('dbtech_social_groups_event_type.' . $this->type);
	}

	/**
	 * @inheritDoc
	 */
	public function getTypeDescription(): Phrase
	{
		return \XF::phrase('dbtech_social_groups_event_type_desc.' . $this->type);
	}

	/**
	 * @inheritDoc
	 */
	public function getTypeTitlePlural(): Phrase
	{
		return \XF::phrase('dbtech_social_groups_event_type_plural.' . $this->type);
	}

	/**
	 * @inheritDoc
	 */
	public function getEventLink(Event $event, string $path = '', bool $canonical = false, array $linkParams = []): string
	{
		$group = \XF::app()->em()->find(Group::class, $event->Calendar->type_config['group_id']);

		return \XF::app()->router('public')->buildLink(
			($canonical ? 'canonical:dbtech-social/calendar' : 'dbtech-social/calendar') . ($path ? '/' : '') . $path,
			['group_id' => $group->group_id, 'title' => $group->title, 'event_id' => $event->event_id],
			$linkParams
		);
	}

	/**
	 * @inheritDoc
	 */
	public function getEventViewAndTemplate(Event $event, array $overrideContext = []): array
	{
		return match ($overrideContext['action'] ?? null)
		{
			'tooltip'     => [EventTooltipView::class,   'dbtech_social_groups_group_calendar_event_tooltip'],
			'add', 'edit' => [EventEditView::class,      'dbtech_social_groups_group_calendar_event_edit'],
			'field'       => [EventFieldView::class,     'dbtech_social_groups_group_calendar_event_field'],
			'responses'   => [EventResponsesView::class, 'dbtech_social_groups_group_calendar_event_responses'],
			'dates'       => [EventDatesView::class,     'dbtech_social_groups_group_calendar_event_dates'],
			default       => [EventView::class,          'dbtech_social_groups_group_calendar_event']
		};
	}

	public function adjustEventViewParams(Event $event, array $viewParams, Request $request): array
	{
		$group = \XF::app()->em()->find(Group::class, $event->Calendar->type_config['group_id']);
		$viewParams['group'] = $group;

		return $viewParams;
	}

	/**
	 * @inheritDoc
	 */
	public function getDefaultTypeData(): array
	{
		return [
			'event_privacy' => 'members',
		];
	}

	/**
	 * @inheritDoc
	 */
	protected function getTypeDataColumnDefinitions(): array
	{
		return [
			'event_privacy' => [
				'type' => Entity::STR,
				'allowedValues' => ['group_owner', 'group_staff', 'members', 'everyone'],
			],
		];
	}

	/**
	 * @inheritDoc
	 */
	protected function renderExtraDataEditInternal(
		Event $event,
		array $typeData,
		string $context,
		string $subContext,
		array $options = []
	): string
	{
		$params = [
			'handler' => $this,
			'event' => $event,
			'typeData' => $typeData,
			'typeDataDefinitions' => $this->getTypeDataColumnDefinitions(),
			'context' => $context,
			'subContext' => $subContext,
		];

		return \XF::app()->templater()->renderTemplate(
			'public:dbtech_social_groups_group_calendar_event_type_config',
			$params
		);
	}

	/**
	 * @inheritDoc
	 */
	public function processExtraDataSimple(
		Event $event,
		string $context,
		Request $request,
		array &$errors = [],
		array $options = []
	): array|ArrayValidator|null
	{
		$validator = $this->getTypeDataValidator($event);
		$validator->event_privacy = $request->filter('social_group.event_privacy', InputFilterer::STRING);

		return $validator;
	}

	/**
	 * @inheritDoc
	 */
	public function processExtraDataForApiSimple(
		Event $event,
		string $context,
		Request $request,
		array &$errors = [],
		array $options = []
	): array|ArrayValidator|null
	{
		$validator = $this->getTypeDataValidator($event);
		$eventPrivacy = $request->filter('social_group.event_privacy', '?str');
		if ($eventPrivacy !== null)
		{
			$validator->event_privacy = $eventPrivacy;
		}

		return $validator;
	}

	/**
	 * @inheritDoc
	 */
	public function addTypeDataToApiResult(
		Event $event,
		EntityResult $result,
		int $verbosity = Entity::VERBOSITY_NORMAL,
		array $options = []
	): void
	{
		$result->dbtechSocial = [
			'event_privacy' => $event->type_data['event_privacy'],
		];
	}

	/**
	 * @param Event $event
	 *
	 * @return void
	 * @throws PrintableException
	 *
	 * @noinspection PhpMissingReturnTypeInspection
	 */
	public function onEventSave(Event $event)
	{
		if ($event->isInsert() && !empty($event->Calendar->type_config['group_id']))
		{
			$groupMember = \XF::app()->em()->findOne(
				GroupMember::class,
				[
					'group_id'   => $event->Calendar->type_config['group_id'],
					'user_id'    => $event->user_id,
				]
			);
			if ($groupMember)
			{
				$groupMember->eventAdded($event);
				$groupMember->save();
			}
		}
	}

	/**
	 * @param Event $event
	 *
	 * @return void
	 * @throws PrintableException
	 *
	 * @noinspection PhpMissingReturnTypeInspection
	 */
	public function onEventMadeVisible(Event $event)
	{
		if ($event->isUpdate() && !empty($event->Calendar->type_config['group_id']))
		{
			$groupMember = \XF::app()->em()->findOne(
				GroupMember::class,
				[
					'group_id'   => $event->Calendar->type_config['group_id'],
					'user_id'    => $event->user_id,
				]
			);
			if ($groupMember)
			{
				$groupMember->eventAdded($event);
				$groupMember->save();
			}
		}
	}

	/**
	 * @param Event $event
	 *
	 * @return void
	 * @throws PrintableException
	 *
	 * @noinspection PhpMissingReturnTypeInspection
	 */
	public function onEventDelete(Event $event)
	{
		if (!empty($event->Calendar->type_config['group_id']))
		{
			$groupMember = \XF::app()->em()->findOne(
				GroupMember::class,
				[
					'group_id'   => $event->Calendar->type_config['group_id'],
					'user_id'    => $event->user_id,
				]
			);
			if ($groupMember)
			{
				$groupMember->eventRemoved($event);
				$groupMember->save();
			}
		}
	}

	/**
	 * @param Event $event
	 * @param bool $isDelete
	 *
	 * @return void
	 * @throws PrintableException
	 *
	 * @noinspection PhpMissingReturnTypeInspection
	 */
	public function onEventHidden(Event $event, bool $isDelete)
	{
		if (!$isDelete && !empty($event->Calendar->type_config['group_id']))
		{
			$groupMember = \XF::app()->em()->findOne(
				GroupMember::class,
				[
					'group_id'   => $event->Calendar->type_config['group_id'],
					'user_id'    => $event->user_id,
				]
			);
			if ($groupMember)
			{
				$groupMember->eventRemoved($event);
				$groupMember->save();
			}
		}
	}

	/**
	 * @inheritDoc
	 */
	public function hasEventPermission(Event $event, string $permission): bool
	{
		$group = \XF::app()->em()->find(Group::class, $event->Calendar->type_config['group_id']);

		return match ($permission)
		{
			'viewEvents' => $group->canViewCalendarEvent($event),
			default => parent::hasEventPermission($event, $permission),
		};
	}
}