<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\Poll;

use DBTech\SocialGroups\Entity\Discussion;
use DBTech\SocialGroups\XF\Entity\User as ExtendedUserEntity;
use XF\Entity\Poll;
use XF\Mvc\Entity\Entity;
use XF\Poll\AbstractHandler;
use XF\PrintableException;

class DiscussionHandler extends AbstractHandler
{
	/**
	 * @param Discussion $content
	 * @param $error
	 *
	 * @return bool
	 */
	public function canCreate(Entity $content, &$error = null)
	{
		return $content->canCreatePoll($error);
	}

	/**
	 * @param Discussion $content
	 * @param Poll $poll
	 * @param $error
	 *
	 * @return bool
	 */
	public function canEdit(Entity $content, Poll $poll, &$error = null)
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();
		if (!$visitor->user_id)
		{
			return false;
		}

		if (!$content->discussion_open && !$content->canLockUnlock())
		{
			$error = \XF::phraseDeferred('you_may_not_perform_this_action_because_discussion_is_closed');
			return false;
		}

		if ($visitor->hasDbtechSocialGroupsGroupPermission($content->group_id, 'manageAnyDiscussion'))
		{
			return true;
		}

		$groupId = $content->group_id;

		if ($content->user_id == $visitor->user_id && $visitor->hasDbtechSocialGroupsGroupPermission($groupId, 'editOwnMessage'))
		{
			$editLimit = $visitor->hasDbtechSocialGroupsGroupPermission($groupId, 'editOwnMessageTimeLimit');
			if ($editLimit != -1 && (!$editLimit || $content->message_date < \XF::$time - 60 * $editLimit))
			{
				$error = \XF::phraseDeferred('message_edit_time_limit_expired', ['minutes' => $editLimit]);
				return false;
			}

			if (!$content->Group || !$content->Group->allow_discussions)
			{
				$error = \XF::phraseDeferred('dbtech_social_groups_you_may_not_perform_this_action_because_group_does_not_allow_posting');
				return false;
			}

			return true;
		}

		return false;
	}

	/**
	 * @param Discussion $content
	 * @param Poll $poll
	 * @param $error
	 *
	 * @return bool
	 */
	public function canAlwaysEditDetails(Entity $content, Poll $poll, &$error = null)
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();
		return ($visitor->user_id
			&& $visitor->hasDbtechSocialGroupsGroupPermission($content->group_id, 'manageAnyDiscussion')
		);
	}

	/**
	 * @param Discussion $content
	 * @param Poll $poll
	 * @param $error
	 *
	 * @return bool
	 */
	public function canDelete(Entity $content, Poll $poll, &$error = null)
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();
		if (!$visitor->user_id)
		{
			return false;
		}

		if ($visitor->hasDbtechSocialGroupsGroupPermission($content->group_id, 'manageAnyDiscussion'))
		{
			return true;
		}

		if ($visitor->user_id != $content->user_id)
		{
			return false;
		}

		return ($poll->voter_count == 0);
	}

	public function canVote(Entity $content, Poll $poll, &$error = null)
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();
		if (!$visitor->user_id)
		{
			return false;
		}

		if (!$content->discussion_open)
		{
			$error = \XF::phraseDeferred('you_may_not_perform_this_action_because_discussion_is_closed');
			return false;
		}

		if (!$content->Group || !$content->Group->allow_posting)
		{
			$error = \XF::phraseDeferred(
				'dbtech_social_groups_you_may_not_perform_this_action_because_group_does_not_allow_posting'
			);
			return false;
		}

		return $visitor->hasDbtechSocialGroupsGroupPermission($content->group_id, 'votePoll');
	}

	/**
	 * @param $action
	 * @param Discussion $content
	 * @param array $extraParams
	 *
	 * @return string
	 */
	public function getPollLink($action, Entity $content, array $extraParams = [])
	{
		if ($action == 'content')
		{
			return \XF::app()->router('public')->buildLink('dbtech-social/discussions', $content, $extraParams);
		}
		else
		{
			return \XF::app()->router('public')->buildLink('dbtech-social/discussions/poll/' . $action, $content, $extraParams);
		}
	}

	/**
	 * @param Discussion $content
	 * @param Poll $poll
	 *
	 * @return void
	 * @throws PrintableException
	 */
	public function finalizeCreation(Entity $content, Poll $poll)
	{
		if ($content->discussion_type != 'poll')
		{
			$content->discussion_type = 'poll';
			$content->save();
		}
	}

	/**
	 * @param Discussion $content
	 * @param Poll $poll
	 *
	 * @return void
	 * @throws PrintableException
	 */
	public function finalizeDeletion(Entity $content, Poll $poll)
	{
		if ($content->discussion_type == 'poll')
		{
			$content->discussion_type = '';
			$content->save();
		}
	}

	/**
	 * @return string[]
	 */
	public function getEntityWith()
	{
		return ['Group', 'User'];
	}
}