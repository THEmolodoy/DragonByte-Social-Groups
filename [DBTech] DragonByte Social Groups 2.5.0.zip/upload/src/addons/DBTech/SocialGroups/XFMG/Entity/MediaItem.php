<?php

/** @noinspection PhpMissingParamTypeInspection,PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\XFMG\Entity;

/**
 * @extends \XFMG\Entity\MediaItem
 */
class MediaItem extends XFCP_MediaItem
{
	public function canView(&$error = null)
	{
		if ($this->album_id
			&& $this->Album
			&& !empty($this->Album->SocialGroupAlbum)
		)
		{
			// This media item belongs to a social group album
			//  so we should check the album's permissions too
			return $this->Album->canView($error);
		}

		return parent::canView($error);
	}
}