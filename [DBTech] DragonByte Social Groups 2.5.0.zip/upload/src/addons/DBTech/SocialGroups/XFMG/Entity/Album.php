<?php

/** @noinspection PhpMissingParamTypeInspection,PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\XFMG\Entity;

use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Entity\GroupAlbum;
use DBTech\SocialGroups\Entity\GroupMember;
use DBTech\SocialGroups\Repository\GroupRepository;
use DBTech\SocialGroups\XF\Entity\User as ExtendedUserEntity;
use XF\Mvc\Entity\Structure;
use XF\PrintableException;
use XFMG\Entity\MediaItem;

/**
 * @extends \XFMG\Entity\Album
 *
 * GETTERS
 * @property Group $DbtechSocialGroupsGroup
 *
 * RELATIONS
 * @property GroupAlbum $SocialGroupAlbum
 */
class Album extends XFCP_Album
{
	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canView(&$error = null)
	{
		$group = $this->getDbtechSocialGroupsGroupIfIntegrationActive();
		if ($group !== null)
		{
			return $group->canViewMedia();
		}

		return parent::canView($error);
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canEdit(&$error = null)
	{
		$group = $this->getDbtechSocialGroupsGroupIfIntegrationActive();
		if ($group !== null && $group->canEditAnyAlbum())
		{
			return true;
		}

		return parent::canEdit($error);
	}

	/**
	 * @param $type
	 * @param $error
	 *
	 * @return bool
	 * @noinspection PhpMissingParamTypeInspection
	 */
	public function canDelete($type = 'soft', &$error = null)
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		if (!$visitor->user_id)
		{
			return false;
		}

		$group = $this->getDbtechSocialGroupsGroupIfIntegrationActive();
		if ($group !== null)
		{
			// Integrated with a group

			if ($type === 'hard' && $this->hasPermission('hardDeleteAnyAlbum'))
			{
				// Staff has permission to hard delete any album
				return true;
			}

			if ($type === 'soft' && $this->hasPermission('deleteAnyAlbum'))
			{
				// Staff has permission to soft delete any album
				return true;
			}

			if ($this->user_id !== $visitor->user_id)
			{
				// Album owner is not current user
				return false;
			}
		}

		return parent::canDelete($type, $error);
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canMove(&$error = null)
	{
		$group = $this->getDbtechSocialGroupsGroupIfIntegrationActive(false);
		if ($group !== null)
		{
			return false;
		}

		return parent::canMove($error);
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canChangePrivacy(&$error = null)
	{
		$group = $this->getDbtechSocialGroupsGroupIfIntegrationActive(false);
		if ($group !== null)
		{
			// Privacy level is controlled by the group's privacy level
			return false;
		}

		return parent::canChangePrivacy($error);
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canAddMedia(&$error = null)
	{
		$group = $this->getDbtechSocialGroupsGroupIfIntegrationActive();
		if ($group !== null && $group->canAddMedia($error))
		{
			/** @var ExtendedUserEntity $visitor */
			$visitor = \XF::visitor();

			return ($visitor->user_id == $this->user_id
				&& ($this->canEmbedMedia($error) || $this->canUploadMedia($error))
			);
		}

		return parent::canAddMedia($error);
	}

	/**
	 * @param $error
	 *
	 * @return bool
	 */
	public function canUnlinkDbtechSocialGroup(&$error = null): bool
	{
		$group = $this->getDbtechSocialGroupsGroupIfIntegrationActive(false);
		if ($group === null)
		{
			return false;
		}

		if ($group->canUnlinkAnyAlbum())
		{
			return true;
		}

		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		return ($this->user_id === $visitor->user_id);
	}

	/**
	 * @return string
	 */
	public function getDbtechSocialGroupsViewPrivacyPhraseValue(): string
	{
		$group = $this->getDbtechSocialGroupsGroupIfIntegrationActive();
		if ($group !== null)
		{
			return !\XF::app()->repository(GroupRepository::class)
				->isLowerPrivacy($group->group_type, 'private')
					? 'dbtech_social_groups_group_members_only'
					: 'dbtech_social_groups_inherited_from_group';
		}

		return $this->view_privacy;
	}

	/**
	 * @param $includeSelf
	 *
	 * @return array|array[]
	 */
	public function getBreadcrumbs($includeSelf = true)
	{
		$group = $this->getDbtechSocialGroupsGroupIfIntegrationActive();

		return $group ? [] : parent::getBreadcrumbs($includeSelf);
	}

	/**
	 * @return GroupAlbum
	 */
	public function getNewDbtechSocialGroupAlbum(): GroupAlbum
	{
		$entity = \XF::app()->em()->create(GroupAlbum::class);
		$entity->album_id = $this->_getDeferredValue(function ()
		{
			return $this->album_id;
		}, 'save');

		$this->addCascadedSave($entity);

		return $entity;
	}

	/**
	 * @param bool $checkVisibility
	 *
	 * @return Group|null
	 */
	protected function getDbtechSocialGroupsGroupIfIntegrationActive(bool $checkVisibility = true): ?Group
	{
		if (!\XF::options()->dbtechSocialEnableMediaGallery
			|| ($checkVisibility && $this->album_state !== 'visible')
		)
		{
			return null;
		}

		return $this->DbtechSocialGroupsGroup;
	}

	/**
	 * @return Group|null
	 */
	public function getDbtechSocialGroupsGroup(): ?Group
	{
		if (!\XF::options()->dbtechSocialEnableMediaGallery)
		{
			return null;
		}

		return $this->SocialGroupAlbum->Group ?? null;
	}

	/**
	 * @param Group|null $group
	 */
	public function setDbtechSocialGroupsGroup(?Group $group = null)
	{
		$this->_getterCache['DbtechSocialGroupsGroup'] = $group;
	}

	/**
	 * @throws PrintableException
	 */
	protected function updateDbtechSocialGroupsMemberRecord()
	{
		$group = $this->getDbtechSocialGroupsGroupIfIntegrationActive(false);
		if ($group === null)
		{
			return;
		}

		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		if (!$visitor->isMemberOfSocialGroup($group, true))
		{
			return;
		}

		/** @var GroupMember $groupMembership */
		$groupMembership = $visitor->SocialGroupMemberships[$group->group_id];

		// check for member entering/leaving visible
		$visibilityChange = $this->isStateChanged('album_state', 'visible');
		if ($visibilityChange == 'enter')
		{
			$groupMembership->albumAdded($this);
			$groupMembership->save();
		}
		else if ($visibilityChange == 'leave')
		{
			$groupMembership->albumRemoved($this);
			$groupMembership->save();
		}
	}

	/**
	 * @param MediaItem $mediaItem
	 *
	 * @return void
	 * @throws PrintableException
	 */
	public function mediaItemAdded(MediaItem $mediaItem)
	{
		parent::mediaItemAdded($mediaItem);

		$group = $this->getDbtechSocialGroupsGroupIfIntegrationActive(false);
		if ($group === null)
		{
			return;
		}

		/** @var GroupMember $groupMembership */
		$groupMembership = $mediaItem->User->SocialGroupMemberships[$group->group_id];
		if ($groupMembership)
		{
			$groupMembership->mediaItemAdded($mediaItem);
			$groupMembership->save();
		}
	}

	/**
	 * @param MediaItem $mediaItem
	 *
	 * @return void
	 * @throws PrintableException
	 */
	public function mediaItemRemoved(MediaItem $mediaItem)
	{
		parent::mediaItemRemoved($mediaItem);

		$group = $this->getDbtechSocialGroupsGroupIfIntegrationActive(false);
		if ($group === null)
		{
			return;
		}

		/** @var GroupMember $groupMembership */
		$groupMembership = $mediaItem->User->SocialGroupMemberships[$group->group_id];
		if ($groupMembership)
		{
			$groupMembership->mediaItemRemoved($mediaItem);
			$groupMembership->save();
		}
	}

	protected function _preSave()
	{
		$savedViewPrivacy = null;

		if ($this->isUpdate()
			&& $this->isChanged('category_id')
			&& $this->isChanged('view_privacy')
		)
		{
			$savedViewPrivacy = $this->view_privacy;
		}

		parent::_preSave();

		if ($savedViewPrivacy !== null)
		{
			// Workaround XFMG bug where it will not check if view_privacy is already set
			$this->view_privacy = $savedViewPrivacy;
		}
	}

	/**
	 * @return void
	 * @throws PrintableException
	 */
	protected function _postSave()
	{
		parent::_postSave();

		$this->updateDbtechSocialGroupsMemberRecord();
	}

	/**
	 * @return void
	 * @throws PrintableException
	 */
	protected function _postDelete()
	{
		parent::_postDelete();

		$group = $this->getDbtechSocialGroupsGroupIfIntegrationActive();
		if ($group === null)
		{
			return;
		}

		/** @var ExtendedUserEntity $user */
		$user = $this->User;

		if ($user)
		{
			if (!$user->isMemberOfSocialGroup($group, true))
			{
				return;
			}

			/** @var GroupMember $groupMembership */
			$groupMembership = $user->SocialGroupMemberships[$group->group_id];

			$groupMembership->albumRemoved($this);
			$groupMembership->save();
		}

		if ($groupAlbum = $this->SocialGroupAlbum)
		{
			$groupAlbum->setOption('updateMembership', false);
			$groupAlbum->delete();
		}
	}

	/**
	 * @param Structure $structure
	 *
	 * @return Structure
	 */
	public static function getStructure(Structure $structure)
	{
		$structure = parent::getStructure($structure);

		$structure->relations['SocialGroupAlbum'] = [
			'entity'     => GroupAlbum::class,
			'type'       => self::TO_ONE,
			'conditions' => 'album_id',
		];

		$structure->defaultWith[] = 'SocialGroupAlbum';

		$structure->getters['DbtechSocialGroupsGroup'] = true;

		return $structure;
	}
}