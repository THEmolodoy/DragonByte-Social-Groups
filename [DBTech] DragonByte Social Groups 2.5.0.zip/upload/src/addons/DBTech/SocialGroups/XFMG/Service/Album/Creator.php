<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\XFMG\Service\Album;

use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Entity\Group as GroupEntity;
use DBTech\SocialGroups\Entity\GroupAlbum;

/**
 * @extends \XFMG\Service\Album\Creator
 */
class Creator extends XFCP_Creator
{
	protected ?GroupEntity $dbtechSocialGroup = null;

	/**
	 * @param Group $group
	 *
	 * @return void
	 */
	public function setDbtechSocialGroup(GroupEntity $group)
	{
		$this->dbtechSocialGroup = $group;

		$this->album->setDbtechSocialGroupsGroup($group);

		/** @var GroupAlbum $groupAlbum */
		$groupAlbum = $this->album->getNewDbtechSocialGroupAlbum();
		$groupAlbum->setOption('initialCreate', true);
		$groupAlbum->setOption('updateMembership', false);
		$groupAlbum->group_id = $group->group_id;

		$categoryId = \XF::options()->dbtechSocialMediaGalleryCategoryId;
		if ($categoryId)
		{
			$this->album->category_id = $categoryId;
		}
	}

	/**
	 * @return array
	 */
	protected function _validate()
	{
		$errors = parent::_validate();

		$group = $this->dbtechSocialGroup;
		if ($group && !$group->canCreateAlbum($error))
		{
			$errors[] = $error;
		}

		return $errors;
	}
}