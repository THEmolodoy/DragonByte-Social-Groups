<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\XFMG\Pub\Controller;

use DBTech\SocialGroups\ControllerPlugin\GroupPlugin;
use DBTech\SocialGroups\XFMG\Entity\Album as ExtendedAlbumEntity;
use DBTech\SocialGroups\XFMG\Service\Album\Creator as ExtendedAlbumCreatorService;
use XF\InputFilterer;
use XF\Mvc\ParameterBag;
use XF\Mvc\Reply\AbstractReply;
use XF\Mvc\Reply\Exception as ReplyException;
use XF\Mvc\Reply\View;
use XFMG\Entity\MediaItem;

/**
 * @extends \XFMG\Pub\Controller\Media
 */
class Media extends XFCP_Media
{
	protected bool $dbtechSocialDisableCanonicalRedirect = false;
	protected int $dbtechSocialGroupId = 0;


	/**
	 * @param string $linkUrl
	 *
	 * @return void
	 * @throws ReplyException
	 */
	public function assertCanonicalUrl($linkUrl)
	{
		if ($this->dbtechSocialDisableCanonicalRedirect)
		{
			return;
		}

		parent::assertCanonicalUrl($linkUrl);
	}

	/**
	 * @param string $linkUrl
	 *
	 * @return void
	 * @throws ReplyException
	 * @noinspection PhpMissingParamTypeInspection
	 */
	protected function assertCanonicalMediaUrl($linkUrl)
	{
		// Passthrough so we can call this independently
		parent::assertCanonicalUrl($linkUrl);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionView(ParameterBag $params)
	{
		if (!empty($params['group_id']))
		{
			// We're attempting to access this from a group context
			$this->dbtechSocialDisableCanonicalRedirect = true;
			$this->dbtechSocialGroupId = $params['group_id'];
		}

		$response = parent::actionView($params);
		if (!\XF::app()->options()->dbtechSocialEnableMediaGallery)
		{
			return $response;
		}

		if (!($response instanceof View))
		{
			return $response;
		}

		/** @var MediaItem $mediaItem */
		if (!$mediaItem = $response->getParam('mediaItem'))
		{
			return $response;
		}

		if ($this->filter('lightbox', InputFilterer::BOOLEAN))
		{
			return $response;
		}

		if (!$album = $mediaItem->Album)
		{
			return $response;
		}

		if (!$group = $album->DbtechSocialGroupsGroup)
		{
			return $response;
		}

		$page = $this->filterPage($params['page']);

		$this->assertCanonicalMediaUrl($this->buildLink(
			'dbtech-social/media',
			['group_id' => $group->group_id, 'title' => $group->title, 'media_id' => $mediaItem->media_id],
			['page' => $page]
		));

		$this->setSectionContext('dbtechSocial');

		$response->setParam('group', $group);
		$response->setTemplateName('dbtech_social_groups_group_media_media_view');

		return $response;
	}

	/**
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionAddOnInsert()
	{
		$response = parent::actionAddOnInsert();

		$groupId = $this->filter('dbtech_social_group_id', InputFilterer::UNSIGNED);
		if ($groupId && !$this->filter('category_id', InputFilterer::UNSIGNED))
		{
			$group = $this->plugin(GroupPlugin::class)->assertGroupExists($groupId);

			/** @var ExtendedAlbumEntity $container */
			$container = $response->getParam('container');
			$container->setDbtechSocialGroupsGroup($group);
		}

		return $response;
	}

	/**
	 * @return ExtendedAlbumCreatorService
	 * @throws ReplyException
	 */
	protected function setupAlbumCreate()
	{
		/** @var ExtendedAlbumCreatorService $creator */
		$creator = parent::setupAlbumCreate();

		$groupId = $this->filter('dbtech_social_group_id', InputFilterer::UNSIGNED);
		if ($groupId)
		{
			$group = $this->plugin(GroupPlugin::class)->assertGroupExists($groupId);
			$creator->setDbtechSocialGroup($group);
		}

		return $creator;
	}

	/**
	 * @param $mediaId
	 * @param array $extraWith
	 *
	 * @return MediaItem
	 * @throws ReplyException
	 */
	protected function assertViewableMediaItem($mediaId, array $extraWith = [])
	{
		$extraWith[] = 'Album.SocialGroupAlbum';

		$mediaItem = parent::assertViewableMediaItem($mediaId, $extraWith);

		if (!empty($this->dbtechSocialGroupId))
		{
			if (!$mediaItem->Album->SocialGroupAlbum
				|| $mediaItem->Album->SocialGroupAlbum->group_id !== $this->dbtechSocialGroupId
			)
			{
				// The media item was viewed using the wrong path
				throw $this->exception($this->redirectPermanently($this->buildLink('media', $mediaItem)));
			}
		}

		return $mediaItem;
	}
}