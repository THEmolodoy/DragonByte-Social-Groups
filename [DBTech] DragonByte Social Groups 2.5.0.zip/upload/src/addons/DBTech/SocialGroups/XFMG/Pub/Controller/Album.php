<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\XFMG\Pub\Controller;

use DBTech\SocialGroups\ControllerPlugin\GroupPlugin;
use DBTech\SocialGroups\Pub\View\Media\UnlinkView;
use XF\InputFilterer;
use XF\Mvc\ParameterBag;
use XF\Mvc\Reply\AbstractReply;
use XF\Mvc\Reply\Exception as ReplyException;
use XF\Mvc\Reply\View;
use XF\PrintableException;
use XFMG\ControllerPlugin\AlbumList;

/**
 * @extends \XFMG\Pub\Controller\Album
 */
class Album extends XFCP_Album
{
	protected bool $dbtechSocialDisableCanonicalRedirect = false;
	protected int $dbtechSocialGroupId = 0;


	/**
	 * @param string $linkUrl
	 *
	 * @return void
	 * @throws ReplyException
	 */
	public function assertCanonicalUrl($linkUrl)
	{
		if ($this->dbtechSocialDisableCanonicalRedirect)
		{
			return;
		}

		parent::assertCanonicalUrl($linkUrl);
	}

	/**
	 * @param string $linkUrl
	 *
	 * @return void
	 * @throws ReplyException
	 * @noinspection PhpMissingParamTypeInspection
	 */
	protected function assertCanonicalMediaUrl($linkUrl)
	{
		// Passthrough so we can call this independently
		parent::assertCanonicalUrl($linkUrl);
	}

	/**
	 * @param $albumId
	 * @param array $extraWith
	 *
	 * @return \XFMG\Entity\Album
	 * @throws ReplyException
	 */
	protected function assertViewableAlbum($albumId, array $extraWith = [])
	{
		$extraWith[] = 'SocialGroupAlbum';

		$album = parent::assertViewableAlbum($albumId, $extraWith);

		if (!empty($this->dbtechSocialGroupId))
		{
			if (!$album->SocialGroupAlbum
				|| $album->SocialGroupAlbum->group_id !== $this->dbtechSocialGroupId
			)
			{
				// The media item was viewed using the wrong path
				throw $this->exception($this->redirectPermanently($this->buildLink('media/albums', $album)));
			}
		}

		return $album;
	}

	public function actionIndex(ParameterBag $params)
	{
		$groupId = $this->filter('dbtech_social_group_id', InputFilterer::UNSIGNED);
		if ($groupId)
		{
			// This is coming from filters

			/** @var AlbumList $albumListPlugin */
			$albumListPlugin = $this->plugin(AlbumList::class);

			return $this->redirect(
				$this->buildLink(
					'dbtech-social/media',
					['group_id' => $groupId],
					$albumListPlugin->getFilterInput()
				),
			);
		}

		return parent::actionIndex($params);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionView(ParameterBag $params)
	{
		if (!empty($params['group_id']))
		{
			// We're attempting to access this from a group context
			$this->dbtechSocialDisableCanonicalRedirect = true;
			$this->dbtechSocialGroupId = $params['group_id'];
		}

		$response = parent::actionView($params);
		if (!\XF::app()->options()->dbtechSocialEnableMediaGallery)
		{
			return $response;
		}

		if (!($response instanceof View))
		{
			return $response;
		}

		/** @var \DBTech\SocialGroups\XFMG\Entity\Album $album */
		if (!$album = $response->getParam('album'))
		{
			return $response;
		}

		if (!$group = $album->DbtechSocialGroupsGroup)
		{
			return $response;
		}

		$page = $this->filterPage($params['page']);

		$this->assertCanonicalMediaUrl($this->buildLink(
			'dbtech-social/albums',
			['group_id' => $group->group_id, 'title' => $group->title, 'album_id' => $album->album_id],
			['page' => $page]
		));

		$this->setSectionContext('dbtechSocial');

		$response->setParam('group', $group);
		$response->setTemplateName('dbtech_social_groups_group_media_album_view');

		return $response;
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 */
	public function actionAdd(ParameterBag $params)
	{
		$response = parent::actionAdd($params);
		if (!\XF::app()->options()->dbtechSocialEnableMediaGallery)
		{
			return $response;
		}

		if (!($response instanceof View))
		{
			return $response;
		}

		/** @var \DBTech\SocialGroups\XFMG\Entity\Album $album */
		if (!$album = $response->getParam('album'))
		{
			return $response;
		}

		if (!$group = $album->DbtechSocialGroupsGroup)
		{
			return $response;
		}

		$this->setSectionContext('dbtechSocial');

		$response->setParam('group', $group);
		$response->setTemplateName('dbtech_social_groups_group_media_album_add');

		return $response;
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 */
	public function actionFilters(ParameterBag $params)
	{
		$response = parent::actionFilters($params);
		if (!\XF::app()->options()->dbtechSocialEnableMediaGallery)
		{
			return $response;
		}

		if (!$params['album_id'])
		{
			$groupId = $this->filter('dbtech_social_group_id', InputFilterer::UNSIGNED);
			if (!$groupId)
			{
				return $response;
			}

			if ($response instanceof View)
			{
				$response->setParam('dbtechSocialGroupId', $groupId);
			}
			else if ($this->filter('apply', InputFilterer::BOOLEAN))
			{
				/** @var AlbumList $albumListPlugin */
				$albumListPlugin = $this->plugin(AlbumList::class);

				$response = $this->redirect($this->buildLink(
					'dbtech-social/media',
					['group_id' => $groupId],
					$albumListPlugin->getFilterInput()
				));
			}
		}

		return $response;
	}

	/**
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionCreate()
	{
		$response = parent::actionCreate();
		if (!\XF::app()->options()->dbtechSocialEnableMediaGallery)
		{
			return $response;
		}

		$groupId = $this->filter('dbtech_social_group_id', InputFilterer::UNSIGNED);
		if (!$groupId)
		{
			return $response;
		}

		if ($response instanceof View)
		{
			$group = $this->plugin(GroupPlugin::class)->assertViewableGroup($groupId);
			if (!$group->canCreateAlbum($error))
			{
				return $this->noPermission($error);
			}

			/** @var \DBTech\SocialGroups\XFMG\Entity\Album $baseAlbum */
			$baseAlbum = $response->getParam('album');

			$baseAlbum->setDbtechSocialGroupsGroup($group);

			$response->setParam('album', $baseAlbum);
			$response->setParam('group', $group);
			$response->setTemplateName('dbtech_social_groups_group_media_album_create');
		}

		return $response;
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws PrintableException
	 * @throws ReplyException
	 */
	public function actionDbtechSocialUnlink(ParameterBag $params)
	{
		/** @var \DBTech\SocialGroups\XFMG\Entity\Album $album */
		$album = $this->assertViewableAlbum($params->album_id);
		if (!$album->canUnlinkDbtechSocialGroup($error))
		{
			return $this->noPermission($error);
		}

		$group = $album->DbtechSocialGroupsGroup;
		if (!$group)
		{
			return $this->notFound();
		}

		if ($this->isPost())
		{
			$album->SocialGroupAlbum->delete();

			return $this->redirect($this->buildLink('dbtech-social/media', $group));
		}

		$viewParams = [
			'album' => $album,
			'group' => $group,
		];
		return $this->view(
			UnlinkView::class,
			'dbtech_social_groups_group_media_unlink',
			$viewParams
		);
	}
}