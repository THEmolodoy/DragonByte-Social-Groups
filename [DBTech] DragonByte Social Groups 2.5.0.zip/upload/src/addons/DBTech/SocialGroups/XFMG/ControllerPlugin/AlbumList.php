<?php

/** @noinspection PhpMissingParamTypeInspection,PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\XFMG\ControllerPlugin;

use DBTech\SocialGroups\Entity\Group;
use XF\Entity\User;
use XFMG\Repository\Album;

/**
 * @extends \XFMG\ControllerPlugin\AlbumList
 */
class AlbumList extends XFCP_AlbumList
{
	public function getDbtechSocialGroupAlbumListData(Group $group, int $page = 1, ?User $user = null)
	{
		$albumRepo = \XF::app()->repository(Album::class);

		$allowOwnPending = is_callable([$this->controller, 'hasContentPendingApproval'])
			? $this->controller->hasContentPendingApproval()
			: true;

		if ($user)
		{
			$albumFinder = $albumRepo->findAlbumsForUser($user, null, [
				'allowOwnPending' => $allowOwnPending,
				'onlyInSocialGroup' => $group,
			]);
		}
		else
		{
			$albumFinder = $albumRepo->findAlbumsForIndex(null, [
				'allowOwnPending' => $allowOwnPending,
				'onlyInSocialGroup' => $group,
			]);
		}

		$filters = $this->getFilterInput();
		$this->applyFilters($albumFinder, $filters);

		$totalItems = $albumFinder->total();

		$page = $this->filterPage($page);
		$perPage = \XF::app()->options()->xfmgAlbumsPerPage;

		$albumFinder->limitByPage($page, $perPage);
		$albums = $albumFinder->fetch()->filterViewable();

		if (!empty($filters['owner_id']))
		{
			$ownerFilter = \XF::app()->em()->find(User::class, $filters['owner_id']);
		}
		else
		{
			$ownerFilter = null;
		}

		$canInlineMod = false;
		foreach ($albums AS $album)
		{
			if ($album->canUseInlineModeration())
			{
				$canInlineMod = true;
				break;
			}
		}

		return [
			'albums' => $albums,
			'filters' => $filters,
			'ownerFilter' => $ownerFilter,
			'canInlineMod' => $canInlineMod,

			'totalItems' => $totalItems,
			'page' => $page,
			'perPage' => $perPage,

			'group' => $group,

			'user' => $user,
		];
	}
}