<?php

/** @noinspection PhpMissingParamTypeInspection,PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\XFMG\ControllerPlugin;

use DBTech\SocialGroups\Entity\Group;
use XF\Entity\User;

/**
 * @extends \XFMG\ControllerPlugin\MediaList
 */
class MediaList extends XFCP_MediaList
{
	public function getDbtechSocialGroupMediaListData(Group $group, int $page = 1, ?User $user = null)
	{
		$mediaRepo = $this->getMediaRepo();

		$allowOwnPending = is_callable([$this->controller, 'hasContentPendingApproval'])
			? $this->controller->hasContentPendingApproval()
			: true;

		if ($user)
		{
			$mediaFinder = $mediaRepo->findMediaForUser($user, null, [
				'allowOwnPending' => $allowOwnPending,
				'onlyInSocialGroup' => $group,
			]);
		}
		else
		{
			$mediaFinder = $mediaRepo->findMediaForIndex(null, [
				'allowOwnPending' => $allowOwnPending,
				'onlyInSocialGroup' => $group,
			]);
		}

		$filters = $this->getFilterInput();
		$this->applyFilters($mediaFinder, $filters);
		$isDateLimited = (!$user && \XF::options()->xfmgMediaIndexLimit && empty($filters['no_date_limit']));

		if ($isDateLimited)
		{
			$mediaFinder->limitByDate(\XF::options()->xfmgMediaIndexLimit);
		}

		$totalItems = $mediaFinder->total();

		$page = $this->filterPage($page);
		$perPage = \XF::options()->xfmgMediaPerPage;

		if ($this->responseType() == 'rss')
		{
			$page = 1;
			$perPage *= 2;
			// we generally want a larger number of items and only those from page 1
		}

		$mediaFinder->limitByPage($page, $perPage);
		$mediaItems = $mediaFinder->fetchDeferred()->filterViewable();

		if (!empty($filters['owner_id']) && !$user)
		{
			$ownerFilter = \XF::em()->find(User::class, $filters['owner_id']);
		}
		else
		{
			$ownerFilter = null;
		}

		$canInlineMod = ($user && \XF::visitor()->user_id == $user->user_id);
		if (!$canInlineMod)
		{
			foreach ($mediaItems AS $mediaItem)
			{
				if ($mediaItem->canUseInlineModeration())
				{
					$canInlineMod = true;
					break;
				}
			}
		}

		$mediaEndOffset = ($page - 1) * $perPage + count($mediaItems);
		$showDateLimitDisabler = ($isDateLimited && $mediaEndOffset >= $totalItems);

		return [
			'mediaItems' => $mediaItems,
			'filters' => $filters,
			'ownerFilter' => $ownerFilter,
			'canInlineMod' => $canInlineMod,
			'showDateLimitDisabler' => $showDateLimitDisabler,

			'totalItems' => $totalItems,
			'page' => $page,
			'perPage' => $perPage,

			'user' => $user,

			'group' => $group,
		] + $this->getMediaListMessages();
	}
}