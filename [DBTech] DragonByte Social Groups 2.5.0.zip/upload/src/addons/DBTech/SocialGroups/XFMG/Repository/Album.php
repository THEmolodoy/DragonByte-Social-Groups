<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\XFMG\Repository;

use DBTech\SocialGroups\Entity\Group as GroupEntity;
use DBTech\SocialGroups\XF\Entity\User as ExtendedUserEntity;

/**
 * @extends \XFMG\Repository\Album
 */
class Album extends XFCP_Album
{
	/**
	 * @param array $limits
	 *
	 * @return \XFMG\Finder\Album
	 */
	public function findAlbumsForMixedList(array $limits = [])
	{
		$limits = array_replace([
			'onlyInSocialGroup' => null,
		], $limits);

		$finder = parent::findAlbumsForMixedList($limits);

		$finder->with([
			'SocialGroupAlbum',
			'SocialGroupAlbum.Group',
		]);

		$group = $limits['onlyInSocialGroup'];
		if ($group instanceof GroupEntity)
		{
			$finder->with('SocialGroupAlbum.Group.full');
			$finder->where('SocialGroupAlbum.group_id', $group->group_id);
		}
		else
		{
			/** @var ExtendedUserEntity $visitor */
			$visitor = \XF::visitor();

			if ($visitor->user_id)
			{
				$finder->with('SocialGroupAlbum.Group.Bans|' . $visitor->user_id);
			}

			$conditions = [];
			$conditions[] = ['SocialGroupAlbum.group_id', '=', null];
			$conditions[] = ['SocialGroupAlbum.group_id', '=', 0];
			$conditions[] = ['SocialGroupAlbum.Group.group_type', '=', 'public'];
			$conditions[] = ['SocialGroupAlbum.Group.group_type', '=', 'closed'];

			if ($visitor->user_id)
			{
				if ($visitor->dbtech_social_groups_group_ids)
				{
					$conditions[] = ['SocialGroupAlbum.group_id', '=', $visitor->dbtech_social_groups_group_ids];
				}

				$invitedGroupIds = $visitor->SocialGroupInvitations->keys();
				if ($invitedGroupIds)
				{
					$conditions[] = ['SocialGroupAlbum.group_id', '=', $invitedGroupIds];
				}
			}

			$finder->whereOr($conditions);
		}

		return $finder;
	}

	public function markAllAlbumCommentsReadByVisitor($categoryIds = null, $newRead = null)
	{
		$options = $this->options();
		if ($options->dbtechSocialEnableMediaGallery
			&& $options->dbtechSocialMediaGalleryCategoryId
		)
		{
			// We need to fetch items from the private category too, and exclude personal albums
			//  as they have already been marked as read
			$finder = $this->findAlbumsForIndex(
				$options->dbtechSocialMediaGalleryCategoryId,
				['includePersonalAlbums' => false]
			)
				->withUnreadCommentsOnly()
			;

			$albums = $finder->fetch();

			foreach ($albums AS $album)
			{
				$this->markAlbumCommentsReadByVisitor($album, $newRead);
			}
		}

		parent::markAllAlbumCommentsReadByVisitor($categoryIds, $newRead);
	}
}