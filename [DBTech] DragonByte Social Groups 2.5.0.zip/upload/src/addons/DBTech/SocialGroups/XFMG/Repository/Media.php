<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\XFMG\Repository;

use DBTech\SocialGroups\Entity\Group as GroupEntity;
use DBTech\SocialGroups\XF\Entity\User as ExtendedUserEntity;
use XFMG\Finder\MediaItem;

/**
 * @extends \XFMG\Repository\Media
 */
class Media extends XFCP_Media
{
	/**
	 * @param array $limits
	 *
	 * @return MediaItem
	 */
	public function findMediaForMixedList(array $limits = [])
	{
		$limits = array_replace([
			'onlyInSocialGroup' => null,
			'includeJoinedDbtechSocialGroups' => true,
			'includeInvitedDbtechSocialGroups' => true,
		], $limits);

		$finder = parent::findMediaForMixedList($limits);

		$options = $this->options();
		if ($options->dbtechSocialEnableMediaGallery)
		{
			$finder->with([
				'Album.SocialGroupAlbum',
				'Album.SocialGroupAlbum.Group',
			]);

			/** @var ExtendedUserEntity $visitor */
			$visitor = \XF::visitor();

			if ($visitor->user_id)
			{
				$finder->with('Album.SocialGroupAlbum.Group.Bans|' . $visitor->user_id);
			}

			$group = $limits['onlyInSocialGroup'];
			if ($group instanceof GroupEntity)
			{
				$finder->with('Album.SocialGroupAlbum.Group.full');
				$finder->where('Album.SocialGroupAlbum.group_id', $group->group_id);
			}
			else
			{
				$conditions = [];
				$conditions[] = ['Album.SocialGroupAlbum.group_id', '=', null];
				$conditions[] = ['Album.SocialGroupAlbum.group_id', '=', 0];
				$conditions[] = ['Album.SocialGroupAlbum.Group.group_type', '=', 'public'];
				$conditions[] = ['Album.SocialGroupAlbum.Group.group_type', '=', 'closed'];

				if ($visitor->user_id)
				{
					if ($limits['includeJoinedDbtechSocialGroups'] && $visitor->dbtech_social_groups_group_ids)
					{
						$conditions[] = ['Album.SocialGroupAlbum.group_id', '=', $visitor->dbtech_social_groups_group_ids];
					}

					if ($limits['includeInvitedDbtechSocialGroups'])
					{
						$invitedGroupIds = $visitor->SocialGroupInvitations->keys();
						if ($invitedGroupIds)
						{
							$conditions[] = ['Album.SocialGroupAlbum.group_id', '=', $invitedGroupIds];
						}
					}
				}

				$finder->whereOr($conditions);
			}
		}

		return $finder;
	}

	public function markMediaViewedByVisitor($categoryIds = null, $newViewed = null)
	{
		$options = $this->options();
		if (
			$options->dbtechSocialEnableMediaGallery
			&& $options->dbtechSocialMediaGalleryCategoryId
		)
		{
			// We need to fetch items from the private category too, and exclude personal albums
			//  as they have already been marked as read
			$finder = $this->findMediaForIndex(
				$options->dbtechSocialMediaGalleryCategoryId,
				['includePersonalAlbums' => false]
			)
				->unviewedOnly()
			;

			$mediaItems = $finder->fetch();

			foreach ($mediaItems AS $mediaItem)
			{
				$this->markMediaItemViewedByVisitor($mediaItem, $newViewed);
			}
		}

		parent::markMediaViewedByVisitor($categoryIds, $newViewed);
	}

	public function markAllMediaCommentsReadByVisitor($categoryIds = null, $newRead = null)
	{
		$options = $this->options();
		if (
			$options->dbtechSocialEnableMediaGallery
			&& $options->dbtechSocialMediaGalleryCategoryId
		)
		{
			// We need to fetch items from the private category too, and exclude personal albums
			//  as they have already been marked as read
			$finder = $this->findMediaForIndex(
				$options->dbtechSocialMediaGalleryCategoryId,
				['includePersonalAlbums' => false]
			)
				->withUnreadCommentsOnly()
			;

			$mediaItems = $finder->fetch();

			foreach ($mediaItems AS $mediaItem)
			{
				$this->markMediaCommentsReadByVisitor($mediaItem, $newRead);
			}
		}

		parent::markAllMediaCommentsReadByVisitor($categoryIds, $newRead);
	}
}