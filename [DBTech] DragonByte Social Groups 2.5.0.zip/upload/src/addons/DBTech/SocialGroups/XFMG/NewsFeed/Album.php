<?php

/** @noinspection PhpMissingParamTypeInspection,PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\XFMG\NewsFeed;

/**
 * @extends \XFMG\NewsFeed\Album
 */
class Album extends XFCP_Album
{
	public function getEntityWith()
	{
		$with = parent::getEntityWith();

		$visitor = \XF::visitor();

		$with[] = 'SocialGroupAlbum';
		$with[] = 'SocialGroupAlbum.Group';
		$with[] = 'SocialGroupAlbum.Group.Permissions|' . $visitor->permission_combination_id;

		return $with;
	}
}