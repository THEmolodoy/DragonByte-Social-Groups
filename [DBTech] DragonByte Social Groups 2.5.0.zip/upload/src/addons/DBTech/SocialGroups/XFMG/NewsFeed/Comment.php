<?php

/** @noinspection PhpMissingParamTypeInspection,PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\XFMG\NewsFeed;

/**
 * @extends \XFMG\NewsFeed\Comment
 */
class Comment extends XFCP_Comment
{
	public function getEntityWith()
	{
		$with = parent::getEntityWith();

		$visitor = \XF::visitor();

		$with[] = 'Album.SocialGroupAlbum';
		$with[] = 'Album.SocialGroupAlbum.Group';
		$with[] = 'Album.SocialGroupAlbum.Group.Permissions|' . $visitor->permission_combination_id;

		$with[] = 'Media.Album.SocialGroupAlbum';
		$with[] = 'Media.Album.SocialGroupAlbum.Group';
		$with[] = 'Media.Album.SocialGroupAlbum.Group.Permissions|' . $visitor->permission_combination_id;

		return $with;
	}
}