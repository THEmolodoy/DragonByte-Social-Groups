<?php

/** @noinspection PhpMissingParamTypeInspection,PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\XFMG\NewsFeed;

/**
 * @extends \XFMG\NewsFeed\MediaItem
 */
class MediaItem extends XFCP_MediaItem
{
	public function getEntityWith()
	{
		$with = parent::getEntityWith();

		$visitor = \XF::visitor();

		$with[] = 'Album.SocialGroupAlbum';
		$with[] = 'Album.SocialGroupAlbum.Group';
		$with[] = 'Album.SocialGroupAlbum.Group.Permissions|' . $visitor->permission_combination_id;

		return $with;
	}
}