<?php

namespace DBTech\SocialGroups\EmbedResolver;

use DBTech\SocialGroups\Entity\Message;
use XF\EmbedResolver\AbstractHandler;

/**
 * @extends AbstractHandler<Message>
 */
class MessageHandler extends AbstractHandler
{
	public function getEntityWith(): array
	{
		$visitor = \XF::visitor();

		return [
			'User',
			'Discussion',
			'Discussion.Group',
			'Discussion.Group.Permissions|' . $visitor->permission_combination_id,
		];
	}
}