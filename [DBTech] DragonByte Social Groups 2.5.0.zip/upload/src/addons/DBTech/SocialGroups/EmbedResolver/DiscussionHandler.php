<?php

namespace DBTech\SocialGroups\EmbedResolver;

use DBTech\SocialGroups\Entity\Discussion;
use XF\EmbedResolver\AbstractHandler;

/**
 * @extends AbstractHandler<Discussion>
 */
class DiscussionHandler extends AbstractHandler
{
	public function getEntityWith(): array
	{
		$visitor = \XF::visitor();

		return [
			'Group',
			'Group.Permissions|' . $visitor->permission_combination_id,
			'FirstMessage',
			'User',
		];
	}
}