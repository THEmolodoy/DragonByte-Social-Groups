<?php

namespace DBTech\SocialGroups\EmbedResolver;

use DBTech\SocialGroups\Entity\Group;
use XF\EmbedResolver\AbstractHandler;
use XF\Mvc\Entity\Entity;

/**
 * @extends AbstractHandler<Group>
 */
class GroupHandler extends AbstractHandler
{
	public function getTemplateData(Entity $content): array
	{
		return [
			'group' => $content,
		];
	}

	public function getEntityWith(): array
	{
		$visitor = \XF::visitor();

		return [
			'Permissions|' . $visitor->permission_combination_id,
			'User',
		];
	}
}