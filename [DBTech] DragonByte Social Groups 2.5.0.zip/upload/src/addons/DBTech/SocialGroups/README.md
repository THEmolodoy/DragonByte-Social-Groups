DragonByte Social Groups for XenForo 2.3.0+
===========================================

![Deploy](https://github.com/DragonByteTech/SocialGroups/workflows/Deploy/badge.svg) ![Lint](https://github.com/DragonByteTech/SocialGroups/workflows/Lint/badge.svg)  
  
Description
-----------

Create private or public social groups from within your forum.

Requirements
------------

- PHP 8.0.0+

Recommendations
---------------

- PHP 8.2.0+
- DragonByte WebP v1.0.0+
- Calendar v2.6.0+

Options
-------

#### DragonByte Tech: Social Groups

| Name | Description |
|---|---|
| Enable privacy downgrade | If enabled, social group creators can choose a lower privacy level when editing their groups. For instance, if the group was created as a "Closed" group, group owners would not be able to choose "Public" unless this setting is enabled.      Depending on your site, you may wish to leave this setting disabled to avoid leaking sensitive information. |
| Maximum social group permissions | These buttons let you configure the permissions granted to social group owners, and the maximum permissions that can be granted to social group supervisors.   Updating these permissions does not retroactively update existing owners' or supervisors' permissions. |
| Disabled post counters | If ticked, messages in any social group with that privacy level will not count towards the user's total post count, regardless of the per-group "Count messages" setting. |
| Enable Calendar integration | If you have [Calendar](https://nixfifty.com/products/calendar.10) installed, you can enable integration here. |
| Enable XenForo Media Gallery integration | If you have [XenForo Media Gallery](https://xenforo.com/solutions/#xfmg) installed, you can enable integration here. |
| Enabled features for social group owners | If you wish to disable certain features for social group owners, you can do so below. The fields will remain editable in the AdminCP. |
| Enable sections | If disabled, the "Sections" feature will be turned off for all social groups, and any content in existing sections will be rendered unavailable. |
| Forums excluded from "Related Threads" | Threads belonging to forums marked here cannot be added to the "Related Threads" feature for any social group. |
| Maximum number of Related Threads | "Related Threads" is a widget available for the "Group Overview" page which displays group owner / group supervisor configured forum threads that are related to the social group in question.   This setting controls the maximum number of threads that can be added to any given social group.   Enter 0 to disable this feature. |
| Groups per page | The number of groups that will be listed per page in the overview. |
| Allow group invites to bypass "Max joined groups" check | If checked, users can be invited to social groups even if their "Maximum joined groups" permission would not allow them to join.   Note: Invited users will not be able to join, simply receive the invite. |
| Default group list order | When viewing the social group list page, this will be the default order for groups. |
| Group ban action | When a member is banned from a social group, this setting controls what to do with their created/linked XFMG albums. |
| XenForo Media Gallery category | Albums created via Social Groups will be placed in this category. |
| Default soft-delete action | When a social group is "soft deleted", this setting controls what to do with any linked XFMG albums.   Staff members can override this decision when soft deleting a group, whereas a group owner will always have this action applied. |
| Group kick action | When a member is kicked from a social group, this setting controls what to do with their created/linked XFMG albums. |
| Group leave action | When a member leaves a social group, this setting controls what to do with their created/linked XFMG albums. |
| Default member list order | When viewing a group's member list, this will be the default order for members. |
| Terms of Service page | If a page is selected here, the contents of this page will be displayed in a scrollable area before creating / editing a social group. |
| "Group takeover" default recipient | This setting controls the default recipient for social groups when doing an automated transfer. Can be left empty to require specifying the recipient every time. |
| Enable automatic "Group takeover" discussion creation | After social group(s) have been transferred, either via user deletion or via the "Batch user update" feature in XenForo, a new discussion thread can be started in a specified forum asking users for any volunteers to take over ownership.      You can globally disable this feature with this setting. |
| "Group takeover" discussion forum | This is the forum the automated "group takeover" discussion thread will be created in. |
| "Group takeover" discussion prefix | This setting allows you to set a default prefix for "group takeover" discussion threads.      You need to ensure this prefix is valid for the forum you chose in the above setting, or discussion posting may fail. |
| "Group takeover" discussion starter | This setting controls who should start the "Group takeover" discussion after an automated transfer. Ideally this should be set to a "bot" user that no-one logs in to. |

#### Spam management

| Name | Description |
|---|---|
| Social Groups: Spam cleaner discussion action | This controls what happens to social group discussions started by spammers when the spam cleaner is applied against them. |

Permissions
-----------

#### DragonByte Social Groups permissions

- View
- View social group
- View discussions by others
- View discussion content
- View banned users
- React to messages
- Vote on discussions/messages (when applicable)
- Join social group
- Start new discussion
- Post replies
- Delete own message
- Edit own message
- Time limit on editing/deleting own messages (minutes)
- Edit own discussion (requires edit own message)
- Delete own discussion
- View attachments to messages
- Upload attachments to messages
- Upload video/audio to messages
- Tag own discussion
- Tag any discussion
- Manage tags by others in own discussion
- Tag own social group
- Tag any social group
- Vote on polls
- Create new social groups
- Create "Closed" social group
- Create "Private" social group
- Create "Hidden" social group
- Maximum created social groups
- Maximum joined social groups
- Add media items to social groups
- Maximum created albums per social group
- Maximum batch invited users
- Maximum sections per group
- Create social groups without approval

#### DragonByte Social Groups moderator permissions

- Use inline moderation on discussions / messages
- Stick / unstick discussion
- Lock / unlock discussion
- Manage (edit, etc.) any discussion
- Delete any discussion
- Hard-delete any discussion
- Ban users from replying to a discussion
- Edit any message
- Delete any message
- Hard-delete any message
- Give warnings on messages
- Manage any tags
- View moderator action logs
- View deleted discussions / messages
- View unapproved discussions / messages
- Undelete discussions / messages
- Approve / unapprove discussions / messages
- Approve / reject new members
- Invite users to the group
- Kick users from the group
- Ban users from the group
- Delete social group
- Hard-delete social group
- Upload a social group icon
- Upload a social group banner
- Manage any album
- Unlink any album
- Manage related threads
- Create nested sections

#### DragonByte Social Groups global moderator permissions

- View any social group's logs
- Edit any social group
- Delete any social group
- Feature / unfeature social groups
- Manage any social group's supervisors
- Hard-delete any social group
- View deleted social groups
- View unapproved social groups
- Approve / unapprove social groups
- Import threads
- Delete imported threads
- Hard-delete imported threads

Admin Permissions
-----------------

- Manage DragonByte Social Groups

BB Codes
--------

| Name | Tag | Description | Example |
|---|---|---|---|
| Social group embed | `GROUP` | BB code for displaying social groups. | \[GROUP=X\]Group BB Code\[/GROUP\] |

Style Properties
----------------

#### DragonByte Social Groups

| Property | Description |
|---|---|
| Social groups navigation style | This controls how the navigation is displayed in social groups. |
| Social group list style | This only affects the main group list page overview. |
| Enable Infinite Scroll | Toggles whether infinite scrolling is enabled for this style. |
| Require click to load | Controls whether loading the next page happens automatically, or upon pressing a button. |
| Only require click after X pages | If you want to require click only after a certain amount of pages have loaded, set this here.   0 = Always require click |
| Append to browser history | If selected, new pages loaded will also update the browser's history. |
| Group icon background color | The basic background of all group icons, graphical and generic |
| Group icon border radius | Controls the size of the rounded corners on group icons - a sufficiently large value will make icons circular |
| Dynamic group icon font | For letter-based group icons, this is the font employed for the text |
| Dynamic group icon text size (%) | Using a value between 0 and 100, this represents the approximate height of a dynamic group icon text character as a percentage of group icon. |
| Dynamic group icon base line height | Use this to help vertically center a dynamic group icon character when changing the font. This will be scaled based on the font size percentage. |
| Default group icon type | Controls whether the default group icon is text or image based. Unless disabled in the options, default group icons will be dynamically generated based on the group owner's user name. |
| Default group icon text | The character(s) specified here will be used as the text within the default group icon. Only applies if the "Text" type is selected above. |
| Default group icon image URL | The image URL specified here will be used as the image within the default group icon. Only applies if the "Image" type is selected above. |
| Unread section icon color | Section icons give an at-a-glance indication of whether or not the content housed within the section has been read. The unread icon color should stand out from its background for quick identification. |
| Read section icon color | When the content within a section has been read, its icon will revert to a less attention-grabbing color, defined here. |
| Sub-sections display style | Choose the style in which sub-sections will be displayed within a particular group, according to the amount of space you want them to occupy. |
| Sub-sections display style | Choose the style in which sub-sections will be displayed within a particular group, according to the amount of space you want them to occupy. |

Advertising Positions
---------------------

| Position | Description | Arguments |
|---|---|---|
| DragonByte Social Groups - Discussion view: Above message list (`dbtech_social_discussion_view_above_messages`) | Advertising position above the list of messages when viewing a discussion. | - discussion (Required) |
| DragonByte Social Groups - Discussion view: Below message list (`dbtech_social_discussion_view_below_messages`) | Advertising position below the list of messages when viewing a discussion. | - discussion (Required) |
| DragonByte Social Groups - Group list: Below stickies (`dbtech_social_groups_group_list_below_stickies`) | Position visible below the list of sticky groups while viewing the list of social groups. This only appears if there are sticky groups, and if you're using the List view. |  |
| DragonByte Social Groups - Group view: Above discussion list (`dbtech_social_groups_group_view_above_disc_list`) | Available above the list of discussions while viewing a social group. | - group (Required) |
| DragonByte Social Groups - Group view: Below discussion list (`dbtech_social_groups_group_view_below_disc_list`) | Available below the list of discussions while viewing a social group. | - group (Required) |
| DragonByte Social Groups - Group view: Below stickies (`dbtech_social_groups_group_view_below_stickies`) | Position visible below the list of sticky discussions while viewing a social group. This only appears if there are sticky discussions. | - group (Required) |
| DragonByte Social Groups - Message: Above message content (`dbtech_social_message_above_content`) | Advertising position above the message content in every discussion message. | - message (Required) |
| DragonByte Social Groups - Message: Below message container (`dbtech_social_message_below_container`) | Advertising position below the message container in every discussion message. | - message (Required) |
| DragonByte Social Groups - Message: Below message content (`dbtech_social_message_below_content`) | Advertising position below the message content in every discussion message. | - message (Required) |

Widget Positions
----------------

| Position | Description |
|---|---|
| DragonByte Social Groups - Discussion view: Above messages (`dbtech_social_discussion_view_above_messages`) | A position in the main content area of the discussion view, above the messages. Widget templates rendered in this position can use the current discussion entity in the `{$context.discussion}` param. |
| DragonByte Social Groups - Discussion view: Below messages (`dbtech_social_discussion_view_below_messages`) | A position in the main content area of the discussion view, below the messages. Widget templates rendered in this position can use the current discussion entity in the `{$context.discussion}` param. |
| DragonByte Social Groups - Discussion view: Below quick reply (`dbtech_social_discussion_view_below_quick_reply`) | A position in the main content area of the discussion view, below the quick reply. Widget templates rendered in this position can use the current discussion entity in the `{$context.discussion}` param. |
| DragonByte Social Groups - Discussion view: Sidebar (`dbtech_social_discussion_view_sidebar`) | Position in the sidebar while viewing a discussion. Widget templates rendered in this position can use the current discussion entity in the `{$context.discussion}` param. |
| DragonByte Social Groups - Group list: Above groups (`dbtech_social_group_list_above_groups`) | A position inside the main content area of the group list above the list. |
| DragonByte Social Groups - Group list: Below groups (`dbtech_social_group_list_below_groups`) | A position inside the main content area of the group list below the list. |
| DragonByte Social Groups - Group list: Sidebar (`dbtech_social_group_list_sidebar`) | Position inside the group list sidebar for various stats and new content widgets. |
| DragonByte Social Groups - Group list: Sidenav (`dbtech_social_group_list_sidenav`) | Position inside the group list sidenav for various stats and new content widgets. |
| DragonByte Social Groups - Group overview (`dbtech_social_group_overview`) | Position on the group overview page. Widget templates rendered in this position can use the current social group entity in the `{$context.group}` param. |
| DragonByte Social Groups - Group view: Sidebar (`dbtech_social_group_view_sidebar`) | Position in the sidebar while viewing a list of discussions in a social group. Widget templates rendered in this position can use the current social group entity in the `{$context.group}` param. |
| DragonByte Social Groups - Group view: Sidenav (`dbtech_social_group_view_sidenav`) | Position in the sidenav, if displayed, while viewing pages inside a social group. Widget templates rendered in this position can use the current social group entity in the `{$context.group}` param. |

Widget Definitions
------------------

| Definition | Description |
|---|---|
| DragonByte Social Groups: Featured Groups (`dbt_soc_featured_groups`) | Displays featured social groups. |
| DragonByte Social Groups: Social group statistics (`dbt_soc_group_statistics`) | Displays a block which shows the social groups' current statistics on things like total discussions, messages and members. |
| DragonByte Social Groups: Joined Groups (`dbt_soc_joined_groups`) | Displays social groups the current user has joined. |
| DragonByte Social Groups: Group creation limits (`dbt_soc_limits`) | Displays a block showing the group creation limits placed on the current user. |
| DragonByte Social Groups: New Groups (`dbt_soc_new_groups`) | Displays the most recently created social groups. |
| DragonByte Social Groups: Group media (`dbt_soc_new_media`) | Displays a slider showing the most recent or a random selection of media items for any given social group. This widget will only work in "group overview" positions. |
| DragonByte Social Groups: Newest members (`dbt_soc_new_members`) | Displays a block containing a list of X newest members of a given social group. This widget will only work in "group overview" positions. |
| DragonByte Social Groups: New Messages (`dbt_soc_new_messages`) | Displays a block containing a list of X discussions which have most recently been posted in. |
| DragonByte Social Groups: Owned Groups (`dbt_soc_owned_groups`) | Displays social groups the current user owns. |
| DragonByte Social Groups: Random Groups (`dbt_soc_random_groups`) | Displays random social groups. |
| DragonByte Social Groups: Group related threads (`dbt_soc_related_threads`) | Displays a block containing a list of any defined related threads for a given social group. This widget will only work in "group overview" positions. |
| DragonByte Social Groups: Group supervisors (`dbt_soc_supervisors`) | Displays a block containing a list of the moderators and/or supervisors of a given social group. This widget will only work in "group overview" positions. |
| DragonByte Social Groups: Tag Cloud (`dbt_soc_tag_cloud`) | Displays a tag cloud for the most used social group tags. |

Cron Entries
------------

| Name | Run on... | Run at hours | Run at minutes |
|---|---|---|---|
| DragonByte Social Groups: Daily clean up | Any day of the month | 3AM | 0 |
| DragonByte Social Groups: Hourly clean up | Any day of the month | Any | 10 |
| DragonByte Social Groups: Delete expired bans | Any day of the month | Any | 45 |
| DragonByte Social Groups: Update view counters | Any day of the month | Any | 30 |

CLI Commands
------------

| Command | Description |
|---|---|
| `tck-seeder:seed-social-group-message` | Seeds social group messages |
| `tck-seeder:seed-social-group-member` | Seeds social group members |
| `tck-seeder:seed-social-group-ban` | Seeds social group bans |
| `tck-seeder:seed-social-group-supervisor` | Seeds social group supervisors |
| `tck-seeder:seed-social-group-discussion` | Seeds social group discussions |
| `tck-seeder:seed-social-group-group` | Seeds social groups |
| `tck-seeder:seed-social-group-message-reaction` | Seeds social group message reactions |