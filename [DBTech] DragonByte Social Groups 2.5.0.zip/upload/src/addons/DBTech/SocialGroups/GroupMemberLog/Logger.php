<?php

namespace DBTech\SocialGroups\GroupMemberLog;

use DBTech\SocialGroups\Entity\GroupMember as GroupMemberEntity;
use DBTech\SocialGroups\Entity\GroupMemberLog;
use XF\Entity\User;
use XF\PrintableException;
use XF\Util\Ip;

class Logger
{
	/**
	 * @param GroupMemberEntity $content
	 * @param string $action
	 * @param array $params
	 * @param bool $throw
	 * @param User|null $actor
	 * @param bool|string $ip
	 *
	 * @return GroupMemberLog|null
	 * @throws PrintableException
	 */
	public function log(
		GroupMemberEntity $content,
		string            $action,
		array             $params = [],
		bool              $throw = true,
		?User             $actor = null,
		bool|string       $ip = false
	): ?GroupMemberLog
	{
		if ($this->isLoggableUser($content, $action, $actor) === null)
		{
			return null;
		}

		$log = \XF::app()->em()->create(GroupMemberLog::class);
		$log->group_id = $content->group_id;
		$log->log_date = \XF::$time;
		if ($this->isLoggableUser($content, $action, $actor))
		{
			$log->actor_id = $actor->user_id;
		}
		$log->ip_address = $ip !== false ? Ip::stringToBinary($ip) : '';
		if ($this->isLoggableUser($content, $action, $content->User))
		{
			$log->username = $content->User->username;
		}
		$log->user_id = $content->user_id;
		$log->group_member_id = $content->group_member_id ?? 0;
		$log->action = $action;
		$log->action_params = $params;
		$log->save($throw);

		return $log;
	}

	/**
	 * @param $content
	 * @param $action
	 * @param User|null $actor
	 *
	 * @return bool|int|null
	 */
	public function isLoggableUser($content, $action, ?User $actor = null): bool|int|null
	{
		if ($actor === null)
		{
			return false;
		}

		return $actor->user_id;
	}
}