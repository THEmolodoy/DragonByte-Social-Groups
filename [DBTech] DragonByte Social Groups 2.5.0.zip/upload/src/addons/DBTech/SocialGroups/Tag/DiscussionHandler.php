<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\Tag;

use DBTech\SocialGroups\Entity\Discussion;
use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Entity\Section;
use XF\Mvc\Entity\Entity;
use XF\Tag\AbstractHandler;

/**
 * @extends AbstractHandler<Discussion>
 */
class DiscussionHandler extends AbstractHandler
{
	/**
	 * @param Entity $entity
	 *
	 * @return array
	 */
	public function getPermissionsFromContext(Entity $entity)
	{
		if ($entity instanceof Discussion)
		{
			$discussion = $entity;
			$section = $entity->Section;
			$group = $discussion->Group;
		}
		else if ($entity instanceof Section)
		{
			$discussion = null;
			$section = $entity;
			$group = $entity->Group;
		}
		else if ($entity instanceof Group)
		{
			$discussion = null;
			$section = null;
			$group = $entity;
		}
		else
		{
			throw new \InvalidArgumentException("Entity must be a discussion or group");
		}

		$visitor = \XF::visitor();

		if ($discussion)
		{
			if ($discussion->user_id == $visitor->user_id
				&& $visitor->hasDbtechSocialGroupsGroupPermission(
					$discussion->group_id,
					'manageOthersTagsOwnDisc'
				)
			)
			{
				$removeOthers = true;
			}
			else
			{
				$removeOthers = $visitor->hasDbtechSocialGroupsGroupPermission(
					$discussion->group_id,
					'manageAnyTag'
				);
			}

			$edit = $discussion->canEditTags();
		}
		else
		{
			$removeOthers = false;
			$edit = $group->canEditTags();
		}

		$minTags = 0;
		if (\XF::app()->options()->dbtechSocialEnabledGroupOwnerFeatures['min_tags'] ?? false)
		{
			$minTags = $section ? $section->min_tags : $group->min_tags;
		}

		return [
			'edit' => $edit,
			'removeOthers' => $removeOthers,
			'minTotal' => $minTags,
		];
	}

	/**
	 * @param Discussion $entity
	 *
	 * @return bool
	 */
	public function getContentVisibility(Entity $entity)
	{
		return $entity->discussion_state == 'visible';
	}

	/**
	 * @param Discussion $entity
	 * @param array $options
	 *
	 * @return array
	 */
	public function getTemplateData(Entity $entity, array $options = [])
	{
		return [
			'discussion' => $entity,
			'options' => $options,
		];
	}

	/**
	 * @param bool $forView
	 *
	 * @return string[]
	 */
	public function getEntityWith($forView = false)
	{
		$get = ['Group'];
		if ($forView)
		{
			$get[] = 'User';
			$get[] = 'FirstMessage';

			$visitor = \XF::visitor();
			$get[] = 'Group.Permissions|' . $visitor->permission_combination_id;
		}

		return $get;
	}

	/**
	 * @param Discussion $entity
	 * @param $error
	 *
	 * @return bool
	 */
	public function canUseInlineModeration(Entity $entity, &$error = null)
	{
		return $entity->canUseInlineModeration($error);
	}
}