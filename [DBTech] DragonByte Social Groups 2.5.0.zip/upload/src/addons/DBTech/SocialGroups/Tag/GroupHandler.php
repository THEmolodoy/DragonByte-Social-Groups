<?php

namespace DBTech\SocialGroups\Tag;

use DBTech\SocialGroups\Entity\Group;
use XF\Mvc\Entity\Entity;
use XF\Tag\AbstractHandler;

/**
 * @extends AbstractHandler<Group>
 */
class GroupHandler extends AbstractHandler
{
	/**
	 * @param Entity $entity
	 *
	 * @return array
	 */
	public function getPermissionsFromContext(Entity $entity): array
	{
		if ($entity instanceof Group)
		{
			$group = $entity;
		}
		else
		{
			throw new \InvalidArgumentException('Entity must be a social group');
		}

		if ($group->isGroupOwner() || !$group->exists())
		{
			$removeOthers = true;
		}
		else
		{
			$removeOthers = $group->hasPermission('manageAnyTag');
		}

		$edit = $group->canEditGroupTags();
		$minTags = (\XF::app()->options()->dbtechSocialEnabledGroupOwnerFeatures['min_tags'] ?? false)
			? $group->min_tags
			: 0;

		return [
			'edit' => $edit,
			'removeOthers' => $removeOthers,
			'minTotal' => $group->min_tags,
		];
	}

	/**
	 * @param Group $entity
	 *
	 * @return bool
	 */
	public function getContentVisibility(Entity $entity): bool
	{
		return $entity->canView();
	}

	/**
	 * @param Group $entity
	 * @param array $options
	 *
	 * @return array
	 */
	public function getTemplateData(Entity $entity, array $options = []): array
	{
		return [
			'group' => $entity,
			'options' => $options,
		];
	}

	/**
	 * @param bool $forView
	 *
	 * @return array
	 */
	public function getEntityWith($forView = false): array
	{
		$get = [];
		if ($forView)
		{
			$get[] = 'User';

			$visitor = \XF::visitor();
			$get[] = 'Permissions|' . $visitor->permission_combination_id;
		}

		return $get;
	}
}