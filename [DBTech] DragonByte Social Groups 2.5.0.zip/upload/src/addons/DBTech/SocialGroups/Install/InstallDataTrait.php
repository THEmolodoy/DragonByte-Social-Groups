<?php

namespace DBTech\SocialGroups\Install;

use XF\AddOn\AddOn;
use XF\App;
use XF\Db\AbstractAdapter;
use XF\Db\Schema\Alter;
use XF\Db\Schema\Column;
use XF\Db\Schema\Create;
use XF\Db\SchemaManager;
use XF\Repository\CountersRepository;

/**
 * @property AddOn addOn
 * @property App app
 *
 * @method AbstractAdapter db()
 * @method SchemaManager schemaManager()
 * @method Column addOrChangeColumn($table, $name, $type = null, $length = null)
 */
trait InstallDataTrait
{
	/**
	 * @return \Closure[]
	 */
	protected function getTables(): array
	{
		$tables = [];

		$tables['xf_dbtech_social_groups_container'] = function (Create|Alter $table)
		{
			$this->addOrChangeColumn($table, 'node_id', 'int');
			$table->addPrimaryKey('node_id');
		};

		$tables['xf_dbtech_social_groups_discussion'] = function (Create|Alter $table)
		{
			$this->addOrChangeColumn($table, 'discussion_id', 'int')->autoIncrement();
			$this->addOrChangeColumn($table, 'group_id', 'int');
			$this->addOrChangeColumn($table, 'section_id', 'int');
			$this->addOrChangeColumn($table, 'title', 'varchar', 150);
			$this->addOrChangeColumn($table, 'reply_count', 'int')->setDefault(0);
			$this->addOrChangeColumn($table, 'view_count', 'int')->setDefault(0);
			$this->addOrChangeColumn($table, 'user_id', 'int');
			$this->addOrChangeColumn($table, 'username', 'varchar', 50);
			$this->addOrChangeColumn($table, 'message_date', 'int');
			$this->addOrChangeColumn($table, 'sticky', 'tinyint', 3)->setDefault(0);
			$this->addOrChangeColumn($table, 'discussion_state', 'enum')->values(['visible','moderated','deleted'])->setDefault('visible');
			$this->addOrChangeColumn($table, 'discussion_open', 'tinyint', 3)->setDefault(1);
			$this->addOrChangeColumn($table, 'discussion_type', 'varchar', 25)->setDefault('');
			$this->addOrChangeColumn($table, 'first_message_id', 'int');
			$this->addOrChangeColumn($table, 'first_message_reaction_score', 'int')->unsigned(false)->setDefault(0);
			$this->addOrChangeColumn($table, 'first_message_reactions', 'blob')->nullable();
			$this->addOrChangeColumn($table, 'last_message_date', 'int');
			$this->addOrChangeColumn($table, 'last_message_id', 'int');
			$this->addOrChangeColumn($table, 'last_message_user_id', 'int');
			$this->addOrChangeColumn($table, 'last_message_username', 'varchar', 50);
			$this->addOrChangeColumn($table, 'tags', 'mediumblob');
			$table->addKey(['group_id', 'last_message_date']);
			$table->addKey(['group_id', 'sticky', 'discussion_state', 'last_message_date'], 'group_id_sticky_state_last_message');
			$table->addKey('last_message_date');
			$table->addKey('message_date');
			$table->addKey('user_id');
		};

		$tables['xf_dbtech_social_groups_discussion_read'] = function (Create|Alter $table)
		{
			$this->addOrChangeColumn($table, 'discussion_read_id', 'int')->autoIncrement();
			$this->addOrChangeColumn($table, 'user_id', 'int');
			$this->addOrChangeColumn($table, 'discussion_id', 'int');
			$this->addOrChangeColumn($table, 'discussion_read_date', 'int');
			$table->addUniqueKey(['user_id', 'discussion_id']);
			$table->addKey('discussion_id');
			$table->addKey('discussion_read_date');
		};

		$tables['xf_dbtech_social_groups_discussion_reply_ban'] = function (Create|Alter $table)
		{
			$this->addOrChangeColumn($table, 'discussion_reply_ban_id', 'int')->autoIncrement();
			$this->addOrChangeColumn($table, 'discussion_id', 'int');
			$this->addOrChangeColumn($table, 'user_id', 'int');
			$this->addOrChangeColumn($table, 'ban_date', 'int');
			$this->addOrChangeColumn($table, 'expiry_date', 'int')->nullable();
			$this->addOrChangeColumn($table, 'reason', 'varchar', 100)->setDefault('');
			$this->addOrChangeColumn($table, 'ban_user_id', 'int');
			$table->addUniqueKey(['discussion_id', 'user_id'], 'discussion_id');
			$table->addKey('expiry_date');
			$table->addKey('user_id');
		};

		$tables['xf_dbtech_social_groups_discussion_user_message'] = function (Create|Alter $table)
		{
			$this->addOrChangeColumn($table, 'discussion_id', 'int');
			$this->addOrChangeColumn($table, 'user_id', 'int');
			$this->addOrChangeColumn($table, 'message_count', 'int');
			$table->addPrimaryKey(['discussion_id', 'user_id']);
			$table->addKey('user_id');
		};

		$tables['xf_dbtech_social_groups_discussion_view'] = function (Create|Alter $table)
		{
			$this->addOrChangeColumn($table, 'discussion_id', 'int');
			$this->addOrChangeColumn($table, 'total', 'int');
			$table->addPrimaryKey('discussion_id');
		};

		$tables['xf_dbtech_social_groups_discussion_watch'] = function (Create|Alter $table)
		{
			$this->addOrChangeColumn($table, 'user_id', 'int');
			$this->addOrChangeColumn($table, 'discussion_id', 'int');
			$this->addOrChangeColumn($table, 'email_subscribe', 'tinyint', 3)->setDefault(0);
			$table->addPrimaryKey(['user_id', 'discussion_id']);
			$table->addKey(['discussion_id', 'email_subscribe']);
		};

		$tables['xf_dbtech_social_groups_group'] = function (Create|Alter $table)
		{
			$this->addOrChangeColumn($table, 'group_id', 'int')->autoIncrement();
			$this->addOrChangeColumn($table, 'title', 'varchar', 50);
			$this->addOrChangeColumn($table, 'tagline', 'varchar', 250);
			$this->addOrChangeColumn($table, 'description', 'text');
			$this->addOrChangeColumn($table, 'group_type', 'enum')->values(['public','closed','private','hidden'])->setDefault('public');
			$this->addOrChangeColumn($table, 'group_state', 'enum')->values(['visible','moderated','deleted'])->setDefault('visible');
			$this->addOrChangeColumn($table, 'sticky', 'tinyint')->setDefault(0);
			$this->addOrChangeColumn($table, 'featured', 'tinyint')->setDefault(0);
			$this->addOrChangeColumn($table, 'member_count', 'int');
			$this->addOrChangeColumn($table, 'section_count', 'int');
			$this->addOrChangeColumn($table, 'discussion_count', 'int')->setDefault(0);
			$this->addOrChangeColumn($table, 'message_count', 'int')->setDefault(0);
			$this->addOrChangeColumn($table, 'view_count', 'int')->setDefault(0);
			$this->addOrChangeColumn($table, 'user_id', 'int');
			$this->addOrChangeColumn($table, 'username', 'varchar', 50);
			$this->addOrChangeColumn($table, 'creation_date', 'int')->setDefault(0)->comment('Date of group creation');
			$this->addOrChangeColumn($table, 'last_update_date', 'int')->setDefault(0)->comment('Date of most recent content addition');
			$this->addOrChangeColumn($table, 'last_message_id', 'int')->setDefault(0)->comment('Most recent message_id');
			$this->addOrChangeColumn($table, 'last_message_date', 'int')->setDefault(0)->comment('Date of most recent message');
			$this->addOrChangeColumn($table, 'last_message_user_id', 'int')->setDefault(0)->comment('User_id of user posting most recently');
			$this->addOrChangeColumn($table, 'last_message_username', 'varchar', 50)->setDefault('')->comment('Username of most recently-posting user');
			$this->addOrChangeColumn($table, 'last_discussion_id', 'int')->setDefault(0)->comment('Most recent discussion_id');
			$this->addOrChangeColumn($table, 'last_discussion_title', 'varchar', 150)->setDefault('')->comment('Title of discussion most recent message is in');
			$this->addOrChangeColumn($table, 'icon_date', 'int')->setDefault(0);
			$this->addOrChangeColumn($table, 'icon_hash', 'char', 32);
			$this->addOrChangeColumn($table, 'icon_width', 'smallint', 5)->setDefault(0);
			$this->addOrChangeColumn($table, 'icon_height', 'smallint', 5)->setDefault(0);
			$this->addOrChangeColumn($table, 'icon_highdpi', 'tinyint', 3)->setDefault(0);
			$this->addOrChangeColumn($table, 'icon_crop_x', 'int')->setDefault(0)->comment('X-Position from which to start the square crop on the m icon');
			$this->addOrChangeColumn($table, 'icon_crop_y', 'int')->setDefault(0)->comment('Y-Position from which to start the square crop on the m icon');
			$this->addOrChangeColumn($table, 'banner_date', 'int')->setDefault(0);
			$this->addOrChangeColumn($table, 'banner_hash', 'char', 32);
			$this->addOrChangeColumn($table, 'banner_position_y', 'tinyint')->nullable();
			$this->addOrChangeColumn($table, 'language_code', 'varchar', 25)->setDefault('');
			$this->addOrChangeColumn($table, 'text_direction', 'enum')->values(['LTR','RTL'])->setDefault('LTR');
			$this->addOrChangeColumn($table, 'allow_members', 'tinyint', 3)->setDefault(1);
			$this->addOrChangeColumn($table, 'moderate_members', 'tinyint', 3)->setDefault(0);
			$this->addOrChangeColumn($table, 'moderate_discussions', 'tinyint', 3)->setDefault(0);
			$this->addOrChangeColumn($table, 'moderate_replies', 'tinyint', 3)->setDefault(0);
			$this->addOrChangeColumn($table, 'allow_posting', 'tinyint', 3)->setDefault(1);
			$this->addOrChangeColumn($table, 'allow_discussions', 'tinyint', 3)->setDefault(1);
			$this->addOrChangeColumn($table, 'allow_poll', 'tinyint', 3)->setDefault(1);
			$this->addOrChangeColumn($table, 'count_messages', 'tinyint', 3)->setDefault(1);
			$this->addOrChangeColumn($table, 'find_new', 'tinyint', 3)->setDefault(1)->comment('Include messages from this group when running /find-new/dbtech-social-discussions');
			$this->addOrChangeColumn($table, 'enable_calendar', 'tinyint', 3)->setDefault(0);
			$this->addOrChangeColumn($table, 'calendar_id', 'int')->setDefault(0);
			$this->addOrChangeColumn($table, 'event_creation', 'enum')->values(['group_owner','group_staff','members'])->setDefault('group_owner');
			$this->addOrChangeColumn($table, 'allowed_watch_notifications', 'varchar', 10)->setDefault('all');
			$this->addOrChangeColumn($table, 'default_sort_order', 'varchar', 25)->setDefault('last_message_date');
			$this->addOrChangeColumn($table, 'default_sort_direction', 'varchar', 5)->setDefault('desc');
			$this->addOrChangeColumn($table, 'list_date_limit_days', 'smallint', 5)->setDefault(0);
			$this->addOrChangeColumn($table, 'tags', 'mediumblob');
			$this->addOrChangeColumn($table, 'min_tags', 'smallint', 5)->setDefault(0);
			$this->addOrChangeColumn($table, 'rules', 'mediumtext');
			$table->addKey('user_id');
		};

		$tables['xf_dbtech_social_groups_group_album'] = function (Create|Alter $table)
		{
			$this->addOrChangeColumn($table, 'group_id', 'int');
			$this->addOrChangeColumn($table, 'album_id', 'int');
			$this->addOrChangeColumn($table, 'existing_category_id', 'int');
			$table->addPrimaryKey(['group_id', 'album_id']);
		};

		$tables['xf_dbtech_social_groups_group_ban'] = function (Create|Alter $table)
		{
			$this->addOrChangeColumn($table, 'user_id', 'int');
			$this->addOrChangeColumn($table, 'group_id', 'int');
			$this->addOrChangeColumn($table, 'ban_user_id', 'int');
			$this->addOrChangeColumn($table, 'ban_date', 'int')->setDefault(0);
			$this->addOrChangeColumn($table, 'end_date', 'int')->setDefault(0);
			$this->addOrChangeColumn($table, 'user_reason', 'varchar', 255);
			$this->addOrChangeColumn($table, 'triggered', 'tinyint', 3)->setDefault(1);
			$table->addPrimaryKey(['user_id', 'group_id']);
			$table->addKey('ban_date');
			$table->addKey('end_date');
		};

		$tables['xf_dbtech_social_groups_group_invite'] = function (Create|Alter $table)
		{
			$this->addOrChangeColumn($table, 'group_invite_id', 'int')->autoIncrement();
			$this->addOrChangeColumn($table, 'user_id', 'int');
			$this->addOrChangeColumn($table, 'group_id', 'int');
			$this->addOrChangeColumn($table, 'invited_by_user_id', 'int');
			$this->addOrChangeColumn($table, 'invite_date', 'int');
			$this->addOrChangeColumn($table, 'reason', 'varchar', 255)->setDefault('');
			$table->addUniqueKey(['user_id', 'group_id']);
		};

		$tables['xf_dbtech_social_groups_group_member'] = function (Create|Alter $table)
		{
			$this->addOrChangeColumn($table, 'group_member_id', 'int')->autoIncrement();
			$this->addOrChangeColumn($table, 'user_id', 'int');
			$this->addOrChangeColumn($table, 'group_id', 'int');
			$this->addOrChangeColumn($table, 'join_date', 'int');
			$this->addOrChangeColumn($table, 'last_activity_date', 'int');
			$this->addOrChangeColumn($table, 'last_message_date', 'int');
			$this->addOrChangeColumn($table, 'last_media_upload_date', 'int');
			$this->addOrChangeColumn($table, 'last_event_creation_date', 'int');
			$this->addOrChangeColumn($table, 'is_supervisor', 'tinyint');
			$this->addOrChangeColumn($table, 'member_state', 'enum')->values(['valid','moderated','banned'])->setDefault('valid');
			$this->addOrChangeColumn($table, 'message_count', 'int');
			$this->addOrChangeColumn($table, 'album_count', 'int');
			$this->addOrChangeColumn($table, 'media_count', 'int');
			$this->addOrChangeColumn($table, 'event_count', 'int');
			$this->addOrChangeColumn($table, 'permissions', 'mediumtext');
			$this->addOrChangeColumn($table, 'reason', 'varchar', 255)->setDefault('');
			$table->addUniqueKey(['user_id', 'group_id']);
		};

		$tables['xf_dbtech_social_groups_group_member_log'] = function (Create|Alter $table)
		{
			$this->addOrChangeColumn($table, 'group_member_log_id', 'int')->autoIncrement();
			$this->addOrChangeColumn($table, 'group_id', 'int')->setDefault(0);
			$this->addOrChangeColumn($table, 'log_date', 'int')->setDefault(0);
			$this->addOrChangeColumn($table, 'actor_id', 'int')->setDefault(0);
			$this->addOrChangeColumn($table, 'actor_username', 'varchar', 50)->setDefault('');
			$this->addOrChangeColumn($table, 'user_id', 'int')->setDefault(0);
			$this->addOrChangeColumn($table, 'username', 'varchar', 50)->setDefault('');
			$this->addOrChangeColumn($table, 'ip_address', 'varbinary', 16)->setDefault('');
			$this->addOrChangeColumn($table, 'group_member_id', 'int')->setDefault(0);
			$this->addOrChangeColumn($table, 'action', 'varchar', 50)->setDefault('');
			$this->addOrChangeColumn($table, 'action_params', 'mediumblob')->nullable(true);
		};

		$tables['xf_dbtech_social_groups_group_read'] = function (Create|Alter $table)
		{
			$this->addOrChangeColumn($table, 'group_read_id', 'int')->autoIncrement();
			$this->addOrChangeColumn($table, 'user_id', 'int');
			$this->addOrChangeColumn($table, 'group_id', 'int');
			$this->addOrChangeColumn($table, 'group_read_date', 'int');
			$table->addUniqueKey(['user_id', 'group_id']);
			$table->addKey('group_id');
			$table->addKey('group_read_date');
		};

		$tables['xf_dbtech_social_groups_group_view'] = function (Create|Alter $table)
		{
			$this->addOrChangeColumn($table, 'group_id', 'int');
			$this->addOrChangeColumn($table, 'total', 'int');
			$table->addPrimaryKey('group_id');
		};

		$tables['xf_dbtech_social_groups_group_watch'] = function (Create|Alter $table)
		{
			$this->addOrChangeColumn($table, 'user_id', 'int');
			$this->addOrChangeColumn($table, 'group_id', 'int');
			$this->addOrChangeColumn($table, 'notify_on', 'enum')->values(['','discussion','message']);
			$this->addOrChangeColumn($table, 'send_alert', 'tinyint', 3);
			$this->addOrChangeColumn($table, 'send_email', 'tinyint', 3);
			$table->addPrimaryKey(['user_id', 'group_id']);
			$table->addKey(['group_id', 'notify_on']);
		};

		$tables['xf_dbtech_social_groups_message'] = function (Create|Alter $table)
		{
			$this->addOrChangeColumn($table, 'message_id', 'int')->autoIncrement();
			$this->addOrChangeColumn($table, 'discussion_id', 'int');
			$this->addOrChangeColumn($table, 'user_id', 'int');
			$this->addOrChangeColumn($table, 'username', 'varchar', 50);
			$this->addOrChangeColumn($table, 'message_date', 'int');
			$this->addOrChangeColumn($table, 'message', 'mediumtext');
			$this->addOrChangeColumn($table, 'ip_id', 'int')->setDefault(0);
			$this->addOrChangeColumn($table, 'message_state', 'enum')->values(['visible','moderated','deleted'])->setDefault('visible');
			$this->addOrChangeColumn($table, 'attach_count', 'smallint', 5)->setDefault(0);
			$this->addOrChangeColumn($table, 'position', 'int');
			$this->addOrChangeColumn($table, 'reaction_score', 'int')->unsigned(false)->setDefault(0);
			$this->addOrChangeColumn($table, 'reactions', 'blob')->nullable();
			$this->addOrChangeColumn($table, 'reaction_users', 'blob');
			$this->addOrChangeColumn($table, 'warning_id', 'int')->setDefault(0);
			$this->addOrChangeColumn($table, 'warning_message', 'varchar', 255)->setDefault('');
			$this->addOrChangeColumn($table, 'last_edit_date', 'int')->setDefault(0);
			$this->addOrChangeColumn($table, 'last_edit_user_id', 'int')->setDefault(0);
			$this->addOrChangeColumn($table, 'edit_count', 'int')->setDefault(0);
			$this->addOrChangeColumn($table, 'embed_metadata', 'blob')->nullable();
			$table->addKey(['discussion_id', 'message_date']);
			$table->addKey(['discussion_id', 'position']);
			$table->addKey('user_id');
			$table->addKey('message_date');
		};

		$tables['xf_dbtech_social_groups_related_thread'] = function (Create|Alter $table)
		{
			$this->addOrChangeColumn($table, 'group_id', 'int');
			$this->addOrChangeColumn($table, 'thread_id', 'int');
			$this->addOrChangeColumn($table, 'display_order', 'int');
			$table->addPrimaryKey(['group_id', 'thread_id']);
		};

		$tables['xf_dbtech_social_groups_section'] = function (Create|Alter $table)
		{
			$this->addOrChangeColumn($table, 'section_id', 'int')->autoIncrement();
			$this->addOrChangeColumn($table, 'title', 'varchar', 50);
			$this->addOrChangeColumn($table, 'description', 'text');
			$this->addOrChangeColumn($table, 'parent_section_id', 'int');
			$this->addOrChangeColumn($table, 'group_id', 'int');
			$this->addOrChangeColumn($table, 'display_order', 'int')->setDefault(10);
			$this->addOrChangeColumn($table, 'lft', 'int')->setDefault(0)->comment('Nested set info \'left\' value');
			$this->addOrChangeColumn($table, 'rgt', 'int')->setDefault(0)->comment('Nested set info \'right\' value');
			$this->addOrChangeColumn($table, 'depth', 'int')->setDefault(0)->comment('Depth = 0: no parent');
			$this->addOrChangeColumn($table, 'breadcrumb_data', 'blob')->nullable();
			$this->addOrChangeColumn($table, 'discussion_count', 'int')->setDefault(0);
			$this->addOrChangeColumn($table, 'message_count', 'int')->setDefault(0);
			$this->addOrChangeColumn($table, 'last_update_date', 'int')->setDefault(0)->comment('Date of most recent content addition');
			$this->addOrChangeColumn($table, 'last_message_id', 'int')->setDefault(0)->comment('Most recent message_id');
			$this->addOrChangeColumn($table, 'last_message_date', 'int')->setDefault(0)->comment('Date of most recent message');
			$this->addOrChangeColumn($table, 'last_message_user_id', 'int')->setDefault(0)->comment('User_id of user posting most recently');
			$this->addOrChangeColumn($table, 'last_message_username', 'varchar', 50)->setDefault('')->comment('Username of most recently-posting user');
			$this->addOrChangeColumn($table, 'last_discussion_id', 'int')->setDefault(0)->comment('Most recent discussion_id');
			$this->addOrChangeColumn($table, 'last_discussion_title', 'varchar', 150)->setDefault('')->comment('Title of discussion most recent message is in');
			$this->addOrChangeColumn($table, 'staff_only', 'tinyint', 3)->setDefault(0);
			$this->addOrChangeColumn($table, 'moderate_discussions', 'tinyint', 3)->setDefault(0);
			$this->addOrChangeColumn($table, 'moderate_replies', 'tinyint', 3)->setDefault(0);
			$this->addOrChangeColumn($table, 'allow_posting', 'tinyint', 3)->setDefault(1);
			$this->addOrChangeColumn($table, 'allow_discussions', 'tinyint', 3)->setDefault(1);
			$this->addOrChangeColumn($table, 'allow_poll', 'tinyint', 3)->setDefault(1);
			$this->addOrChangeColumn($table, 'count_messages', 'tinyint', 3)->setDefault(1);
			$this->addOrChangeColumn($table, 'find_new', 'tinyint', 3)->setDefault(1)->comment('Include messages from this section when running /find-new/dbtech-social-discussions');
			$this->addOrChangeColumn($table, 'allowed_watch_notifications', 'varchar', 10)->setDefault('all');
			$this->addOrChangeColumn($table, 'default_sort_order', 'varchar', 25)->setDefault('last_message_date');
			$this->addOrChangeColumn($table, 'default_sort_direction', 'varchar', 5)->setDefault('desc');
			$this->addOrChangeColumn($table, 'list_date_limit_days', 'smallint', 5)->setDefault(0);
			$this->addOrChangeColumn($table, 'tags', 'mediumblob');
			$this->addOrChangeColumn($table, 'min_tags', 'smallint', 5)->setDefault(0);
			$table->addKey('group_id');
		};

		$tables['xf_dbtech_social_groups_section_read'] = function (Create|Alter $table)
		{
			$this->addOrChangeColumn($table, 'section_read_id', 'int')->autoIncrement();
			$this->addOrChangeColumn($table, 'user_id', 'int');
			$this->addOrChangeColumn($table, 'section_id', 'int');
			$this->addOrChangeColumn($table, 'section_read_date', 'int');
			$table->addUniqueKey(['user_id', 'section_id']);
			$table->addKey('section_id');
			$table->addKey('section_read_date');
		};

		$tables['xf_dbtech_social_groups_section_watch'] = function (Create|Alter $table)
		{
			$this->addOrChangeColumn($table, 'user_id', 'int');
			$this->addOrChangeColumn($table, 'section_id', 'int');
			$this->addOrChangeColumn($table, 'notify_on', 'enum')->values(['','discussion','message']);
			$this->addOrChangeColumn($table, 'send_alert', 'tinyint', 3);
			$this->addOrChangeColumn($table, 'send_email', 'tinyint', 3);
			$table->addPrimaryKey(['user_id', 'section_id']);
			$table->addKey(['section_id', 'notify_on']);
		};

		return $tables;
	}

	/**
	 * @return array
	 */
	protected function getAlterDefinitions(): array
	{
		$definitions = [];

		$definitions['xf_user'] = [
			'columns' => [
				'dbtech_social_groups_group_ids' => [
					'type'    => 'mediumblob',
					'nullable' => true,
				],
				'dbtech_social_groups_group_count' => [
					'type'    => 'int',
					'length'  => null,
					'default' => 0,
				],
				'dbtech_social_groups_group_joined_count' => [
					'type'    => 'int',
					'length'  => null,
					'default' => 0,
				],
				'dbtech_social_groups_group_invitation_count' => [
					'type'    => 'int',
					'length'  => null,
					'default' => 0,
				],
			],
		];

		return $definitions;
	}

	/**
	 *
	 */
	public function installStep4(): void
	{
		$this->insertNodeType(
			'DBTechSocialContainer',
			'DBTech\SocialGroups:Container',
			'dbtechSocial',
			'dbtech-social/containers',
			'dbtech-social/containers',
			'DBTech\SocialGroups:SocialGroupContainer'
		);
	}

	/**
	 * @return string[]
	 */
	protected function getInstallQueries(): array
	{
		return [];
	}

	/**
	 * Returns true if permissions were modified, otherwise false.
	 *
	 * @return bool
	 */
	protected function applyPermissionsInstall(): bool
	{
		// Regular perms
		$this->applyGlobalPermission('dbtechSocial', 'view', 'general', 'view');
		$this->applyGlobalPermission('dbtechSocial', 'viewGroup', 'general', 'viewNode');
		$this->applyGlobalPermission('dbtechSocial', 'viewOthers', 'forum', 'viewOthers');
		$this->applyGlobalPermission('dbtechSocial', 'viewContent', 'forum', 'viewContent');
		$this->applyGlobalPermission('dbtechSocial', 'viewBanned', 'forum', 'viewContent');
		$this->applyGlobalPermission('dbtechSocial', 'react', 'forum', 'react');
		$this->applyGlobalPermission('dbtechSocial', 'contentVote', 'forum', 'contentVote');
		$this->applyGlobalPermission('dbtechSocial', 'startDiscussion', 'forum', 'postThread');
		$this->applyGlobalPermission('dbtechSocial', 'postReply', 'forum', 'postReply');
		$this->applyGlobalPermission('dbtechSocial', 'deleteOwnMessage', 'forum', 'deleteOwnPost');
		$this->applyGlobalPermission('dbtechSocial', 'editOwnMessage', 'forum', 'editOwnPost');
		$this->applyGlobalPermissionInt('dbtechSocial', 'editOwnMessageTimeLimit', 5);
		$this->applyGlobalPermission('dbtechSocial', 'editOwnDiscussionTitle', 'forum', 'editOwnThreadTitle');
		$this->applyGlobalPermission('dbtechSocial', 'deleteOwnDiscussion', 'forum', 'deleteOwnThread');
		$this->applyGlobalPermission('dbtechSocial', 'viewAttachment', 'forum', 'viewAttachment');
		$this->applyGlobalPermission('dbtechSocial', 'uploadAttachment', 'forum', 'uploadAttachment');
		$this->applyGlobalPermission('dbtechSocial', 'uploadVideo', 'forum', 'uploadVideo');
		$this->applyGlobalPermission('dbtechSocial', 'tagOwnDiscussion', 'forum', 'tagOwnThread');
		$this->applyGlobalPermission('dbtechSocial', 'tagAnyDiscussion', 'forum', 'tagAnyThread');
		$this->applyGlobalPermission('dbtechSocial', 'tagOwnGroup', 'forum', 'tagOwnThread');
		$this->applyGlobalPermission('dbtechSocial', 'tagAnyGroup', 'forum', 'tagAnyThread');
		$this->applyGlobalPermission('dbtechSocial', 'manageOthersTagsOwnDisc', 'forum', 'manageOthersTagsOwnThread');
		$this->applyGlobalPermission('dbtechSocial', 'votePoll', 'forum', 'votePoll');
		$this->applyGlobalPermission('dbtechSocial', 'createGroup', 'forum', 'postThread');
		$this->applyGlobalPermissionInt('dbtechSocial', 'maxCreatedGroups', 5);
		$this->applyGlobalPermissionInt('dbtechSocial', 'maxJoinedGroups', 5);
		$this->applyGlobalPermission('dbtechSocial', 'createWithoutApproval', 'forum', 'submitWithoutApproval');

		// Moderator perms
		$this->applyGlobalPermission('dbtechSocial', 'inlineMod', 'forum', 'inlineMod');
		$this->applyGlobalPermission('dbtechSocial', 'stickUnstickDiscussion', 'forum', 'stickUnstickThread');
		$this->applyGlobalPermission('dbtechSocial', 'lockUnlockDiscussion', 'forum', 'lockUnlockThread');
		$this->applyGlobalPermission('dbtechSocial', 'manageAnyDiscussion', 'forum', 'manageAnyThread');
		$this->applyGlobalPermission('dbtechSocial', 'deleteAnyDiscussion', 'forum', 'deleteAnyThread');
		$this->applyGlobalPermission('dbtechSocial', 'hardDeleteAnyDiscussion', 'forum', 'hardDeleteAnyThread');
		$this->applyGlobalPermission('dbtechSocial', 'discussionReplyBan', 'forum', 'threadReplyBan');
		$this->applyGlobalPermission('dbtechSocial', 'editAnyMessage', 'forum', 'editAnyPost');
		$this->applyGlobalPermission('dbtechSocial', 'deleteAnyMessage', 'forum', 'deleteAnyPost');
		$this->applyGlobalPermission('dbtechSocial', 'hardDeleteAnyMessage', 'forum', 'hardDeleteAnyPost');
		$this->applyGlobalPermission('dbtechSocial', 'warn', 'forum', 'warn');
		$this->applyGlobalPermission('dbtechSocial', 'manageAnyTag', 'forum', 'manageAnyTag');
		$this->applyGlobalPermission('dbtechSocial', 'viewDeleted', 'forum', 'viewDeleted');
		$this->applyGlobalPermission('dbtechSocial', 'viewModerated', 'forum', 'viewModerated');
		$this->applyGlobalPermission('dbtechSocial', 'undelete', 'forum', 'undelete');
		$this->applyGlobalPermission('dbtechSocial', 'approveUnapprove', 'forum', 'approveUnapprove');
		$this->applyGlobalPermission('dbtechSocial', 'approveRejectMembers', 'forum', 'approveUnapprove');
		$this->applyGlobalPermission('dbtechSocial', 'kickUser', 'general', 'banUser');
		$this->applyGlobalPermission('dbtechSocial', 'banUser', 'general', 'banUser');

		return true;
	}

	/**
	 * @return \Closure[]
	 */
	protected function getDefaultWidgetSetup(): array
	{
		return [
			'dbtech_social_tag_cloud' => function ($key, array $options = [])
			{
				$options = array_replace([
					'limit' => 25,
					'minUses' => 1,
				], $options);

				$this->createWidget(
					$key,
					'dbt_soc_tag_cloud',
					[
						'positions' => ['dbtech_social_group_list_sidenav' => 1],
						'options' => $options,
					],
					'Tag cloud'
				);
			},
			'dbtech_social_limits' => function ($key, array $options = [])
			{
				$this->createWidget(
					$key,
					'dbt_soc_limits',
					[
						'positions' => ['dbtech_social_group_list_sidenav' => 10],
						'options' => $options,
					],
					'Limits'
				);
			},
			'dbtech_social_whats_new_overview_new_messages' => function ($key, array $options = [])
			{
				$options = array_replace([
					'limit' => 10,
					'style' => 'full',
				], $options);

				$this->createWidget(
					$key,
					'dbt_soc_new_messages',
					[
						'positions' => ['whats_new_overview' => 11],
						'options' => $options,
					]
				);
			},
			'dbtech_social_forum_overview_new_messages' => function ($key, array $options = [])
			{
				$options = array_replace([], $options);

				$this->createWidget(
					$key,
					'dbt_soc_new_messages',
					[
						'positions' => [
							'forum_list_sidebar' => 37,
							'forum_new_posts_sidebar' => 27,
						],
						'options' => $options,
					]
				);
			},
			'dbtech_social_group_overview_supervisors' => function ($key, array $options = [])
			{
				$options = array_replace([
					'limit' => 12,
				], $options);

				$this->createWidget(
					$key,
					'dbt_soc_supervisors',
					[
						'positions' => ['dbtech_social_group_overview' => 10],
						'options' => $options,
					]
				);
			},
			'dbtech_social_group_overview_newest_members' => function ($key, array $options = [])
			{
				$options = array_replace([
					'limit' => 12,
				], $options);

				$this->createWidget(
					$key,
					'dbt_soc_new_members',
					[
						'positions' => ['dbtech_social_group_overview' => 20],
						'options' => $options,
					]
				);
			},
			'dbtech_social_group_overview_new_messages' => function ($key, array $options = [])
			{
				$options = array_replace([
					'limit' => 10,
					'style' => 'full',
					'filter' => 'latest',
				], $options);

				$this->createWidget(
					$key,
					'dbt_soc_new_messages',
					[
						'positions' => ['dbtech_social_group_overview' => 30],
						'options' => $options,
					]
				);
			},
			'dbtech_social_group_overview_related_threads' => function ($key, array $options = [])
			{
				$options = array_replace([
					'style' => 'full',
				], $options);

				$this->createWidget(
					$key,
					'dbt_soc_related_threads',
					[
						'positions' => ['dbtech_social_group_overview' => 30],
						'options' => $options,
					]
				);
			},
			'dbtech_social_group_overview_newest_media' => function ($key, array $options = [])
			{
				$options = array_replace([
					'order' => 'latest',
					'limit' => 12,
				], $options);

				$this->createWidget(
					$key,
					'dbt_soc_new_media',
					[
						'positions' => ['dbtech_social_group_overview' => 40],
						'options' => $options,
					]
				);
			},
			'dbtech_social_group_featured_groups' => function ($key, array $options = [])
			{
				$options = array_replace([
					'contextual' => true,
					'contextual_hidden' => false,
					'limit' => 5,
					'style' => 'carousel',
					'snippet_length' => 250,
					'content_type' => 'dbtech_social_group',
				], $options);

				$this->createWidget(
					$key,
					'featured_content',
					[
						'positions' => [
							'dbtech_social_group_list_above_groups' => 10,
						],
						'options' => $options,
					]
				);
			},
		];
	}

	/**
	 *
	 */
	protected function runPostInstallActions(): void
	{
		$countersRepo = \XF::app()->repository(CountersRepository::class);
		$countersRepo->rebuildForumStatisticsCache();
	}

	/**
	 * @return string[]
	 */
	protected function getAdminPermissions(): array
	{
		return [];
	}

	/**
	 * @return string[]
	 */
	protected function getPermissionGroups(): array
	{
		return [
			'dbtechSocial',
		];
	}

	/**
	 * @return string[]
	 */
	protected function getContentTypes(): array
	{
		return [
			'dbtech_social_discussion',
			'dbtech_social_group',
			'dbtech_social_member',
			'dbtech_social_message',
		];
	}

	/**
	 * @return string[]
	 */
	protected function getRegistryEntries(): array
	{
		return [];
	}
}