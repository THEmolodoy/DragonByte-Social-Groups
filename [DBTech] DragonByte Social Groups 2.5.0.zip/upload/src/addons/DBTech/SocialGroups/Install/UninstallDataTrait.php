<?php

namespace DBTech\SocialGroups\Install;

use XF\AddOn\AddOn;
use XF\App;
use XF\Db\AbstractAdapter;
use XF\Db\Exception as DbException;
use XF\Db\SchemaManager;
use XF\Repository\NodeTypeRepository;

/**
 * @property AddOn addOn
 * @property App app
 *
 * @method AbstractAdapter db()
 * @method SchemaManager schemaManager()
 */
trait UninstallDataTrait
{
	/**
	 * Methods MUST start at step 4, as steps 1-3 are reserved by the core
	 */

	/**
	 * @return void
	 * @throws DbException
	 */
	protected function runMiscCleanUp(): void
	{
		$this->db()->delete('xf_change_log', "content_type LIKE 'dbtech_social_%'");
		$this->db()->delete('xf_change_log', "field LIKE 'dbtech_social_%'");
		$this->db()->query('
			DELETE FROM xf_moderator 
			WHERE is_super_moderator = 0 
				AND user_id NOT IN (SELECT user_id FROM xf_moderator_content)
				AND extra_user_group_ids = \'\'
		');

		$this->db()->delete('xf_node_type', "node_type_id LIKE 'DBTechSocial%'");
		\XF::runOnce('rebuildNodeTypeCache', function ()
		{
			\XF::app()->repository(NodeTypeRepository::class)->rebuildNodeTypeCache();
		});
	}
}