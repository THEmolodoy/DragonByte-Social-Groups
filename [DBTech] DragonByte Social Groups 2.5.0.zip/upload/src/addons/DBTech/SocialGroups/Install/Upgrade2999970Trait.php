<?php

namespace DBTech\SocialGroups\Install;

use DBTech\SocialGroups\Job\GroupMemberRebuild;
use XF\AddOn\AddOn;
use XF\App;
use XF\Db\AbstractAdapter;
use XF\Db\Exception as DbException;
use XF\Db\Schema\Alter;
use XF\Db\Schema\Column;
use XF\Db\SchemaManager;

/**
 * @property AddOn addOn
 * @property App app
 *
 * @method AbstractAdapter db()
 * @method SchemaManager schemaManager()
 * @method Column addOrChangeColumn($table, $name, $type = null, $length = null)
 */
trait Upgrade2999970Trait
{
	/**
	 * @return void
	 */
	public function upgrade2000052Step1(): void
	{
		$this->applyTables();
	}

	/**
	 * @return void
	 * @throws DbException
	 */
	public function upgrade2000052Step2(): void
	{
		$this->db()->query("
			UPDATE xf_dbtech_social_groups_group_member_log AS gl
			LEFT JOIN xf_user AS a ON(a.user_id = gl.actor_id)
			SET gl.actor_username = IFNULL(a.username, 'N/A')
		");
	}

	/**
	 * @return void
	 * @throws DbException
	 */
	public function upgrade2000170Step1(): void
	{
		$this->db()->query("
			DELETE s
			FROM xf_dbtech_social_groups_section AS s
			LEFT JOIN xf_dbtech_social_groups_group AS g USING(group_id)
			WHERE g.group_id IS NULL
		");
	}

	/**
	 * @return void
	 */
	public function upgrade2000270Step1(): void
	{
		$this->installStep2();
	}

	/**
	 * @return void
	 * @throws DbException
	 */
	public function upgrade2000270Step2(): void
	{
		$this->db()->query("
			UPDATE `xf_user` AS `u`
			SET `dbtech_social_groups_group_invitation_count` = (
				SELECT COUNT(*)
				FROM `xf_dbtech_social_groups_group_invite` AS `gi`
				LEFT JOIN `xf_dbtech_social_groups_group` AS `g` USING(`group_id`)
				WHERE `gi`.`user_id` = `u`.`user_id`
				  	AND `g`.`group_state` = 'visible'
			)
		");
	}

	/**
	 * @return void
	 */
	public function upgrade2010070Step1(): void
	{
		$this->schemaManager()->alterTable('xf_dbtech_social_groups_group', function (Alter $table)
		{
			$table->renameColumn('is_featured', 'featured');
		});
	}

	/**
	 * @return void
	 */
	public function upgrade2010070Step2(): void
	{
		$this->db()->update('xf_dbtech_social_groups_group', [
			'featured' => 0,
		], null);
	}

	/**
	 * @return void
	 */
	public function upgrade2010070Step3(): void
	{
		$this->insertNamedWidget('dbtech_social_group_featured_groups');
	}

	/**
	 * @return void
	 * @throws DbException
	 */
	public function upgrade2020071Step1(): void
	{
		$this->executeUpgradeQuery("
			UPDATE xf_dbtech_social_groups_message AS gm
			SET gm.attach_count = (
				SELECT COUNT(*)
				FROM xf_attachment
				WHERE content_type = 'dbtech_social_message'
					AND content_id = gm.message_id
			)
		");
	}

	/**
	 * @return void
	 */
	public function upgrade2030031Step1(): void
	{
		$this->applyTables();
	}

	/**
	 * @return void
	 */
	public function upgrade2030170Step1(): void
	{
		$tables = [
			'xf_dbtech_social_groups_discussion_view',
			'xf_dbtech_social_groups_group_view',
		];

		$defaultEngine = \XF::config('db')['engine'] ?? 'InnoDb';
		if ($defaultEngine !== 'InnoDb')
		{
			\XF::logError('During upgrade to DragonByte Social Groups 2.3.1 we could not convert some tables to InnoDb: ' . implode(', ', $tables));
			return;
		}

		foreach ($tables AS $tableName)
		{
			$this->alterTable($tableName, function (Alter $table)
			{
				$table->engine('InnoDB');
			});
		}
	}

	/**
	 * @return void
	 */
	public function upgrade2040032Step1(): void
	{
		$this->applyTables();
	}

	/**
	 * @return void
	 * @throws DbException
	 */
	public function upgrade2040032Step2(): void
	{
		$this->executeUpgradeQuery('
			UPDATE xf_dbtech_social_groups_group_member
			SET last_activity_date = join_date
		');
	}

	/**
	 * @param $previousVersion
	 * @param array $stateChanges
	 */
	protected function postUpgrade2040032($previousVersion, array &$stateChanges): void
	{
		\XF::app()->jobManager()->enqueue(
			GroupMemberRebuild::class
		);
	}

	/**
	 * @return void
	 */
	public function upgrade2040070Step1(): void
	{
		$this->applyTables();
	}

	/**
	 * @param bool $applied
	 * @param int|null $previousVersion
	 *
	 * @return bool
	 */
	protected function applyPermissionsUpgrade2999970(bool &$applied, ?int $previousVersion = null): bool
	{
		if (!$previousVersion || $previousVersion < 2000052)
		{
			$this->applyGlobalPermission('dbtechSocial', 'viewAnyLog', 'dbtechSocial', 'editAny');

			$applied = true;
		}

		return $applied;
	}
}