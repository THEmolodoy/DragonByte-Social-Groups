<?php

namespace DBTech\SocialGroups\Install;

use XF\AddOn\AddOn;
use XF\App;
use XF\Db\AbstractAdapter;
use XF\Db\Schema\Column;
use XF\Db\SchemaManager;
use XF\Entity\Option;
use XF\Finder\OptionFinder;

/**
 * @property AddOn addOn
 * @property App app
 *
 * @method AbstractAdapter db()
 * @method SchemaManager schemaManager()
 * @method Column addOrChangeColumn($table, $name, $type = null, $length = null)
 */
trait Upgrade1999970Trait
{
	/**
	 *
	 */
	public function upgrade1010031Step1(): void
	{
		$this->applyTables();
	}

	/**
	 *
	 */
	public function upgrade1010031Step2(): void
	{
		$this->insertNamedWidget('dbtech_social_tag_cloud');
	}

	/**
	 *
	 */
	public function upgrade1010031Step3(): void
	{
		/** @var Option $option */
		$option = \XF::app()->finder(OptionFinder::class)
			->where('option_id', '=', 'dbtechSocialDefaultPermissions')
			->fetchOne()
		;

		if (!$option)
		{
			// Option: Mr. XenForo I don't feel so good
			throw new \LogicException("XenForo installation is damaged. Expected option 'dbtechSocialDefaultPermissions' to exist.");
		}

		$groupOwnerValues = \json_decode($option->option_value['groupOwner'], true);
		$groupSupervisorValues = \json_decode($option->option_value['groupModerators'], true);

		// New group owner values
		$groupOwnerValues['contentPermissions']['dbtechSocial']['editAnyAlbum'] = 'content_allow';
		$groupOwnerValues['contentPermissions']['dbtechSocial']['unlinkAnyAlbum'] = 'content_allow';
		$groupOwnerValues['contentPermissions']['dbtechSocial']['deleteAnyAlbum'] = 'content_allow';

		// New group supervisor values
		$groupSupervisorValues['contentPermissions']['dbtechSocial']['editAnyAlbum'] = 'content_allow';
		$groupSupervisorValues['contentPermissions']['dbtechSocial']['unlinkAnyAlbum'] = 'content_allow';
		$groupSupervisorValues['contentPermissions']['dbtechSocial']['deleteAnyAlbum'] = 'content_allow';

		$option->option_value = [
			'groupOwner' => \json_encode($groupOwnerValues),
			'groupModerators' => \json_encode($groupSupervisorValues),
		];
		$option->saveIfChanged();
	}

	/**
	 *
	 */
	public function upgrade1010032Step1(): void
	{
		$this->insertNamedWidget('dbtech_social_whats_new_overview_new_messages');
		$this->insertNamedWidget('dbtech_social_forum_overview_new_messages');
	}

	/**
	 *
	 */
	public function upgrade1010033Step1(): void
	{
		$this->applyTables();
	}

	/**
	 *
	 */
	public function upgrade1010035Step1(): void
	{
		$this->installStep4();
	}

	/**
	 *
	 */
	public function upgrade1010035Step2(): void
	{
		$this->applyTables();
	}

	/**
	 *
	 */
	public function upgrade1010036Step1(): void
	{
		$this->applyTables();
	}

	/**
	 *
	 */
	public function upgrade1010037Step1(): void
	{
		$this->insertNamedWidget('dbtech_social_group_overview_supervisors');
		$this->insertNamedWidget('dbtech_social_group_overview_newest_members');
		$this->insertNamedWidget('dbtech_social_group_overview_new_messages');
		$this->insertNamedWidget('dbtech_social_group_overview_newest_media');
	}

	/**
	 *
	 */
	public function upgrade1010038Step1(): void
	{
		$this->applyTables();
	}

	/**
	 *
	 */
	public function upgrade1010038Step2(): void
	{
		$this->insertNamedWidget('dbtech_social_group_overview_related_threads');
	}

	/**
	 *
	 */
	public function upgrade1020032Step1(): void
	{
		$this->insertNamedWidget('dbtech_social_limits');
	}

	/**
	 *
	 */
	public function upgrade1020033Step1(): void
	{
		$this->applyTables();
	}

	/**
	 *
	 */
	public function upgrade1020034Step1(): void
	{
		$this->applyTables();
	}

	/**
	 *
	 */
	public function upgrade1020035Step1(): void
	{
		$this->applyTables();
	}

	/**
	 *
	 */
	public function upgrade1020035Step2(): void
	{
		/** @var Option $option */
		$option = \XF::app()->finder(OptionFinder::class)
			->where('option_id', '=', 'dbtechSocialDefaultPermissions')
			->fetchOne()
		;

		if (!$option)
		{
			// Option: Mr. XenForo I don't feel so good
			throw new \LogicException("XenForo installation is damaged. Expected option 'dbtechSocialDefaultPermissions' to exist.");
		}

		$groupOwnerValues = \json_decode($option->option_value['groupOwner'], true);
		$groupSupervisorValues = \json_decode($option->option_value['groupModerators'], true);

		// New group owner values
		$groupOwnerValues['contentPermissions']['dbtechSocial']['createNestedSections'] = 'content_allow';

		// New group supervisor values
		$groupSupervisorValues['contentPermissions']['dbtechSocial']['createNestedSections'] = 'content_allow';

		$option->option_value = [
			'groupOwner' => \json_encode($groupOwnerValues),
			'groupModerators' => \json_encode($groupSupervisorValues),
		];
		$option->saveIfChanged();
	}

	/**
	 *
	 */
	public function upgrade1020170Step1(): void
	{
		$this->applyTables();
	}

	/**
	 *
	 */
	public function upgrade1020170Step2(): void
	{
		/** @var Option $option */
		$option = \XF::app()->finder(OptionFinder::class)
			->where('option_id', '=', 'dbtechSocialEnabledGroupOwnerFeatures')
			->fetchOne()
		;

		if (!$option)
		{
			// Option: Mr. XenForo I don't feel so good
			throw new \LogicException("XenForo installation is damaged. Expected option 'dbtechSocialEnabledGroupOwnerFeatures' to exist.");
		}

		$optionValue = $option->option_value;

		// New values
		$optionValue['locale'] = "1";

		$option->option_value = $optionValue;
		$option->saveIfChanged();
	}

	/**
	 *
	 */
	public function upgrade1020231Step1(): void
	{
		$this->applyTables();
	}

	/**
	 *
	 */
	public function upgrade1020232Step1(): void
	{
		$this->applyTables();
	}

	/**
	 *
	 */
	public function upgrade1020233Step1(): void
	{
		$this->applyTables();
	}

	/**
	 *
	 */
	public function upgrade1020234Step1(): void
	{
		$this->applyTables();
	}

	/**
	 *
	 */
	public function upgrade1020234Step2(): void
	{
		$this->db()->emptyTable('xf_dbtech_social_groups_group_member_log');
	}

	/**
	 * @param bool $applied
	 * @param int|null $previousVersion
	 *
	 * @return bool
	 */
	protected function applyPermissionsUpgrade1999970(bool &$applied, ?int $previousVersion = null): bool
	{
		if (!$previousVersion || $previousVersion < 1010031)
		{
			$this->applyGlobalPermission('dbtechSocial', 'addMedia', 'forum', 'uploadAttachment');
			$this->applyGlobalPermissionInt('dbtechSocial', 'maxAlbumsPerGroup', 5);

			$this->applyGlobalPermission('dbtechSocial', 'editAnyAlbum', 'forum', 'editAnyPost');
			$this->applyGlobalPermission('dbtechSocial', 'unlinkAnyAlbum', 'forum', 'editAnyPost');

			$applied = true;
		}

		if (!$previousVersion || $previousVersion < 1010034)
		{
			$this->applyGlobalPermissionInt('dbtechSocial', 'maxInvitedUserBatch', 5);

			$applied = true;
		}

		if (!$previousVersion || $previousVersion < 1010038)
		{
			$this->applyGlobalPermission('dbtechSocial', 'manageRelatedThreads', 'forum', 'editAnyPost');

			$applied = true;
		}

		if (!$previousVersion || $previousVersion < 1020031)
		{
			$this->applyGlobalPermission('dbtechSocial', 'joinGroup', 'general', 'viewNode');

			$applied = true;
		}

		if (!$previousVersion || $previousVersion < 1020035)
		{
			$this->applyGlobalPermissionInt(
				'dbtechSocial',
				'maxCreatedSections',
				5,
				$previousVersion ? 'dbtechSocial' : 'forum',
				$previousVersion ? 'createGroup' : 'postThread'
			);
			$this->applyGlobalPermission('dbtechSocial', 'createNestedSections', 'general', 'viewNode');

			$applied = true;
		}

		return $applied;
	}
}