<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\Job;

use DBTech\SocialGroups\Entity\Discussion;
use DBTech\SocialGroups\Service\Thread\ImporterService;
use XF\Job\AbstractJob;
use XF\Job\JobResult;
use XF\PrintableException;

class ThreadImportProcess extends AbstractJob
{
	protected $defaultData = [
		'actorId' => null,
		'threadId' => null,
		'threadTitle' => null,
		'userId' => null,
		'username' => null,
		'discussionId' => null,
		'groupId' => null,
		'sectionId' => null,

		'cleanUpType' => 'do_nothing',
		'reason' => '',
		'log' => true,

		'currentStep' => 0,
		'lastOffset' => null,

		'start' => 0,
	];

	/**
	 * @param $maxRunTime
	 *
	 * @return JobResult
	 * @throws PrintableException
	 */
	public function run($maxRunTime)
	{
		$this->data['start']++;

		if (!$this->data['groupId']
			|| !$this->data['threadId']
			|| !$this->data['threadTitle']
			|| !$this->data['actorId']
		)
		{
			return $this->complete();
		}

		if (!$this->data['discussionId'])
		{
			$this->createDiscussion();
		}

		$importer = \XF::app()->service(
			ImporterService::class,
			$this->data['actorId'],
			$this->data['threadId'],
			$this->data['discussionId'],
			$this->data['groupId'],
			$this->data['sectionId']
		);
		$importer->setCleanupOptions($this->data['cleanUpType'], $this->data['reason']);
		$importer->setLog($this->data['log']);
		$importer->restoreState($this->data['currentStep'], $this->data['lastOffset']);

		$result = $importer->import($maxRunTime);
		if ($result->isCompleted())
		{
			return $this->complete();
		}
		else
		{
			$continueData = $result->getContinueData();
			$this->data['currentStep'] = $continueData['currentStep'];
			$this->data['lastOffset'] = $continueData['lastOffset'];

			return $this->resume();
		}
	}

	/**
	 * @return void
	 * @throws PrintableException
	 */
	protected function createDiscussion()
	{
		$newDiscussion = \XF::em()->create(Discussion::class);
		$newDiscussion->title = $this->data['threadTitle'];
		$newDiscussion->group_id = $this->data['groupId'];
		$newDiscussion->user_id = $this->data['userId'];
		$newDiscussion->username = $this->data['username'];

		if ($this->data['sectionId'])
		{
			$newDiscussion->section_id = $this->data['sectionId'];
		}

		$newDiscussion->save();

		$this->data['discussionId'] = $newDiscussion->discussion_id;
	}

	public function getStatusMessage()
	{
		$actionPhrase = \XF::phrase('dbtech_social_groups_processing_thread_import');
		$typePhrase = \XF::phrase('posts');
		return sprintf('%s... (%s - %s)', $actionPhrase, $typePhrase, $this->data['start']);
	}

	public function canCancel()
	{
		return false;
	}

	public function canTriggerByChoice()
	{
		return false;
	}
}