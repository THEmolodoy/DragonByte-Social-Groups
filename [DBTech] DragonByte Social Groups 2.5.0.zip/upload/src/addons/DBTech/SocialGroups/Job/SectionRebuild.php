<?php

namespace DBTech\SocialGroups\Job;

use DBTech\SocialGroups\Entity\Section;
use XF\Job\AbstractRebuildJob;
use XF\Phrase;
use XF\PrintableException;

class SectionRebuild extends AbstractRebuildJob
{
	/**
	 * @param int $start
	 * @param int $batch
	 *
	 * @return array
	 */
	protected function getNextIds($start, $batch): array
	{
		$db = \XF::app()->db();

		return $db->fetchAllColumn($db->limit(
			'
				SELECT section_id
				FROM xf_dbtech_social_groups_section
				WHERE section_id > ?
				ORDER BY section_id
			',
			$batch
		), $start);
	}

	/**
	 * @param int $id
	 *
	 * @throws \LogicException
	 * @throws \Exception
	 * @throws PrintableException
	 */
	protected function rebuildById($id): void
	{
		$section = \XF::app()->em()->find(Section::class, $id);
		if (!$section)
		{
			return;
		}

		if ($section->rebuildCounters())
		{
			$section->save();
		}
	}

	/**
	 * @return Phrase
	 */
	protected function getStatusType(): Phrase
	{
		return \XF::phrase('dbtech_social_groups_social_group_sections');
	}
}