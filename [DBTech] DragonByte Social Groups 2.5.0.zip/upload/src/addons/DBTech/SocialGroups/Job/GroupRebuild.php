<?php

namespace DBTech\SocialGroups\Job;

use DBTech\SocialGroups\Entity\Group;
use XF\Job\AbstractRebuildJob;
use XF\Phrase;
use XF\PrintableException;

class GroupRebuild extends AbstractRebuildJob
{
	/**
	 * @param int $start
	 * @param int $batch
	 *
	 * @return array
	 */
	protected function getNextIds($start, $batch): array
	{
		$db = \XF::app()->db();

		return $db->fetchAllColumn($db->limit(
			'
				SELECT group_id
				FROM xf_dbtech_social_groups_group
				WHERE group_id > ?
				ORDER BY group_id
			',
			$batch
		), $start);
	}

	/**
	 * @param int $id
	 *
	 * @throws \LogicException
	 * @throws \Exception
	 * @throws PrintableException
	 */
	protected function rebuildById($id): void
	{
		$group = \XF::app()->em()->find(Group::class, $id);
		if (!$group)
		{
			return;
		}

		if ($group->rebuildCounters())
		{
			$group->save();
		}
	}

	/**
	 * @return Phrase
	 */
	protected function getStatusType(): Phrase
	{
		return \XF::phrase('dbtech_social_groups_social_groups');
	}
}