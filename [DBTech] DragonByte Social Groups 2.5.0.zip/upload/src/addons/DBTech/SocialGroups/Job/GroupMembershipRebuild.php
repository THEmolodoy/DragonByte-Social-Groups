<?php

namespace DBTech\SocialGroups\Job;

use DBTech\SocialGroups\Finder\GroupMemberFinder;
use XF\Entity\User;
use XF\Job\AbstractRebuildJob;
use XF\Phrase;
use XF\PrintableException;

class GroupMembershipRebuild extends AbstractRebuildJob
{
	protected $defaultData = [
		'groupId' => null,
	];

	/**
	 * @param int $start
	 * @param int $batch
	 *
	 * @return array
	 */
	protected function getNextIds($start, $batch): array
	{
		$db = \XF::app()->db();

		return $db->fetchAllColumn($db->limit(
			'
				SELECT DISTINCT user_id
				FROM xf_dbtech_social_groups_group_member
				WHERE user_id > ?
					' . ($this->data['groupId'] ? (' AND group_id = ' . $db->quote($this->data['groupId'])) : '') . '
				ORDER BY user_id
			',
			$batch
		), $start);
	}

	/**
	 * @param int $id
	 *
	 * @throws \LogicException
	 * @throws \Exception
	 * @throws PrintableException
	 */
	protected function rebuildById($id): void
	{
		$user = \XF::app()->em()->find(User::class, $id);
		if (!$user)
		{
			return;
		}

		$groupIdCache = [];

		$memberships = \XF::app()->finder(GroupMemberFinder::class)
			->where('user_id', $user->user_id)
			->fetch()
		;
		foreach ($memberships AS $membership)
		{
			$groupIdCache[] = $membership->group_id;
		}

		$user->dbtech_social_groups_group_ids = $groupIdCache;
		$user->updateDbtechSocialGroupCounters();
		$user->updateDbtechSocialGroupInvitationCount();
		$user->save();
	}

	/**
	 * @return Phrase
	 */
	protected function getStatusType(): Phrase
	{
		return \XF::phrase('dbtech_social_groups_group_memberships');
	}
}