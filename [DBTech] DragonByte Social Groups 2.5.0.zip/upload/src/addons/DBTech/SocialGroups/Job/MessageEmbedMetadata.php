<?php

namespace DBTech\SocialGroups\Job;

use DBTech\SocialGroups\Entity\Message;
use XF\Job\AbstractEmbedMetadataJob;
use XF\Mvc\Entity\Entity;
use XF\Service\Message\PreparerService;

class MessageEmbedMetadata extends AbstractEmbedMetadataJob
{
	protected function getIdsToRebuild(array $types): array
	{
		$db = $this->app->db();

		return $db->fetchAllColumn($db->limit(
			"
				SELECT message_id
				FROM xf_dbtech_social_groups_message
				WHERE message_id > ?
				ORDER BY message_id
			",
			$this->data['batch']
		), $this->data['start']);
	}

	protected function getRecordToRebuild($id): ?Message
	{
		return $this->app->em()->find(Message::class, $id);
	}

	protected function getPreparerContext(): string
	{
		return 'dbtech_social_message';
	}

	protected function getMessageContent(Entity $record): string
	{
		/** @var Message $record */
		return $record->message;
	}

	protected function rebuildQuotes(Entity $record, PreparerService $preparer, array &$embedMetadata): void
	{
		$embedMetadata['quotes'] = $preparer->getEmbeddedQuotes();
	}

	protected function rebuildAttachments(Entity $record, PreparerService $preparer, array &$embedMetadata): void
	{
		$embedMetadata['attachments'] = $preparer->getEmbeddedAttachments();
	}

	protected function rebuildEmbeds(Entity $record, PreparerService $preparer, array &$embedMetadata): void
	{
		$embedMetadata['embeds'] = $preparer->getEmbeds();
	}

	protected function getActionDescription(): string
	{
		$rebuildPhrase = \XF::phrase('rebuilding');
		$type = \XF::phrase('dbtech_social_groups_messages');
		return sprintf('%s... %s', $rebuildPhrase, $type);
	}
}