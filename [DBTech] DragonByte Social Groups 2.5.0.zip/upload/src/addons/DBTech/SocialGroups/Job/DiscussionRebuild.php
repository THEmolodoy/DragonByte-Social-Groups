<?php

namespace DBTech\SocialGroups\Job;

use DBTech\SocialGroups\Entity\Discussion;
use DBTech\SocialGroups\Repository\DiscussionRepository;
use XF\Job\AbstractRebuildJob;
use XF\Phrase;
use XF\PrintableException;
use XF\Repository\ActivityLogRepository;

class DiscussionRebuild extends AbstractRebuildJob
{
	protected $defaultData = [
		'position_rebuild' => false,
	];

	/**
	 * @param int $start
	 * @param int $batch
	 *
	 * @return array
	 */
	protected function getNextIds($start, $batch): array
	{
		$db = \XF::app()->db();

		return $db->fetchAllColumn($db->limit(
			'
				SELECT discussion_id
				FROM xf_dbtech_social_groups_discussion
				WHERE discussion_id > ?
				ORDER BY discussion_id
			',
			$batch
		), $start);
	}

	/**
	 * @param int $id
	 *
	 * @throws \LogicException
	 * @throws \Exception
	 * @throws PrintableException
	 */
	protected function rebuildById($id): void
	{
		$discussion = \XF::app()->em()->find(Discussion::class, $id);
		if (!$discussion)
		{
			return;
		}

		$discussion->rebuildCounters();
		$discussion->save();

		$activityLogRepo = \XF::repository(ActivityLogRepository::class);
		$activityLogRepo->rebuildReplyMetrics($discussion);

		if ($this->data['position_rebuild'])
		{
			$discussionRepo = \XF::app()->repository(DiscussionRepository::class);
			$discussionRepo->rebuildDiscussionUserMessageCounters($id);
			$discussionRepo->rebuildDiscussionMessagePositions($id);
		}
	}

	/**
	 * @return Phrase
	 */
	protected function getStatusType(): Phrase
	{
		return \XF::phrase('dbtech_social_groups_social_group_discussions');
	}
}