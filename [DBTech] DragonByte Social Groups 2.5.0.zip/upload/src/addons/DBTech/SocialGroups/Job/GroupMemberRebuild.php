<?php

namespace DBTech\SocialGroups\Job;

use DBTech\SocialGroups\Entity\GroupMember;
use XF\Job\AbstractRebuildJob;
use XF\Phrase;
use XF\PrintableException;

class GroupMemberRebuild extends AbstractRebuildJob
{
	protected $defaultData = [
		'groupId' => null,
	];

	/**
	 * @param int $start
	 * @param int $batch
	 *
	 * @return array
	 */
	protected function getNextIds($start, $batch): array
	{
		$db = \XF::app()->db();

		return $db->fetchAllColumn($db->limit(
			'
				SELECT group_member_id
				FROM xf_dbtech_social_groups_group_member
				WHERE group_member_id > ?
					' . ($this->data['groupId'] ? (' AND group_id = ' . $db->quote($this->data['groupId'])) : '') . '
				ORDER BY group_member_id
			',
			$batch
		), $start);
	}

	/**
	 * @param int $id
	 *
	 * @throws \LogicException
	 * @throws \Exception
	 * @throws PrintableException
	 */
	protected function rebuildById($id): void
	{
		$member = \XF::app()->em()->find(GroupMember::class, $id);
		if (!$member)
		{
			return;
		}

		if ($member->rebuildCounters())
		{
			$member->save();
		}
	}

	/**
	 * @return Phrase
	 */
	protected function getStatusType(): Phrase
	{
		return \XF::phrase('dbtech_social_groups_group_members');
	}
}