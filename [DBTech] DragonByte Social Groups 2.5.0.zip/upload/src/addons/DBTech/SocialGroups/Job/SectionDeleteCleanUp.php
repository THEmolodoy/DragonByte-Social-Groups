<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\Job;

use DBTech\SocialGroups\Service\Section\DeleteCleanUpService;
use XF\Job\AbstractJob;

use function is_null;

class SectionDeleteCleanUp extends AbstractJob
{
	protected $defaultData = [
		'sectionId' => null,
		'title' => null,
		'userId' => null,

		'currentStep' => 0,
		'lastOffset' => null,

		'start' => 0,
	];

	public function run($maxRunTime)
	{
		$this->data['start']++;

		if (!$this->data['sectionId'] || $this->data['title'] === '' || is_null($this->data['title']))
		{
			return $this->complete();
		}

		$deleter = \XF::app()->service(
			DeleteCleanUpService::class,
			$this->data['sectionId'],
			$this->data['title'],
			$this->data['userId']
		);
		$deleter->restoreState($this->data['currentStep'], $this->data['lastOffset']);

		$result = $deleter->cleanUp($maxRunTime);
		if ($result->isCompleted())
		{
			return $this->complete();
		}
		else
		{
			$continueData = $result->getContinueData();
			$this->data['currentStep'] = $continueData['currentStep'];
			$this->data['lastOffset'] = $continueData['lastOffset'];

			return $this->resume();
		}
	}

	public function getStatusMessage()
	{
		$actionPhrase = \XF::phrase('deleting');
		$typePhrase = $this->data['title'];
		return sprintf('%s... %s (%s)', $actionPhrase, $typePhrase, $this->data['start']);
	}

	public function canCancel()
	{
		return false;
	}

	public function canTriggerByChoice()
	{
		return false;
	}
}