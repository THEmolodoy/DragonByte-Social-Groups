<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\Job;

use DBTech\SocialGroups\Service\Group\TransferService;
use XF\Entity\User;
use XF\Job\AbstractJob;

class TransferGroups extends AbstractJob
{
	protected $defaultData = [
		'toUserId' => null,
		'groupIds' => null,

		'currentStep' => 0,
		'lastOffset' => null,

		'start' => 0,
	];

	public function run($maxRunTime)
	{
		$this->data['start']++;

		if (!$this->data['toUserId'])
		{
			return $this->complete();
		}

		$toUser = \XF::app()->em()->find(User::class, $this->data['toUserId']);
		if (!$toUser)
		{
			return $this->complete();
		}

		$transferrer = \XF::app()->service(
			TransferService::class,
			$toUser,
			$this->data['groupIds']
		);
		$transferrer->restoreState($this->data['currentStep'], $this->data['lastOffset']);

		$result = $transferrer->transfer($maxRunTime);
		if ($result->isCompleted())
		{
			return $this->complete();
		}
		else
		{
			$continueData = $result->getContinueData();
			$this->data['currentStep'] = $continueData['currentStep'];
			$this->data['lastOffset'] = $continueData['lastOffset'];

			return $this->resume();
		}
	}

	public function getStatusMessage()
	{
		$actionPhrase = \XF::phrase('dbtech_social_groups_transferring');
		$typePhrase = \XF::phrase('dbtech_social_groups_social_groups');
		return sprintf('%s... %s (%s)', $actionPhrase, $typePhrase, $this->data['start']);
	}

	public function canCancel()
	{
		return false;
	}

	public function canTriggerByChoice()
	{
		return false;
	}
}