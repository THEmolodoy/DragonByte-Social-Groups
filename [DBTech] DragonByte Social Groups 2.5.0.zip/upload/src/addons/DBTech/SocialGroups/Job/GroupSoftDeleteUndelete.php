<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\Job;

use DBTech\SocialGroups\Entity\GroupMember;
use DBTech\SocialGroups\Finder\GroupMemberFinder;
use DBTech\SocialGroups\XF\Entity\User as ExtendedUserEntity;
use XF\Job\AbstractJob;
use XF\Job\JobResult;
use XF\PrintableException;

use function count;

class GroupSoftDeleteUndelete extends AbstractJob
{
	protected $defaultData = [
		'group_id' => null,
		'count' => 0,
		'total' => null,
		'lastOffset' => 0,
	];

	/**
	 * @param $maxRunTime
	 *
	 * @return JobResult
	 * @throws PrintableException
	 */
	public function run($maxRunTime)
	{
		$s = microtime(true);

		if (!$this->data['group_id'])
		{
			throw new \InvalidArgumentException('Cannot delete members without a group_id.');
		}

		$memberFinder = \XF::app()->finder(GroupMemberFinder::class)
			->where('group_id', $this->data['group_id'])
			->where('group_member_id', '>=', $this->data['lastOffset'])
		;

		if ($this->data['total'] === null)
		{
			$this->data['total'] = $memberFinder->total();
			if (!$this->data['total'])
			{
				return $this->complete();
			}
		}

		$memberIds = $memberFinder->pluckFrom('group_member_id')->fetch(1000)->toArray();
		if (!$memberIds)
		{
			return $this->complete();
		}

		$continue = !(count($memberIds) < 1000);

		foreach ($memberIds AS $memberId)
		{
			$this->data['count']++;
			$this->data['lastOffset'] = $memberId;

			$member = \XF::app()->em()->find(GroupMember::class, $memberId);
			if (!$member)
			{
				continue;
			}

			if (!$member->User)
			{
				$member->delete(false);
			}

			/** @var ExtendedUserEntity $user */
			$user = $member->User;
			$user->updateDbtechSocialGroupCounters();
			$user->save();

			if ($maxRunTime && microtime(true) - $s > $maxRunTime)
			{
				$continue = true;
				break;
			}
		}

		if ($continue)
		{
			return $this->resume();
		}
		else
		{
			return $this->complete();
		}
	}

	public function getStatusMessage()
	{
		$actionPhrase = \XF::phrase('rebuilding');
		$typePhrase = \XF::phrase('dbtech_social_groups_group_members');
		return sprintf(
			'%s... %s (%s/%s)',
			$actionPhrase,
			$typePhrase,
			\XF::language()->numberFormat($this->data['count']),
			\XF::language()->numberFormat($this->data['total'])
		);
	}

	public function canCancel()
	{
		return true;
	}

	public function canTriggerByChoice()
	{
		return false;
	}
}