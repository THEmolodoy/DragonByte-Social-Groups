<?php

namespace DBTech\SocialGroups\Service\Group;

use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Entity\GroupMember;
use DBTech\SocialGroups\Repository\GroupMemberRepository;
use DBTech\SocialGroups\Repository\GroupPermissionsRepository;
use DBTech\SocialGroups\Repository\GroupRepository;
use DBTech\SocialGroups\XF\Entity\User as ExtendedUserEntity;
use XF\App;
use XF\Entity\Forum;
use XF\Entity\Thread;
use XF\Entity\User;
use XF\PrintableException;
use XF\Service\AbstractService;
use XF\Service\Thread\CreatorService;

class ReassignService extends AbstractService
{
	protected Group $group;
	protected bool $alert = false;
	protected bool $startDiscussion = false;
	protected bool $logIp = true;
	protected bool $isAutomated = false;
	protected string $alertReason = '';


	/**
	 * @param App $app
	 * @param Group $group
	 */
	public function __construct(App $app, Group $group)
	{
		parent::__construct($app);
		$this->group = $group;
	}

	/**
	 * @return Group
	 */
	public function getGroup(): Group
	{
		return $this->group;
	}

	/**
	 * @param bool $logIp
	 */
	public function logIp(bool $logIp): void
	{
		$this->logIp = $logIp;
	}

	/**
	 *
	 */
	public function setIsAutomated(): void
	{
		$this->isAutomated = true;
		$this->logIp(false);
	}

	/**
	 * @param bool $alert
	 * @param string|null $reason
	 *
	 * @return $this
	 */
	public function setSendAlert(bool $alert, ?string $reason = null): ReassignService
	{
		$this->alert = $alert;
		if ($reason !== null)
		{
			$this->alertReason = $reason;
		}

		return $this;
	}

	/**
	 * @param bool $startDiscussion
	 *
	 * @return $this
	 */
	public function setStartDiscussion(bool $startDiscussion): ReassignService
	{
		$this->startDiscussion = $startDiscussion;

		return $this;
	}

	/**
	 * @param User $newUser
	 *
	 * @return bool
	 * @throws \LogicException
	 * @throws \Exception
	 * @throws PrintableException
	 */
	public function reassignTo(User $newUser): bool
	{
		/** @var ExtendedUserEntity $newUser */

		$options = \XF::options();
		$group = $this->group;

		/** @var ExtendedUserEntity $oldUser */
		$oldUser = $group->User;
		$reassigned = ($group->user_id != $newUser->user_id);

		$db = $this->db();

		$db->beginTransaction();

		$group->user_id = $newUser->user_id;
		$group->username = $newUser->username;
		$group->save(true, false);

		if (!$newUser->isMemberOfSocialGroup($group->group_id))
		{
			$groupMemberRepo = \XF::app()->repository(GroupMemberRepository::class);
			$groupMemberRepo->joinGroup($group, $newUser);
		}

		$db->commit();

		if ($reassigned)
		{
			$permissionsRepo = \XF::app()->repository(GroupPermissionsRepository::class);
			if ($oldUser && $oldUser->exists())
			{
				$permissionsRepo->deleteModeratorPermissionsForUserInGroup($oldUser, $group, false);
			}
			$permissionsRepo->addOwnerPermissionsForGroup($newUser, $group);
		}

		if ($reassigned && $this->alert)
		{
			if ($oldUser && \XF::visitor()->user_id != $oldUser->user_id && $oldUser->exists())
			{
				\XF::app()->repository(GroupRepository::class)
					->sendModeratorActionAlert(
						$group,
						'reassign_from',
						$this->alertReason,
						['to' => $newUser->username],
						$oldUser
					)
				;
			}

			if (\XF::visitor()->user_id != $newUser->user_id)
			{
				\XF::app()->repository(GroupRepository::class)
					->sendModeratorActionAlert(
						$group,
						'reassign_to',
						$this->alertReason,
						[],
						$newUser
					)
				;
			}
		}

		if ($reassigned)
		{
			/** @var GroupMember $groupMember */
			$groupMember = $group->Members[$newUser->user_id];

			\XF::app()->repository(GroupMemberRepository::class)
				->logAction(
					$groupMember,
					'ownership_transfer',
					[],
					$this->isAutomated ? null : \XF::visitor(),
					($this->logIp === true ? \XF::app()->request()->getIp() : $this->logIp)
				)
			;
		}

		if ($reassigned
			&& $this->startDiscussion
			&& $options->dbtechSocialTransferDiscussionEnabled
			&& $options->dbtechSocialTransferDiscussionStarter
			&& $options->dbtechSocialTransferDiscussionNodeId
		)
		{
			$user = \XF::app()->em()->find(User::class, $options->dbtechSocialTransferDiscussionStarter);
			$forum = \XF::app()->em()->find(Forum::class, $options->dbtechSocialTransferDiscussionNodeId);

			/** @var Thread $thread */
			$thread = \XF::asVisitor(
				$user,
				function () use ($forum)
				{
					$creator = $this->setupTransferThreadCreation($forum);
					if ($creator->validate($errors))
					{
						$creator->save();
					}
				}
			);
		}

		if ($reassigned)
		{
			// Rebuild both users' counters just to be safe
			if ($oldUser && $oldUser->exists())
			{
				$oldUser->updateDbtechSocialGroupCounters();
				$oldUser->save();
			}

			$newUser->updateDbtechSocialGroupCounters();
			$newUser->save();
		}

		return $reassigned;
	}

	protected function setupTransferThreadCreation(Forum $forum): CreatorService
	{
		$options = \XF::options();
		$group = $this->group;

		$language = \XF::app()->language(\XF::options()->defaultLanguageId);

		$creator = \XF::app()->service(CreatorService::class, $forum);
		$creator->setIsAutomated();

		$creator->setContent(
			$language->renderPhrase('dbtech_social_groups_new_owner_needed_x_title', [
				'group' => $group->title,
			]),
			$language->renderPhrase('dbtech_social_groups_new_owner_needed_x_message', [
				'link' => $group->getContentUrl(true),
				'group' => $group->title,
			]),
			false
		);
		$creator->setPrefix($options->dbtechSocialTransferDiscussionPrefixId);

		return $creator;
	}
}