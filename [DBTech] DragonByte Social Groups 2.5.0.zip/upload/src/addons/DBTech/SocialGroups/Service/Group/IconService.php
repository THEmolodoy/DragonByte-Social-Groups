<?php

namespace DBTech\SocialGroups\Service\Group;

use DBTech\SocialGroups\Entity\Group;
use League\Flysystem\FileExistsException;
use XF\App;
use XF\Http\Upload;
use XF\Image\AbstractDriver;
use XF\PrintableException;
use XF\Service\AbstractService;
use XF\Util\File;

use function count, in_array;

class IconService extends AbstractService
{
	protected Group $group;

	protected ?string $fileName;

	protected int $width;
	protected int $height;

	protected ?int $cropX = 0;
	protected ?int $cropY = 0;

	protected string $type;
	protected array $allowedTypes = [IMAGETYPE_GIF, IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_WEBP];
	protected array $sizeMap;

	protected mixed $error = null;
	protected bool $throwErrors = true;

	public const HIGH_DPI_THRESHOLD = 384;


	/**
	 * @param App $app
	 * @param Group $group
	 */
	public function __construct(App $app, Group $group)
	{
		parent::__construct($app);
		$this->setGroup($group);

		$this->sizeMap = \XF::app()->container('avatarSizeMap');
	}

	/**
	 * @param Group $group
	 *
	 * @return void
	 */
	protected function setGroup(Group $group): void
	{
		if ($group->group_id)
		{
			$this->group = $group;
		}
		else
		{
			throw new \LogicException("Group must be saved");
		}
	}

	/**
	 * @return mixed|null
	 */
	public function getError(): mixed
	{
		return $this->error;
	}

	/**
	 * @param bool $runSilent
	 *
	 * @return void
	 */
	public function silentRunning(bool $runSilent): void
	{
		$this->throwErrors = !$runSilent;
	}

	/**
	 * @param string $fileName
	 *
	 * @return bool
	 * @throws \Exception
	 */
	public function setImage(string $fileName): bool
	{
		if (!$this->validateImageAsIcon($fileName, $error))
		{
			$this->error = $error;
			$this->fileName = null;
			return false;
		}

		$this->fileName = $fileName;
		return true;
	}

	/**
	 * @param Upload $upload
	 *
	 * @return bool
	 * @throws \Exception
	 */
	public function setImageFromUpload(Upload $upload): bool
	{
		$upload->requireImage();

		if (!$upload->isValid($errors))
		{
			$this->error = reset($errors);
			return false;
		}

		if (!$upload->getTempFile())
		{
			$this->error = \XF::phraseDeferred('file_not_an_image');
			return false;
		}

		return $this->setImage($upload->getTempFile());
	}

	/**
	 * @return bool
	 * @throws \Exception
	 */
	public function setImageFromExisting(): bool
	{
		$path = $this->group->getAbstractedCustomIconPath('o');
		if (!\XF::app()->fs()->has($path))
		{
			return $this->throwException(new \InvalidArgumentException("Group does not have an 'o' icon ($path)"));
		}

		$tempFile = File::copyAbstractedPathToTempFile($path);
		return $this->setImage($tempFile);
	}

	/**
	 * Sets the cropping values. These coordinates must be scaled to the medium size icon (default 96px)!
	 * Using null will automatically crop at the middle.
	 *
	 * @param int|null $x
	 * @param int|null $y
	 */
	public function setCrop(?int $x, ?int $y): void
	{
		$this->cropX = $x;
		$this->cropY = $y;
	}

	public function getCrop(): array
	{
		return [$this->cropX, $this->cropY];
	}

	/**
	 * @param string $fileName
	 * @param $error
	 *
	 * @return bool
	 * @throws \Exception
	 */
	public function validateImageAsIcon(string $fileName, &$error = null): bool
	{
		$error = null;

		if (!file_exists($fileName))
		{
			return $this->throwException(new \InvalidArgumentException("Invalid file '$fileName' passed to icon service"));
		}
		if (!is_readable($fileName))
		{
			return $this->throwException(new \InvalidArgumentException("'$fileName' passed to icon service is not readable"));
		}

		$imageInfo = filesize($fileName) ? @getimagesize($fileName) : false;
		if (!$imageInfo)
		{
			$error = \XF::phrase('provided_file_is_not_valid_image');
			return false;
		}

		$type = $imageInfo[2];
		if (!in_array($type, $this->allowedTypes))
		{
			$error = \XF::phrase('provided_file_is_not_valid_image');
			return false;
		}

		$width = $imageInfo[0];
		$height = $imageInfo[1];

		if (!\XF::app()->imageManager()->canResize($width, $height))
		{
			$error = \XF::phrase('uploaded_image_is_too_big');
			return false;
		}

		$this->width = $width;
		$this->height = $height;
		$this->type = $type;

		return true;
	}

	/**
	 * @return bool
	 * @throws PrintableException
	 * @throws \Exception
	 */
	public function updateIcon(): bool
	{
		if (!$this->fileName)
		{
			return $this->throwException(new \LogicException("No source file for icon set"));
		}
		if (!$this->group->exists())
		{
			return $this->throwException(new \LogicException("Group does not exist, cannot update icon"));
		}

		$imageManager = \XF::app()->imageManager();

		$outputFiles = [];
		$baseFile = $this->fileName;

		$origSize = $this->sizeMap['o'];
		$shortSide = min($this->width, $this->height);

		if ($shortSide > $origSize)
		{
			$image = $imageManager->imageFromFile($this->fileName);
			if (!$image)
			{
				return false;
			}

			$image->resizeShortEdge($origSize);

			$newTempFile = File::getTempFile();
			if ($newTempFile && $image->save($newTempFile, null, 95))
			{
				$outputFiles['o'] = $newTempFile;
				$baseFile = $newTempFile;
				$width = $image->getWidth();
				$height = $image->getHeight();
			}
			else
			{
				return $this->throwException(new \RuntimeException("Failed to save image to temporary file; check internal_data/data permissions"));
			}

			unset($image);
		}
		else
		{
			$outputFiles['o'] = $this->fileName;
			$width = $this->width;
			$height = $this->height;
		}

		$crop = [
			'm' => [0, 0],
		];

		foreach ($this->sizeMap AS $code => $size)
		{
			if (isset($outputFiles[$code]))
			{
				continue;
			}

			$image = $imageManager->imageFromFile($baseFile);
			if (!$image)
			{
				continue;
			}

			$crop[$code] = $this->resizeIconImage($image, $size);

			$newTempFile = File::getTempFile();
			if ($newTempFile && $image->save($newTempFile))
			{
				$outputFiles[$code] = $newTempFile;
			}
			unset($image);
		}

		if (count($outputFiles) != count($this->sizeMap))
		{
			return $this->throwException(new \RuntimeException("Failed to save image to temporary file; image may be corrupt or check internal_data/data permissions"));
		}

		$group = $this->group;
		$group->icon_date = \XF::$time;
		$group->icon_hash = hash_hmac(
			'md5',
			$group->group_id . $group->icon_date,
			\XF::config('globalSalt')
		);
		$group->icon_width = $width;
		$group->icon_height = $height;
		$group->icon_highdpi = ($width >= self::HIGH_DPI_THRESHOLD && $height >= self::HIGH_DPI_THRESHOLD);
		$group->icon_crop_x = $crop['m'][0];
		$group->icon_crop_y = $crop['m'][1];

		foreach ($outputFiles AS $code => $file)
		{
			$dataFile = $this->group->getAbstractedCustomIconPath($code);
			File::copyFileToAbstractedPath($file, $dataFile);
		}

		$group->save();

		return true;
	}

	protected function resizeIconImage(AbstractDriver $image, int $size): array
	{
		$sizeMap = $this->sizeMap;

		$cropX = $this->cropX;
		$cropY = $this->cropY;
		$cropScaleRef = $sizeMap['m'];
		if ($cropX === null || $cropY === null)
		{
			$cropScale = $sizeMap['o'] / $cropScaleRef;
			$width = $image->getWidth();
			$height = $image->getHeight();

			$cropX = floor(
				(($width - $sizeMap['o']) / 2) / $cropScale
			);
			$cropY = floor(
				(($height - $sizeMap['o']) / 2) / $cropScale
			);
		}

		$cropX = max($cropX, 0);
		$cropY = max($cropY, 0);

		$image->resizeShortEdge($size, true);

		$cropScale = $size / $cropScaleRef;
		$thisCropX = floor($cropScale * $cropX);
		$thisCropY = floor($cropScale * $cropY);

		$widthOverage = $image->getWidth() - $size;
		if ($widthOverage)
		{
			$thisCropX = min($thisCropX, $widthOverage);
		}

		$heightOverage = $image->getHeight() - $size;
		if ($heightOverage)
		{
			$thisCropY = min($thisCropY, $heightOverage);
		}

		$image->crop($size, $size, $thisCropX, $thisCropY);

		return [$thisCropX, $thisCropY];
	}

	/**
	 * @return bool
	 * @throws FileExistsException
	 */
	public function createOSizeIconFromL(): bool
	{
		$group = $this->group;

		$l = $group->getAbstractedCustomIconPath('l');
		$o = $group->getAbstractedCustomIconPath('o');
		$fs = \XF::app()->fs();

		if (!$fs->has($l) || $fs->has($o))
		{
			return true;
		}

		$fs->copy($l, $o);

		$imageManager = \XF::app()->imageManager();
		$lSize = $this->sizeMap['l'];

		// temp file has original L image content
		$tempFile = File::copyAbstractedPathToTempFile($l);

		$success = false;

		try
		{
			$image = $imageManager->imageFromFile($tempFile);
			if ($image)
			{
				$this->resizeIconImage($image, $lSize);
				$image->save($tempFile);
				// temp file has new L image content
				$success = true;
			}
		}
		catch (\Exception $e)
		{
			\XF::logException($e, false, "Failed to update icon for group " . $group->group_id . ": ");
		}

		if ($success)
		{
			File::copyFileToAbstractedPath($tempFile, $l);
		}

		return true;
	}

	/**
	 * @return bool
	 * @throws PrintableException
	 */
	public function deleteIcon(): bool
	{
		$this->deleteIconFiles();

		$group = $this->group;
		$group->bulkSet([
			'icon_date' => 0,
			'icon_width' => 0,
			'icon_height' => 0,
			'icon_highdpi' => false,
			'icon_crop_x' => 0,
			'icon_crop_y' => 0,
		]);

		$group->save();

		return true;
	}

	/**
	 * @return bool
	 */
	public function deleteIconForGroupDelete(): bool
	{
		$this->deleteIconFiles();

		return true;
	}

	/**
	 * @return void
	 */
	protected function deleteIconFiles(): void
	{
		if ($this->group->icon_date)
		{
			foreach ($this->sizeMap AS $code => $size)
			{
				File::deleteFromAbstractedPath($this->group->getAbstractedCustomIconPath($code));
			}
		}
	}

	/**
	 * @param \Exception $error
	 *
	 * @return bool
	 * @throws \Exception
	 */
	protected function throwException(\Exception $error): bool
	{
		if ($this->throwErrors)
		{
			throw $error;
		}
		else
		{
			return false;
		}
	}
}