<?php

namespace DBTech\SocialGroups\Service\Group;

use DBTech\SocialGroups\Entity\GroupAlbum;
use DBTech\SocialGroups\Finder\GroupAlbumFinder;
use XF\Entity\User;
use XF\Mvc\Entity\AbstractCollection;
use XF\Mvc\Entity\Finder;
use XF\Mvc\Entity\Manager;
use XF\Mvc\Entity\Repository;
use XF\PrintableException;
use XF\Repository\UserRepository;

use function count;

/**
 * @property int userId
 * @property int groupId
 *
 * @method Manager em()
 * @method Repository repository(string $repository)
 * @method Finder finder(string $identifier)
 */
trait StepDeleteAlbumsTrait
{
	protected bool $skipDeleteAlbums = false;
	protected bool $unlinkAlbums = false;
	protected bool $onlyUser = false;
	protected bool $updateMembership = false;

	/**
	 * @param bool $skip
	 *
	 * @return void
	 */
	public function setSkipDeleteAlbums(bool $skip): void
	{
		$this->skipDeleteAlbums = $skip;
	}

	/**
	 * @param bool $unlink
	 *
	 * @return void
	 */
	public function setUnlinkAlbums(bool $unlink): void
	{
		$this->unlinkAlbums = $unlink;
	}

	/**
	 * @param bool $onlyUser
	 *
	 * @return void
	 */
	public function setOnlyUser(bool $onlyUser): void
	{
		$this->onlyUser = $onlyUser;
	}

	/**
	 * @param bool $updateMembership
	 *
	 * @return void
	 */
	public function setUpdateMembership(bool $updateMembership): void
	{
		$this->updateMembership = $updateMembership;
	}

	/**
	 * @param int|null $lastOffset
	 * @param float|int $maxRunTime
	 *
	 * @return int|null
	 * @throws \InvalidArgumentException
	 * @throws \LogicException
	 * @throws PrintableException
	 * @throws \Exception
	 */
	protected function stepDeleteAlbums(?int $lastOffset, float|int $maxRunTime): ?int
	{
		if ($this->skipDeleteAlbums)
		{
			return null;
		}

		$start = microtime(true);

		$user = \XF::app()->em()->find(User::class, $this->userId);
		$user = $user ?: \XF::app()->repository(UserRepository::class)
			->getGuestUser()
		;

		$finder = \XF::app()->finder(GroupAlbumFinder::class)
			->with('Album')
			->where('group_id', $this->groupId)
			->order('album_id');

		if ($this->onlyUser)
		{
			$finder->where('Album.user_id', $this->userId);
		}

		if ($lastOffset !== null)
		{
			$finder->where('album_id', '>', $lastOffset);
		}

		$maxFetch = 1000;

		/** @var AbstractCollection<GroupAlbum> $groupAlbums */
		$groupAlbums = $finder->fetch($maxFetch);
		$fetchedGroupAlbums = count($groupAlbums);

		if (!$fetchedGroupAlbums)
		{
			return null; // done or nothing to do
		}

		foreach ($groupAlbums AS $groupAlbum)
		{
			$lastOffset = $groupAlbum->album_id;

			if (\XF::options()->dbtechSocialEnableMediaGallery
				&& \XF::isAddOnActive('XFMG')
				&& $groupAlbum->Album
				&& !$this->unlinkAlbums
			)
			{
				// Only delete the associated album if the integration is enabled and we're not unlinking
				$groupAlbum->Album->delete();
			}

			\XF::asVisitor($user, function () use ($groupAlbum)
			{
				$groupAlbum->setOption('updateMembership', $this->updateMembership);
				$groupAlbum->delete();
			});

			if ($maxRunTime && microtime(true) - $start > $maxRunTime)
			{
				return $lastOffset; // continue at this position
			}
		}

		if ($fetchedGroupAlbums == $maxFetch)
		{
			return $lastOffset; // more to do
		}

		return null;
	}
}