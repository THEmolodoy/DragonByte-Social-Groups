<?php

namespace DBTech\SocialGroups\Service\Group;

use DBTech\SocialGroups\Entity\Group;
use XF\App;
use XF\Http\Upload;
use XF\PrintableException;
use XF\Service\AbstractService;
use XF\Util\File;

use function count, in_array;

class BannerService extends AbstractService
{
	protected Group $group;

	protected ?string $fileName;

	protected string $type;
	protected array $allowedTypes = [IMAGETYPE_GIF, IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_WEBP];
	protected array $sizeMap;

	protected mixed $error = null;
	protected bool $throwErrors = true;


	/**
	 * @param App $app
	 * @param Group $group
	 */
	public function __construct(App $app, Group $group)
	{
		parent::__construct($app);
		$this->setGroup($group);

		$this->sizeMap = \XF::app()->container('profileBannerSizeMap');
	}

	/**
	 * @param Group $group
	 *
	 * @return void
	 */
	protected function setGroup(Group $group): void
	{
		if ($group->group_id)
		{
			$this->group = $group;
		}
		else
		{
			throw new \LogicException("Group must be saved");
		}
	}

	/**
	 * @return mixed
	 */
	public function getError(): mixed
	{
		return $this->error;
	}

	/**
	 * @param bool $runSilent
	 *
	 * @return void
	 */
	public function silentRunning(bool $runSilent): void
	{
		$this->throwErrors = !$runSilent;
	}

	/**
	 * @param string $fileName
	 *
	 * @return bool
	 * @throws \Exception
	 */
	public function setImage(string $fileName): bool
	{
		if (!$this->validateImageAsBanner($fileName, $error))
		{
			$this->error = $error;
			$this->fileName = null;
			return false;
		}

		$this->fileName = $fileName;
		return true;
	}

	/**
	 * @param Upload $upload
	 *
	 * @return bool
	 * @throws \Exception
	 */
	public function setImageFromUpload(Upload $upload): bool
	{
		$upload->requireImage();

		if (!$upload->isValid($errors))
		{
			$this->error = reset($errors);
			return false;
		}

		return $this->setImage($upload->getTempFile());
	}

	/**
	 * @param string $fileName
	 * @param mixed $error
	 *
	 * @return bool
	 * @throws \Exception
	 */
	public function validateImageAsBanner(string $fileName, mixed &$error = null): bool
	{
		$error = null;

		if (!file_exists($fileName))
		{
			return $this->throwException(new \InvalidArgumentException("Invalid file '$fileName' passed to banner service"));
		}
		if (!is_readable($fileName))
		{
			return $this->throwException(new \InvalidArgumentException("'$fileName' passed to banner service is not readable"));
		}

		$imageInfo = filesize($fileName) ? @getimagesize($fileName) : false;
		if (!$imageInfo)
		{
			$error = \XF::phrase('provided_file_is_not_valid_image');
			return false;
		}

		$type = $imageInfo[2];
		if (!in_array($type, $this->allowedTypes))
		{
			$error = \XF::phrase('provided_file_is_not_valid_image');
			return false;
		}

		$width = $imageInfo[0];
		$height = $imageInfo[1];

		if (!\XF::app()->imageManager()->canResize($width, $height))
		{
			$error = \XF::phrase('uploaded_image_is_too_big');
			return false;
		}

		$this->type = $type;

		return true;
	}

	/**
	 * @return bool
	 * @throws \Exception
	 */
	public function updateBanner(): bool
	{
		if (!$this->fileName)
		{
			return $this->throwException(new \LogicException("No source file for banner set"));
		}
		if (!$this->group->exists())
		{
			return $this->throwException(new \LogicException("User does not exist, cannot update banner"));
		}

		$imageManager = \XF::app()->imageManager();

		$outputFiles = [];

		foreach ($this->sizeMap AS $size => $width)
		{
			$image = $imageManager->imageFromFile($this->fileName);
			if (!$image)
			{
				continue;
			}

			$image->resizeWidth($width, true);

			$newTempFile = File::getTempFile();
			if ($newTempFile && $image->save($newTempFile, null, 95))
			{
				$outputFiles[$size] = $newTempFile;
			}
			unset($image);
		}

		if (count($outputFiles) != count($this->sizeMap))
		{
			return $this->throwException(new \RuntimeException("Failed to save image to temporary file; image may be corrupt or check internal_data/data permissions"));
		}

		$group = $this->group;
		$group->banner_position_y = 50;
		$group->banner_date = \XF::$time;
		$group->banner_hash = hash_hmac(
			'md5',
			$group->group_id . $group->banner_date,
			\XF::config('globalSalt')
		);

		foreach ($outputFiles AS $code => $file)
		{
			$dataFile = $this->group->getAbstractedBannerPath($code);
			File::copyFileToAbstractedPath($file, $dataFile);
		}

		$group->save();

		return true;
	}

	/**
	 * @param int $y
	 *
	 * @return bool
	 * @throws PrintableException
	 */
	public function setPosition(int $y): bool
	{
		$group = $this->group;
		$group->bulkSet([
			'banner_position_y' => $y,
		]);

		$group->save();

		return true;
	}

	/**
	 * @return bool
	 * @throws PrintableException
	 */
	public function deleteBanner(): bool
	{
		$this->deleteBannerFiles();

		$group = $this->group;
		$group->bulkSet([
			'banner_date' => 0,
			'banner_position_y' => null,
		]);

		$group->save();

		return true;
	}

	/**
	 * @return bool
	 */
	public function deleteBannerForGroupDelete(): bool
	{
		$this->deleteBannerFiles();

		return true;
	}

	/**
	 * @return void
	 */
	protected function deleteBannerFiles(): void
	{
		if ($this->group->banner_date)
		{
			foreach ($this->sizeMap AS $code => $size)
			{
				File::deleteFromAbstractedPath($this->group->getAbstractedBannerPath($code));
			}
		}
	}

	/**
	 * @param \Exception $error
	 *
	 * @return bool
	 * @throws \Exception
	 */
	protected function throwException(\Exception $error): bool
	{
		if ($this->throwErrors)
		{
			throw $error;
		}
		else
		{
			return false;
		}
	}
}