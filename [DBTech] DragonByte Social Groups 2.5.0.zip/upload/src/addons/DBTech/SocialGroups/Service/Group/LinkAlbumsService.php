<?php

namespace DBTech\SocialGroups\Service\Group;

use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Entity\GroupAlbum;
use DBTech\SocialGroups\Job\GroupMemberRebuild;
use DBTech\SocialGroups\XF\Entity\User as ExtendedUserEntity;
use XF\App;
use XF\Db\DuplicateKeyException;
use XF\PrintableException;
use XF\Service\AbstractService;
use XF\Service\ValidateAndSavableTrait;
use XFMG\Entity\Album;

use function count, in_array;

class LinkAlbumsService extends AbstractService
{
	use ValidateAndSavableTrait;

	protected Group $group;
	protected array $albumIds;

	/** @var GroupAlbum[] */
	protected array $groupAlbums = [];


	/**
	 * @param App $app
	 * @param Group $group
	 * @param array $albumIds
	 */
	public function __construct(App $app, Group $group, array $albumIds)
	{
		parent::__construct($app);
		$this->albumIds = \array_unique($albumIds);
		$this->setGroup($group);
	}

	/**
	 * @param Group $group
	 *
	 * @return void
	 */
	protected function setGroup(Group $group): void
	{
		if ($group->group_id)
		{
			$this->group = $group;
		}
		else
		{
			throw new \LogicException("Group must be saved");
		}
	}

	/**
	 *
	 */
	protected function finalSetup(&$errors)
	{
	}

	/**
	 * @return array
	 */
	protected function _validate(): array
	{
		$group = $this->group;

		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		$albumIds = [];

		$errors = [];
		foreach ($this->albumIds AS $albumIdOrLink)
		{
			if (empty($albumIdOrLink))
			{
				continue;
			}

			if (is_numeric($albumIdOrLink))
			{
				$album = \XF::app()->em()->find(Album::class, $albumIdOrLink, ['SocialGroupAlbum']);
				if (!$album)
				{
					$errors[] = \XF::phraseDeferred('dbtech_social_groups_no_album_could_be_found_with_id_x', [
						'id' => $albumIdOrLink,
					]);
					continue;
				}
			}
			else
			{
				$routePath = \XF::app()->request()->getRoutePathFromUrl($albumIdOrLink);
				$routeMatch = \XF::app()->router('public')->routeToController($routePath);
				$params = $routeMatch->getParameterBag();

				if (!$params['album_id'])
				{
					$errors[] = \XF::phraseDeferred('dbtech_social_groups_no_album_id_could_be_found_from_url_x', [
						'url' => $albumIdOrLink,
					]);
					continue;
				}

				$album = \XF::app()->em()->find(Album::class, $params['album_id'], ['SocialGroupAlbum']);
				if (!$album)
				{
					$errors[] = \XF::phraseDeferred('dbtech_social_groups_no_album_could_be_found_with_id_x', [
						'id' => $params['album_id'],
					]);
					continue;
				}
			}

			//			if ($album->view_privacy !== 'public')
			//			{
			//				$errors[] = \XF::phraseDeferred('dbtech_social_groups_album_x_must_be_public_privacy', [
			//					'album' => $album->title
			//				]);
			//				continue;
			//			}

			if ($album->SocialGroupAlbum)
			{
				if ($album->SocialGroupAlbum->group_id !== $group->group_id)
				{
					$errors[] = \XF::phraseDeferred('dbtech_social_groups_album_x_linked_another_group', [
						'album' => $album->title,
					]);
				}

				continue;
			}

			if (
				(
					!$group->canEditAnyAlbum()
					|| !$album->hasPermission('moveAnyAlbum')
				)
				&& $album->user_id !== $visitor->user_id
			)
			{
				$errors[] = \XF::phraseDeferred('dbtech_social_groups_you_do_not_own_album_x', [
					'album' => $album->title,
				]);
				continue;
			}

			if (in_array($album->album_id, $albumIds))
			{
				continue;
			}

			$albumIds[] = $album->album_id;
			$groupAlbum = $group->getNewAlbum($album);

			$groupAlbum->preSave();
			$errors = \array_merge($errors, $groupAlbum->getErrors());

			$this->groupAlbums[] = $groupAlbum;
		}

		if (count($errors))
		{
			return $errors;
		}

		$numInserts = count($this->groupAlbums);
		if (!$numInserts)
		{
			$errors[] = \XF::phraseDeferred('dbtech_social_groups_nothing_to_do');
		}
		else
		{
			$maxAlbumsPerGroup = $visitor->hasPermission('dbtechSocial', 'maxAlbumsPerGroup');
			if (
				$maxAlbumsPerGroup !== -1
				&& (($visitor->SocialGroupMemberships[$group->group_id]->album_count + $numInserts) >= $maxAlbumsPerGroup)
			)
			{
				$errors[] = \XF::phraseDeferred('dbtech_social_groups_can_only_create_x_more_albums_this_group', [
					'count' => $maxAlbumsPerGroup - $visitor->SocialGroupMemberships[$group->group_id]->album_count,
				]);
			}
		}

		$this->finalSetup($errors);

		return $errors;
	}

	/**
	 * @throws PrintableException
	 */
	protected function _save(): void
	{
		$db = $this->db();
		$db->beginTransaction();

		foreach ($this->groupAlbums AS $groupAlbum)
		{
			try
			{
				$groupAlbum->setOption('updateMembership', true);
				$groupAlbum->save(true, false);
			}
			/** @noinspection PhpRedundantCatchClauseInspection */
			catch (DuplicateKeyException $e)
			{
			}
		}

		$this->afterLink();

		$db->commit();
	}

	/**
	 * @return void
	 */
	protected function afterLink(): void
	{
		\XF::app()->jobManager()->enqueue(
			GroupMemberRebuild::class,
			['group_id' => $this->group->group_id]
		);
	}
}