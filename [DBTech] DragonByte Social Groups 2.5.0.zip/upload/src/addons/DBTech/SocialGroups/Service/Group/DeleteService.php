<?php

namespace DBTech\SocialGroups\Service\Group;

use DBTech\SocialGroups\Entity\Group;
use XF\App;
use XF\Entity\User;
use XF\PrintableException;
use XF\Service\AbstractService;

class DeleteService extends AbstractService
{
	protected Group $group;
	protected User $user;

	/**
	 * @param App $app
	 * @param Group $group
	 */
	public function __construct(App $app, Group $group)
	{
		parent::__construct($app);
		$this->group = $group;
		$this->user = \XF::visitor();
	}

	/**
	 * @return Group
	 */
	public function getGroup(): Group
	{
		return $this->group;
	}

	public function setUser(User $user): DeleteService
	{
		$this->user = $user;

		return $this;
	}

	public function getUser(): User
	{
		return $this->user;
	}

	/**
	 * @param string $type
	 * @param string $reason
	 *
	 * @return bool
	 * @throws \InvalidArgumentException
	 * @throws \LogicException
	 * @throws \Exception
	 * @throws PrintableException
	 */
	public function delete(string $type, string $reason = ''): bool
	{
		$user = $this->user;

		if ($type == 'soft')
		{
			$result = $this->group->softDelete($reason, $user);
		}
		else
		{
			$result = $this->group->delete();
		}

		return $result;
	}

	/**
	 * @return bool
	 * @throws \LogicException
	 * @throws \Exception
	 * @throws PrintableException
	 */
	public function unDelete(): bool
	{
		$user = $this->user;
		$wasDeleted = $this->group->group_state == 'deleted';

		return $this->group->unDelete($user);
	}
}