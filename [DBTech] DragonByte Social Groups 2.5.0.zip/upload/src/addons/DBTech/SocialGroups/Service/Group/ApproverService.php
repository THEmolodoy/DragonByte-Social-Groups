<?php

namespace DBTech\SocialGroups\Service\Group;

use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Repository\GroupRepository;
use XF\App;
use XF\PrintableException;
use XF\Service\AbstractService;

class ApproverService extends AbstractService
{
	protected Group $group;
	protected bool $notify = true;
	protected int $notifyRunTime = 3;
	protected string $reason = '';


	/**
	 * @param App $app
	 * @param Group $group
	 */
	public function __construct(App $app, Group $group)
	{
		parent::__construct($app);
		$this->group = $group;
	}

	/**
	 * @return Group
	 */
	public function getGroup(): Group
	{
		return $this->group;
	}

	/**
	 * @param bool $notify
	 *
	 * @return $this
	 */
	public function setNotify(bool $notify): ApproverService
	{
		$this->notify = $notify;

		return $this;
	}

	/**
	 * @param int $time
	 *
	 * @return $this
	 */
	public function setNotifyRunTime(int $time): ApproverService
	{
		$this->notifyRunTime = $time;

		return $this;
	}

	/**
	 * @param string $reason
	 *
	 * @return $this
	 */
	public function setReason(string $reason): ApproverService
	{
		$this->reason = $reason;

		return $this;
	}

	/**
	 * @return bool
	 * @throws \LogicException
	 * @throws \Exception
	 * @throws PrintableException
	 */
	public function approve(): bool
	{
		if ($this->group->group_state == 'moderated')
		{
			$this->group->group_state = 'visible';
			$this->group->save();

			$this->onApprove();
			return true;
		}

		return false;
	}

	/**
	 * @return bool
	 * @throws \LogicException
	 * @throws \Exception
	 * @throws PrintableException
	 */
	public function reject(): bool
	{
		if ($this->group->group_state == 'moderated')
		{
			$this->group->softDelete();

			$this->onReject();
			return true;
		}

		return false;
	}

	/**
	 *
	 */
	protected function onApprove(): void
	{
		$group = $this->group;
		$user = $group->User;

		if ($this->notify)
		{
			$groupRepo = \XF::app()->repository(GroupRepository::class);
			$groupRepo->sendModeratorActionAlert($this->group, 'approve', $this->reason, [], $user);
		}
	}

	/**
	 * @throws \Exception
	 */
	protected function onReject(): void
	{
		$group = $this->group;
		$user = $group->User;

		if ($this->notify)
		{
			$groupRepo = \XF::app()->repository(GroupRepository::class);
			$groupRepo->sendModeratorActionAlert($group, 'reject', $this->reason, [], $user);
		}
	}
}