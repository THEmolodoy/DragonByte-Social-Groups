<?php

namespace DBTech\SocialGroups\Service\Group;

use DBTech\SocialGroups\Finder\DiscussionFinder;
use DBTech\SocialGroups\Finder\GroupMemberFinder;
use DBTech\SocialGroups\Finder\SectionFinder;
use XF\App;
use XF\ContinuationResult;
use XF\MultiPartRunnerTrait;
use XF\PrintableException;
use XF\Service\AbstractService;

use function count, is_array;

class DeleteCleanUpService extends AbstractService
{
	use StepDeleteAlbumsTrait;
	use MultiPartRunnerTrait;

	protected int $groupId;
	protected string $title;
	protected int $userId;

	protected array $steps = [
		'stepDeleteContent',
		'stepDeleteGroupMembers',
		'stepDeleteSections',
		'stepDeleteDiscussions',
		'stepDeleteAlbums',
	];

	protected array $deletes = [
		'xf_dbtech_social_groups_group_ban' => 'group_id = ?',
		'xf_dbtech_social_groups_group_invite' => 'group_id = ?',
		'xf_dbtech_social_groups_group_read' => 'group_id = ?',
		'xf_dbtech_social_groups_group_watch' => 'group_id = ?',
	];


	/**
	 * @param App $app
	 * @param int $groupId
	 * @param string $title
	 * @param int $userId
	 */
	public function __construct(App $app, int $groupId, string $title, int $userId)
	{
		parent::__construct($app);

		$this->groupId = $groupId;
		$this->title = $title;
		$this->userId = $userId;
	}

	/**
	 * @return array
	 */
	protected function getSteps(): array
	{
		return $this->steps;
	}

	/**
	 * @param float|int $maxRunTime
	 *
	 * @return ContinuationResult
	 */
	public function cleanUp(float|int $maxRunTime = 0): ContinuationResult
	{
		$this->db()->beginTransaction();
		$result = $this->runLoop($maxRunTime);
		$this->db()->commit();

		return $result;
	}

	/**
	 * @param int|null $lastOffset
	 * @param float|int $maxRunTime
	 *
	 * @return int|null
	 */
	protected function stepDeleteContent(?int $lastOffset, float|int $maxRunTime): ?int
	{
		$db = $this->db();

		$lastOffset = $lastOffset === null ? -1 : $lastOffset;
		$thisOffset = -1;
		$start = microtime(true);

		foreach ($this->deletes AS $table => $actions)
		{
			$thisOffset++;
			if ($thisOffset <= $lastOffset)
			{
				continue;
			}

			if (!is_array($actions))
			{
				$actions = [$actions];
			}

			foreach ($actions AS $action)
			{
				$db->delete($table, $action, $this->userId);
			}

			$lastOffset = $thisOffset;
			if ($maxRunTime && microtime(true) - $start > $maxRunTime)
			{
				return $lastOffset; // continue at this position
			}
		}

		return null;
	}

	/**
	 * @param int|null $lastOffset
	 * @param float|int $maxRunTime
	 *
	 * @return int|null
	 * @throws \InvalidArgumentException
	 * @throws \LogicException
	 * @throws PrintableException
	 */
	protected function stepDeleteGroupMembers(?int $lastOffset, float|int $maxRunTime): ?int
	{
		$start = microtime(true);

		$finder = \XF::app()->finder(GroupMemberFinder::class)
			->where('group_id', $this->groupId)
			->order('group_member_id');

		if ($lastOffset !== null)
		{
			$finder->where('group_member_id', '>', $lastOffset);
		}

		$maxFetch = 1000;
		$groupMembers = $finder->fetch($maxFetch);
		$fetchedGroupMembers = count($groupMembers);

		if (!$fetchedGroupMembers)
		{
			return null; // done or nothing to do
		}

		foreach ($groupMembers AS $groupMember)
		{
			$lastOffset = $groupMember->group_member_id;

			//			$groupMember->setOption('log_moderator', false);
			$groupMember->delete();

			if ($maxRunTime && microtime(true) - $start > $maxRunTime)
			{
				return $lastOffset; // continue at this position
			}
		}

		if ($fetchedGroupMembers == $maxFetch)
		{
			return $lastOffset; // more to do
		}

		return null;
	}

	/**
	 * @param int|null $lastOffset
	 * @param float|int $maxRunTime
	 *
	 * @return int|null
	 * @throws \InvalidArgumentException
	 * @throws \LogicException
	 * @throws PrintableException
	 */
	protected function stepDeleteSections(?int $lastOffset, float|int $maxRunTime): ?int
	{
		$start = microtime(true);

		$finder = \XF::app()->finder(SectionFinder::class)
			->where('group_id', $this->groupId)
			->order('section_id');

		if ($lastOffset !== null)
		{
			$finder->where('section_id', '>', $lastOffset);
		}

		$maxFetch = 1000;
		$sections = $finder->fetch($maxFetch);
		$fetchedSections = count($sections);

		if (!$fetchedSections)
		{
			return null; // done or nothing to do
		}

		foreach ($sections AS $section)
		{
			$lastOffset = $section->section_id;

			$section->delete();

			if ($maxRunTime && microtime(true) - $start > $maxRunTime)
			{
				return $lastOffset; // continue at this position
			}
		}

		if ($fetchedSections == $maxFetch)
		{
			return $lastOffset; // more to do
		}

		return null;
	}

	/**
	 * @param int|null $lastOffset
	 * @param float|int $maxRunTime
	 *
	 * @return int|null
	 * @throws \InvalidArgumentException
	 * @throws \LogicException
	 * @throws PrintableException
	 */
	protected function stepDeleteDiscussions(?int $lastOffset, float|int $maxRunTime): ?int
	{
		$start = microtime(true);

		$finder = \XF::app()->finder(DiscussionFinder::class)
			->where('group_id', $this->groupId)
			->order('discussion_id');

		if ($lastOffset !== null)
		{
			$finder->where('discussion_id', '>', $lastOffset);
		}

		$maxFetch = 1000;
		$discussions = $finder->fetch($maxFetch);
		$fetchedDiscussions = count($discussions);

		if (!$fetchedDiscussions)
		{
			return null; // done or nothing to do
		}

		foreach ($discussions AS $discussion)
		{
			$lastOffset = $discussion->discussion_id;

			$discussion->setOption('log_moderator', false);
			$discussion->delete();

			if ($maxRunTime && microtime(true) - $start > $maxRunTime)
			{
				return $lastOffset; // continue at this position
			}
		}

		if ($fetchedDiscussions == $maxFetch)
		{
			return $lastOffset; // more to do
		}

		return null;
	}
}