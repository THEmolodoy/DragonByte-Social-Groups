<?php

namespace DBTech\SocialGroups\Service\Group;

use XF\App;
use XF\ContinuationResult;
use XF\MultiPartRunnerTrait;
use XF\Service\AbstractService;

class SoftDeleteCleanUpService extends AbstractService
{
	use StepDeleteAlbumsTrait;
	use MultiPartRunnerTrait;

	protected int $groupId;
	protected string $title;
	protected int $userId;

	protected array $steps = [
		'stepDeleteAlbums',
	];


	/**
	 * @param App $app
	 * @param int $groupId
	 * @param string $title
	 * @param int $userId
	 */
	public function __construct(App $app, int $groupId, string $title, int $userId)
	{
		parent::__construct($app);

		$this->groupId = $groupId;
		$this->title = $title;
		$this->userId = $userId;

		$this->setUpdateMembership(true);
	}

	/**
	 * @return array
	 */
	protected function getSteps(): array
	{
		return $this->steps;
	}

	/**
	 * @param float|int $maxRunTime
	 *
	 * @return ContinuationResult
	 */
	public function cleanUp(float|int $maxRunTime = 0): ContinuationResult
	{
		$this->db()->beginTransaction();
		$result = $this->runLoop($maxRunTime);
		$this->db()->commit();

		return $result;
	}
}