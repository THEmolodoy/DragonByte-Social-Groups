<?php

namespace DBTech\SocialGroups\Service\Group;

use DBTech\SocialGroups\Entity\Group;
use NF\Calendar\Entity\Calendar;
use XF\App;
use XF\PrintableException;
use XF\Service\AbstractService;
use XF\Service\ValidateAndSavableTrait;

class CalendarCreatorService extends AbstractService
{
	use ValidateAndSavableTrait;

	protected Group $group;
	protected Calendar $calendar;


	/**
	 * @param App $app
	 * @param Group $group
	 */
	public function __construct(App $app, Group $group)
	{
		parent::__construct($app);
		$this->group = $group;

		$this->setupDefaults();
	}

	protected function setupDefaults(): void
	{
		$this->calendar = $this->group->getNewCalendar();
	}

	/**
	 * @return Group
	 */
	public function getGroup(): Group
	{
		return $this->group;
	}

	/**
	 *
	 */
	protected function finalSetup(&$errors): void
	{
		$this->calendar->title = $this->group->title;
		$this->calendar->type_config = [
			'group_id' => $this->group->group_id,
		];
	}

	/**
	 * @return array
	 */
	protected function _validate(): array
	{
		$group = $this->group;

		$group->preSave();
		$errors = $group->getErrors();

		$this->finalSetup($errors);

		return $errors;
	}

	/**
	 * @throws PrintableException
	 */
	protected function _save(): void
	{
		$db = $this->db();
		$db->beginTransaction();

		$this->calendar->save(true, false);

		$this->group->set('calendar_id', $this->calendar->category_id, ['forceSet' => true]);
		$this->group->save(true, false);

		$this->afterCreate();

		$db->commit();
	}

	/**
	 * @return void
	 */
	protected function afterCreate()
	{
	}
}