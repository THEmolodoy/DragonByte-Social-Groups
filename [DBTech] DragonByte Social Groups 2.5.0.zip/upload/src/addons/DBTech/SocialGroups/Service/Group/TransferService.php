<?php

namespace DBTech\SocialGroups\Service\Group;

use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Finder\GroupFinder;
use XF\App;
use XF\ContinuationResult;
use XF\Entity\User;
use XF\MultiPartRunnerTrait;
use XF\Mvc\Entity\AbstractCollection;
use XF\PrintableException;
use XF\Service\AbstractService;

class TransferService extends AbstractService
{
	use MultiPartRunnerTrait;

	protected User $toUser;
	protected array $groupIds;

	protected array $steps = [
		'stepTransferGroups',
	];

	public function __construct(App $app, User $toUser, array $groupIds)
	{
		parent::__construct($app);

		$this->toUser = $toUser;
		$this->groupIds = $groupIds;
	}

	protected function getSteps(): array
	{
		return $this->steps;
	}

	public function transfer($maxRunTime = 0): ContinuationResult
	{
		return $this->runLoop($maxRunTime);
	}

	/**
	 * @param $lastOffset
	 * @param $maxRunTime
	 *
	 * @return int|mixed|null
	 * @throws PrintableException
	 */
	protected function stepTransferGroups($lastOffset, $maxRunTime): mixed
	{
		$start = microtime(true);

		$groupFinder = \XF::app()->finder(GroupFinder::class)
			->where('group_id', $this->groupIds)
			->order('group_id');

		if ($lastOffset !== null)
		{
			$groupFinder->where('group_id', '>', $lastOffset);
		}

		$maxFetch = 1000;

		/** @var AbstractCollection<Group> $groups */
		$groups = $groupFinder->fetch($maxFetch);

		if (!$groups->count())
		{
			return null;
		}

		foreach ($groups AS $group)
		{
			$lastOffset = $group->group_id;
			$options = \XF::options();

			$startDiscussion = (
				$group->group_type !== 'hidden'
				&& (
					!$options->dbtechSocialTransferDefaultRecipient
					|| $options->dbtechSocialTransferDefaultRecipient == $this->toUser->user_id
				)
			);

			$reassigner = \XF::app()->service(ReassignService::class, $group);
			$reassigner->setIsAutomated();
			$reassigner->setSendAlert(true);
			$reassigner->setStartDiscussion($startDiscussion);
			$reassigner->reassignTo($this->toUser);

			if ($maxRunTime && ((microtime(true) - $start) > $maxRunTime))
			{
				return $lastOffset;
			}
		}

		if ($groups->count() == $maxFetch)
		{
			return $lastOffset;
		}

		return null;
	}
}