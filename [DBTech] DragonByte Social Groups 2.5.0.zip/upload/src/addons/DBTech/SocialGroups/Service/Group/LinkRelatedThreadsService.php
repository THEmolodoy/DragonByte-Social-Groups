<?php

namespace DBTech\SocialGroups\Service\Group;

use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Entity\RelatedThread;
use DBTech\SocialGroups\XF\Entity\User as ExtendedUserEntity;
use XF\App;
use XF\Entity\Thread;
use XF\PrintableException;
use XF\Service\AbstractService;
use XF\Service\ValidateAndSavableTrait;

use function count, in_array;

class LinkRelatedThreadsService extends AbstractService
{
	use ValidateAndSavableTrait;

	protected Group $group;
	protected array $threadIds;

	/** @var RelatedThread[] */
	protected array $relatedThreads = [];


	/**
	 * @param App $app
	 * @param Group $group
	 * @param array $threadIds
	 */
	public function __construct(App $app, Group $group, array $threadIds)
	{
		parent::__construct($app);
		$this->threadIds = $threadIds;
		$this->setGroup($group);
	}

	/**
	 * @param Group $group
	 *
	 * @return void
	 */
	protected function setGroup(Group $group): void
	{
		if ($group->group_id)
		{
			$this->group = $group;
		}
		else
		{
			throw new \LogicException("Group must be saved");
		}
	}

	/**
	 *
	 */
	protected function finalSetup(&$errors)
	{
	}

	/**
	 * @return array
	 */
	protected function _validate(): array
	{
		$group = $this->group;

		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		$errors = [];
		foreach ($this->threadIds AS $threadIdOrLink)
		{
			if (empty($threadIdOrLink))
			{
				continue;
			}

			if (is_numeric($threadIdOrLink))
			{
				$thread = \XF::app()->em()->find(Thread::class, $threadIdOrLink);
				if (!$thread)
				{
					$errors[] = \XF::phraseDeferred('no_thread_could_be_found_with_id_x', [
						'thread_id' => $threadIdOrLink,
					]);
					continue;
				}
			}
			else
			{
				$routePath = \XF::app()->request()->getRoutePathFromUrl($threadIdOrLink);
				$routeMatch = \XF::app()->router('public')->routeToController($routePath);
				$params = $routeMatch->getParameterBag();

				if (!$params['thread_id'])
				{
					$errors[] = \XF::phraseDeferred('dbtech_social_groups_no_thread_id_could_be_found_from_url_x', [
						'url' => $threadIdOrLink,
					]);
					continue;
				}

				$thread = \XF::app()->em()->find(Thread::class, $params['thread_id']);
				if (!$thread)
				{
					$errors[] = \XF::phraseDeferred('no_thread_could_be_found_with_id_x', [
						'thread_id' => $params['thread_id'],
					]);
					continue;
				}
			}

			if ($group->RelatedThreads->offsetExists($thread->thread_id))
			{
				$errors[] = \XF::phraseDeferred('dbtech_social_groups_thread_id_x_already_related', [
					'thread_id' => $thread->thread_id,
				]);
				continue;
			}

			if (in_array($thread->node_id, \XF::options()->dbtechSocialGroupsExcludedRelatedThreadsNodes))
			{
				$errors[] = \XF::phraseDeferred('dbtech_social_groups_thread_id_x_prohibited_node', [
					'thread_id' => $thread->thread_id,
				]);
				continue;
			}

			if (!$thread->canView())
			{
				$errors[] = \XF::phraseDeferred('dbtech_social_groups_you_cant_view_thread_id_x', [
					'thread_id' => $thread->thread_id,
				]);
				continue;
			}

			$relatedThread = $group->getNewRelatedThread($thread);

			$relatedThread->preSave();
			$errors = \array_merge($errors, $relatedThread->getErrors());

			$this->relatedThreads[] = $relatedThread;
		}

		$numInserts = count($this->relatedThreads);
		if (!$numInserts)
		{
			if (empty($errors))
			{
				$errors[] = \XF::phraseDeferred('dbtech_social_groups_nothing_to_do');
			}
		}
		else
		{
			$maxThreadsPerGroup = \XF::options()->dbtechSocialGroupsMaxRelatedThreads;
			if (
				$maxThreadsPerGroup
				&& (($group->RelatedThreads->count() + $numInserts) > $maxThreadsPerGroup)
			)
			{
				$errors[] = \XF::phraseDeferred('dbtech_social_groups_can_only_link_x_more_related_threads_this_group', [
					'count' => $maxThreadsPerGroup - $group->RelatedThreads->count(),
				]);
			}
		}

		$this->finalSetup($errors);

		return $errors;
	}

	/**
	 * @throws PrintableException
	 */
	protected function _save(): void
	{
		$db = $this->db();
		$db->beginTransaction();

		foreach ($this->relatedThreads AS $relatedThread)
		{
			$relatedThread->save(true, false);
		}

		$this->afterLink();

		$db->commit();
	}

	/**
	 * @return void
	 */
	protected function afterLink()
	{
	}
}