<?php

namespace DBTech\SocialGroups\Service\Section;

use DBTech\SocialGroups\Entity\Discussion;
use DBTech\SocialGroups\Finder\DiscussionFinder;
use XF\App;
use XF\ContinuationResult;
use XF\Entity\User;
use XF\MultiPartRunnerTrait;
use XF\Mvc\Entity\AbstractCollection;
use XF\PrintableException;
use XF\Service\AbstractService;

use function count, is_array;

class DeleteCleanUpService extends AbstractService
{
	use MultiPartRunnerTrait;

	protected int $sectionId;
	protected string $title;
	protected int $userId;
	protected ?User $user;

	protected array $steps = [
		'stepMoveAndDeleteDiscussions',
	];

	protected array $deletes = [
		'xf_dbtech_social_groups_section_read' => 'section_id = ?',
		'xf_dbtech_social_groups_section_watch' => 'section_id = ?',
	];


	/**
	 * @param App $app
	 * @param int $sectionId
	 * @param string $title
	 * @param int $userId
	 */
	public function __construct(App $app, int $sectionId, string $title, int $userId)
	{
		parent::__construct($app);

		$this->sectionId = $sectionId;
		$this->title = $title;
		$this->userId = $userId;

		$this->user = \XF::app()->em()->find(User::class, $userId);
	}

	/**
	 * @return array
	 */
	protected function getSteps(): array
	{
		return $this->steps;
	}

	/**
	 * @param float|int $maxRunTime
	 *
	 * @return ContinuationResult
	 */
	public function cleanUp(float|int $maxRunTime = 0): ContinuationResult
	{
		$this->db()->beginTransaction();
		$result = $this->runLoop($maxRunTime);
		$this->db()->commit();

		return $result;
	}

	/**
	 * @param int|null $lastOffset
	 * @param float|int $maxRunTime
	 *
	 * @return int|null
	 */
	protected function stepDeleteContent(?int $lastOffset, float|int $maxRunTime): ?int
	{
		$db = $this->db();

		$lastOffset = $lastOffset === null ? -1 : $lastOffset;
		$thisOffset = -1;
		$start = microtime(true);

		foreach ($this->deletes AS $table => $actions)
		{
			$thisOffset++;
			if ($thisOffset <= $lastOffset)
			{
				continue;
			}

			if (!is_array($actions))
			{
				$actions = [$actions];
			}

			foreach ($actions AS $action)
			{
				$db->delete($table, $action, $this->userId);
			}

			$lastOffset = $thisOffset;
			if ($maxRunTime && microtime(true) - $start > $maxRunTime)
			{
				return $lastOffset; // continue at this position
			}
		}

		return null;
	}

	/**
	 * @param int|null $lastOffset
	 * @param float|int $maxRunTime
	 *
	 * @return int|null
	 * @throws \InvalidArgumentException
	 * @throws \LogicException
	 * @throws PrintableException
	 */
	protected function stepMoveAndDeleteDiscussions(?int $lastOffset, float|int $maxRunTime): ?int
	{
		$start = microtime(true);

		$finder = \XF::app()->finder(DiscussionFinder::class)
			->where('section_id', $this->sectionId)
			->order('discussion_id');

		if ($lastOffset !== null)
		{
			$finder->where('discussion_id', '>', $lastOffset);
		}

		$maxFetch = 1000;

		/** @var AbstractCollection<Discussion> $discussions */
		$discussions = $finder->fetch($maxFetch);
		$fetchedDiscussions = count($discussions);

		if (!$fetchedDiscussions)
		{
			return null; // done or nothing to do
		}

		foreach ($discussions AS $discussion)
		{
			$lastOffset = $discussion->discussion_id;

			$discussion->setOption('log_moderator', false);
			$discussion->section_id = 0;
			$discussion->softDelete('Section "' . $this->title . '" deleted', $this->user);

			if ($maxRunTime && microtime(true) - $start > $maxRunTime)
			{
				return $lastOffset; // continue at this position
			}
		}

		if ($fetchedDiscussions == $maxFetch)
		{
			return $lastOffset; // more to do
		}

		return null;
	}
}