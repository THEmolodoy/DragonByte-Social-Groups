<?php

namespace DBTech\SocialGroups\Service\User;

use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Finder\GroupFinder;
use XF\App;
use XF\ContinuationResult;
use XF\MultiPartRunnerTrait;
use XF\Mvc\Entity\AbstractCollection;
use XF\PrintableException;
use XF\Service\AbstractService;

class DeleteCleanUpGroupsService extends AbstractService
{
	use MultiPartRunnerTrait;

	protected int $userId;
	protected string $userName;
	protected array $excludedGroupIds;

	protected array $steps = [
		'stepDeleteGroups',
	];

	public function __construct(App $app, int $userId, string $username, array $excludedGroupIds)
	{
		parent::__construct($app);

		$this->userId = $userId;
		$this->userName = $username;
		$this->excludedGroupIds = $excludedGroupIds;
	}

	protected function getSteps(): array
	{
		return $this->steps;
	}

	public function cleanUp($maxRunTime = 0): ContinuationResult
	{
		return $this->runLoop($maxRunTime);
	}

	/**
	 * @param $lastOffset
	 * @param $maxRunTime
	 *
	 * @return int|mixed|null
	 * @throws PrintableException
	 */
	protected function stepDeleteGroups($lastOffset, $maxRunTime): mixed
	{
		$start = microtime(true);

		$groupFinder = \XF::app()->finder(GroupFinder::class)
			->where('user_id', $this->userId)
			->where('group_id', '!=', $this->excludedGroupIds)
			->order('group_id');

		if ($lastOffset !== null)
		{
			$groupFinder->where('group_id', '>', $lastOffset);
		}

		$maxFetch = 1000;

		/** @var AbstractCollection<Group> $groups */
		$groups = $groupFinder->fetch($maxFetch);

		if (!$groups->count())
		{
			return null;
		}

		foreach ($groups AS $group)
		{
			$lastOffset = $group->group_id;

			//			$group->setOption('log_moderator', false);
			$group->delete();

			if ($maxRunTime && ((microtime(true) - $start) > $maxRunTime))
			{
				return $lastOffset;
			}
		}

		if ($groups->count() == $maxFetch)
		{
			return $lastOffset;
		}

		return null;
	}
}