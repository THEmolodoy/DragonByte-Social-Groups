<?php

namespace DBTech\SocialGroups\Service\User;

use DBTech\SocialGroups\Entity\Discussion;
use DBTech\SocialGroups\Entity\Message;
use DBTech\SocialGroups\Finder\DiscussionFinder;
use DBTech\SocialGroups\Finder\MessageFinder;
use XF\App;
use XF\ContinuationResult;
use XF\MultiPartRunnerTrait;
use XF\Mvc\Entity\AbstractCollection;
use XF\PrintableException;
use XF\Service\AbstractService;

class DeleteCleanUpContentService extends AbstractService
{
	use MultiPartRunnerTrait;

	protected int $userId;
	protected string $userName;

	protected array $steps = [
		'stepDeleteMessages',
		'stepDeleteDiscussions',
	];

	public function __construct(App $app, int $userId, string $username)
	{
		parent::__construct($app);

		$this->userId = $userId;
		$this->userName = $username;
	}

	protected function getSteps(): array
	{
		return $this->steps;
	}

	public function cleanUp($maxRunTime = 0): ContinuationResult
	{
		return $this->runLoop($maxRunTime);
	}

	/**
	 * @param $lastOffset
	 * @param $maxRunTime
	 *
	 * @return int|mixed|null
	 * @throws PrintableException
	 */
	protected function stepDeleteMessages($lastOffset, $maxRunTime): mixed
	{
		$start = microtime(true);

		$messageFinder = \XF::app()->finder(MessageFinder::class)
			->where('user_id', $this->userId)
			->order('message_id');

		if ($lastOffset !== null)
		{
			$messageFinder->where('message_id', '>', $lastOffset);
		}

		$maxFetch = 1000;

		/** @var AbstractCollection<Message> $messages */
		$messages = $messageFinder->fetch($maxFetch);

		if (!$messages->count())
		{
			return null;
		}

		foreach ($messages AS $message)
		{
			$lastOffset = $message->message_id;

			$message->setOption('log_moderator', false);
			$message->delete();

			if ($maxRunTime && ((microtime(true) - $start) > $maxRunTime))
			{
				return $lastOffset;
			}
		}

		if ($messages->count() == $maxFetch)
		{
			return $lastOffset;
		}

		return null;
	}

	/**
	 * @param $lastOffset
	 * @param $maxRunTime
	 *
	 * @return int|mixed|null
	 * @throws PrintableException
	 */
	protected function stepDeleteDiscussions($lastOffset, $maxRunTime): mixed
	{
		$start = microtime(true);

		$discussionFinder = \XF::app()->finder(DiscussionFinder::class)
			->where('user_id', $this->userId)
			->order('discussion_id');

		if ($lastOffset !== null)
		{
			$discussionFinder->where('discussion_id', '>', $lastOffset);
		}

		$maxFetch = 1000;

		/** @var AbstractCollection<Discussion> $discussions */
		$discussions = $discussionFinder->fetch($maxFetch);

		if (!$discussions->count())
		{
			return null;
		}

		foreach ($discussions AS $discussion)
		{
			$lastOffset = $discussion->discussion_id;

			$discussion->setOption('log_moderator', false);
			$discussion->delete();

			if ($maxRunTime && ((microtime(true) - $start) > $maxRunTime))
			{
				return $lastOffset;
			}
		}

		if ($discussions->count() == $maxFetch)
		{
			return $lastOffset;
		}

		return null;
	}
}