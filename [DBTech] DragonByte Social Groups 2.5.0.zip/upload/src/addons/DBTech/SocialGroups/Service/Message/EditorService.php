<?php

namespace DBTech\SocialGroups\Service\Message;

use DBTech\SocialGroups\Entity\Message;
use DBTech\SocialGroups\Repository\MessageRepository;
use DBTech\SocialGroups\Service\Discussion\EditorService as DiscussionEditorService;
use XF\App;
use XF\PrintableException;
use XF\Repository\EditHistoryRepository;
use XF\Service\AbstractService;
use XF\Service\ValidateAndSavableTrait;

use function is_null;

class EditorService extends AbstractService
{
	use ValidateAndSavableTrait;

	protected Message $message;
	protected PreparerService $messagePreparer;
	protected ?string $oldMessage = null;
	protected ?int $logDelay = null;
	protected bool $logEdit = true;
	protected bool $logHistory = true;
	protected bool $alert = false;
	protected string $alertReason = '';
	protected bool $performValidations = true;
	protected ?DiscussionEditorService $discussionEditor = null;


	/**
	 * @param App $app
	 * @param Message $message
	 */
	public function __construct(App $app, Message $message)
	{
		parent::__construct($app);
		$this->setMessage($message);
	}

	/**
	 * @param Message $message
	 */
	protected function setMessage(Message $message): void
	{
		$this->message = $message;
		$this->messagePreparer = \XF::app()->service(
			PreparerService::class,
			$this->message
		);
	}

	/**
	 * @return Message
	 */
	public function getMessage(): Message
	{
		return $this->message;
	}

	/**
	 * @param int|null $logDelay
	 */
	public function logDelay(?int $logDelay): void
	{
		$this->logDelay = $logDelay;
	}

	/**
	 * @param bool $logEdit
	 */
	public function logEdit(bool $logEdit): void
	{
		$this->logEdit = $logEdit;
	}

	/**
	 * @param bool $logHistory
	 */
	public function logHistory(bool $logHistory): void
	{
		$this->logHistory = $logHistory;
	}

	/**
	 * @param bool $perform
	 */
	public function setPerformValidations(bool $perform): void
	{
		$this->performValidations = $perform;
	}

	public function getPerformValidations(): bool
	{
		return $this->performValidations;
	}

	/**
	 *
	 */
	public function setIsAutomated(): void
	{
		$this->setPerformValidations(false);
	}

	/**
	 * @param DiscussionEditorService|null $editor
	 */
	public function setDiscussionEditor(?DiscussionEditorService $editor = null): void
	{
		$this->discussionEditor = $editor;
	}

	/**
	 * @return DiscussionEditorService|null
	 */
	public function getDiscussionEditor(): ?DiscussionEditorService
	{
		return $this->discussionEditor;
	}

	/**
	 * @return PreparerService
	 */
	public function getMessagePreparer(): PreparerService
	{
		return $this->messagePreparer;
	}

	/**
	 * @param string $oldMessage
	 */
	protected function setupEditHistory(string $oldMessage): void
	{
		$message = $this->message;

		$message->edit_count++;

		$options = \XF::app()->options();
		if ($options->editLogDisplay['enabled'] && $this->logEdit)
		{
			$delay = is_null($this->logDelay) ? $options->editLogDisplay['delay'] * 60 : $this->logDelay;
			if ($message->message_date + $delay <= \XF::$time)
			{
				$message->last_edit_date = \XF::$time;
				$message->last_edit_user_id = \XF::visitor()->user_id;
			}
		}

		if ($options->editHistory['enabled'] && $this->logHistory)
		{
			$this->oldMessage = $oldMessage;
		}
	}

	/**
	 * @param string $message
	 * @param bool $format
	 *
	 * @return bool
	 */
	public function setMessageContent(string $message, bool $format = true): bool
	{
		$setupHistory = !$this->message->isChanged('message');
		$oldMessage = $this->message->message;

		$result = $this->messagePreparer->setMessageContent($message, $format, $this->performValidations);

		if ($setupHistory && $result && $this->message->isChanged('message'))
		{
			$this->setupEditHistory($oldMessage);
		}

		return $result;
	}

	/**
	 * @param string $hash
	 */
	public function setAttachmentHash(string $hash): void
	{
		$this->messagePreparer->setAttachmentHash($hash);
	}

	/**
	 * @param bool $alert
	 * @param string|null $reason
	 */
	public function setSendAlert(bool $alert, ?string $reason = null): void
	{
		$this->alert = $alert;
		if ($reason !== null)
		{
			$this->alertReason = $reason;
		}
	}

	/**
	 *
	 */
	public function checkForSpam(): void
	{
		if ($this->message->message_state == 'visible' && \XF::visitor()->isSpamCheckRequired())
		{
			$this->messagePreparer->checkForSpam();
		}
	}

	/**
	 *
	 */
	protected function finalSetup()
	{
	}

	/**
	 * @return array
	 */
	protected function _validate(): array
	{
		$this->finalSetup();

		$this->message->preSave();
		$errors = $this->message->getErrors();

		if ($this->discussionEditor && !$this->discussionEditor->validate($discussionErrors))
		{
			$errors = array_merge($errors, $discussionErrors);
		}

		return $errors;
	}

	/**
	 * @return Message
	 * @throws PrintableException
	 */
	protected function _save(): Message
	{
		$message = $this->message;
		$visitor = \XF::visitor();

		$db = $this->db();
		$db->beginTransaction();

		$message->save(true, false);

		$this->messagePreparer->afterUpdate();

		if ($this->oldMessage !== null)
		{
			\XF::app()->repository(EditHistoryRepository::class)
				->insertEditHistory(
					'dbtech_social_message',
					$message,
					$visitor,
					$this->oldMessage,
					\XF::app()->request()->getIp()
				)
			;
		}

		if ($message->message_state == 'visible' && $this->alert && $message->user_id != $visitor->user_id)
		{
			\XF::app()->repository(MessageRepository::class)
				->sendModeratorActionAlert($message, 'edit', $this->alertReason)
			;
		}

		$this->discussionEditor?->save();

		$db->commit();

		return $message;
	}
}