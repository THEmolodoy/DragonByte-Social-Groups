<?php

namespace DBTech\SocialGroups\Service\Message;

use DBTech\SocialGroups\Entity\Message;
use XF\App;
use XF\PrintableException;
use XF\Service\AbstractService;

class ApproverService extends AbstractService
{
	protected Message $message;
	protected int $notifyRunTime = 3;


	/**
	 * @param App $app
	 * @param Message $message
	 */
	public function __construct(App $app, Message $message)
	{
		parent::__construct($app);
		$this->message = $message;
	}

	/**
	 * @return Message
	 */
	public function getMessage(): Message
	{
		return $this->message;
	}

	/**
	 * @param int $time
	 */
	public function setNotifyRunTime(int $time): void
	{
		$this->notifyRunTime = $time;
	}

	/**
	 * @return bool
	 * @throws PrintableException
	 */
	public function approve(): bool
	{
		if ($this->message->message_state == 'moderated')
		{
			$this->message->message_state = 'visible';
			$this->message->save();

			$this->onApprove();
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 *
	 */
	protected function onApprove(): void
	{
		$preparer = \XF::app()->service(PreparerService::class, $this->message);
		$preparer->setMessageContent($this->message->message);

		// TODO: this doesn't solve mentioned user IDs

		$notifier = \XF::app()->service(NotifierService::class, $this->message, 'reply');
		$notifier->setQuotedUserIds($preparer->getQuotedUserIds());
		$notifier->notifyAndEnqueue($this->notifyRunTime);
	}
}