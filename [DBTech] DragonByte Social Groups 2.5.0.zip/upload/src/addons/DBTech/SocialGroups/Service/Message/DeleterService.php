<?php

namespace DBTech\SocialGroups\Service\Message;

use DBTech\SocialGroups\Entity\Discussion;
use DBTech\SocialGroups\Entity\Message;
use DBTech\SocialGroups\Repository\MessageRepository;
use XF\App;
use XF\Entity\User;
use XF\PrintableException;
use XF\Service\AbstractService;

class DeleterService extends AbstractService
{
	protected Message $message;
	protected User $user;
	protected bool $alert = false;
	protected string $alertReason = '';
	protected bool $discussionDeleted = false;


	/**
	 * @param App $app
	 * @param Message $message
	 */
	public function __construct(App $app, Message $message)
	{
		parent::__construct($app);
		$this->message = $message;
		$this->setUser(\XF::visitor());
	}

	/**
	 * @return Message
	 */
	public function getMessage(): Message
	{
		return $this->message;
	}

	/**
	 * @param User $user
	 */
	protected function setUser(User $user): void
	{
		$this->user = $user;
	}

	/**
	 * @return User
	 */
	public function getUser(): User
	{
		return $this->user;
	}

	/**
	 * @param bool $alert
	 * @param string|null $reason
	 */
	public function setSendAlert(bool $alert, ?string $reason = null): void
	{
		$this->alert = $alert;
		if ($reason !== null)
		{
			$this->alertReason = $reason;
		}
	}

	/**
	 * @param string $type
	 * @param string $reason
	 *
	 * @return bool|null
	 * @throws PrintableException
	 */
	public function delete(string $type, string $reason = ''): ?bool
	{
		$deleteDiscussion = $this->isDiscussionDeleteRequired($type);

		$user = $this->user;

		/** @var Discussion $discussion */
		$discussion = $this->message->Discussion;

		$result = null;
		$this->discussionDeleted = $deleteDiscussion;

		$wasVisible = $this->message->message_state == 'visible';

		if ($type == 'soft')
		{
			if ($deleteDiscussion)
			{
				$result = $discussion?->softDelete($reason, $user);
			}
			else
			{
				$result = $this->message->softDelete($reason, $user);
			}
		}
		else
		{
			if ($deleteDiscussion)
			{
				$result = $discussion?->delete();
			}
			else
			{
				$result = $this->message->delete();
			}
		}

		if ($result && $wasVisible && $this->alert && $this->message->user_id != $user->user_id)
		{
			\XF::app()->repository(MessageRepository::class)
				->sendModeratorActionAlert(
					$this->message,
					'delete',
					$this->alertReason
				)
			;
		}

		return $result;
	}

	/**
	 * @return bool
	 */
	public function wasDiscussionDeleted(): bool
	{
		return $this->discussionDeleted;
	}

	/**
	 * @param string $type
	 *
	 * @return bool
	 */
	protected function isDiscussionDeleteRequired(string $type): bool
	{
		return $this->message->isFirstMessage();
	}
}