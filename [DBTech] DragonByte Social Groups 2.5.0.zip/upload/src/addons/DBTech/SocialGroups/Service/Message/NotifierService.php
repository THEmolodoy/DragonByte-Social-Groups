<?php

namespace DBTech\SocialGroups\Service\Message;

use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Entity\Message;
use DBTech\SocialGroups\Entity\Section;
use DBTech\SocialGroups\Notifier\Message\DiscussionWatch;
use DBTech\SocialGroups\Notifier\Message\GroupWatch;
use DBTech\SocialGroups\Notifier\Message\Mention;
use DBTech\SocialGroups\Notifier\Message\Quote;
use XF\App;
use XF\Entity\User;
use XF\Service\AbstractNotifier;

class NotifierService extends AbstractNotifier
{
	protected Message $message;
	protected string $actionType;


	/**
	 * @param App $app
	 * @param Message $message
	 * @param string $actionType
	 */
	public function __construct(App $app, Message $message, string $actionType)
	{
		parent::__construct($app);

		switch ($actionType)
		{
			case 'reply':
			case 'discussion':
				break;

			default:
				throw new \InvalidArgumentException("Unknown action type '$actionType'");
		}

		$this->actionType = $actionType;
		$this->message = $message;
	}

	/**
	 * @param array $extraData
	 *
	 * @return NotifierService|null
	 */
	public static function createForJob(array $extraData): ?NotifierService
	{
		$message = \XF::app()->em()->find(
			Message::class,
			$extraData['messageId'],
			['Discussion', 'Discussion.Group']
		);
		if (!$message)
		{
			return null;
		}

		return \XF::app()->service(NotifierService::class, $message, $extraData['actionType']);
	}

	/**
	 * @return array
	 */
	protected function getExtraJobData(): array
	{
		return [
			'messageId' => $this->message->message_id,
			'actionType' => $this->actionType,
		];
	}

	/**
	 * @return array
	 */
	protected function loadNotifiers(): array
	{
		$notifiers = [
			'quote' => \XF::app()->notifier(Quote::class, $this->message),
			'mention' => \XF::app()->notifier(Mention::class, $this->message),
			'groupWatch' => \XF::app()->notifier(GroupWatch::class, $this->message, $this->actionType),
		];

		// if this is not the last message, then another notification would have been triggered already
		if ($this->message->isLastMessage())
		{
			$notifiers['discussionWatch'] = \XF::app()->notifier(
				DiscussionWatch::class,
				$this->message,
				$this->actionType
			);
		}

		return $notifiers;
	}

	/**
	 * @param array $users
	 */
	protected function loadExtraUserData(array $users): void
	{
		$permCombinationIds = [];

		/** @var User $user */
		foreach ($users AS $user)
		{
			$id = $user->permission_combination_id;
			$permCombinationIds[$id] = $id;
		}

		\XF::app()->permissionCache()->cacheMultipleContentPermsForContent(
			$permCombinationIds,
			'dbtech_social_group',
			$this->message->Discussion->group_id
		);
	}

	/**
	 * @throws \Exception
	 */
	protected function canUserViewContent(User $user)
	{
		return \XF::asVisitor(
			$user,
			function ()
			{
				return $this->message->canView();
			}
		);
	}

	/**
	 * @param Group $group
	 */
	public function skipUsersWatchingGroup(Group $group): void
	{
		$watchers = $this->db()->fetchAll("
			SELECT user_id, send_alert, send_email
			FROM xf_dbtech_social_groups_group_watch
			WHERE group_id = ?
				AND (send_alert = 1 OR send_email = 1)
		", $group->group_id);

		foreach ($watchers AS $watcher)
		{
			if ($watcher['send_alert'])
			{
				$this->setUserAsAlerted($watcher['user_id']);
			}
			if ($watcher['send_email'])
			{
				$this->setUserAsEmailed($watcher['user_id']);
			}
		}
	}

	/**
	 * @param Section $section
	 */
	public function skipUsersWatchingSection(Section $section): void
	{
		$watchers = $this->db()->fetchAll("
			SELECT user_id, send_alert, send_email
			FROM xf_dbtech_social_groups_section_watch
			WHERE section_id = ?
				AND (send_alert = 1 OR send_email = 1)
		", $section->section_id);

		foreach ($watchers AS $watcher)
		{
			if ($watcher['send_alert'])
			{
				$this->setUserAsAlerted($watcher['user_id']);
			}
			if ($watcher['send_email'])
			{
				$this->setUserAsEmailed($watcher['user_id']);
			}
		}
	}
}