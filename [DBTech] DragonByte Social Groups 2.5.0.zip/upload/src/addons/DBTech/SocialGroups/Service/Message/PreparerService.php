<?php

namespace DBTech\SocialGroups\Service\Message;

use DBTech\SocialGroups\Entity\Message;
use XF\App;
use XF\Repository\IpRepository;
use XF\Repository\UserRepository;
use XF\Service\AbstractService;

class PreparerService extends AbstractService
{
	protected Message $message;
	protected ?string $attachmentHash = null;
	protected bool $logIp = true;
	protected array $quotedMessages = [];
	protected array $mentionedUsers = [];


	/**
	 * @param App $app
	 * @param Message $message
	 */
	public function __construct(App $app, Message $message)
	{
		parent::__construct($app);
		$this->message = $message;
	}

	/**
	 * @return Message
	 */
	public function getMessage(): Message
	{
		return $this->message;
	}

	/**
	 * @param bool $logIp
	 */
	public function logIp(bool $logIp): void
	{
		$this->logIp = $logIp;
	}

	/**
	 * @return array
	 */
	public function getQuotedMessages(): array
	{
		return $this->quotedMessages;
	}

	/**
	 * @return array
	 */
	public function getQuotedUserIds(): array
	{
		if (!$this->quotedMessages)
		{
			return [];
		}

		$messageIds = array_map('intval', array_keys($this->quotedMessages));
		$quotedUserIds = [];

		$db = $this->db();
		$messageUserMap = $db->fetchPairs("
			SELECT message_id, user_id
			FROM xf_dbtech_social_groups_message
			WHERE message_id IN (" . $db->quote($messageIds) . ")
		");
		foreach ($messageUserMap AS $messageId => $userId)
		{
			if (!isset($this->quotedMessages[$messageId]) || !$userId)
			{
				continue;
			}

			$quote = $this->quotedMessages[$messageId];
			if (!isset($quote['member']) || $quote['member'] == $userId)
			{
				$quotedUserIds[] = $userId;
			}
		}

		return $quotedUserIds;
	}

	/**
	 * @param bool $limitPermissions
	 *
	 * @return array
	 */
	public function getMentionedUsers(bool $limitPermissions = true): array
	{
		if ($limitPermissions)
		{
			$user = $this->message->User ?: \XF::app()->repository(UserRepository::class)
				->getGuestUser()
			;
			return $user->getAllowedUserMentions($this->mentionedUsers);
		}
		else
		{
			return $this->mentionedUsers;
		}
	}

	/**
	 * @param bool $limitPermissions
	 *
	 * @return int[]|string[]
	 */
	public function getMentionedUserIds(bool $limitPermissions = true): array
	{
		return array_keys($this->getMentionedUsers($limitPermissions));
	}

	/**
	 * @param string $message
	 * @param bool $format
	 * @param bool $checkValidity
	 *
	 * @return bool
	 */
	public function setMessageContent(string $message, bool $format = true, bool $checkValidity = true): bool
	{
		$preparer = $this->getMessagePreparer($format);
		$this->message->message = $preparer->prepare($message, $checkValidity);
		$this->message->embed_metadata = $preparer->getEmbedMetadata();

		$this->quotedMessages = $preparer->getQuotesKeyed('dbtech_social_message');
		$this->mentionedUsers = $preparer->getMentionedUsers();

		return $preparer->pushEntityErrorIfInvalid($this->message);
	}

	/**
	 * @param bool $format
	 *
	 * @return \XF\Service\Message\PreparerService
	 */
	protected function getMessagePreparer(bool $format = true): \XF\Service\Message\PreparerService
	{
		$preparer = \XF::app()->service(
			\XF\Service\Message\PreparerService::class,
			'dbtech_social_message',
			$this->message
		);
		if (!$format)
		{
			$preparer->disableAllFilters();
		}

		return $preparer;
	}

	/**
	 * @param string $hash
	 */
	public function setAttachmentHash(string $hash): void
	{
		$this->attachmentHash = $hash;
	}

	/**
	 *
	 */
	public function checkForSpam(): void
	{
		$message = $this->message;
		$discussion = $this->message->Discussion;

		$user = $message->User ?: \XF::app()->repository(UserRepository::class)
			->getGuestUser($message->username)
		;

		if ($message->isFirstMessage())
		{
			$check = $discussion->title . "\n" . $message->message;
			$contentType = 'dbtech_social_discussion';
		}
		else
		{
			$check = $message->message;
			$contentType = 'dbtech_social_message';
		}

		$checker = \XF::app()->spam()->contentChecker();
		$checker->check($user, $check, [
			'permalink' => \XF::app()->router('public')->buildLink(
				'canonical:dbtech-social/discussions',
				$discussion
			),
			'content_type' => $contentType,
		]);

		$decision = $checker->getFinalDecision();
		switch ($decision)
		{
			case 'moderated':

				if ($message->isFirstMessage())
				{
					$discussion->discussion_state = 'moderated';
				}
				else
				{
					$message->message_state = 'moderated';
				}
				break;

			case 'denied':
				$checker->logSpamTrigger(
					$message->isFirstMessage() ? 'dbtech_social_discussion' : 'dbtech_social_message',
					null
				);
				$message->error(\XF::phrase('your_content_cannot_be_submitted_try_later'));
				break;
		}
	}

	/**
	 *
	 */
	public function afterInsert(): void
	{
		if ($this->attachmentHash)
		{
			$this->associateAttachments($this->attachmentHash);
		}

		if ($this->logIp)
		{
			$ip = ($this->logIp === true ? \XF::app()->request()->getIp() : $this->logIp);
			$this->writeIpLog($ip);
		}

		$message = $this->message;
		$checker = \XF::app()->spam()->contentChecker();

		if ($message->isFirstMessage())
		{
			$checker->logContentSpamCheck('dbtech_social_discussion', $message->discussion_id);
			$checker->logSpamTrigger('dbtech_social_discussion', $message->discussion_id);
		}
		else
		{
			$checker->logContentSpamCheck('dbtech_social_message', $message->message_id);
			$checker->logSpamTrigger('dbtech_social_message', $message->message_id);
		}
	}

	/**
	 *
	 */
	public function afterUpdate(): void
	{
		if ($this->attachmentHash)
		{
			$this->associateAttachments($this->attachmentHash);
		}

		$message = $this->message;
		$checker = \XF::app()->spam()->contentChecker();

		if ($message->isFirstMessage())
		{
			$checker->logSpamTrigger('dbtech_social_discussion', $message->discussion_id);
		}
		else
		{
			$checker->logSpamTrigger('dbtech_social_message', $message->message_id);
		}
	}

	/**
	 * @param string $hash
	 */
	protected function associateAttachments(string $hash): void
	{
		$message = $this->message;

		$inserter = \XF::app()->service(\XF\Service\Attachment\PreparerService::class);
		$associated = $inserter->associateAttachmentsWithContent(
			$hash,
			'dbtech_social_message',
			$message->message_id
		);
		if ($associated)
		{
			$message->fastUpdate('attach_count', $message->attach_count + $associated);
		}
	}

	/**
	 * @param string $ip
	 */
	protected function writeIpLog(string $ip): void
	{
		$message = $this->message;

		$ipEnt = \XF::app()->repository(IpRepository::class)
			->logIp(
				$message->user_id,
				$ip,
				'dbtech_social_message',
				$message->message_id
			)
		;
		if ($ipEnt)
		{
			$message->fastUpdate('ip_id', $ipEnt->ip_id);
		}
	}
}