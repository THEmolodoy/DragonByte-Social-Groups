<?php

namespace DBTech\SocialGroups\Service\Discussion;

use DBTech\SocialGroups\Entity\Discussion;
use DBTech\SocialGroups\Service\Message\NotifierService;
use XF\App;
use XF\PrintableException;
use XF\Service\AbstractService;

class ApproverService extends AbstractService
{
	protected Discussion $discussion;
	protected int $notifyRunTime = 3;


	/**
	 * @param App $app
	 * @param Discussion $discussion
	 */
	public function __construct(App $app, Discussion $discussion)
	{
		parent::__construct($app);
		$this->discussion = $discussion;
	}

	/**
	 * @return Discussion
	 */
	public function getDiscussion(): Discussion
	{
		return $this->discussion;
	}

	/**
	 * @param int $time
	 */
	public function setNotifyRunTime(int $time): void
	{
		$this->notifyRunTime = $time;
	}

	/**
	 * @return bool
	 * @throws PrintableException
	 */
	public function approve(): bool
	{
		if ($this->discussion->discussion_state == 'moderated')
		{
			$this->discussion->discussion_state = 'visible';
			$this->discussion->save();

			$this->onApprove();
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 *
	 */
	protected function onApprove(): void
	{
		$message = $this->discussion->FirstMessage;

		if ($message)
		{
			$notifier = \XF::app()->service(
				NotifierService::class,
				$message,
				'discussion'
			);
			$notifier->notifyAndEnqueue($this->notifyRunTime);
		}
	}
}