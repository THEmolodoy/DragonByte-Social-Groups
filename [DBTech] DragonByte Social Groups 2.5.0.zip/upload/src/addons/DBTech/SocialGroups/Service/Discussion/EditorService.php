<?php

namespace DBTech\SocialGroups\Service\Discussion;

use DBTech\SocialGroups\Entity\Discussion;
use XF\App;
use XF\Entity\User;
use XF\PrintableException;
use XF\Service\AbstractService;
use XF\Service\Tag\ChangerService;
use XF\Service\ValidateAndSavableTrait;

class EditorService extends AbstractService
{
	use ValidateAndSavableTrait;

	protected Discussion $discussion;
	protected User $user;
	protected ChangerService $tagChanger;
	protected bool $performValidations = true;


	/**
	 * @param App $app
	 * @param Discussion $discussion
	 */
	public function __construct(App $app, Discussion $discussion)
	{
		parent::__construct($app);
		$this->discussion = $discussion;
		$this->user = \XF::visitor();

		$this->tagChanger = \XF::app()->service(
			ChangerService::class,
			'dbtech_social_discussion',
			$discussion
		);
	}

	/**
	 * @return Discussion
	 */
	public function getDiscussion(): Discussion
	{
		return $this->discussion;
	}

	/**
	 * @return User|null
	 */
	public function getUser(): ?User
	{
		return $this->user;
	}

	/**
	 * @param bool $perform
	 */
	public function setPerformValidations(bool $perform): void
	{
		$this->performValidations = $perform;
	}

	/**
	 * @return bool
	 */
	public function getPerformValidations(): bool
	{
		return $this->performValidations;
	}

	/**
	 * @param string $title
	 */
	public function setTitle(string $title): void
	{
		$this->discussion->set(
			'title',
			$title,
			['forceConstraint' => !$this->performValidations]
		);
	}

	/**
	 * @param bool $discussionOpen
	 */
	public function setDiscussionOpen(bool $discussionOpen): void
	{
		$this->discussion->discussion_open = $discussionOpen;
	}

	/**
	 * @param string $discussionState
	 */
	public function setDiscussionState(string $discussionState): void
	{
		$this->discussion->discussion_state = $discussionState;
	}

	/**
	 * @param bool $sticky
	 */
	public function setSticky(bool $sticky): void
	{
		$this->discussion->sticky = $sticky;
	}

	/**
	 * @param $tags
	 */
	public function setTags($tags): void
	{
		if ($this->tagChanger->canEdit())
		{
			$this->tagChanger->setEditableTags($tags);
		}
	}

	/**
	 * @param $tags
	 */
	public function addTags($tags): void
	{
		if ($this->tagChanger->canEdit())
		{
			$this->tagChanger->addTags($tags);
		}
	}

	/**
	 * @param $tags
	 */
	public function removeTags($tags): void
	{
		if ($this->tagChanger->canEdit())
		{
			$this->tagChanger->removeTags($tags);
		}
	}

	/**
	 *
	 */
	public function checkForSpam(): void
	{
		$discussion = $this->discussion;
		$message = $discussion->FirstMessage;

		if ($discussion->discussion_state == 'visible' && $this->user->isSpamCheckRequired())
		{
			$user = $this->user;

			$message = $discussion->title . "\n" . $message->message;

			$checker = \XF::app()->spam()->contentChecker();
			$checker->check($user, $message, [
				'permalink' => \XF::app()->router('public')
					->buildLink('canonical:dbtech-social/discussions', $discussion)
				,
				'content_type' => 'dbtech_social_discussion',
			]);

			$decision = $checker->getFinalDecision();
			switch ($decision)
			{
				case 'moderated':
					$discussion->discussion_state = 'moderated';
					break;

				case 'denied':
					$checker->logSpamTrigger('dbtech_social_discussion', $discussion->discussion_id);
					$discussion->error(\XF::phrase('your_content_cannot_be_submitted_try_later'));
					break;
			}
		}
	}

	/**
	 *
	 */
	protected function finalSetup()
	{
	}

	/**
	 * @return array
	 */
	protected function _validate(): array
	{
		$this->finalSetup();

		$discussion = $this->discussion;

		if ($this->performValidations)
		{
			$this->checkForSpam();
		}

		$discussion->preSave();
		$errors = $discussion->getErrors();

		if ($this->performValidations)
		{
			if ($this->tagChanger->canEdit() && $this->tagChanger->tagsChanged())
			{
				$tagErrors = $this->tagChanger->getErrors();
				if ($tagErrors)
				{
					$errors = array_merge($errors, $tagErrors);
				}
			}
		}

		return $errors;
	}

	/**
	 * @return Discussion
	 * @throws PrintableException
	 */
	protected function _save(): Discussion
	{
		$discussion = $this->discussion;

		$db = $this->db();
		$db->beginTransaction();

		$discussion->save(true, false);

		if ($this->tagChanger->canEdit() && $this->tagChanger->tagsChanged())
		{
			$this->tagChanger->save($this->performValidations);
		}

		$db->commit();

		return $discussion;
	}
}