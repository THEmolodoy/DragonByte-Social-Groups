<?php

namespace DBTech\SocialGroups\Service\Discussion;

use DBTech\SocialGroups\Entity\Discussion;
use DBTech\SocialGroups\Repository\DiscussionRepository;
use XF\App;
use XF\Entity\User;
use XF\PrintableException;
use XF\Service\AbstractService;

class DeleterService extends AbstractService
{
	protected Discussion $discussion;
	protected User $user;
	protected bool $alert = false;
	protected string $alertReason = '';


	/**
	 * @param App $app
	 * @param Discussion $discussion
	 */
	public function __construct(App $app, Discussion $discussion)
	{
		parent::__construct($app);
		$this->discussion = $discussion;
		$this->setUser(\XF::visitor());
	}

	/**
	 * @return Discussion
	 */
	public function getDiscussion(): Discussion
	{
		return $this->discussion;
	}

	/**
	 * @param User|null $user
	 */
	public function setUser(?User $user = null): void
	{
		$this->user = $user;
	}

	/**
	 * @return User|null
	 */
	public function getUser(): ?User
	{
		return $this->user;
	}

	/**
	 * @param bool $alert
	 * @param string|null $reason
	 */
	public function setSendAlert(bool $alert, ?string $reason = null): void
	{
		$this->alert = $alert;
		if ($reason !== null)
		{
			$this->alertReason = $reason;
		}
	}

	/**
	 * @param string $type
	 * @param string $reason
	 *
	 * @return bool
	 * @throws PrintableException
	 */
	public function delete(string $type, string $reason = ''): bool
	{
		switch ($type)
		{
			case 'soft':
			case 'hard':
				break;

			default:
				throw new \InvalidArgumentException("Unexpected delete type '$type'. Should be soft or hard.");
		}

		$user = $this->user;
		$wasVisible = $this->discussion->discussion_state == 'visible';

		if ($type == 'soft')
		{
			$result = $this->discussion->softDelete($reason, $user);
		}
		else
		{
			$result = $this->discussion->delete();
		}

		if ($result
			&& $wasVisible
			&& $this->alert
			&& $this->discussion->user_id != $user->user_id
			&& $this->discussion->discussion_state != 'redirect'
		)
		{
			\XF::app()->repository(DiscussionRepository::class)
				->sendModeratorActionAlert($this->discussion, 'delete', $this->alertReason)
			;
		}

		return $result;
	}
}