<?php

namespace DBTech\SocialGroups\Service\Discussion;

use DBTech\SocialGroups\Entity\Discussion;
use DBTech\SocialGroups\Entity\Discussion as DiscussionEntity;
use DBTech\SocialGroups\Entity\Section;
use DBTech\SocialGroups\Repository\DiscussionRepository;
use DBTech\SocialGroups\Repository\GroupRepository;
use DBTech\SocialGroups\Repository\SectionRepository;
use DBTech\SocialGroups\Service\Message\NotifierService;
use XF\App;
use XF\Db\DeadlockException;
use XF\PrintableException;
use XF\Service\AbstractService;
use XF\Service\ModerationAlertSendableTrait;

use function call_user_func;

class MoverService extends AbstractService
{
	use ModerationAlertSendableTrait;

	protected DiscussionEntity $discussion;
	protected bool $alert = false;
	protected string $alertReason = '';
	protected bool $notifyWatchers = false;
	protected array $extraSetup = [];


	/**
	 * @param App $app
	 * @param Discussion $discussion
	 */
	public function __construct(App $app, DiscussionEntity $discussion)
	{
		parent::__construct($app);

		$this->discussion = $discussion;
	}

	/**
	 * @return Discussion
	 */
	public function getDiscussion(): DiscussionEntity
	{
		return $this->discussion;
	}

	/**
	 * @param bool $alert
	 * @param string|null $reason
	 *
	 * @return void
	 */
	public function setSendAlert(bool $alert, ?string $reason = null): void
	{
		$this->alert = $alert;
		if ($reason !== null)
		{
			$this->alertReason = $reason;
		}
	}

	/**
	 * @param bool $value
	 *
	 * @return void
	 */
	public function setNotifyWatchers(bool $value = true): void
	{
		$this->notifyWatchers = $value;
	}

	/**
	 * @param callable $extra
	 *
	 * @return void
	 */
	public function addExtraSetup(callable $extra): void
	{
		$this->extraSetup[] = $extra;
	}

	/**
	 * @param Section|null $section
	 *
	 * @return bool
	 * @throws PrintableException
	 * @throws DeadlockException
	 */
	public function move(?Section $section = null): bool
	{
		$actor = \XF::visitor();

		$discussion = $this->discussion;
		$oldSection = $discussion->Section;
		$newSectionId = ($section ? $section->section_id : 0);

		$moved = ($discussion->section_id != $newSectionId);

		if ($this->alert)
		{
			$wasVisibleForAlert = $this->isContentVisibleToContentAuthor(
				$discussion,
				$discussion
			);
		}
		else
		{
			$wasVisibleForAlert = false;
		}

		foreach ($this->extraSetup AS $extra)
		{
			call_user_func($extra, $discussion, $section, $newSectionId);
		}

		$discussion->section_id = $newSectionId;

		if (!$discussion->preSave())
		{
			throw new PrintableException($discussion->getErrors());
		}

		$db = $this->db();
		$db->beginTransaction();

		$discussion->save(true, false);

		$db->commit();

		if ($this->alert)
		{
			$isVisibleForAlert = $this->isContentVisibleToContentAuthor(
				$discussion,
				$discussion
			);
		}
		else
		{
			$isVisibleForAlert = false;
		}

		$discussionRepo = \XF::app()->repository(DiscussionRepository::class);

		if ($moved
			&& $discussion->discussion_state == 'visible'
			&& $this->alert
			&& $discussion->user_id != $actor->user_id
			&& $discussion->discussion_type != 'redirect'
			&& ($wasVisibleForAlert || $isVisibleForAlert)
		)
		{
			$discussionRepo->sendModeratorActionAlert($discussion, 'move', $this->alertReason);
		}

		if ($moved
			&& $this->notifyWatchers
			&& $discussion->FirstMessage
			&& $discussion->discussion_type != 'redirect'
		)
		{
			$notifier = \XF::app()->service(
				NotifierService::class,
				$discussion->FirstMessage,
				'discussion'
			);
			if ($oldSection)
			{
				$notifier->skipUsersWatchingSection($oldSection);
			}
			else
			{
				$notifier->skipUsersWatchingGroup($discussion->Group);
			}
			$notifier->notifyAndEnqueue(3);
		}

		if ($moved
			&& $discussion->Group
			&& !$discussionRepo->countUnreadDiscussionsInGroupForUser($discussion->Group, $actor))
		{
			\XF::app()->repository(GroupRepository::class)->markGroupReadByUser($discussion->Group, $actor->user_id);
		}

		if ($moved
			&& $discussion->Section
			&& !$discussionRepo->countUnreadDiscussionsInSectionForUser($discussion->Section, $actor)
		)
		{
			\XF::app()->repository(SectionRepository::class)->markSectionReadByUser($discussion->Section, $actor->user_id);
		}

		return $moved;
	}
}