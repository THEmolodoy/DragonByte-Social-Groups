<?php

namespace DBTech\SocialGroups\Service\Discussion;

use DBTech\SocialGroups\Entity\Discussion;
use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Entity\Message;
use DBTech\SocialGroups\Entity\Section;
use DBTech\SocialGroups\Service\Message\NotifierService;
use DBTech\SocialGroups\Service\Message\PreparerService;
use XF\App;
use XF\Entity\User;
use XF\PrintableException;
use XF\Service\AbstractService;
use XF\Service\Poll\CreatorService as PollCreatorService;
use XF\Service\Tag\ChangerService;
use XF\Service\ValidateAndSavableTrait;
use XF\Validator\Username;

class CreatorService extends AbstractService
{
	use ValidateAndSavableTrait;

	protected Group $group;
	protected ?Section $section = null;
	protected Discussion $discussion;
	protected Message $message;
	protected User $user;
	protected PreparerService $messagePreparer;
	protected ChangerService $tagChanger;
	protected ?PollCreatorService $pollCreator = null;
	protected bool $performValidations = true;


	/**
	 * @param App $app
	 * @param Group $group
	 * @param Section|null $section
	 */
	public function __construct(App $app, Group $group, ?Section $section = null)
	{
		parent::__construct($app);
		$this->group = $group;
		$this->section = $section;
		$this->setupDefaults();
	}

	/**
	 *
	 */
	protected function setupDefaults(): void
	{
		$this->discussion = $this->group->getNewDiscussion();
		$this->message = $this->discussion->getNewMessage();

		$this->messagePreparer = \XF::app()->service(
			PreparerService::class,
			$this->message
		);

		$this->discussion->addCascadedSave($this->message);
		$this->message->hydrateRelation('Discussion', $this->discussion);

		$this->tagChanger = \XF::app()->service(
			ChangerService::class,
			'dbtech_social_discussion',
			$this->section ?: $this->group
		);

		$user = \XF::visitor();
		$this->setUser($user);

		$this->message->message_state = 'visible';

		if ($this->section)
		{
			$this->discussion->section_id = $this->section->section_id;
			$this->discussion->hydrateRelation('Section', $this->section);

			$this->discussion->discussion_state = $this->section->getNewContentState();
		}
		else
		{
			$this->discussion->discussion_state = $this->group->getNewContentState();
		}
	}

	/**
	 * @return Group
	 */
	public function getGroup(): Group
	{
		return $this->group;
	}

	/**
	 * @return Section|null
	 */
	public function getSection(): ?Section
	{
		return $this->section;
	}

	/**
	 * @return Discussion
	 */
	public function getDiscussion(): Discussion
	{
		return $this->discussion;
	}

	/**
	 * @return Message
	 */
	public function getMessage(): Message
	{
		return $this->message;
	}

	/**
	 * @return User
	 */
	public function getUser(): User
	{
		return $this->user;
	}

	/**
	 * @return PreparerService
	 */
	public function getMessagePreparer(): PreparerService
	{
		return $this->messagePreparer;
	}

	/**
	 * @param User $user
	 */
	protected function setUser(User $user): void
	{
		$this->user = $user;

		$this->discussion->user_id = $user->user_id;
		$this->discussion->username = $user->username;

		$this->message->user_id = $user->user_id;
		$this->message->username = $user->username;
	}

	/**
	 * @param bool $perform
	 */
	public function setPerformValidations(bool $perform): void
	{
		$this->performValidations = $perform;
	}

	/**
	 * @return bool
	 */
	public function getPerformValidations(): bool
	{
		return $this->performValidations;
	}

	/**
	 *
	 */
	public function setIsAutomated(): void
	{
		$this->logIp(false);
		$this->setPerformValidations(false);
	}

	/**
	 * @param PollCreatorService|null $creator
	 */
	public function setPollCreator(?PollCreatorService $creator = null): void
	{
		$this->pollCreator = $creator;
	}

	/**
	 * @return PollCreatorService|null
	 */
	public function getPollCreator(): ?PollCreatorService
	{
		return $this->pollCreator;
	}

	/**
	 * @param bool $logIp
	 */
	public function logIp(bool $logIp): void
	{
		$this->messagePreparer->logIp($logIp);
	}

	/**
	 * @param string $title
	 * @param string $message
	 * @param bool $format
	 *
	 * @return bool
	 */
	public function setContent(string $title, string $message, bool $format = true): bool
	{
		$this->discussion->set(
			'title',
			$title,
			['forceConstraint' => !$this->performValidations]
		);

		return $this->messagePreparer->setMessageContent($message, $format, $this->performValidations);
	}

	/**
	 * @param $tags
	 */
	public function setTags($tags): void
	{
		if ($this->tagChanger->canEdit())
		{
			$this->tagChanger->setEditableTags($tags);
		}
	}

	/**
	 * @param string $hash
	 */
	public function setAttachmentHash(string $hash): void
	{
		$this->messagePreparer->setAttachmentHash($hash);
	}

	/**
	 * @param bool $discussionOpen
	 */
	public function setDiscussionOpen(bool $discussionOpen): void
	{
		$this->discussion->discussion_open = $discussionOpen;
	}

	/**
	 * @param string $discussionState
	 */
	public function setDiscussionState(string $discussionState): void
	{
		$this->discussion->discussion_state = $discussionState;
	}

	/**
	 * @param bool $sticky
	 */
	public function setSticky(bool $sticky): void
	{
		$this->discussion->sticky = $sticky;
	}

	/**
	 *
	 */
	public function checkForSpam(): void
	{
		if ($this->discussion->discussion_state == 'visible' && $this->user->isSpamCheckRequired())
		{
			$this->messagePreparer->checkForSpam();
		}
	}

	/**
	 *
	 */
	protected function finalSetup(): void
	{
		$date = time();

		$this->discussion->message_date = $date;
		$this->discussion->last_message_date = $date;
		$this->discussion->last_message_user_id = $this->discussion->user_id;
		$this->discussion->last_message_username = $this->discussion->username;

		$this->message->message_date = $date;
		$this->message->position = 0;
	}

	/**
	 * @return array
	 */
	protected function _validate(): array
	{
		$this->finalSetup();

		$discussion = $this->discussion;

		if (!$discussion->user_id)
		{
			/** @var Username $validator */
			$validator = \XF::app()->validator('Username');
			$discussion->username = $validator->coerceValue($discussion->username);
			$this->message->username = $discussion->username;

			if ($this->performValidations && !$validator->isValid($discussion->username, $error))
			{
				return [
					$validator->getPrintableErrorValue($error),
				];
			}
		}

		$discussion->preSave();
		$errors = $discussion->getErrors();

		if ($this->performValidations)
		{
			if ($this->tagChanger->canEdit())
			{
				$tagErrors = $this->tagChanger->getErrors();
				if ($tagErrors)
				{
					$errors = array_merge($errors, $tagErrors);
				}
			}
		}

		if ($this->pollCreator)
		{
			if (!$this->pollCreator->validate($pollErrors))
			{
				$errors = array_merge($errors, $pollErrors);
			}
		}

		return $errors;
	}

	/**
	 * @return Discussion
	 * @throws PrintableException
	 */
	protected function _save(): Discussion
	{
		$group = $this->group;
		$section = $this->section;
		$discussion = $this->discussion;
		$message = $this->message;

		$db = $this->db();
		$db->beginTransaction();

		$discussion->save(true, false);
		// message will also be saved now

		$discussion->fastUpdate([
			'first_message_id' => $message->message_id,
			'last_message_id' => $message->message_id,
		]);

		if ($section)
		{
			if ($discussion->last_message_date == $section->last_message_date)
			{
				$section->fastUpdate([
					'last_message_id' => $message->message_id,
					'last_discussion_id' => $message->discussion_id,
				]);
			}
		}

		if ($discussion->last_message_date == $group->last_message_date)
		{
			$group->fastUpdate([
				'last_message_id' => $message->message_id,
				'last_discussion_id' => $message->discussion_id,
			]);
		}

		$this->messagePreparer->afterInsert();

		if ($this->tagChanger->canEdit())
		{
			$this->tagChanger
				->setContentId($discussion->discussion_id, true)
				->save($this->performValidations);
		}

		$this->pollCreator?->save();

		$db->commit();

		return $discussion;
	}

	/**
	 *
	 */
	public function sendNotifications(): void
	{
		if ($this->discussion->isVisible())
		{
			$notifier = \XF::app()->service(
				NotifierService::class,
				$this->message,
				'discussion'
			);
			$notifier->setMentionedUserIds($this->messagePreparer->getMentionedUserIds());
			$notifier->setQuotedUserIds($this->messagePreparer->getQuotedUserIds());
			$notifier->notifyAndEnqueue(3);
		}
	}
}