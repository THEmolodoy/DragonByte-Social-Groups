<?php

namespace DBTech\SocialGroups\Service\Discussion;

use DBTech\SocialGroups\Entity\Discussion;
use DBTech\SocialGroups\Entity\DiscussionReplyBan;
use XF\App;
use XF\Entity\User;
use XF\PrintableException;
use XF\Repository\UserAlertRepository;
use XF\Service\AbstractService;
use XF\Service\ValidateAndSavableTrait;

use function is_int;

class ReplyBanService extends AbstractService
{
	use ValidateAndSavableTrait;

	protected Discussion $discussion;
	protected DiscussionReplyBan $replyBan;
	protected User $user;
	protected bool $alert = false;


	/**
	 * @param App $app
	 * @param Discussion $discussion
	 * @param User $user
	 */
	public function __construct(App $app, Discussion $discussion, User $user)
	{
		parent::__construct($app);

		$this->discussion = $discussion;
		$this->user = $user;

		$replyBan = \XF::app()->em()->findOne(DiscussionReplyBan::class, [
			'discussion_id' => $discussion->discussion_id,
			'user_id' => $user->user_id,
		]);
		if (!$replyBan)
		{
			$replyBan = \XF::app()->em()->create(DiscussionReplyBan::class);
			$replyBan->discussion_id = $discussion->discussion_id;
			$replyBan->user_id = $user->user_id;
		}

		$replyBan->ban_user_id = \XF::visitor()->user_id;

		$this->replyBan = $replyBan;
	}

	/**
	 * @return Discussion
	 */
	public function getDiscussion(): Discussion
	{
		return $this->discussion;
	}

	/**
	 * @return User
	 */
	public function getUser(): User
	{
		return $this->user;
	}

	/**
	 * @param $unit
	 * @param null $value
	 */
	public function setExpiryDate($unit, $value = null): void
	{
		if (is_int($unit))
		{
			$value = $unit;
			$expiryDate = $value;
		}
		else
		{
			if (!$value)
			{
				$value = 1;
			}
			$expiryDate = min(
				pow(2, 32) - 1,
				strtotime("+$value $unit")
			);
		}
		$this->replyBan->expiry_date = $expiryDate;
	}

	/**
	 * @param bool $alert
	 */
	public function setSendAlert(bool $alert): void
	{
		$this->alert = $alert;
	}

	/**
	 * @param string|null $reason
	 */
	public function setReason(?string $reason = null): void
	{
		if ($reason !== null)
		{
			$this->replyBan->reason = $reason;
		}
	}

	/**
	 *
	 */
	protected function finalSetup()
	{
	}

	/**
	 * @return array
	 */
	protected function _validate(): array
	{
		$this->finalSetup();

		$this->replyBan->preSave();
		$errors = $this->replyBan->getErrors();

		if ($this->user->is_staff)
		{
			$errors['is_staff'] = \XF::phrase('staff_members_cannot_be_reply_banned');
		}

		return $errors;
	}

	/**
	 * @return DiscussionReplyBan|null
	 * @throws PrintableException
	 */
	protected function _save(): ?DiscussionReplyBan
	{
		$replyBan = $this->replyBan;
		$replyBan->save();

		\XF::app()->logger()->logModeratorAction(
			'dbtech_social_discussion',
			$this->discussion,
			'reply_ban',
			[
				'name' => $replyBan->User->username,
				'reason' => $replyBan->reason,
			]
		);

		$this->sendAlert();

		return $replyBan;
	}

	/**
	 *
	 */
	protected function sendAlert(): void
	{
		$discussion = $this->discussion;
		$replyBan = $this->replyBan;

		if ($discussion->discussion_state == 'visible' && $this->alert)
		{
			$extra = [
				'reason' => $replyBan->reason,
				'expiry' => $replyBan->expiry_date,
			];

			\XF::app()->repository(UserAlertRepository::class)
				->alert(
					$replyBan->User,
					0,
					'',
					'dbtech_social_discussion',
					$discussion->discussion_id,
					'reply_ban',
					$extra
				)
			;
		}
	}
}