<?php

namespace DBTech\SocialGroups\Service\Discussion;

use DBTech\SocialGroups\Entity\Discussion;
use DBTech\SocialGroups\Entity\Message;
use DBTech\SocialGroups\Service\Message\NotifierService;
use DBTech\SocialGroups\Service\Message\PreparerService;
use XF\App;
use XF\Entity\User;
use XF\PrintableException;
use XF\Service\AbstractService;
use XF\Service\ValidateAndSavableTrait;
use XF\Validator\Username;

class ReplierService extends AbstractService
{
	use ValidateAndSavableTrait;

	protected Discussion $discussion;
	protected Message $message;
	protected User $user;
	protected PreparerService $messagePreparer;
	protected bool $performValidations = true;


	/**
	 * @param App $app
	 * @param Discussion $discussion
	 */
	public function __construct(App $app, Discussion $discussion)
	{
		parent::__construct($app);
		$this->setDiscussion($discussion);
		$this->setUser(\XF::visitor());
		$this->setMessageDefaults();
	}

	/**
	 * @param Discussion $discussion
	 */
	protected function setDiscussion(Discussion $discussion): void
	{
		$this->discussion = $discussion;
		$this->message = $discussion->getNewMessage();
		$this->messagePreparer = \XF::app()->service(
			PreparerService::class,
			$this->message
		);
	}

	/**
	 * @return Discussion
	 */
	public function getDiscussion(): Discussion
	{
		return $this->discussion;
	}

	/**
	 * @return Message
	 */
	public function getMessage(): Message
	{
		return $this->message;
	}

	/**
	 * @return PreparerService
	 */
	public function getMessagePreparer(): PreparerService
	{
		return $this->messagePreparer;
	}

	/**
	 * @param User $user
	 */
	protected function setUser(User $user): void
	{
		$this->user = $user;
	}

	/**
	 * @param bool $logIp
	 */
	public function logIp(bool $logIp): void
	{
		$this->messagePreparer->logIp($logIp);
	}

	/**
	 * @param bool $perform
	 */
	public function setPerformValidations(bool $perform): void
	{
		$this->performValidations = $perform;
	}

	/**
	 * @return bool
	 */
	public function getPerformValidations(): bool
	{
		return $this->performValidations;
	}

	/**
	 *
	 */
	public function setIsAutomated(): void
	{
		$this->logIp(false);
		$this->setPerformValidations(false);
	}

	/**
	 *
	 */
	protected function setMessageDefaults(): void
	{
		$group = $this->discussion->Group;

		if (!$group)
		{
			throw new \LogicException("Discussion is not in a valid group");
		}

		$section = $this->discussion->Section;

		if ($section)
		{
			$this->message->message_state = $section->getNewContentState($this->discussion);
		}
		else
		{
			$this->message->message_state = $group->getNewContentState($this->discussion);
		}

		$this->message->user_id = $this->user->user_id;
		$this->message->username = $this->user->username;
	}

	/**
	 * @param string $message
	 * @param bool $format
	 *
	 * @return bool
	 */
	public function setMessageContent(string $message, bool $format = true): bool
	{
		return $this->messagePreparer->setMessageContent($message, $format, $this->performValidations);
	}

	/**
	 * @param string $hash
	 */
	public function setAttachmentHash(string $hash): void
	{
		$this->messagePreparer->setAttachmentHash($hash);
	}

	/**
	 *
	 */
	public function checkForSpam(): void
	{
		if ($this->message->message_state == 'visible' && $this->user->isSpamCheckRequired())
		{
			$this->messagePreparer->checkForSpam();
		}
	}

	/**
	 *
	 */
	protected function finalSetup(): void
	{
		$this->message->message_date = time();
	}

	/**
	 * @return array
	 */
	protected function _validate(): array
	{
		$this->finalSetup();

		$message = $this->message;

		if (!$message->user_id)
		{
			/** @var Username $validator */
			$validator = \XF::app()->validator('Username');
			$message->username = $validator->coerceValue($message->username);
			if ($this->performValidations && !$validator->isValid($message->username, $error))
			{
				return [$validator->getPrintableErrorValue($error)];
			}
		}

		$message->preSave();
		return $message->getErrors();
	}

	/**
	 * @return Message
	 * @throws PrintableException
	 */
	protected function _save(): Message
	{
		$message = $this->message;

		$db = $this->db();
		$db->beginTransaction();

		$discussionLatest = $this->db()->fetchRow("
			SELECT *
			FROM xf_dbtech_social_groups_discussion
			WHERE discussion_id = ?
			FOR UPDATE
		", $this->discussion->discussion_id);

		// Ensure our discussion entity has the latest data to make sure things like reply count are correct
		$forceUpdateColumns = [
			'first_message_id',
			'reply_count',
			'last_message_date',
			'last_message_id',
			'last_message_user_id',
			'last_message_username',
		];
		foreach ($forceUpdateColumns AS $forceUpdateColumn)
		{
			$this->discussion->setAsSaved($forceUpdateColumn, $discussionLatest[$forceUpdateColumn]);
		}

		$this->setMessagePosition($discussionLatest);

		$message->save(true, false);

		$this->messagePreparer->afterInsert();

		$db->commit();

		return $message;
	}

	/**
	 * @param array $discussionInfo
	 */
	protected function setMessagePosition(array $discussionInfo): void
	{
		$message = $this->message;

		if ($message->message_date < $discussionInfo['last_message_date'])
		{
			throw new \LogicException("Replier can only add messages at the end of a discussion");
		}

		if ($message->message_state == 'visible')
		{
			$position = $discussionInfo['reply_count'] + 1;
		}
		else
		{
			$position = $discussionInfo['reply_count'];
		}

		$message->set('position', $position, ['forceSet' => true]);
	}

	/**
	 *
	 */
	public function sendNotifications(): void
	{
		if ($this->message->isVisible())
		{
			$notifier = \XF::app()->service(
				NotifierService::class,
				$this->message,
				'reply'
			);
			$notifier->setMentionedUserIds($this->messagePreparer->getMentionedUserIds());
			$notifier->setQuotedUserIds($this->messagePreparer->getQuotedUserIds());
			$notifier->notifyAndEnqueue(3);
		}
	}
}