<?php

namespace DBTech\SocialGroups\Service\Thread;

use DBTech\SocialGroups\Entity\Discussion;
use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Entity\Section;
use DBTech\SocialGroups\Job\GroupMemberRebuild;
use DBTech\SocialGroups\Service\Post\ImporterService as PostImporterService;
use XF\App;
use XF\ContinuationResult;
use XF\Db\Exception as DbException;
use XF\Entity\Post;
use XF\Entity\Thread;
use XF\Entity\User;
use XF\Finder\PostFinder;
use XF\MultiPartRunnerTrait;
use XF\Mvc\Entity\AbstractCollection;
use XF\PrintableException;
use XF\Repository\UserRepository;
use XF\Service\AbstractService;
use XF\Service\Thread\DeleterService;

use function count;

class ImporterService extends AbstractService
{
	use MultiPartRunnerTrait;

	protected array $steps = [
		'stepImportPosts',
		'stepFinalizeImport',
	];

	protected Thread $sourceThread;
	protected Discussion $targetDiscussion;
	protected Group $targetGroup;
	protected ?Section $targetSection = null;
	protected int $actorId;
	protected string $cleanupType = 'do_nothing';
	protected string $reason = '';
	protected bool $log = true;


	public function __construct(
		App $app,
		int $actorId,
		int $sourceThreadId,
		int $targetDiscussionId,
		int $targetGroupId,
		?int $targetSectionId = null
	)
	{
		parent::__construct($app);

		$this->actorId = $actorId;

		$sourceThread = \XF::app()->em()->find(Thread::class, $sourceThreadId);
		if ($sourceThread === null)
		{
			throw new \InvalidArgumentException("Invalid source thread ($sourceThreadId)");
		}

		$targetDiscussion = \XF::app()->em()->find(Discussion::class, $targetDiscussionId);
		if ($targetDiscussion === null)
		{
			throw new \InvalidArgumentException("Invalid target discussion ($targetDiscussionId)");
		}

		$targetGroup = \XF::app()->em()->find(Group::class, $targetGroupId);
		if ($targetGroup === null)
		{
			throw new \InvalidArgumentException("Invalid target social group ($targetGroupId)");
		}

		$targetSection = null;
		if ($targetSectionId !== null)
		{
			$targetSection = \XF::app()->em()->find(Section::class, $targetSectionId);
			if ($targetSection === null)
			{
				throw new \InvalidArgumentException("Invalid target social group section ($targetSectionId)");
			}
			if ($targetSection->group_id !== $targetGroup->group_id)
			{
				throw new \InvalidArgumentException("Target section's group does not match the target group");
			}
		}

		$this->sourceThread = $sourceThread;
		$this->targetGroup = $targetGroup;
		$this->targetDiscussion = $targetDiscussion;
		$this->targetSection = $targetSection;
	}

	/**
	 * @return array
	 */
	protected function getSteps(): array
	{
		return $this->steps;
	}

	public function setLog(bool $log): void
	{
		$this->log = $log;
	}

	public function setCleanupOptions(string $cleanupType, string $reason = ''): void
	{
		switch ($cleanupType)
		{
			case 'do_nothing':
			case 'soft':
			case 'hard':
				break;

			default:
				throw new \InvalidArgumentException("Unexpected cleanup type '$cleanupType'. Should be soft or hard.");
		}

		$this->cleanupType = $cleanupType;
		$this->reason = $reason;
	}

	/**
	 * @param int|null $lastOffset
	 * @param float|int $maxRunTime
	 *
	 * @return int|null
	 * @throws PrintableException
	 * @throws DbException
	 */
	protected function stepImportPosts(?int $lastOffset, float|int $maxRunTime): ?int
	{
		$start = microtime(true);

		$postImporter = \XF::app()->service(PostImporterService::class, $this->targetDiscussion);
		$postImporter->setLog(false);

		$finder = \XF::app()->finder(PostFinder::class)
			->where('thread_id', $this->sourceThread->thread_id)
		;

		if ($lastOffset !== null)
		{
			$finder->where('post_id', '>', $lastOffset);
		}

		$maxFetch = 100;

		/** @var AbstractCollection<Post> $posts */
		$posts = $finder->fetch($maxFetch);
		$fetchedPosts = count($posts);

		if (!$fetchedPosts)
		{
			return null; // done or nothing to do
		}

		$postImporter->import($posts);
		$lastOffset = $posts->last()->post_id;

		if ($fetchedPosts == $maxFetch)
		{
			return $lastOffset; // more to do
		}

		return null;
	}

	/**
	 * @throws \Exception
	 */
	protected function stepFinalizeImport(): void
	{
		$asUser = $this->app->em()->find(User::class, $this->actorId);
		if (!$asUser)
		{
			$asUser = $this->app->repository(UserRepository::class)->getGuestUser();
		}

		\XF::app()->jobManager()->enqueue(
			GroupMemberRebuild::class,
			['group_id' => $this->targetGroup->group_id]
		);

		\XF::asVisitor($asUser, fn () => $this->finalActions());
	}

	protected function finalActions(): void
	{
		$this->targetDiscussion->fastUpdate('view_count', $this->sourceThread->view_count);

		if ($this->cleanupType !== 'do_nothing')
		{
			$deleter = \XF::app()->service(DeleterService::class, $this->sourceThread);
			$deleter->delete($this->cleanupType, $this->reason);
		}

		if ($this->log)
		{
			\XF::app()->logger()->logModeratorAction(
				'dbtech_social_discussion',
				$this->targetDiscussion,
				'thread_copy_target',
				[
					'url'   => \XF::app()->router('public')->buildLink('nopath:threads', $this->sourceThread),
					'title' => $this->sourceThread->title,
				]
			);
			\XF::app()->logger()->logModeratorAction(
				'thread',
				$this->sourceThread,
				'dbt_soc_thread_copy_src',
				[
					'url'   => \XF::app()->router('public')->buildLink('nopath:dbtech-social/discussions', $this->targetDiscussion),
					'title' => $this->targetDiscussion->title,
				]
			);
		}
	}

	/**
	 * @param float|int $maxRunTime
	 *
	 * @return ContinuationResult
	 */
	public function import(float|int $maxRunTime = 0): ContinuationResult
	{
		$this->db()->beginTransaction();
		$result = $this->runLoop($maxRunTime);
		$this->db()->commit();

		return $result;
	}
}