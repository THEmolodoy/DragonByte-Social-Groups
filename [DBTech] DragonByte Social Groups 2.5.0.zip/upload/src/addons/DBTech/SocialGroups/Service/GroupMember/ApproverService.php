<?php

namespace DBTech\SocialGroups\Service\GroupMember;

use DBTech\SocialGroups\Entity\GroupMember;
use DBTech\SocialGroups\Repository\GroupMemberRepository;
use XF\App;
use XF\PrintableException;
use XF\Service\AbstractService;

class ApproverService extends AbstractService
{
	protected GroupMember $groupMember;
	protected bool $notify = true;
	protected int $notifyRunTime = 3;
	protected string $reason = '';


	/**
	 * @param App $app
	 * @param GroupMember $groupMember
	 */
	public function __construct(App $app, GroupMember $groupMember)
	{
		parent::__construct($app);
		$this->groupMember = $groupMember;
	}

	/**
	 * @return GroupMember
	 */
	public function getGroupMember(): GroupMember
	{
		return $this->groupMember;
	}

	/**
	 * @param bool $notify
	 *
	 * @return $this
	 */
	public function setNotify(bool $notify): ApproverService
	{
		$this->notify = $notify;

		return $this;
	}

	/**
	 * @param int $time
	 *
	 * @return $this
	 */
	public function setNotifyRunTime(int $time): ApproverService
	{
		$this->notifyRunTime = $time;

		return $this;
	}

	/**
	 * @param string $reason
	 *
	 * @return $this
	 */
	public function setReason(string $reason): ApproverService
	{
		$this->reason = $reason;

		return $this;
	}

	/**
	 * @return bool
	 * @throws \LogicException
	 * @throws \Exception
	 * @throws PrintableException
	 */
	public function approve(): bool
	{
		if ($this->groupMember->member_state == 'moderated')
		{
			$this->groupMember->member_state = 'valid';
			$this->groupMember->reason = '';
			$this->groupMember->save();

			$this->onApprove();
			return true;
		}

		return false;
	}

	/**
	 * @return bool
	 * @throws \LogicException
	 * @throws \Exception
	 * @throws PrintableException
	 */
	public function reject(): bool
	{
		if ($this->groupMember->member_state == 'moderated')
		{
			$this->groupMember->delete();

			$this->onReject();
			return true;
		}

		return false;
	}

	/**
	 * @throws PrintableException
	 */
	protected function onApprove(): void
	{
		$groupMember = $this->groupMember;

		$groupMember->fastUpdate('member_state', 'valid');

		$groupMemberRepo = \XF::app()->repository(GroupMemberRepository::class);

		// Membership request
		if ($this->reason)
		{
			$groupMemberRepo
				->logAction($groupMember, 'join_approve_reason', [
					'reason' => $this->reason,
				], \XF::visitor())
			;
		}
		else
		{
			$groupMemberRepo
				->logAction($groupMember, 'join_approve', [], \XF::visitor())
			;
		}

		if ($this->notify)
		{
			$groupMemberRepo->sendModeratorActionAlert($groupMember, 'approve', $this->reason);
		}
	}

	/**
	 * @throws \Exception
	 */
	protected function onReject(): void
	{
		$groupMember = $this->groupMember;
		$user = $groupMember->User;

		$groupMember->delete();

		$groupMemberRepo = \XF::app()->repository(GroupMemberRepository::class);

		// Membership request
		if ($this->reason)
		{
			$groupMemberRepo
				->logAction($groupMember, 'join_reject_reason', [
					'reason' => $this->reason,
				], \XF::visitor())
			;
		}
		else
		{
			$groupMemberRepo
				->logAction($groupMember, 'join_reject', [], \XF::visitor())
			;
		}

		if ($this->notify)
		{
			$groupMemberRepo->sendModeratorActionAlert($groupMember, 'reject', $this->reason);
		}
	}
}