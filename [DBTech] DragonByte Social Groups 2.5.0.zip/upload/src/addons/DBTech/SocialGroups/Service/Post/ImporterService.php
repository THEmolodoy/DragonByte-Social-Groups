<?php

namespace DBTech\SocialGroups\Service\Post;

use DBTech\SocialGroups\Entity\Discussion;
use DBTech\SocialGroups\Entity\Message;
use DBTech\SocialGroups\Repository\DiscussionRepository;
use XF\App;
use XF\Db\Exception as DbException;
use XF\Entity\Post;
use XF\Entity\Thread;
use XF\Mvc\Entity\AbstractCollection;
use XF\PrintableException;
use XF\Repository\ActivityLogRepository;
use XF\Repository\ReactionRepository;
use XF\Service\AbstractService;
use XF\Util\Arr;

use function array_key_exists, is_int;

class ImporterService extends AbstractService
{
	protected Discussion $target;
	protected bool $existingTarget = false;
	protected bool $log = true;

	/** @var Thread[] */
	protected array $sourceThreads = [];

	/** @var Post[] */
	protected array $sourcePosts = [];

	protected array $copiedReactions = [];


	public function __construct(App $app, Discussion $target)
	{
		parent::__construct($app);
		$this->target = $target;
	}

	public function getTarget(): Discussion
	{
		return $this->target;
	}

	public function setExistingTarget(bool $existing): void
	{
		$this->existingTarget = $existing;
	}

	public function setLog(bool $log): void
	{
		$this->log = $log;
	}

	/**
	 * @param AbstractCollection<Post>|Post|array $sourcePostsRaw
	 *
	 * @return bool
	 * @throws PrintableException
	 * @throws DbException
	 */
	public function import(AbstractCollection|Post|array $sourcePostsRaw): bool
	{
		if ($sourcePostsRaw instanceof AbstractCollection)
		{
			$sourcePostsRaw = $sourcePostsRaw->toArray();
		}
		else if ($sourcePostsRaw instanceof Post)
		{
			$sourcePostsRaw = [$sourcePostsRaw];
		}

		if (!$sourcePostsRaw)
		{
			return false;
		}

		$db = $this->db();

		/** @var Post[] $sourcePosts */
		$sourcePosts = [];

		/** @var Thread[] $sourceThreads */
		$sourceThreads = [];

		foreach ($sourcePostsRaw AS $sourcePost)
		{
			$sourcePost->setOption('log_moderator', false);
			$sourcePosts[$sourcePost->post_id] = $sourcePost;

			/** @var Thread $sourceThread */
			$sourceThread = $sourcePost->Thread;
			if (!isset($sourceThreads[$sourceThread->thread_id]))
			{
				$sourceThread->setOption('log_moderator', false);
				$sourceThreads[$sourceThread->thread_id] = $sourceThread;
			}
		}

		$sourcePosts = Arr::columnSort($sourcePosts, 'post_date');

		$this->sourceThreads = $sourceThreads;
		$this->sourcePosts = $sourcePosts;

		$target = $this->target;
		$target->setOption('log_moderator', false);

		if (!$target->discussion_id)
		{
			$firstPost = reset($sourcePosts);

			$target->user_id = $firstPost->user_id;
			$target->username = $firstPost->username;
			$target->message_date = $firstPost->post_date;
		}

		$db->beginTransaction();

		$target->save();

		$this->copyDataToTarget();
		$this->updateTargetData();
		$this->updateActivityLog();
		$this->updateUserCounters();

		$this->finalActions();

		$db->commit();

		return true;
	}

	/**
	 * @return void
	 * @throws PrintableException
	 */
	protected function copyDataToTarget(): void
	{
		$reactionRepo = \XF::repository(ReactionRepository::class);
		$postDataMap = $this->getPostDataMap();

		$position = 0;
		$firstMessage = $this->existingTarget ? $this->target->FirstMessage : null;

		// messages are sorted in date order
		foreach ($this->sourcePosts AS $sourcePost)
		{
			$newMessage = \XF::em()->create(Message::class);

			$values = $sourcePost->toArray(false);

			$newMessage->discussion_id = $this->target->discussion_id;
			$newMessage->bulkSet($this->mapPostData($values, $postDataMap));

			$newMessage->position = $position;
			if (!$firstMessage)
			{
				// first message is always visible, set $firstMessage later
				$this->target->discussion_state = $newMessage->message_state;
				$newMessage->message_state = 'visible';
			}

			$newMessage->save();

			if (!$firstMessage)
			{
				$firstMessage = $newMessage;

				$this->target->fastUpdate('first_message_id', $newMessage->message_id);
			}

			$embedMetadata = $sourcePost->embed_metadata;
			$newMessage->embed_metadata = $this->updateEmbeds(
				$sourcePost,
				$newMessage,
				$embedMetadata ?: []
			);
			$newMessage->saveIfChanged();

			if ($newMessage->message_state == 'visible')
			{
				$position++;
			}

			$db = \XF::db();
			$sourceReactions = $db->fetchAllKeyed("
				SELECT *
				FROM xf_reaction_content AS reaction_content
				INNER JOIN xf_reaction AS reaction
					ON (reaction.reaction_id = reaction_content.reaction_id)
				WHERE content_type = 'post'
				AND content_id = ?
			", 'reaction_content_id', $sourcePost->post_id);
			if ($sourceReactions)
			{
				foreach ($sourceReactions AS $sourceReaction)
				{
					// Insert the new reaction data
					$db->insert(
						'xf_reaction_content',
						[
							'reaction_id' => $sourceReaction['reaction_id'],
							'content_type' => 'dbtech_social_message',
							'content_id' => $newMessage->message_id,
							'reaction_user_id' => $sourceReaction['reaction_user_id'],
							'reaction_date' => $sourceReaction['reaction_date'],
							'content_user_id' => $sourceReaction['content_user_id'],
							'is_counted' => $sourceReaction['is_counted'],
						],
						false,
						false,
						'IGNORE'
					);
				}
				$this->copiedReactions = \array_merge($this->copiedReactions, $sourceReactions);
			}

			$reactionRepo->rebuildContentReactionCache(
				'dbtech_social_message',
				$newMessage->message_id
			);
		}
	}

	/**
	 * @return string[]
	 */
	protected function getPostDataMap(): array
	{
		return  [
			'user_id',
			'username',
			'message_date' => 'post_date',
			'message',
			'ip_id',
			'message_state',
			'attach_count',
		];
	}

	/**
	 * @param array $originalData
	 * @param array $map
	 * @param bool $skipUnset
	 *
	 * @return array
	 */
	public function mapPostData(array $originalData, array $map, bool $skipUnset = false): array
	{
		$output = [];

		foreach ($map AS $newKey => $originalKey)
		{
			if (is_int($newKey))
			{
				$newKey = $originalKey;
			}

			if (!array_key_exists($originalKey, $originalData))
			{
				if ($skipUnset)
				{
					continue;
				}

				throw new \InvalidArgumentException("Could not find '$originalKey' in data");
			}

			$output[$newKey] = $originalData[$originalKey];
		}

		$output['message'] = $this->rewriteQuotes($output['message']);

		return $output;
	}

	/**
	 * @param string $text
	 *
	 * @return array|string|string[]|null
	 */
	protected function rewriteQuotes(string $text): array|string|null
	{
		if (stripos($text, '[quote=') === false)
		{
			return $text;
		}

		return preg_replace_callback(
			'/\[quote=("|\'|)(?P<username>[^,]*)\s*,\s*(?P<content_type>[^:]*):\s*(?P<content_id>\d+)\s*(?:,\s*member:\s*(?P<user_id>\d+))?\s*\1\]/iU',
			function ($match)
			{
				if (trim($match['content_type']) == 'post' && \in_array(\XF::db()->fetchOne("
					SELECT thread_id
					FROM xf_post
					WHERE post_id = ?
				", $match['content_id']), \array_keys($this->sourceThreads)))
				{
					// Post belongs to an imported thread
					if (!empty($match['user_id']))
					{
						return sprintf(
							'[QUOTE="%s, member: %d"]',
							$match['username'],
							$match['user_id']
						);
					}
					else
					{
						return sprintf(
							'[QUOTE="%s"]',
							$match['username'],
						);
					}
				}

				return $match[0];
			},
			$text
		);
	}

	/**
	 * @param Post $sourcePost
	 * @param Message $newMessage
	 * @param array $embedMetadata
	 *
	 * @return array
	 * @throws PrintableException
	 */
	protected function updateEmbeds(Post $sourcePost, Message $newMessage, array $embedMetadata): array
	{
		$attachEmbed = $embedMetadata['attachments'] ?? [];

		foreach ($sourcePost->Attachments AS $sourceAttachment)
		{
			$newAttachment = $sourceAttachment->createDuplicate();
			$newAttachment->content_type = 'dbtech_social_message';
			$newAttachment->content_id = $newMessage->message_id;
			$newAttachment->save();

			$newMessage->message = preg_replace(
				'#(\[attach[^\]]*\])' . $sourceAttachment->attachment_id . '(\[/attach\])#i',
				'${1}' . $newAttachment->attachment_id . '${2}',
				$newMessage->message
			);

			if (isset($attachEmbed[$sourceAttachment->attachment_id]))
			{
				unset($attachEmbed[$sourceAttachment->attachment_id]);
				$attachEmbed[$newAttachment->attachment_id] = $newAttachment->attachment_id;
			}
		}

		if ($attachEmbed)
		{
			$embedMetadata['attachments'] = $attachEmbed;
		}
		else
		{
			unset($embedMetadata['attachments']);
		}

		return $embedMetadata;
	}

	/**
	 * @return void
	 * @throws PrintableException
	 * @throws DbException
	 */
	protected function updateTargetData(): void
	{
		$target = $this->target;

		$target->rebuildCounters();
		$target->save();

		$target->Group->rebuildCounters();
		$target->Group->save();

		if ($target->Section)
		{
			$target->Section->rebuildCounters();
			$target->Section->save();
		}

		$discussionRepo = \XF::repository(DiscussionRepository::class);
		$discussionRepo->rebuildDiscussionMessagePositions($target->discussion_id);
		$discussionRepo->rebuildDiscussionUserMessageCounters($target->discussion_id);
	}

	protected function updateActivityLog(): void
	{
		if (!$this->existingTarget)
		{
			return;
		}

		foreach ($this->sourcePosts AS $sourcePost)
		{
			if ($sourcePost->post_date <= $this->target->message_date)
			{
				$activityLogRepo = \XF::repository(ActivityLogRepository::class);
				$activityLogRepo->rebuildReactionMetrics($this->target);
				break;
			}
		}
	}

	/**
	 * @throws DbException
	 */
	protected function updateUserCounters(): void
	{
		$target = $this->target;

		$userReactionCountAdjust = [];
		$targetReactionsCount = $target->discussion_state == 'visible';

		foreach ($this->copiedReactions AS $reactionContentId => $reactionContent)
		{
			$sourceReactionsCount = $reactionContent['is_counted'];
			$targetUserId = $target->user_id;
			$reactionScore = $reactionContent['reaction_score'];

			if ($targetReactionsCount && $sourceReactionsCount && $targetUserId)
			{
				if (!isset($userReactionCountAdjust[$targetUserId]))
				{
					$userReactionCountAdjust[$targetUserId] = 0;
				}

				$userReactionCountAdjust[$targetUserId] += $reactionScore;
			}
		}

		foreach ($userReactionCountAdjust AS $userId => $adjust)
		{
			if (!$adjust)
			{
				continue;
			}

			\XF::db()->query(
				'UPDATE xf_user
					SET reaction_score = reaction_score + ?
					WHERE user_id = ?',
				[$adjust, $userId]
			);
		}
	}

	protected function finalActions(): void
	{
		$target = $this->target;
		$postIds = array_keys($this->sourcePosts);

		if ($this->log)
		{
			$this->app->logger()->logModeratorAction(
				'dbtech_social_discussion',
				$target,
				'post_copy_target' . ($this->existingTarget ? '_existing' : ''),
				['ids' => implode(', ', $postIds)]
			);

			foreach ($this->sourceThreads AS $sourceThread)
			{
				$this->app->logger()->logModeratorAction(
					'thread',
					$sourceThread,
					'dbt_soc_post_copy_source',
					[
						'url' => $this->app->router('public')->buildLink('nopath:threads', $target),
						'title' => $target->title,
					]
				);
			}
		}
	}
}