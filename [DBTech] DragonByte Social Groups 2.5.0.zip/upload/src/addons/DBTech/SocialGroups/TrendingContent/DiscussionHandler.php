<?php

namespace DBTech\SocialGroups\TrendingContent;

use DBTech\SocialGroups\Entity\Discussion;
use XF\Mvc\Entity\AbstractCollection;
use XF\Repository\AttachmentRepository;
use XF\TrendingContent\AbstractHandler;

use function in_array;

/**
 * @extends AbstractHandler<Discussion>
 */
class DiscussionHandler extends AbstractHandler
{
	public function getEntityWith(string $style): array
	{
		$visitor = \XF::visitor();

		$with = [
			'Group',
			'Group.Permissions|' . $visitor->permission_combination_id,
			'User',
		];

		if (
			in_array($style, ['article', 'carousel'], true) ||
			$this->areAttachmentsHydratedForStyle($style)
		)
		{
			$with[] = 'FirstMessage';
		}

		return $with;
	}

	public function filterContent(AbstractCollection $content): AbstractCollection
	{
		return $content->filter(
			function (Discussion $item): bool
			{
				return $item->canView() && !$item->isIgnored();
			}
		);
	}

	public function addAttachmentsToContent(AbstractCollection $content): void
	{
		$firstMessages = $content
			->filter(function (Discussion $discussion): bool
			{
				return $discussion->FirstMessage !== null;
			})
			->pluckNamed('FirstMessage', 'first_message_id');

		$attachmentRepo = \XF::repository(AttachmentRepository::class);
		$attachmentRepo->addAttachmentsToContent($firstMessages, 'dbtech_social_message');
	}
}