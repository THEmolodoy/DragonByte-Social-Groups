<?php

namespace DBTech\SocialGroups\ActivityLog;

use DBTech\SocialGroups\Entity\Message;
use XF\ActivityLog\AbstractShimHandler;
use XF\Mvc\Entity\Entity;

use function in_array;

/**
 * @extends AbstractShimHandler<Message>
 */
class MessageHandler extends AbstractShimHandler
{
	public function log(
		Entity $content,
		int $logDate,
		array $values,
		bool $increment
	): void
	{
		if (!$content->isFirstMessage())
		{
			return;
		}

		$discussion = $content->Discussion;
		if (!$discussion)
		{
			return;
		}

		$values = array_filter(
			$values,
			function ($type)
			{
				return in_array($type, ['reaction_count', 'reaction_score']);
			},
			ARRAY_FILTER_USE_KEY
		);

		$this->getActivityLogRepo()->log(
			$discussion,
			$logDate,
			$values,
			$increment
		);
	}
}