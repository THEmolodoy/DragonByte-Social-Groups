<?php

namespace DBTech\SocialGroups\ActivityLog;

use DBTech\SocialGroups\Entity\Discussion;
use XF\ActivityLog\AbstractHandler;
use XF\Mvc\Entity\Entity;

/**
 * @extends AbstractHandler<Discussion>
 */
class DiscussionHandler extends AbstractHandler
{
	protected function getReplyMetrics(Entity $content): array
	{
		return $this->getReplyMetricsSimple(
			'xf_dbtech_social_groups_message',
			'message_date',
			'discussion_id = ?',
			[$content->getEntityId()]
		);
	}

	protected function getReactionMetrics(Entity $content): array
	{
		$firstMessage = $content->FirstMessage;
		if (!$firstMessage)
		{
			return [];
		}

		return parent::getReactionMetrics($firstMessage);
	}
}