<?php

namespace DBTech\SocialGroups\ContentVote;

use DBTech\SocialGroups\Entity\Message;
use XF\ContentVote\AbstractHandler;
use XF\Mvc\Entity\Entity;

/**
 * @extends AbstractHandler<Message>
 */
class MessageHandler extends AbstractHandler
{
	public function isCountedForContentUser(Entity $entity): bool
	{
		return $entity->isVisible();
	}

	public function getEntityWith(): array
	{
		$visitor = \XF::visitor();
		return [
			'Discussion',
			'Discussion.Group',
			'Discussion.Group.Permissions|' . $visitor->permission_combination_id,
		];
	}
}