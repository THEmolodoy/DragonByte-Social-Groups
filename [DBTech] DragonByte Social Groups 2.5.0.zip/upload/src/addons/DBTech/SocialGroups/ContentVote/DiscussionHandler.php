<?php

namespace DBTech\SocialGroups\ContentVote;

use DBTech\SocialGroups\Entity\Discussion;
use XF\ContentVote\AbstractHandler;
use XF\Mvc\Entity\Entity;

/**
 * @extends AbstractHandler<Discussion>
 */
class DiscussionHandler extends AbstractHandler
{
	public function isCountedForContentUser(Entity $entity): bool
	{
		return false;
	}

	public function getEntityWith(): array
	{
		$visitor = \XF::visitor();
		return [
			'Group',
			'Group.Permissions|' . $visitor->permission_combination_id,
		];
	}
}