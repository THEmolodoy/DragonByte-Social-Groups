<?php

namespace DBTech\SocialGroups;

use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Repository\GroupInviteRepository;
use DBTech\SocialGroups\Repository\GroupMemberRepository;
use DBTech\SocialGroups\Repository\GroupRepository;
use DBTech\SocialGroups\XF\Entity\User as ExtendedUserEntity;
use XF\Container;
use XF\Entity\User;
use XF\Import\Manager;
use XF\Mvc\Renderer\AbstractRenderer;
use XF\Mvc\Reply\AbstractReply;
use XF\Pub\App;
use XF\Service\User\ContentChangeService;
use XF\Service\User\DeleteCleanUpService;
use XF\SubContainer\Import;
use XF\Template\Templater;

class Listener
{
	/**
	 * The product ID (in the DBTech store)
	 * @var int
	 */
	protected static int $_productId = 414;

	/**
	 * Called after the public \XF\Pub\App object has been setup.
	 *
	 * @param App $app Public App object.
	 */
	public static function appPubSetup(App $app): void
	{
		/*DBTECH_BRANDING_START*/
		// Make sure we fetch the branding array from the application
		$branding = $app->offsetExists('dbtech_branding') ? $app->dbtech_branding : [];

		// Add productid to the array
		$branding[] = self::$_productId;

		// Store the branding
		$app->dbtech_branding = $branding;
		/*DBTECH_BRANDING_END*/
	}

	/**
	 * @param App $app
	 * @param array $params
	 * @param AbstractReply $reply
	 * @param AbstractRenderer $renderer
	 */
	public static function appPubRenderPage(
		App $app,
		array &$params,
		AbstractReply $reply,
		AbstractRenderer $renderer
	): void
	{
		$visitor = \XF::visitor();

		if (!$visitor->user_id)
		{
			return;
		}

		if (isset($params['navTree']['dbtechSocial']))
		{
			$attributes = $params['navTree']['dbtechSocial']['attributes'];

			$attributes['class'] = $attributes['class'] ?? '';
			$attributes['data-badge'] = $attributes['data-badge'] ?? 0;

			$attributes['class'] .= ' badgeContainer';
			if ($visitor->dbtech_social_groups_group_invitation_count)
			{
				$attributes['class'] .= ' badgeContainer--highlighted';
				$attributes['data-badge'] = $visitor->dbtech_social_groups_group_invitation_count;
			}

			$params['navTree']['dbtechSocial']['attributes'] = $attributes;
		}
	}

	/**
	 * Fired inside the constructor of the \XF\Service\User\DeleteCleanUp class.
	 *
	 * @param DeleteCleanUpService $deleteService The service being initialized.
	 * @param array                                 $deletes       A list of tables and where clauses
	 *                                                             representing content to be removed when a user is deleted.
	 */
	public static function userDeleteCleanInit(DeleteCleanUpService $deleteService, array &$deletes): void
	{
		$deletes['xf_dbtech_social_groups_discussion_read'] = 'user_id = ?';
		$deletes['xf_dbtech_social_groups_discussion_reply_ban'] = 'user_id = ?';
		$deletes['xf_dbtech_social_groups_discussion_user_message'] = 'user_id = ?';
		$deletes['xf_dbtech_social_groups_discussion_watch'] = 'user_id = ?';
		$deletes['xf_dbtech_social_groups_group_ban'] = 'user_id = ?';
		$deletes['xf_dbtech_social_groups_group_invite'] = 'user_id = ?';
		$deletes['xf_dbtech_social_groups_group_member_log'] = 'user_id = ?';
		$deletes['xf_dbtech_social_groups_group_read'] = 'user_id = ?';
		$deletes['xf_dbtech_social_groups_group_watch'] = 'user_id = ?';
	}

	/**
	 * Fired inside the constructor for the \XF\Service\User\ContentChange class.
	 *
	 * @param ContentChangeService $changeService The service being initialized.
	 * @param array                                 $updates       A list of tables and columns within
	 *                                                             that need to be updated when this service runs.
	 */
	public static function userContentChangeInit(ContentChangeService $changeService, array &$updates): void
	{
		$updates['xf_dbtech_social_groups_group'] = ['last_message_user_id', 'last_message_username'];
		$updates['xf_dbtech_social_groups_group_watch'] = ['user_id', 'emptyable' => false];
		$updates['xf_dbtech_social_groups_message'] = ['user_id', 'username'];
		$updates['xf_dbtech_social_groups_discussion'] = [
			['user_id', 'username'],
			['last_message_user_id', 'last_message_username'],
		];
		$updates['xf_dbtech_social_groups_discussion_read'] = ['user_id', 'emptyable' => false];
		$updates['xf_dbtech_social_groups_discussion_reply_ban'] = [
			['user_id', 'emptyable' => false],
			['ban_user_id'],
		];
		$updates['xf_dbtech_social_groups_discussion_user_message'] = ['user_id'];
		$updates['xf_dbtech_social_groups_discussion_watch'] = ['user_id', 'emptyable' => false];
		$updates['xf_dbtech_social_groups_group_ban'] = [
			['user_id', 'emptyable' => false],
			['ban_user_id'],
		];
		$updates['xf_dbtech_social_groups_group_invite'] = ['user_id', 'emptyable' => false];
		$updates['xf_dbtech_social_groups_group_member_log'] = [
			['user_id', 'username'],
			['actor_id', 'actor_username'],
		];
		$updates['xf_dbtech_social_groups_group_read'] = ['user_id', 'emptyable' => false];
		$updates['xf_dbtech_social_groups_group_watch'] = ['user_id', 'emptyable' => false];
	}

	/**
	 * Fired when the Templater object has been setup.
	 *
	 * @param Container          $container Dependency injection container object.
	 * @param Templater $templater The Templater object. Note: This could also be
	 *                                          the Mailer templater.
	 */
	public static function templaterSetup(Container $container, Templater &$templater): void
	{
		$templater->addFunction('dbtech_social_groups_member_blurb', [$templater, 'fnDbtechSocialMemberBlurb']);
		$templater->addFunction('dbtech_social_groups_member_title', [$templater, 'fnDbtechSocialMemberTitle']);
		$templater->addFunction('dbtech_social_groups_group_banner', [$templater, 'fnDbtechSocialGroupBanner']);
		$templater->addFunction('dbtech_social_groups_group_icon', [$templater, 'fnDbtechSocialGroupIcon']);
		$templater->addFunction('dbtech_social_groups_user_banner', [$templater, 'fnDbtechSocialGroupUserBanner']);
	}

	/**
	 * Called while testing a user against user criteria in \XF\Criteria\User::isMatch() for trophies,
	 * notices etc.
	 *
	 * @param string $rule Text identifying the criteria that should be checked.
	 * @param array $data Data defining the conditions of the criteria.
	 * @param User $user User entity object to be used in the criteria checks.
	 * @param bool $returnValue The event code should set this to true if a criteria check matches.
	 */
	public static function criteriaUser(string $rule, array $data, User $user, bool &$returnValue): void
	{
		/** @var ExtendedUserEntity $user */

		switch ($rule)
		{
			case 'dbtech_social_groups_group_count':
				if (isset($user->dbtech_social_groups_group_count)
					&& $user->dbtech_social_groups_group_count >= $data['groups']
				)
				{
					$returnValue = true;
				}
				break;

			case 'not_dbtech_social_groups_group_count':
				if (isset($user->dbtech_social_groups_group_count)
					&& $user->dbtech_social_groups_group_count < $data['groups']
				)
				{
					$returnValue = true;
				}
				break;

			case 'dbtech_social_groups_group_joined_count':
				if (isset($user->dbtech_social_groups_group_joined_count)
					&& $user->dbtech_social_groups_group_joined_count >= $data['memberships']
				)
				{
					$returnValue = true;
				}
				break;

			case 'not_dbtech_social_groups_group_joined_count':
				if (isset($user->dbtech_social_groups_group_joined_count)
					&& $user->dbtech_social_groups_group_joined_count < $data['memberships']
				)
				{
					$returnValue = true;
				}
				break;
		}
	}

	/**
	 * Fired inside the importers container in the Import sub-container. Add-ons can use this to add
	 * additional importer classes to the importer list. The class names can be fully qualified or the
	 * short class version e.g. AddOn:ClassName.
	 *
	 * @param Import $container       Import sub-container object.
	 * @param Container           $parentContainer Global App object.
	 * @param array                   $importers       Array of importers.
	 */
	public static function importImporterClasses(Import $container, Container $parentContainer, array &$importers): void
	{
		$importers = array_merge(
			$importers,
			Manager::getImporterShortNamesForType('DBTech/SocialGroups')
		);
	}

	/**
	 * @param Templater $templater Templater object.
	 * @param string $type Template type.
	 * @param string $template Template name.
	 * @param string $name Macro ID.
	 * @param array $arguments Array of arguments passed to this macro.
	 * @param array $globalVars Array of global vars available to this macro.
	 *
	 * @noinspection PhpUnusedParameterInspection
	 */
	public static function templaterMacroPreRender(
		Templater $templater,
		string &$type,
		string &$template,
		string &$name,
		array &$arguments,
		array &$globalVars
	): void
	{
		$hint = "$type:$template:$name";

		switch ($hint)
		{
			case 'admin:dbtech_social_groups_user_delete_macros:group':
				/** @var ExtendedUserEntity $user */
				$user = $arguments['user'];

				if (\XF::options()->dbtechSocialTransferDefaultRecipient && $user->OwnedSocialGroups)
				{
					$arguments['defaultRecipient'] = \XF::app()->em()->find(
						User::class,
						\XF::options()->dbtechSocialTransferDefaultRecipient
					);
				}
				break;

			case 'admin:dbtech_social_groups_user_batch_update_macros:confirm_update':
			case 'admin:dbtech_social_groups_user_batch_update_macros:confirm_delete':
				if (\XF::options()->dbtechSocialTransferDefaultRecipient)
				{
					$arguments['defaultRecipient'] = \XF::app()->em()->find(
						User::class,
						\XF::options()->dbtechSocialTransferDefaultRecipient
					);
				}
				break;

			case 'public:dbtech_social_groups_group_list_wrapper:links':
				/** @var ExtendedUserEntity $visitor */
				$visitor = \XF::visitor();

				if ($visitor->user_id)
				{
					$arguments['invitations'] = \XF::repository(GroupInviteRepository::class)
						->findGroupInvitesForUser($visitor)
						->total()
					;
				}
				break;

			case 'public:dbtech_social_groups_group_wrapper:links':
				/** @var Group $group */
				$group = $arguments['group'];

				if ($group->canApproveRejectMembers())
				{
					$arguments['unapprovedMembers'] = \XF::repository(GroupMemberRepository::class)
						->getUnapprovedMembersInGroup($group)
						->total()
					;
				}
				break;

			case 'public:dbtech_social_groups_membership_macros:tabs':
				/** @var ExtendedUserEntity $user */
				$user = $arguments['user'];

				$groupMemberRepo = \XF::repository(GroupMemberRepository::class);

				$joinedCollection = $groupMemberRepo->getGroupMembershipsForUser($user)->fetch();
				if ($user->user_id === \XF::visitor()->user_id)
				{
					$arguments['joined'] = $joinedCollection->count();
				}
				else
				{
					$arguments['joined'] = $joinedCollection->filterViewable()->count();
				}

				$pendingCollection = $groupMemberRepo->getUnapprovedGroupMembershipsForUser($user)->fetch();
				if ($user->user_id === \XF::visitor()->user_id)
				{
					$arguments['pending'] = $pendingCollection->count();
				}
				else
				{
					$arguments['pending'] = $pendingCollection->filterViewable()->count();
				}

				$bansCollection = $groupMemberRepo->getBannedGroupMembershipsForUser($user)->fetch();
				if ($user->user_id === \XF::visitor()->user_id)
				{
					$arguments['bans'] = $bansCollection->count();
				}
				else
				{
					$arguments['bans'] = $bansCollection->filterViewable()->count();
				}
				break;

			case 'public:dbtech_social_groups_node_list_container:depth1':
				$arguments['groupMemberships'] = \XF::repository(GroupRepository::class)
					->getJoinedGroups()
				;
				break;
		}
	}
}