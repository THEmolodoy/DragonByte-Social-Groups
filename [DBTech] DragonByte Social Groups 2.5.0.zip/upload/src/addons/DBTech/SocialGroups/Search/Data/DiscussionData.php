<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\Search\Data;

use DBTech\SocialGroups\Entity\Discussion;
use XF\Mvc\Entity\Entity;
use XF\Search\Data\AbstractData;
use XF\Search\IndexRecord;
use XF\Search\MetadataStructure;

/**
 * @extends AbstractData<Discussion>
 */
class DiscussionData extends AbstractData
{
	/**
	 * @param false $forView
	 *
	 * @return string[]
	 */
	public function getEntityWith($forView = false): array
	{
		$get = ['Group', 'FirstMessage'];
		if ($forView)
		{
			$get[] = 'User';

			$visitor = \XF::visitor();
			$get[] = 'Group.Permissions|' . $visitor->permission_combination_id;
		}

		return $get;
	}

	public function getIndexData(Entity $entity): ?IndexRecord
	{
		if (!$entity->Group || $entity->discussion_type == 'redirect')
		{
			return null;
		}

		$firstMessage = $entity->FirstMessage;

		$index = IndexRecord::create('dbtech_social_discussion', $entity->discussion_id, [
			'title' => $entity->title_,
			'message' => $firstMessage ? $firstMessage->message : '',
			'date' => $entity->message_date,
			'user_id' => $entity->user_id,
			'discussion_id' => $entity->discussion_id,
			'metadata' => $this->getMetaData($entity),
		]);

		if (!$entity->isVisible())
		{
			$index->setHidden();
		}

		if ($entity->tags)
		{
			$index->indexTags($entity->tags);
		}

		return $index;
	}

	protected function getMetaData(Discussion $entity): array
	{
		return [
			'group' => $entity->group_id,
			'discussion' => $entity->discussion_id,
			'discussion_type' => $entity->discussion_type,
		];
	}

	public function setupMetadataStructure(MetadataStructure $structure): void
	{
		$structure->addField('group', MetadataStructure::INT);
		$structure->addField('discussion', MetadataStructure::INT);
		$structure->addField('discussion_type', MetadataStructure::KEYWORD);
	}

	public function getResultDate(Entity $entity): int
	{
		return $entity->message_date;
	}

	public function getTemplateData(Entity $entity, array $options = []): array
	{
		return [
			'discussion' => $entity,
			'options' => $options,
		];
	}

	public function canUseInlineModeration(Entity $entity, &$error = null): bool
	{
		return $entity->canUseInlineModeration($error);
	}
}