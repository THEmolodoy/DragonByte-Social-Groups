<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\Search\Data;

use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Finder\GroupFinder;
use DBTech\SocialGroups\XF\Entity\User as ExtendedUserEntity;
use XF\Http\Request;
use XF\InputFilterer;
use XF\Mvc\Entity\Entity;
use XF\Search\Data\AbstractData;
use XF\Search\IndexRecord;
use XF\Search\MetadataStructure;
use XF\Search\Query\MetadataConstraint;
use XF\Search\Query\Query;
use XF\Search\Query\SqlConstraint;
use XF\Search\Query\SqlOrder;
use XF\Search\Query\TableReference;

/**
 * @extends AbstractData<Group>
 */
class GroupData extends AbstractData
{
	public function getEntityWith($forView = false): array
	{
		$get = ['LastDiscussion'];

		if ($forView)
		{
			$get[] = 'User';

			$visitor = \XF::visitor();
			$get[] = 'Permissions|' . $visitor->permission_combination_id;
		}

		return $get;
	}

	public function getIndexData(Entity $entity): IndexRecord
	{
		$index = IndexRecord::create('dbtech_social_group', $entity->group_id, [
			'title' => $entity->title,
			'message' => strip_tags($entity->description),
			'date' => $entity->last_update_date,
			'user_id' => $entity->user_id,
			'discussion_id' => $entity->group_id,
			'metadata' => $this->getMetaData($entity),
		]);

		if (!$entity->isVisible())
		{
			$index->setHidden();
		}

		if ($entity->tags)
		{
			$index->indexTags($entity->tags);
		}

		return $index;
	}

	protected function getMetaData(Group $entity): array
	{
		return [
			'group' => $entity->group_id,
			'group_type' => $entity->group_type,
		];
	}

	public function setupMetadataStructure(MetadataStructure $structure): void
	{
		$structure->addField('group', MetadataStructure::INT);
		$structure->addField('group_type', MetadataStructure::KEYWORD);
	}

	public function getResultDate(Entity $entity): int
	{
		return $entity->last_update_date;
	}

	public function getTemplateData(Entity $entity, array $options = []): array
	{
		return [
			'group' => $entity,
			'options' => $options,
		];
	}

	public function getSearchFormTab(): ?array
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();
		if (!$visitor->canViewDbtechSocialGroups())
		{
			return null;
		}

		return [
			'title' => \XF::phrase('dbtech_social_groups_search_groups'),
			'order' => 11,
		];
	}

	public function getSectionContext(): string
	{
		return 'dbtechSocial';
	}

	public function applyTypeConstraintsFromInput(
		Query $query,
		Request $request,
		array &$urlConstraints
	): void
	{
		$minMemberCount = $request->filter('c.min_member_count', InputFilterer::UNSIGNED);
		if ($minMemberCount)
		{
			$query->withSql(new SqlConstraint(
				'social_group.member_count >= %s',
				$minMemberCount,
				$this->getGroupQueryTableReference()
			));
		}
		else
		{
			unset($urlConstraints['min_member_count']);
		}

		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		$groupRestriction = $visitor->user_id ? $request->filter('c.group_restrictions', InputFilterer::STRING) : 'all_groups';
		switch ($groupRestriction)
		{
			case 'only_member':
				$groupIds = \XF::db()->fetchAllColumn("
					SELECT group_id
					FROM xf_dbtech_social_groups_group_member
					WHERE user_id = ?
				", $visitor->user_id);
				if (empty($groupIds))
				{
					// Ensure impossible condition, has to be positive int
					$groupIds = [PHP_INT_MAX];
				}
				break;

			case 'only_owned':
				$groupIds = \XF::db()->fetchAllColumn("
					SELECT group_id
					FROM xf_dbtech_social_groups_group
					WHERE user_id = ?
				", $visitor->user_id);
				if (empty($groupIds))
				{
					// Ensure impossible condition, has to be positive int
					$groupIds = [PHP_INT_MAX];
				}
				break;

			case 'all_groups':
			default:
				$groupIds = [];
				break;
		}

		$groupIds = array_unique($groupIds);
		if ($groupIds && reset($groupIds))
		{
			$query->withMetadata('group', $groupIds);
		}
		else
		{
			unset($urlConstraints['groups']);
			unset($urlConstraints['group_restrictions']);
		}
	}

	public function getTypePermissionConstraints(Query $query, $isOnlyType): array
	{
		$skip = [];
		$groups = \XF::app()->em()->getFinder(GroupFinder::class)
			->with('Permissions|' . \XF::visitor()->permission_combination_id)
			->fetch();

		/** @var Group $group */
		foreach ($groups AS $group)
		{
			if (!$group->canView())
			{
				$skip[] = $group->group_id;
			}
		}

		if ($skip)
		{
			return [
				new MetadataConstraint('group', $skip, MetadataConstraint::MATCH_NONE),
			];
		}
		else
		{
			return [];
		}
	}

	public function getTypeOrder($order): ?SqlOrder
	{
		if ($order == 'members')
		{
			return new SqlOrder('social_group.member_count DESC', $this->getGroupQueryTableReference());
		}
		else
		{
			return null;
		}
	}

	protected function getGroupQueryTableReference(): TableReference
	{
		return new TableReference(
			'social_group',
			'xf_dbtech_social_groups_group',
			'social_group.group_id = search_index.discussion_id'
		);
	}

	public function getGroupByType(): string
	{
		return 'dbtech_social_group';
	}
}