<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\Search\Data;

use DBTech\SocialGroups\Entity\Message;
use DBTech\SocialGroups\Finder\GroupFinder;
use DBTech\SocialGroups\Repository\GroupRepository;
use DBTech\SocialGroups\XF\Entity\User as ExtendedUserEntity;
use XF\Http\Request;
use XF\InputFilterer;
use XF\Mvc\Entity\AbstractCollection;
use XF\Mvc\Entity\Entity;
use XF\Search\Data\AbstractData;
use XF\Search\IndexRecord;
use XF\Search\MetadataStructure;
use XF\Search\Query\KeywordQuery;
use XF\Search\Query\MetadataConstraint;
use XF\Search\Query\Query;
use XF\Search\Query\SqlConstraint;
use XF\Search\Query\SqlOrder;
use XF\Search\Query\TableReference;

/**
 * @extends AbstractData<Message>
 */
class MessageData extends AbstractData
{
	public function getEntityWith($forView = false): array
	{
		$get = ['Discussion', 'Discussion.Group'];
		if ($forView)
		{
			$get[] = 'User';

			$visitor = \XF::visitor();
			$get[] = 'Discussion.Group.Permissions|' . $visitor->permission_combination_id;
		}

		return $get;
	}

	public function getIndexData(Entity $entity): ?IndexRecord
	{
		if (!$entity->Discussion || !$entity->Discussion->Group)
		{
			return null;
		}

		$discussion = $entity->Discussion;

		if ($entity->isFirstMessage())
		{
			return $this->searcher->handler('dbtech_social_discussion')->getIndexData($discussion);
		}

		$index = IndexRecord::create('dbtech_social_message', $entity->message_id, [
			'message' => $entity->message,
			'date' => $entity->message_date,
			'user_id' => $entity->user_id,
			'discussion_id' => $entity->discussion_id,
			'metadata' => $this->getMetaData($entity),
		]);

		if (!$entity->isVisible())
		{
			$index->setHidden();
		}

		return $index;
	}

	protected function getMetaData(Message $entity): array
	{
		$discussion = $entity->Discussion;

		return [
			'group' => $discussion->group_id,
			'discussion' => $entity->discussion_id,
		];
	}

	public function setupMetadataStructure(MetadataStructure $structure): void
	{
		$structure->addField('group', MetadataStructure::INT);
		$structure->addField('discussion', MetadataStructure::INT);
	}

	public function canIncludeInResults(Entity $entity, array $resultIds): bool
	{
		if (isset($resultIds['dbtech_social_discussion-' . $entity->discussion_id]) && $entity->isFirstMessage())
		{
			return false;
		}

		return true;
	}

	public function getResultDate(Entity $entity): int
	{
		return $entity->message_date;
	}

	public function getTemplateData(Entity $entity, array $options = []): array
	{
		return [
			'message' => $entity,
			'options' => $options,
		];
	}

	public function getSearchableContentTypes(): array
	{
		return ['dbtech_social_message', 'dbtech_social_discussion'];
	}

	public function getSearchFormTab(): ?array
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();
		if (!$visitor->canViewDbtechSocialGroups())
		{
			return null;
		}

		return [
			'title' => \XF::phrase('dbtech_social_groups_search_discussions'),
			'order' => 12,
		];
	}

	public function getSectionContext(): string
	{
		return 'dbtechSocial';
	}

	public function getSearchFormData(): array
	{
		return [
			//			'groups' => $this->getSearchableGroups(),
		];
	}

	/**
	 * @return AbstractCollection<GroupData>
	 */
	protected function getSearchableGroups(): AbstractCollection
	{
		return \XF::app()->repository(GroupRepository::class)
			->getViewableGroups()
		;
	}

	public function applyTypeConstraintsFromInput(
		Query $query,
		Request $request,
		array &$urlConstraints
	): void
	{
		$minReplyCount = $request->filter('c.min_reply_count', InputFilterer::UNSIGNED);
		if ($minReplyCount)
		{
			$query->withSql(new SqlConstraint(
				'discussion.reply_count >= %s',
				$minReplyCount,
				$this->getDiscussionQueryTableReference()
			));
		}
		else
		{
			unset($urlConstraints['min_reply_count']);
		}

		$discussionId = $request->filter('c.discussion', InputFilterer::UNSIGNED);
		if ($discussionId)
		{
			$query->withMetadata('discussion', $discussionId);

			if ($query instanceof KeywordQuery)
			{
				$query->inTitleOnly(false);
			}
		}
		else
		{
			unset($urlConstraints['discussion']);

			$groupIds = $request->filter('c.groups', 'array-uint');

			if (empty($groupIds))
			{
				/** @var ExtendedUserEntity $visitor */
				$visitor = \XF::visitor();

				$groupRestriction = $visitor->user_id
					? $request->filter('c.group_restrictions', InputFilterer::STRING)
					: 'all_groups'
				;
				switch ($groupRestriction)
				{
					case 'only_member':
						$groupIds = \XF::db()->fetchAllColumn("
							SELECT group_id
							FROM xf_dbtech_social_groups_group_member
							WHERE user_id = ?
						", $visitor->user_id);
						if (empty($groupIds))
						{
							// Ensure impossible condition, has to be positive int
							$groupIds = [PHP_INT_MAX];
						}
						break;

					case 'only_owned':
						$groupIds = \XF::db()->fetchAllColumn("
							SELECT group_id
							FROM xf_dbtech_social_groups_group
							WHERE user_id = ?
						", $visitor->user_id);
						if (empty($groupIds))
						{
							// Ensure impossible condition, has to be positive int
							$groupIds = [PHP_INT_MAX];
						}
						break;

					case 'all_groups':
					default:
						$groupIds = [];
						break;
				}
			}

			$groupIds = array_unique($groupIds);
			if ($groupIds && reset($groupIds))
			{
				$query->withMetadata('group', $groupIds);
			}
			else
			{
				unset($urlConstraints['groups']);
				unset($urlConstraints['group_restrictions']);
			}
		}
	}

	public function getTypePermissionConstraints(Query $query, $isOnlyType): array
	{
		$skip = [];
		$groups = \XF::app()->em()->getFinder(GroupFinder::class)
			->with('Permissions|' . \XF::visitor()->permission_combination_id)
			->fetch();

		/** @var GroupData $group */
		foreach ($groups AS $group)
		{
			if (!$group->canView())
			{
				$skip[] = $group->group_id;
			}
		}

		if ($skip)
		{
			return [
				new MetadataConstraint('group', $skip, MetadataConstraint::MATCH_NONE),
			];
		}
		else
		{
			return [];
		}
	}

	public function getTypeOrder($order): ?SqlOrder
	{
		if ($order == 'replies')
		{
			return new SqlOrder('discussion.reply_count DESC', $this->getDiscussionQueryTableReference());
		}
		else
		{
			return null;
		}
	}

	protected function getDiscussionQueryTableReference(): TableReference
	{
		return new TableReference(
			'discussion',
			'xf_dbtech_social_groups_discussion',
			'discussion.discussion_id = search_index.discussion_id'
		);
	}

	public function getGroupByType(): string
	{
		return 'dbtech_social_discussion';
	}

	public function canUseInlineModeration(Entity $entity, &$error = null): bool
	{
		return $entity->canUseInlineModeration($error);
	}
}