<?php

namespace DBTech\SocialGroups\Stats;

use XF\Stats\AbstractHandler;

class MessageHandler extends AbstractHandler
{
	/**
	 * @return array
	 */
	public function getStatsTypes(): array
	{
		return [
			'dbtech_social_message' => \XF::phrase('dbtech_social_groups_social_group_messages'),
			'dbtech_social_message_reaction' => \XF::phrase('dbtech_social_groups_social_group_message_reactions'),
		];
	}

	/**
	 * @param $start
	 * @param $end
	 *
	 * @return array
	 */
	public function getData($start, $end): array
	{
		$db = $this->db();

		$messages = $db->fetchPairs(
			$this->getBasicDataQuery(
				'xf_dbtech_social_groups_message',
				'message_date',
				'message_state = ?'
			),
			[$start, $end, 'visible']
		);

		$messageReactions = $db->fetchPairs(
			$this->getBasicDataQuery(
				'xf_reaction_content',
				'reaction_date',
				'content_type = ? AND is_counted = ?'
			),
			[$start, $end, 'dbtech_social_message', 1]
		);

		return [
			'dbtech_social_message' => $messages,
			'dbtech_social_message_reaction' => $messageReactions,
		];
	}
}