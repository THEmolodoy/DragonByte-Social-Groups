<?php

namespace DBTech\SocialGroups\Stats;

use XF\Stats\AbstractHandler;

class DiscussionHandler extends AbstractHandler
{
	/**
	 * @return array
	 */
	public function getStatsTypes(): array
	{
		return [
			'dbtech_social_discussion' => \XF::phrase('dbtech_social_groups_social_group_discussions'),
		];
	}

	/**
	 * @param $start
	 * @param $end
	 *
	 * @return array
	 */
	public function getData($start, $end): array
	{
		$discussions = $this->db()->fetchPairs(
			$this->getBasicDataQuery(
				'xf_dbtech_social_groups_discussion',
				'message_date',
				'discussion_state = ?'
			),
			[$start, $end, 'visible']
		);

		return [
			'dbtech_social_discussion' => $discussions,
		];
	}
}