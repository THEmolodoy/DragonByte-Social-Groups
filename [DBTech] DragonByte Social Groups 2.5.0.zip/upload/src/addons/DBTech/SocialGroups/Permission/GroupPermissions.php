<?php

namespace DBTech\SocialGroups\Permission;

use DBTech\SocialGroups\Repository\GroupRepository;
use XF\Entity\Permission;
use XF\Mvc\Entity\AbstractCollection;
use XF\Permission\FlatContentPermissions;
use XF\Phrase;

use function in_array;

class GroupPermissions extends FlatContentPermissions
{
	/**
	 * @return string
	 */
	protected function getContentType(): string
	{
		return 'dbtech_social_group';
	}

	/**
	 * @return Phrase
	 */
	public function getAnalysisTypeTitle(): Phrase
	{
		return \XF::phrase('dbtech_social_groups_group_permissions');
	}

	/**
	 * @return AbstractCollection
	 */
	public function getContentList(): AbstractCollection
	{
		return \XF::app()->repository(GroupRepository::class)
			->findEntriesForPermissionList()
			->fetch()
		;
	}

	/**
	 * @param Permission $permission
	 *
	 * @return bool
	 */
	public function isValidPermission(Permission $permission): bool
	{
		return ($permission->permission_group_id == 'dbtechSocial' && !in_array(
			$permission->permission_id,
			[
				'view',
				'createGroup',
				'viewAnyLog',
				'editAny',
				'deleteAny',
				'hardDeleteAny',
				'manageAnyGroup',
				'createGroup',
				'createClosedGroup',
				'createPrivateGroup',
				'createHiddenGroup',
				'maxCreatedGroups',
				'maxJoinedGroups',
				'maxAlbumsPerGroup',
				'maxInvitedUserBatch',
				'maxCreatedSections',
				'createWithoutApproval',
				'approveUnapproveGroups',
				'viewDeletedGroups',
				'viewModeratedGroups',
				'featureUnfeatureGroups',
				'importThreads',
				'deleteImportedThreads',
				'hardDeleteImportedThreads',
			]
		));
	}

	/**
	 * @param $contentId
	 * @param array $calculated
	 * @param array $childPerms
	 *
	 * @return array
	 */
	protected function getFinalPerms($contentId, array $calculated, array &$childPerms): array
	{
		if (!isset($calculated['dbtechSocial']))
		{
			$calculated['dbtechSocial'] = [];
		}

		$final = $this->builder->finalizePermissionValues($calculated['dbtechSocial']);

		if (empty($final['viewGroup']))
		{
			$childPerms['dbtechSocial']['viewGroup'] = 'deny';
		}

		return $final;
	}

	/**
	 * @param $contentId
	 * @param array $calculated
	 * @param array $childPerms
	 *
	 * @return array
	 */
	protected function getFinalAnalysisPerms($contentId, array $calculated, array &$childPerms): array
	{
		$final = $this->builder->finalizePermissionValues($calculated);

		if (empty($final['dbtechSocial']['viewGroup']))
		{
			$childPerms['dbtechSocial']['viewGroup'] = 'deny';
		}

		return $final;
	}
}