<?php

namespace DBTech\SocialGroups\Util;

use function array_key_exists;

class Arr
{
	public static function array_insert_after(array $array, string $after, string $newKey, mixed $newValue): array
	{
		if (array_key_exists($after, $array))
		{
			$arr = [];
			foreach ($array AS $k => $v)
			{
				$arr[$k] = $v;
				if ($k === $after)
				{
					$arr[$newKey] = $newValue;
				}
			}

			return $arr;
		}

		$array[$newKey] = $newValue;

		return $array;
	}
}