<?php

namespace DBTech\SocialGroups\Reaction;

use DBTech\SocialGroups\Entity\Message;
use XF\Mvc\Entity\Entity;
use XF\Reaction\AbstractHandler;

/**
 * @extends AbstractHandler<Message>
 */
class MessageHandler extends AbstractHandler
{
	public function getTemplateName(): string
	{
		return 'public:dbtech_social_groups_reaction_item_message';
	}

	public function reactionsCounted(Entity $entity): bool
	{
		if (!$entity->Discussion || !$entity->Discussion->Group)
		{
			return false;
		}

		return ($entity->message_state == 'visible'
			&& $entity->Discussion->discussion_state == 'visible'
		);
	}

	public function getEntityWith(): array
	{
		$visitor = \XF::visitor();

		return [
			'Discussion',
			'Discussion.Group',
			'Discussion.Group.Permissions|' . $visitor->permission_combination_id,
		];
	}
}