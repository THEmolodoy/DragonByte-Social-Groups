<?php

namespace DBTech\SocialGroups\Notifier\Message;

use DBTech\SocialGroups\Finder\GroupWatchFinder;
use XF\Entity\User;

class GroupWatch extends AbstractWatch
{
	/**
	 * @return string[]
	 */
	protected function getApplicableActionTypes(): array
	{
		return ['reply', 'discussion'];
	}

	/**
	 * @return array
	 */
	protected function getDefaultWatchNotifyData(): array
	{
		$message = $this->message;

		$finder = \XF::app()->finder(GroupWatchFinder::class);

		$finder->where('group_id', $message->Discussion->group_id)
			->where('User.user_state', '=', 'valid')
			->where('User.is_banned', '=', 0)
			->whereOr(
				['send_alert', '>', 0],
				['send_email', '>', 0]
			);

		if ($this->actionType == 'reply')
		{
			$finder->where('notify_on', 'message');
		}
		else
		{
			$finder->where('notify_on', ['discussion', 'message']);
		}

		$activeLimit = \XF::app()->options()->watchAlertActiveOnly;
		if (!empty($activeLimit['enabled']))
		{
			$finder->where('User.last_activity', '>=', \XF::$time - 86400 * $activeLimit['days']);
		}

		$notifyData = [];
		foreach ($finder->fetchColumns(['user_id', 'send_alert', 'send_email']) AS $watch)
		{
			$notifyData[$watch['user_id']] = [
				'alert' => (bool) $watch['send_alert'],
				'email' => (bool) $watch['send_email'],
			];
		}

		return $notifyData;
	}

	/**
	 * @param User $user
	 *
	 * @return bool
	 */
	public function sendAlert(User $user): bool
	{
		$message = $this->message;

		return $this->basicAlert(
			$user,
			$message->user_id,
			$message->username,
			'dbtech_social_message',
			$message->message_id,
			'groupwatch_insert'
		);
	}

	/**
	 * @return string
	 */
	protected function getWatchEmailTemplateName(): string
	{
		return 'dbtech_social_groups_watched_group_' . ($this->actionType == 'discussion' ? 'discussion' : 'reply');
	}
}