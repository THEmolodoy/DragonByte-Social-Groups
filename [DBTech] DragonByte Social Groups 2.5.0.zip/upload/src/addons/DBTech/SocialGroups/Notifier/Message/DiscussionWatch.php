<?php

namespace DBTech\SocialGroups\Notifier\Message;

use DBTech\SocialGroups\Finder\DiscussionWatchFinder;

class DiscussionWatch extends AbstractWatch
{
	/**
	 * @return string[]
	 */
	protected function getApplicableActionTypes(): array
	{
		return ['reply'];
	}

	/**
	 * @return array
	 */
	protected function getDefaultWatchNotifyData(): array
	{
		$message = $this->message;

		if ($message->isFirstMessage())
		{
			return [];
		}

		$finder = \XF::app()->finder(DiscussionWatchFinder::class);

		$finder->where('discussion_id', $message->discussion_id)
			->where('User.user_state', '=', 'valid')
			->where('User.is_banned', '=', 0);

		$activeLimit = \XF::app()->options()->watchAlertActiveOnly;
		if (!empty($activeLimit['enabled']))
		{
			$finder->where('User.last_activity', '>=', \XF::$time - 86400 * $activeLimit['days']);
		}

		$notifyData = [];
		foreach ($finder->fetchColumns(['user_id', 'email_subscribe']) AS $watch)
		{
			$notifyData[$watch['user_id']] = [
				'alert' => true,
				'email' => (bool) $watch['email_subscribe'],
			];
		}

		return $notifyData;
	}

	/**
	 * @return string
	 */
	protected function getWatchEmailTemplateName(): string
	{
		return 'dbtech_social_groups_watched_discussion_reply';
	}
}