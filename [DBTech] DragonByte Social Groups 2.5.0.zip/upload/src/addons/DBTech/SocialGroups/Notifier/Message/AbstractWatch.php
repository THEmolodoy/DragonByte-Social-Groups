<?php

namespace DBTech\SocialGroups\Notifier\Message;

use DBTech\SocialGroups\Entity\Message;
use DBTech\SocialGroups\Finder\MessageFinder;
use XF\App;
use XF\Entity\User;
use XF\Mvc\Entity\AbstractCollection;
use XF\Notifier\AbstractNotifier;

use function in_array;

abstract class AbstractWatch extends AbstractNotifier
{
	protected Message $message;
	protected string $actionType;
	protected bool $isApplicable;
	protected array $userReadDates = [];
	protected ?AbstractCollection $previousMessages = null;

	abstract protected function getDefaultWatchNotifyData();
	abstract protected function getApplicableActionTypes();
	abstract protected function getWatchEmailTemplateName();


	/**
	 * @param App $app
	 * @param Message $message
	 * @param string $actionType
	 */
	public function __construct(App $app, Message $message, string $actionType)
	{
		parent::__construct($app);

		$this->message = $message;
		$this->actionType = $actionType;
		$this->isApplicable = $this->isApplicable();
	}

	/**
	 * @return bool
	 */
	protected function isApplicable(): bool
	{
		if (!in_array($this->actionType, $this->getApplicableActionTypes()))
		{
			return false;
		}

		if (!$this->message->isVisible())
		{
			return false;
		}

		return true;
	}

	/**
	 * @param User $user
	 *
	 * @return bool
	 */
	public function canNotify(User $user): bool
	{
		if (!$this->isApplicable)
		{
			return false;
		}

		if (!isset($this->userReadDates[$user->user_id]))
		{
			// this should have a record for every user, so generally shouldn't happen
			return false;
		}

		$userReadDate = $this->userReadDates[$user->user_id];
		$message = $this->message;

		if ($user->user_id == $message->user_id || $user->isIgnoring($message->user_id))
		{
			return false;
		}

		if ($userReadDate > $message->Discussion->last_message_date)
		{
			return false;
		}

		if ($this->actionType == 'reply')
		{
			/** @var Message|null $previousVisibleMessage */
			$previousVisibleMessage = null;
			foreach ($this->getPreviousMessages() AS $previousMessage)
			{
				if (!$user->isIgnoring($previousMessage->user_id))
				{
					$previousVisibleMessage = $previousMessage;
					break;
				}
			}

			$autoReadDate = \XF::$time - \XF::app()->options()->readMarkingDataLifetime * 86400;

			/** @noinspection PhpStatementHasEmptyBodyInspection */
			if (!$previousVisibleMessage || $previousVisibleMessage->message_date < $autoReadDate)
			{
				// always alert
			}
			else if ($previousVisibleMessage->message_date > $userReadDate)
			{
				return false;
			}
		}

		return true;
	}

	/**
	 * @param User $user
	 *
	 * @return bool
	 */
	public function sendAlert(User $user): bool
	{
		$message = $this->message;

		return $this->basicAlert(
			$user,
			$message->user_id,
			$message->username,
			'dbtech_social_message',
			$message->message_id,
			'insert'
		);
	}

	/**
	 * @param User $user
	 *
	 * @return bool
	 */
	public function sendEmail(User $user): bool
	{
		if (!$user->email || $user->user_state != 'valid')
		{
			return false;
		}

		$message = $this->message;

		$params = [
			'message' => $message,
			'discussion' => $message->Discussion,
			'group' => $message->Discussion->Group,
			'receiver' => $user,
		];

		$template = $this->getWatchEmailTemplateName();

		\XF::app()->mailer()->newMail()
			->setToUser($user)
			->setTemplate($template, $params)
			->queue();

		return true;
	}

	/**
	 * @return array
	 */
	public function getDefaultNotifyData(): array
	{
		if (!$this->isApplicable)
		{
			return [];
		}

		return $this->getDefaultWatchNotifyData();
	}

	/**
	 * @param array $userIds
	 *
	 * @return array
	 */
	public function getUserData(array $userIds): array
	{
		$users = parent::getUserData($userIds);
		$this->userReadDates = $this->getUserReadDates($userIds);

		return $users;
	}

	/**
	 * @param array $userIds
	 *
	 * @return array
	 */
	protected function getUserReadDates(array $userIds): array
	{
		if (!$userIds)
		{
			return [];
		}

		$autoReadDate = \XF::$time - \XF::app()->options()->readMarkingDataLifetime * 86400;
		$message = $this->message;

		$db = \XF::app()->db();
		$readDates = $db->fetchPairs("
			SELECT user.user_id,
				GREATEST(
					COALESCE(discussion_read.discussion_read_date, 0),
					COALESCE(group_read.group_read_date, 0),
					?
				)
			FROM xf_user AS user
			LEFT JOIN xf_dbtech_social_groups_discussion_read AS discussion_read ON
				(discussion_read.user_id = user.user_id AND discussion_read.discussion_id = ?)
			LEFT JOIN xf_dbtech_social_groups_group_read AS group_read ON
				(group_read.user_id = user.user_id AND group_read.group_id = ?)
			WHERE user.user_id IN (" . $db->quote($userIds) . ")
		", [$autoReadDate, $message->discussion_id, $message->Discussion->group_id]);

		foreach ($userIds AS $userId)
		{
			if (!isset($readDates[$userId]))
			{
				$readDates[$userId] = $autoReadDate;
			}
		}

		return $readDates;
	}

	/**
	 * @return AbstractCollection|null
	 */
	protected function getPreviousMessages(): ?AbstractCollection
	{
		if ($this->previousMessages === null)
		{
			$autoReadDate = \XF::$time - \XF::app()->options()->readMarkingDataLifetime * 86400;

			$finder = \XF::app()->finder(MessageFinder::class)
				->where('discussion_id', $this->message->discussion_id)
				->where('message_state', 'visible')
				->where('message_date', '<', $this->message->message_date)
				->where('message_date', '>=', $autoReadDate)
				->order('message_date', 'desc');

			$this->previousMessages = $finder->fetch(15);
		}

		return $this->previousMessages;
	}
}