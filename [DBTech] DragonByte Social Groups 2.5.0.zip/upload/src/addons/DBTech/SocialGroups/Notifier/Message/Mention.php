<?php

namespace DBTech\SocialGroups\Notifier\Message;

use DBTech\SocialGroups\Entity\Message;
use XF\App;
use XF\Entity\User;
use XF\Notifier\AbstractNotifier;

class Mention extends AbstractNotifier
{
	protected Message $message;


	/**
	 * @param App $app
	 * @param Message $message
	 */
	public function __construct(App $app, Message $message)
	{
		parent::__construct($app);

		$this->message = $message;
	}

	/**
	 * @param User $user
	 *
	 * @return bool
	 */
	public function canNotify(User $user): bool
	{
		return ($user->user_id != $this->message->user_id);
	}

	/**
	 * @param User $user
	 *
	 * @return bool
	 */
	public function sendAlert(User $user): bool
	{
		$message = $this->message;
		return $this->basicAlert(
			$user,
			$message->user_id,
			$message->username,
			'dbtech_social_message',
			$message->message_id,
			'mention'
		);
	}
}