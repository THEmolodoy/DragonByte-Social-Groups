<?php

namespace DBTech\SocialGroups\Pub\Route;

use DBTech\SocialGroups\Entity\Group;
use XF\Mvc\RouteBuiltLink;
use XF\Mvc\Router;
use XFMG\Entity\MediaItem;

class Media
{
	/**
	 * @param $prefix
	 * @param array $route
	 * @param $action
	 * @param $data
	 * @param array $params
	 * @param Router $router
	 *
	 * @return ?RouteBuiltLink
	 */
	public static function build(&$prefix, array &$route, &$action, &$data, array &$params, Router $router): ?RouteBuiltLink
	{
		if (($data instanceof MediaItem)
			&& empty($action)
			&& $data->Album
		)
		{
			/** @var Group $group */
			$group = $data->Album->DbtechSocialGroupsGroup;
			if (!$group)
			{
				// Not in a group, default processing
				return null;
			}

			$data = [
				'group_id' => $group->group_id,
				'title' => $group->title,
				'media_id' => $data->media_id,
			];

			$prefix = 'dbtech-social';
			$route['format'] = ':int<group_id,title>/media/:int<media_id>/:page';
			$route['context'] = 'dbtechSocial';
		}

		return null; // default processing otherwise
	}
}