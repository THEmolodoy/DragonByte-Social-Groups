<?php

namespace DBTech\SocialGroups\Pub\Route;

use XF\Mvc\RouteBuiltLink;
use XF\Mvc\Router;

use function in_array;

class Album
{
	/**
	 * @param $prefix
	 * @param array $route
	 * @param $action
	 * @param $data
	 * @param array $params
	 * @param Router $router
	 *
	 * @return ?RouteBuiltLink
	 */
	public static function build(&$prefix, array &$route, &$action, &$data, array &$params, Router $router): ?RouteBuiltLink
	{
		if (($data instanceof \DBTech\SocialGroups\XFMG\Entity\Album)
			&& in_array($action, ['', 'add', 'dbtech-social-unlink'])
		)
		{
			$group = $data->DbtechSocialGroupsGroup;
			if (!$group)
			{
				// Not in a group, default processing
				return null;
			}

			if ($action === 'dbtech-social-unlink')
			{
				$action = 'unlink';
			}

			$data = [
				'group_id' => $group->group_id,
				'title' => $group->title,
				'album_id' => $data->album_id,
			];

			$prefix = 'dbtech-social';
			$route['format'] = ':int<group_id,title>/albums/:int<album_id>/:page';
			$route['context'] = 'dbtechSocial';
		}

		return null; // default processing otherwise
	}
}