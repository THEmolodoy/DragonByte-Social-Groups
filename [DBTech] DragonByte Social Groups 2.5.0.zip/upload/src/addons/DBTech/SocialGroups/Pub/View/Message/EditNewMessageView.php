<?php

namespace DBTech\SocialGroups\Pub\View\Message;

use XF\Mvc\View;

class EditNewMessageView extends View
{
}