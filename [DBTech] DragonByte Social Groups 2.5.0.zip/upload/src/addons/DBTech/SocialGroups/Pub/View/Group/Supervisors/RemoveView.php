<?php

namespace DBTech\SocialGroups\Pub\View\Group\Supervisors;

use XF\Mvc\View;

class RemoveView extends View
{
}