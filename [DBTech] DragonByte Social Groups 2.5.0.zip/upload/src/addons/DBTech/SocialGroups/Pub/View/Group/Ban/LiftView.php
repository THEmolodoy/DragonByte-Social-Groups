<?php

namespace DBTech\SocialGroups\Pub\View\Group\Ban;

use XF\Mvc\View;

class LiftView extends View
{
}