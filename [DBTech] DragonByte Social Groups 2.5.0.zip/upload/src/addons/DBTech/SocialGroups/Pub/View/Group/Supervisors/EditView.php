<?php

namespace DBTech\SocialGroups\Pub\View\Group\Supervisors;

use XF\Mvc\View;

class EditView extends View
{
}