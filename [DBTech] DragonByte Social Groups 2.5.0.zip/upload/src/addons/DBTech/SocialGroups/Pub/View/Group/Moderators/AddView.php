<?php

namespace DBTech\SocialGroups\Pub\View\Group\Moderators;

use XF\Mvc\View;

class AddView extends View
{
}