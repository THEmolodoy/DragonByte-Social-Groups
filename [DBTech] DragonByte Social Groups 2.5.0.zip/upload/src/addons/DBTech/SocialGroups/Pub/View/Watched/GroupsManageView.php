<?php

namespace DBTech\SocialGroups\Pub\View\Watched;

use XF\Mvc\View;

class GroupsManageView extends View
{
}