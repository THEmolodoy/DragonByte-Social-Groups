<?php

namespace DBTech\SocialGroups\Pub\View\Group;

use DBTech\SocialGroups\Entity\Discussion;
use DBTech\SocialGroups\Entity\Group;
use Laminas\Feed\Writer\Feed;
use XF\Mvc\View;

use function strlen;

class RssView extends View
{
	/**
	 * @return string
	 * @noinspection PhpMissingReturnTypeInspection
	 */
	public function renderRss()
	{
		$app = \XF::app();
		$router = $app->router('public');
		$options = $app->options();

		/** @var Group $group */
		$group = $this->params['group'];

		$indexUrl = $router->buildLink('canonical:index');
		if ($group)
		{
			$feedLink = $router->buildLink('canonical:dbtech-social/index.rss', $group);
		}
		else
		{
			$feedLink = $router->buildLink('canonical:dbtech-social/index.rss', '-');
		}

		if ($group)
		{
			$title = $group->title;
			$description = $group->description;
		}
		else
		{
			$title = $options->boardTitle;
			$description = $options->boardDescription;
		}

		$title = $title ?: $indexUrl;
		$description = $description ?: $title; // required in RSS 2.0 spec

		$feed = new Feed();

		$feed->setEncoding('utf-8')
			->setTitle($title)
			->setDescription($description)
			->setLink($indexUrl)
			->setFeedLink($feedLink, 'rss')
			->setDateModified(\XF::$time)
			->setLastBuildDate(\XF::$time)
			->setGenerator($options->boardTitle);

		$parser = $app->bbCode()->parser();
		$rules = $app->bbCode()->rules('post:rss');

		$bbCodeCleaner = $app->bbCode()->renderer('bbCodeClean');
		$bbCodeRenderer = $app->bbCode()->renderer('html');

		$formatter = $app->stringFormatter();
		$maxLength = $options->discussionRssContentLength;

		/** @var Discussion $discussion */
		foreach ($this->params['discussions'] AS $discussion)
		{
			$discussionGroup = $discussion->Group;
			$entry = $feed->createEntry();

			$title = (empty($discussion->title) ? \XF::phrase('title:') . ' ' . $discussion->title : $discussion->title);
			$entry->setTitle($title)
				->setLink($router->buildLink('canonical:dbtech-social/discussions', $discussion))
				->setDateCreated($discussion->message_date)
				->setDateModified($discussion->last_message_date);

			if ($discussionGroup && !$group)
			{
				$entry->addCategory([
					'term' => $discussionGroup->title,
					'scheme' => $router->buildLink('canonical:dbtech-social', $discussionGroup),
				]);
			}

			$firstPost = $discussion->FirstMessage;

			if ($maxLength && $firstPost && $firstPost->message)
			{
				$snippet = $bbCodeCleaner->render($formatter->wholeWordTrim($firstPost->message, $maxLength), $parser, $rules);

				if ($snippet != $firstPost->message)
				{
					$snippet .= "\n\n[URL='" . $router->buildLink('canonical:dbtech-social/discussions', $discussion) . "']$discussion->title[/URL]";
				}

				$renderOptions = $firstPost->getBbCodeRenderOptions('post:rss', 'html');
				$renderOptions['noProxy'] = true;

				$content = trim($bbCodeRenderer->render($snippet, $parser, $rules, $renderOptions));
				if (strlen($content))
				{
					$entry->setContent($content);
				}
			}

			$entry->addAuthor([
				'name' => $discussion->username,
				'email' => 'invalid@example.com',
				'uri' => $router->buildLink('canonical:members', $discussion),
			]);
			if ($discussion->reply_count)
			{
				$entry->setCommentCount($discussion->reply_count);
			}

			$feed->addEntry($entry);
		}

		return $feed->export('rss', true);
	}
}