<?php

namespace DBTech\SocialGroups\Pub\View\Group;

use XF\Mvc\View;

class CalendarView extends View
{
}