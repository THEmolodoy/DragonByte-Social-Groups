<?php

namespace DBTech\SocialGroups\Pub\View\Group\Media;

use XF\Mvc\View;

class AlbumUserIndexView extends View
{
}