<?php

namespace DBTech\SocialGroups\Pub\View\Delete;

use XF\Mvc\View;

class StateView extends View
{
}