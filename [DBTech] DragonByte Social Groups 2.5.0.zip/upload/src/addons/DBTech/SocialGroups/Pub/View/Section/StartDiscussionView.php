<?php

namespace DBTech\SocialGroups\Pub\View\Section;

use XF\Mvc\View;

class StartDiscussionView extends View
{
}