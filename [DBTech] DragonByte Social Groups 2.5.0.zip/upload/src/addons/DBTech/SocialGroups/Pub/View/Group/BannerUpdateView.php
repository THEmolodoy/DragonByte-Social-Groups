<?php

namespace DBTech\SocialGroups\Pub\View\Group;

use DBTech\SocialGroups\Entity\Group;
use XF\Mvc\View;

class BannerUpdateView extends View
{
	/**
	 * @return array
	 * @noinspection PhpMissingReturnTypeInspection
	 */
	public function renderJson()
	{
		/** @var Group $group */
		$group = $this->params['group'];

		$banners = [];
		$bannerCodes = array_keys(\XF::app()->container('profileBannerSizeMap'));
		foreach ($bannerCodes AS $code)
		{
			$bannerUrl = $group->getBannerUrl($code);
			if (!$bannerUrl)
			{
				$banners = [];
				break;
			}
			$banners[$code] = $bannerUrl;
		}

		return [
			'groupId' => $group->group_id,
			'position' => $group->banner_position_y,
			'banners' => $banners,
		];
	}
}