<?php

namespace DBTech\SocialGroups\Pub\View\WhatsNew;

use XF\Mvc\View;

class MessagesView extends View
{
}