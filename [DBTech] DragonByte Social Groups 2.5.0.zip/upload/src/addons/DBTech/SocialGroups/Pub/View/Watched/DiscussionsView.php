<?php

namespace DBTech\SocialGroups\Pub\View\Watched;

use XF\Mvc\View;

class DiscussionsView extends View
{
}