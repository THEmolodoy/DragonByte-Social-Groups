<?php

namespace DBTech\SocialGroups\Pub\View\Group\Calendar;

use XF\Mvc\View;

class ViewView extends View
{
}