<?php

namespace DBTech\SocialGroups\Pub\View\Group\RelatedThreads;

use XF\Mvc\View;

class DeleteView extends View
{
}