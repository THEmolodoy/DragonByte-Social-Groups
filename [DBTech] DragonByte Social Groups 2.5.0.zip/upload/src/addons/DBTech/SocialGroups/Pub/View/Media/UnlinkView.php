<?php

namespace DBTech\SocialGroups\Pub\View\Media;

use XF\Mvc\View;

class UnlinkView extends View
{
}