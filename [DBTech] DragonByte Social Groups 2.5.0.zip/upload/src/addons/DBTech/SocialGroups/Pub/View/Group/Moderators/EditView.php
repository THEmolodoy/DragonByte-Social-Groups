<?php

namespace DBTech\SocialGroups\Pub\View\Group\Moderators;

use XF\Mvc\View;

class EditView extends View
{
}