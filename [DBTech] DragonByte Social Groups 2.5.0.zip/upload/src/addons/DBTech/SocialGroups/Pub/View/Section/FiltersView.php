<?php

namespace DBTech\SocialGroups\Pub\View\Section;

use XF\Mvc\View;

class FiltersView extends View
{
}