<?php

namespace DBTech\SocialGroups\Pub\View\Discussion;

use XF\Mvc\View;

class EditInlineView extends View
{
}