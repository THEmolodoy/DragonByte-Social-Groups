<?php

namespace DBTech\SocialGroups\Pub\View\Group\Media;

use XF\Mvc\View;

class UserIndexView extends View
{
}