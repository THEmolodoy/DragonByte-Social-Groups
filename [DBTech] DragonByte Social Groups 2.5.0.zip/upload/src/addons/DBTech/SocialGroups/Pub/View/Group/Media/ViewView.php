<?php

namespace DBTech\SocialGroups\Pub\View\Group\Media;

use XF\Mvc\View;

class ViewView extends View
{
}