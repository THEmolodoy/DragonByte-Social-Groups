<?php

namespace DBTech\SocialGroups\Pub\View\Thread;

use XF\Mvc\View;

class ImportView extends View
{
}