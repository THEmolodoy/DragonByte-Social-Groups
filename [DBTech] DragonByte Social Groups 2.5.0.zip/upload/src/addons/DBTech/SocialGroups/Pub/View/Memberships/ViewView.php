<?php

namespace DBTech\SocialGroups\Pub\View\Memberships;

use XF\Mvc\View;

class ViewView extends View
{
}