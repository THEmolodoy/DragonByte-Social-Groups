<?php

namespace DBTech\SocialGroups\Pub\View\Group;

use XF\Mvc\View;

class EventDatesView extends View
{
}