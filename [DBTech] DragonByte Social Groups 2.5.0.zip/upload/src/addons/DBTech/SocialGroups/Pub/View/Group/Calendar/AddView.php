<?php

namespace DBTech\SocialGroups\Pub\View\Group\Calendar;

use XF\Mvc\View;

class AddView extends View
{
}