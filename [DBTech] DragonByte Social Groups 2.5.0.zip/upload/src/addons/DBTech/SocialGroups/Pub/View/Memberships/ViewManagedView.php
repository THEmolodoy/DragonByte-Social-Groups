<?php

namespace DBTech\SocialGroups\Pub\View\Memberships;

use XF\Mvc\View;

class ViewManagedView extends View
{
}