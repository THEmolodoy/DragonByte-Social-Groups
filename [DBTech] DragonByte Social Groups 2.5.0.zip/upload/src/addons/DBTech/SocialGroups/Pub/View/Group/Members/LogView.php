<?php

namespace DBTech\SocialGroups\Pub\View\Group\Members;

use XF\Mvc\View;

class LogView extends View
{
}