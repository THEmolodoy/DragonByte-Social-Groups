<?php

namespace DBTech\SocialGroups\Pub\View\Group;

use DBTech\SocialGroups\Entity\Group;
use XF\Mvc\View;

class IconUpdateView extends View
{
	/**
	 * @return array
	 * @noinspection PhpMissingReturnTypeInspection
	 */
	public function renderJson()
	{
		/** @var Group $group */
		$group = $this->params['group'];

		$templater = $this->renderer->getTemplater();

		$icons = [];
		$avatarCodes = array_keys(\XF::app()->container('avatarSizeMap'));
		foreach ($avatarCodes AS $code)
		{
			$icons[$code] = $templater->func('dbtech_social_groups_group_icon', [$group, $code]);
		}

		return [
			'groupId' => $group->group_id,
			'icons' => $icons,
			'defaultIcons' => ($group->getIconUrl('s') === null),
			'cropX' => $group->icon_crop_x,
			'cropY' => $group->icon_crop_y,
		];
	}
}