<?php

namespace DBTech\SocialGroups\Pub\View\Group;

use DBTech\SocialGroups\Entity\GroupMember;
use XF\Mvc\View;

class FindMemberView extends View
{
	/**
	 * @return array
	 * @noinspection PhpMissingReturnTypeInspection
	 */
	public function renderJson()
	{
		$results = [];
		foreach ($this->params['members'] AS $members)
		{
			/** @var GroupMember $members */
			$avatarArgs = [$members->User, 'xxs', false, ['href' => '']];

			$results[] = [
				'id' => $members->User->username,
				'iconHtml' => $this->renderer->getTemplater()->func('avatar', $avatarArgs),
				'text' => $members->User->username,
				'q' => $this->params['q'],
			];
		}

		return [
			'results' => $results,
			'q' => $this->params['q'],
		];
	}
}