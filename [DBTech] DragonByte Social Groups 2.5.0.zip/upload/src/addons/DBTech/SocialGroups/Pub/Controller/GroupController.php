<?php

namespace DBTech\SocialGroups\Pub\Controller;

use DBTech\SocialGroups\ControllerPlugin\DeletePlugin;
use DBTech\SocialGroups\ControllerPlugin\GroupMemberPlugin;
use DBTech\SocialGroups\ControllerPlugin\GroupPlugin;
use DBTech\SocialGroups\ControllerPlugin\SectionPlugin;
use DBTech\SocialGroups\Entity\Discussion;
use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Entity\GroupBan;
use DBTech\SocialGroups\Entity\GroupInvite;
use DBTech\SocialGroups\Entity\GroupMember;
use DBTech\SocialGroups\Entity\Section;
use DBTech\SocialGroups\Filterer\GroupMemberFilterer;
use DBTech\SocialGroups\Finder\DiscussionFinder;
use DBTech\SocialGroups\Finder\GroupFinder;
use DBTech\SocialGroups\Finder\GroupMemberFinder;
use DBTech\SocialGroups\Pub\View;
use DBTech\SocialGroups\Repository\BanningRepository;
use DBTech\SocialGroups\Repository\DiscussionRepository;
use DBTech\SocialGroups\Repository\DiscussionWatchRepository;
use DBTech\SocialGroups\Repository\GroupInviteRepository;
use DBTech\SocialGroups\Repository\GroupMemberRepository;
use DBTech\SocialGroups\Repository\GroupPermissionsRepository;
use DBTech\SocialGroups\Repository\GroupRepository;
use DBTech\SocialGroups\Repository\GroupWatchRepository;
use DBTech\SocialGroups\Repository\SectionRepository;
use DBTech\SocialGroups\Service\Discussion\CreatorService;
use DBTech\SocialGroups\Service\Group\BannerService;
use DBTech\SocialGroups\Service\Group\IconService;
use DBTech\SocialGroups\Service\Group\LinkRelatedThreadsService;
use DBTech\SocialGroups\Service\Group\ReassignService;
use DBTech\SocialGroups\Service\GroupMember\ApproverService;
use DBTech\SocialGroups\XF\Entity\User as ExtendedUserEntity;
use XF\ControllerPlugin\BbCodePreviewPlugin;
use XF\ControllerPlugin\BookmarkPlugin;
use XF\ControllerPlugin\DraftPlugin;
use XF\ControllerPlugin\EditorPlugin;
use XF\ControllerPlugin\FeaturedContentPlugin;
use XF\ControllerPlugin\PollPlugin;
use XF\ControllerPlugin\ReportPlugin;
use XF\ControllerPlugin\SharePlugin;
use XF\ControllerPlugin\SortPlugin;
use XF\Db\DeadlockException;
use XF\Db\Exception as DbException;
use XF\Entity\User;
use XF\Finder\UserFinder;
use XF\InputFilterer;
use XF\Mvc\Entity\AbstractCollection;
use XF\Mvc\FormAction;
use XF\Mvc\ParameterBag;
use XF\Mvc\Reply\AbstractReply;
use XF\Mvc\Reply\Exception as ReplyException;
use XF\Mvc\RouteMatch;
use XF\PrintableException;
use XF\Pub\Controller\EmbedResolverTrait;
use XF\Repository\AttachmentRepository;
use XF\Repository\ModeratorRepository;
use XF\Service\Tag\ChangerService;

use function count, in_array, intval, strlen;

class GroupController extends AbstractGroupController
{
	use EmbedResolverTrait;

	/**
	 * @param $action
	 * @param ParameterBag $params
	 *
	 * @return void
	 * @throws ReplyException
	 */
	protected function preDispatchController($action, ParameterBag $params): void
	{
		parent::preDispatchController($action, $params);

		if (!empty($params['section_id']) && !\XF::app()->options()->dbtechSocialGroupsEnableSections)
		{
			throw $this->exception($this->notFound());
		}

		switch (\strtolower($action))
		{
			case 'media':
			case 'mediaadd':
				if (!\XF::app()->options()->dbtechSocialEnableMediaGallery
					|| !\XF::isAddOnActive('XFMG')
				)
				{
					throw $this->exception($this->noPermission());
				}
				break;
		}
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 */
	public function actionIndex(ParameterBag $params): AbstractReply
	{
		if ($params['group_id'])
		{
			return $this->rerouteController(__CLASS__, 'group', $params);
		}

		return $this->rerouteController(__CLASS__, 'list', $params);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws \LogicException
	 * @throws ReplyException
	 */
	public function actionTags(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);
		if (!$group->canEditGroupTags($error))
		{
			return $this->noPermission($error);
		}

		$tagger = \XF::app()->service(ChangerService::class, 'dbtech_social_group', $group);

		if ($this->isPost())
		{
			$tagger->setEditableTags($this->filter('tags', InputFilterer::STRING));
			if ($tagger->hasErrors())
			{
				return $this->error($tagger->getErrors());
			}

			$tagger->save();

			return $this->redirect($this->buildLink('dbtech-social', $group));
		}

		$grouped = $tagger->getExistingTagsByEditability();

		$viewParams = [
			'group' => $group,
			'editableTags' => $grouped['editable'],
			'uneditableTags' => $grouped['uneditable'],
		];
		return $this->view(
			View\Group\TagsView::class,
			'dbtech_social_groups_group_tags',
			$viewParams
		);
	}

	/**
	 * @param Group $group
	 *
	 * @return AbstractReply
	 */
	protected function groupAddEdit(Group $group): AbstractReply
	{
		if ($group->exists())
		{
			$tagger = \XF::app()->service(ChangerService::class, 'dbtech_social_group', $group);
			$grouped = $tagger->getExistingTagsByEditability();
		}
		else
		{
			$grouped = [
				'editable' => null,
				'uneditable' => null,
			];
		}

		$viewParams = [
			'group' => $group,
			'editableTags' => $grouped['editable'],
			'uneditableTags' => $grouped['uneditable'],
		];
		return $this->view(
			View\Group\EditView::class,
			'dbtech_social_groups_group_edit',
			$viewParams
		);
	}

	/**
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionCreate(): AbstractReply
	{
		if (!\XF::visitor()->canCreateDbtechSocialGroups($error))
		{
			throw $this->exception($this->noPermission($error));
		}

		$this->assertValidSettings();

		$group = \XF::app()->em()->create(Group::class);
		return $this->groupAddEdit($group);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionEdit(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);
		if (!$group->canEdit($error))
		{
			return $this->noPermission($error);
		}

		return $this->groupAddEdit($group);
	}

	/**
	 * @param Group $group
	 *
	 * @return FormAction
	 */
	protected function groupSaveProcess(Group $group): FormAction
	{
		$form = $this->formAction();

		$input = $this->filter([
			'title' => InputFilterer::STRING,
			'tagline' => InputFilterer::STRING,

			'group_type' => InputFilterer::STRING,
			'allow_posting' => InputFilterer::BOOLEAN,
			'allow_discussions' => InputFilterer::BOOLEAN,
			'allow_poll' => InputFilterer::BOOLEAN,
			'allow_members' => InputFilterer::BOOLEAN,
			'moderate_members' => InputFilterer::BOOLEAN,
			'find_new' => InputFilterer::BOOLEAN,
			//			'default_prefix_id' => InputFilterer::UNSIGNED,
			//			'require_prefix' => InputFilterer::BOOLEAN,
		]);

		if (\XF::options()->dbtechSocialEnableCalendar && \XF::isAddOnActive('NF/Calendar', 2060070))
		{
			$input['enable_calendar'] = $this->filter('enable_calendar', InputFilterer::BOOLEAN);
			$input['event_creation'] = $this->filter('event_creation', InputFilterer::STRING, 'group_owner');
		}

		if (!(\XF::app()->options()->dbtechSocialEnabledGroupOwnerFeatures['locale'] ?? false))
		{
			if (!$group->exists())
			{
				$input['language_code'] = '';
				$input['text_direction'] = 'LTR';
			}
		}
		else
		{
			$input['language_code'] = $this->filter('language_code', InputFilterer::STRING);
			$input['text_direction'] = $this->filter('text_direction', InputFilterer::STRING);
		}

		if (!(\XF::app()->options()->dbtechSocialEnabledGroupOwnerFeatures['moderation'] ?? false))
		{
			if (!$group->exists())
			{
				$input['moderate_discussions'] = false;
				$input['moderate_replies'] = false;
			}
		}
		else
		{
			$input['moderate_discussions'] = $this->filter('moderate_discussions', InputFilterer::BOOLEAN);
			$input['moderate_replies'] = $this->filter('moderate_replies', InputFilterer::BOOLEAN);
		}

		if (!(\XF::app()->options()->dbtechSocialEnabledGroupOwnerFeatures['allowed_watch_notifications'] ?? false))
		{
			if (!$group->exists())
			{
				$input['allowed_watch_notifications'] = 'all';
			}
		}
		else
		{
			$input['allowed_watch_notifications'] = $this->filter('allowed_watch_notifications', InputFilterer::STRING);
		}

		if (!(\XF::app()->options()->dbtechSocialEnabledGroupOwnerFeatures['min_tags'] ?? false))
		{
			if (!$group->exists())
			{
				$input['min_tags'] = 0;
			}
		}
		else
		{
			$input['min_tags'] = $this->filter('min_tags', InputFilterer::UNSIGNED);
		}

		if (!(\XF::app()->options()->dbtechSocialEnabledGroupOwnerFeatures['default_sort'] ?? false))
		{
			if (!$group->exists())
			{
				$input['default_sort_order'] = 'last_message_date';
				$input['default_sort_direction'] = 'desc';
			}
		}
		else
		{
			$input['default_sort_order'] = $this->filter('default_sort_order', InputFilterer::STRING);
			$input['default_sort_direction'] = $this->filter('default_sort_direction', InputFilterer::STRING);
		}

		if (!(\XF::app()->options()->dbtechSocialEnabledGroupOwnerFeatures['list_date_limit_days'] ?? false))
		{
			if (!$group->exists())
			{
				$input['list_date_limit_days'] = 0;
			}
		}
		else
		{
			$input['list_date_limit_days'] = $this->filter('list_date_limit_days', InputFilterer::UNSIGNED);
		}

		$groupRepo = \XF::app()->repository(GroupRepository::class);

		if ($group->verifyCheckPrivacy()
			&& $groupRepo->isLowerPrivacy($input['group_type'], $group->group_type)
		)
		{
			$form->logError(\XF::phrase('dbtech_social_groups_cannot_downgrade_group_type'), 'group_type');
		}

		$editorPlugin = $this->plugin(EditorPlugin::class);
		$input['description'] = $editorPlugin->fromInput('description');
		$input['rules'] = $editorPlugin->fromInput('rules');

		if (!$group->exists())
		{
			$visitor = \XF::visitor();

			$input['user_id'] = $visitor->user_id;
			$input['username'] = $visitor->username;
		}

		$form->basicEntitySave($group, $input);

		$tags = $this->filter('tags', InputFilterer::STRING);
		$form->complete(function () use ($group, $tags)
		{
			$tagger = \XF::app()->service(ChangerService::class, 'dbtech_social_group', $group);
			$tagger->setEditableTags($tags);
			if (!$tagger->hasErrors())
			{
				$tagger->save();
			}
		});

		return $form;
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 * @throws PrintableException
	 */
	public function actionSave(ParameterBag $params): AbstractReply
	{
		if ($params['group_id'])
		{
			$group = $this->assertViewableGroup($params['group_id']);
			if (!$group->canEdit($error))
			{
				return $this->noPermission($error);
			}
		}
		else
		{
			if (!\XF::visitor()->canCreateDbtechSocialGroups($error))
			{
				throw $this->exception($this->noPermission($error));
			}

			$this->assertValidSettings();

			$group = \XF::app()->em()->create(Group::class);
		}

		if (\XF::app()->options()->dbtechSocialTermsPageId && !$this->filter('confirm', InputFilterer::BOOLEAN))
		{
			return $this->error(
				\XF::phrase('dbtech_social_groups_cannot_proceed_without_accepting_terms')
			);
		}

		$this->groupSaveProcess($group)->run();

		return $this->redirect($this->buildLink('dbtech-social', $group));
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 * @throws PrintableException
	 * @throws \Exception
	 */
	public function actionIcon(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);

		if (!$group->canUploadIcon())
		{
			return $this->noPermission();
		}

		if ($this->isPost())
		{
			$useCustom = $this->filter('use_custom', InputFilterer::BOOLEAN);
			$message = '';

			$iconService = \XF::app()->service(IconService::class, $group);

			if ($this->filter('delete_icon', InputFilterer::BOOLEAN))
			{
				$iconService->deleteIcon();
			}
			else if ($useCustom)
			{
				$upload = $this->request->getFile('upload', false, false);
				if ($upload)
				{
					if (!$iconService->setImageFromUpload($upload))
					{
						return $this->error($iconService->getError());
					}

					if (!$iconService->updateIcon())
					{
						return $this->error(\XF::phrase('dbtech_social_groups_new_icon_could_not_be_processed'));
					}
				}
				else if ($group->icon_date)
				{
					// recrop existing icon
					$cropX = round($this->filter('icon_crop_x', InputFilterer::UNUM));
					$cropY = round($this->filter('icon_crop_y', InputFilterer::UNUM));
					if ($cropX != $group->icon_crop_x || $cropY != $group->icon_crop_y)
					{
						$iconService->setImageFromExisting();
						$iconService->setCrop($cropX, $cropY);
						if (!$iconService->updateIcon())
						{
							return $this->error(\XF::phrase('dbtech_social_groups_new_icon_could_not_be_processed'));
						}
					}
				}
			}

			if ($this->filter('_xfWithData', InputFilterer::BOOLEAN))
			{
				return $this->view(
					View\Group\IconUpdateView::class,
					'',
					['group' => $group]
				);
			}
			else
			{
				return $this->redirect($this->buildLink('dbtech-social', $group));
			}
		}

		$viewParams = [
			'group' => $group,
			'maxSize' => \XF::app()->container('avatarSizeMap')['m'],
			'maxDimension' => ($group->icon_width > $group->icon_height ? 'height' : 'width'),
			'x' => $group->icon_crop_x,
			'y' => $group->icon_crop_y,
		];
		return $this->view(
			View\Group\IconView::class,
			'dbtech_social_groups_group_icon',
			$viewParams
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 * @throws PrintableException
	 * @throws \Exception
	 */
	public function actionBanner(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);

		if (!$group->canUploadBanner())
		{
			return $this->noPermission();
		}

		if ($this->isPost())
		{
			$bannerService = \XF::app()->service(BannerService::class, $group);

			if ($this->filter('delete_banner', InputFilterer::BOOLEAN))
			{
				$bannerService->deleteBanner();
			}
			else
			{
				$upload = $this->request->getFile('upload', false, false);
				if ($upload)
				{
					if (!$bannerService->setImageFromUpload($upload))
					{
						return $this->error($bannerService->getError());
					}

					if (!$bannerService->updateBanner())
					{
						return $this->error(\XF::phrase('new_banner_could_not_be_processed'));
					}
				}
				else if ($group->banner_date)
				{
					// reposition existing avatar
					$posY = $this->filter('banner_position_y', InputFilterer::UNSIGNED);
					if ($posY != $group->banner_position_y)
					{
						if (!$bannerService->setPosition($posY))
						{
							return $this->error(\XF::phrase('new_banner_could_not_be_processed'));
						}
					}
				}
			}

			if ($this->filter('_xfWithData', InputFilterer::BOOLEAN))
			{
				return $this->view(
					View\Group\BannerUpdateView::class,
					'',
					['group' => $group]
				);
			}
			else
			{
				return $this->redirect($this->buildLink('dbtech-social', $group));
			}
		}

		$viewParams = [
			'group' => $group,
		];
		return $this->view(
			View\Group\BannerView::class,
			'dbtech_social_groups_group_banner',
			$viewParams
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 * @throws PrintableException
	 * @throws \Exception
	 */
	public function actionTransferOwnership(ParameterBag $params): AbstractReply
	{
		$this->assertRegistrationRequired();
		$this->assertValidSettings();

		$visitor = \XF::visitor();

		$group = $this->assertViewableGroup($params['group_id']);
		if (!$group->canEdit($error))
		{
			return $this->noPermission($error);
		}

		if ($this->isPost())
		{
			if (!$visitor->authenticate($this->filter('visitor_password', InputFilterer::STRING)))
			{
				return $this->error(\XF::phrase('your_existing_password_is_not_correct'));
			}

			$username = $this->filter('username', InputFilterer::STRING);
			if (!$username)
			{
				return $this->error(\XF::phrase('requested_user_not_found'), 404);
			}

			$newOwner = \XF::app()->em()->findOne(User::class, ['username' => $username]);
			if (!$newOwner)
			{
				return $this->error(\XF::phrase('requested_user_not_found'), 404);
			}
			if ($newOwner->user_state !== 'valid' || $newOwner->is_banned)
			{
				return $this->error(
					\XF::phrase('dbtech_social_groups_you_cannot_make_x_owner_because_not_valid', [
						'user' => $newOwner->username,
					]),
					403
				);
			}
			if (!$newOwner->isMemberOfSocialGroup($group))
			{
				return $this->error(
					\XF::phrase('dbtech_social_groups_you_cannot_make_x_owner_because_not_member', [
						'user' => $newOwner->username,
					]),
					403
				);
			}
			if (!$newOwner->SocialGroupMemberships[$group->group_id]->isValid())
			{
				return $this->error(
					\XF::phrase('dbtech_social_groups_you_cannot_make_x_owner_because_not_valid_member', [
						'user' => $newOwner->username,
					]),
					403
				);
			}

			$canTargetView = \XF::asVisitor($newOwner, function () use ($group): bool
			{
				return $group->canView();
			});
			if (!$canTargetView)
			{
				return $this->error(\XF::phrase('dbtech_social_groups_new_owner_must_be_able_to_view_this_group'));
			}

			switch ($group->group_type)
			{
				case 'closed':
					if (!$newOwner->hasPermission('dbtechSocial', 'createClosedGroup'))
					{
						return $this->error(
							\XF::phrase('dbtech_social_groups_new_owner_must_be_able_to_create_group_type')
						);
					}
					break;

				case 'private':
					if (!$newOwner->hasPermission('dbtechSocial', 'createPrivateGroup'))
					{
						return $this->error(
							\XF::phrase('dbtech_social_groups_new_owner_must_be_able_to_create_group_type')
						);
					}
					break;

				case 'hidden':
					if (!$newOwner->hasPermission('dbtechSocial', 'createHiddenGroup'))
					{
						return $this->error(
							\XF::phrase('dbtech_social_groups_new_owner_must_be_able_to_create_group_type')
						);
					}
					break;
			}

			$maxCreatedGroups = $newOwner->hasPermission('dbtechSocial', 'maxCreatedGroups');
			if ($maxCreatedGroups != -1 && $newOwner->dbtech_social_groups_group_count >= $maxCreatedGroups)
			{
				return $this->error(
					\XF::phrase('dbtech_social_groups_new_owner_has_reached_limit_of_created_groups')
				);
			}

			$reassigner = \XF::app()->service(ReassignService::class, $group);
			$reassigner->setSendAlert(true, $this->filter('alert_reason', InputFilterer::STRING));
			$reassigner->reassignTo($newOwner);

			return $this->redirect($this->buildLink('dbtech-social', $group));
		}

		$viewParams = [
			'group' => $group,
		];
		return $this->view(
			View\Group\TransferOwnershipView::class,
			'dbtech_social_groups_group_transfer_ownership',
			$viewParams
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionDelete(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);
		if (!$group->canDelete())
		{
			return $this->noPermission();
		}

		$visitor = \XF::visitor();
		if ($this->isPost())
		{
			if (!$visitor->authenticate($this->filter('visitor_password', InputFilterer::STRING)))
			{
				return $this->error(\XF::phrase('your_existing_password_is_not_correct'));
			}
		}

		$deleteType = ($visitor->user_id != $group->user_id
			? $this->filter('delete_albums', InputFilterer::STRING)
			: \XF::app()->options()->dbtechSocialMediaGalleryDeleteAction)
		;

		// Can't be done in the plugin without too many hacks
		$group->setOption(
			'unlink_albums_on_delete',
			$deleteType === 'unlink'
		);

		$plugin = $this->plugin(DeletePlugin::class);
		return $plugin->actionDeleteWithState(
			$group,
			'group_state',
			'DBTech\SocialGroups:Group\Delete',
			'dbtech_social_group',
			$this->buildLink('dbtech-social/delete', $group),
			$this->buildLink('dbtech-social/edit', $group),
			$this->buildLink('dbtech-social'),
			$group->title,
			$group->canDelete('hard'),
			false,
			'dbtech_social_groups_group_delete'
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionList(ParameterBag $params): AbstractReply
	{
		$page = $this->filterPage($params['page']);
		$perPage = \XF::app()->options()->dbtechSocialGroupsPerPage;

		$this->assertCanonicalUrl($this->buildLink('dbtech-social', null, ['page' => $page]));

		$allowOwnPending = $this->hasContentPendingApproval();

		$groupRepo = \XF::app()->repository(GroupRepository::class);
		$groupFinder = $groupRepo->findGroupsForOverviewList([
			'allowOwnPending' => $allowOwnPending,
		]);

		$filters = $this->getGroupListFilterInput();
		$this->applyGroupListFilters($groupFinder, $filters);

		if ($page == 1)
		{
			$stickyGroupList = clone $groupFinder;

			/** @var AbstractCollection<Group> $stickyGroups */
			$stickyGroups = $stickyGroupList->where('sticky', 1)->fetch()->filterViewable();
		}
		else
		{
			$stickyGroups = null;
		}

		$groupFinder
			->where('sticky', 0)
			->limitByPage($page, $perPage);

		$total = $groupFinder->total();
		$groups = $groupFinder->fetch()->filterViewable();

		if (!empty($filters['owner_id']))
		{
			$ownerFilter = \XF::app()->em()->find(User::class, $filters['owner_id']);
		}
		else
		{
			$ownerFilter = null;
		}

		$viewParams = [
			'stickyGroups' => $stickyGroups,
			'groups' => $groups,

			'filters' => $filters,
			'ownerFilter' => $ownerFilter,

			'page' => $page,
			'perPage' => $perPage,
			'total' => $total,
		];
		return $this->view(
			View\Group\GroupListView::class,
			'dbtech_social_groups_group_list',
			$viewParams
		);
	}

	/**
	 * @param GroupFinder $groupFinder
	 * @param array $filters
	 */
	protected function applyGroupListFilters(GroupFinder $groupFinder, array $filters): void
	{
		if (!empty($filters['group_type']))
		{
			$groupFinder->where('group_type', $filters['group_type']);
		}

		if (!empty($filters['owner_id']))
		{
			$groupFinder->where('user_id', (int) $filters['owner_id']);
		}

		$sorts = $this->getAvailableGroupListSorts();

		if (!empty($filters['order']) && isset($sorts[$filters['order']]))
		{
			//			$groupFinder->order('featured', 'desc');
			if ($sorts[$filters['order']] == '__random__')
			{
				$groupFinder->order($groupFinder->expression('RAND()'));
			}
			else
			{
				$groupFinder->order($sorts[$filters['order']], $filters['direction']);
			}
		}
		// else the default order has already been applied
	}

	/**
	 * @return array
	 */
	protected function getGroupListFilterInput(): array
	{
		$filters = [];

		$input = $this->filter([
			'group_type' => InputFilterer::STRING,
			'owner'      => InputFilterer::STRING,
			'owner_id'   => InputFilterer::UNSIGNED,
			'order'      => InputFilterer::STRING,
			'direction'  => InputFilterer::STRING,
		]);

		if ($input['group_type'])
		{
			$filters['group_type'] = $input['group_type'];
		}

		if ($input['owner_id'])
		{
			$filters['owner_id'] = $input['owner_id'];
		}
		else if ($input['owner'])
		{
			$user = \XF::app()->em()->findOne(User::class, ['username' => $input['owner']]);
			if ($user)
			{
				$filters['owner_id'] = $user->user_id;
			}
		}

		$sorts = $this->getAvailableGroupListSorts();

		if ($input['order'] && isset($sorts[$input['order']]))
		{
			if (!in_array($input['direction'], ['asc', 'desc']))
			{
				$input['direction'] = 'desc';
			}

			$defaultOrder = \XF::app()->options()->dbtechSocialListDefaultOrder ?: 'last_message_date';
			$defaultDir = $defaultOrder == 'title' ? 'asc' : 'desc';

			if ($input['order'] != $defaultOrder || $input['direction'] != $defaultDir)
			{
				$filters['order'] = $input['order'];
				$filters['direction'] = $input['direction'];
			}
		}

		return $filters;
	}

	/**
	 * @return string[]
	 */
	protected function getAvailableGroupListSorts(): array
	{
		// maps [name of sort] => field in/relative to Group entity
		return [
			'title'             => 'title',
			'member_count'      => 'member_count',
			'discussion_count'  => 'discussion_count',
			'message_count'     => 'message_count',
			'view_count'        => 'view_count',
			'last_message_date' => 'last_message_date',
			'creation_date'     => 'creation_date',
			'last_update_date'  => 'last_update_date',
			'random'            => '__random__',
		];
	}

	/**
	 * @return AbstractReply
	 * @throws \Exception
	 */
	public function actionGroupListFilters(): AbstractReply
	{
		$filters = $this->getGroupListFilterInput();

		if ($this->filter('apply', InputFilterer::BOOLEAN))
		{
			return $this->redirect($this->buildLink('dbtech-social', null, $filters));
		}

		if (!empty($filters['owner_id']))
		{
			$ownerFilter = \XF::app()->em()->find(User::class, $filters['owner_id']);
		}
		else
		{
			$ownerFilter = null;
		}

		$defaultOrder = \XF::app()->options()->dbtechSocialListDefaultOrder ?: 'last_message_date';
		$defaultDir = $defaultOrder == 'title' ? 'asc' : 'desc';

		if (empty($filters['order']))
		{
			$filters['order'] = $defaultOrder;
		}
		if (empty($filters['direction']))
		{
			$filters['direction'] = $defaultDir;
		}

		$viewParams = [
			'filters' => $filters,
			'ownerFilter' => $ownerFilter,
		];
		return $this->view(
			View\Group\FiltersView::class,
			'dbtech_social_groups_group_list_filters',
			$viewParams
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 * @throws DbException
	 */
	public function actionGroup(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id'], $this->getGroupViewExtraWith());

		$this->assertCanonicalUrl($this->buildLink('dbtech-social', $group));

		$groupRepo = \XF::app()->repository(GroupRepository::class);
		$groupRepo->logGroupView($group);

		$viewParams = [
			'group' => $group,
		];
		return $this->view(
			View\Group\OverviewView::class,
			'dbtech_social_groups_group_overview',
			$viewParams
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionCreateDiscussion(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id'], $this->getGroupViewExtraWith());

		$sectionRepo = \XF::app()->repository(SectionRepository::class);
		$sections = $sectionRepo->findSectionsInGroup($group)->fetch();
		$sectionTree = count($sections) ? $sectionRepo->createSectionTree($sections) : null;
		$sectionExtras = $sectionTree ? $sectionRepo->getSectionListExtras($sectionTree) : null;

		$viewParams = [
			'group' => $group,
			'sectionTree' => $sectionTree,
			'sectionExtras' => $sectionExtras,
		];
		return $this->view(
			View\Group\CreateDiscussionChooser::class,
			'dbtech_social_groups_create_discussion_chooser',
			$viewParams
		);
	}

	/**
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionLoadSections(): AbstractReply
	{
		$this->assertPostOnly();

		$viewParams = [];

		$groupId = $this->filter('val', 'uint');
		if ($groupId)
		{
			$group = $this->assertGroupExists($groupId);

			$sectionRepo = \XF::app()->repository(SectionRepository::class);
			$sections = $sectionRepo->findSectionsInGroup($group)->fetch();
			$sectionTree = count($sections) ? $sectionRepo->createSectionTree($sections) : null;

			$viewParams['group'] = $group;
			$viewParams['sectionTree'] = $sectionTree;
		}

		return $this->view(
			View\Group\LoadSectionsView::class,
			'public:dbtech_social_groups_group_sections',
			$viewParams
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws DeadlockException
	 * @throws ReplyException
	 */
	public function actionDiscussions(ParameterBag $params): AbstractReply
	{
		if (!empty($params['section_id']))
		{
			// Viewing a section, fetch group by section
			$section = $this->assertViewableSection($params['section_id'], $this->getSectionViewExtraWith());
			$group = $section->getRelationFinder('Group')->with($this->getGroupViewExtraWith())->fetchOne();
		}
		else
		{
			$section = null;
			$group = $this->assertViewableGroup($params['group_id'], $this->getGroupViewExtraWith());
		}

		if ($this->responseType == 'rss')
		{
			if ($section)
			{
				return $this->getSectionRss($section);
			}
			else
			{
				return $this->getGroupRss($group);
			}
		}

		$page = $this->filterPage($params['page']);
		$perPage = \XF::app()->options()->discussionsPerPage;

		if ($section)
		{
			$this->assertCanonicalUrl($this->buildLink('dbtech-social/sections', $section, ['page' => $page]));
		}
		else
		{
			$this->assertCanonicalUrl($this->buildLink('dbtech-social/discussions/list', $group, ['page' => $page]));
		}

		if (\XF::app()->options()->dbtechSocialGroupsEnableSections)
		{
			$sectionRepo = \XF::app()->repository(SectionRepository::class);
			$sections = $sectionRepo->findSectionsInGroup($group, $section)->fetch();
			$sectionTree = count($sections) ? $sectionRepo->createSectionTree($sections, $section ? $section->section_id : 0) : null;
			$sectionExtras = $sectionTree ? $sectionRepo->getSectionListExtras($sectionTree) : null;
		}
		else
		{
			$sections = null;
			$sectionTree = null;
			$sectionExtras = null;
		}

		$hasDescendents = false;
		if ($sectionTree)
		{
			$sectionTree->traverse(function ($id, Section $childSection) use (&$hasDescendents)
			{
				$hasDescendents = true;
			});
		}

		$template = $section ? 'dbtech_social_groups_section_view' : 'dbtech_social_groups_group_view';

		if (!$group->canViewDiscussions())
		{
			$emptyCollection = \XF::app()->em()->getEmptyCollection();

			$viewParams = [
				'group' => $group,
				'section' => $section,

				'canInlineMod' => false,

				'stickyDiscussions' => $emptyCollection,
				'discussions' => $emptyCollection,

				'hasDescendents' => $hasDescendents,

				'sectionTree' => $sectionTree,
				'sectionExtras' => $sectionExtras,

				'page' => $page,
				'perPage' => $perPage,
				'total' => 0,

				'filters' => [],
				'canonicalFilters' => [],
				'starterFilter' => [],
				'showDateLimitDisabler' => false,

				'sortInfo' => $this->getEffectiveSortInfo($group, []),

				'pendingApproval' => $this->filter('pending_approval', InputFilterer::BOOLEAN),
			];
			return $this->view(
				View\Group\ViewView::class,
				$template,
				$viewParams
			);
		}

		$discussionRepo = \XF::app()->repository(DiscussionRepository::class);

		$discussionFinder = $discussionRepo->findDiscussionsForGroupView($group, [
			'allowOwnPending' => $this->hasContentPendingApproval(),
		]);

		if ($section)
		{
			$filters = [];
			$filters = $this->plugin(SectionPlugin::class)->getSectionFilterInput($section);
			$this->applySectionFilters($section, $discussionFinder, $filters);
		}
		else
		{
			$filters = $this->getGroupFilterInput($group);
			$this->applyGroupFilters($group, $discussionFinder, $filters);
		}

		if ($page == 1)
		{
			$stickyDiscussionList = clone $discussionFinder;

			/** @var AbstractCollection<Discussion> $stickyDiscussions */
			$stickyDiscussions = $stickyDiscussionList->where('sticky', 1)->fetch();
		}
		else
		{
			$stickyDiscussions = null;
		}

		$this->applyDateLimitFilters($group, $discussionFinder, $filters);

		$discussionFinder->where('sticky', 0)
			->limitByPage($page, $perPage);

		/** @var AbstractCollection<Discussion> $discussions */
		$discussions = $discussionFinder->fetch();
		$totalDiscussions = $discussionFinder->total();

		if ($section)
		{
			$this->assertValidPage($page, $perPage, $totalDiscussions, 'dbtech-social/sections', $section);
		}
		else
		{
			$this->assertValidPage($page, $perPage, $totalDiscussions, 'dbtech-social/discussions/list', $group);
		}

		$canInlineMod = false;
		if ($stickyDiscussions)
		{
			foreach ($stickyDiscussions AS $discussion)
			{
				if ($discussion->canUseInlineModeration())
				{
					$canInlineMod = true;
					break;
				}
			}
		}
		foreach ($discussions AS $discussion)
		{
			if ($discussion->canUseInlineModeration())
			{
				$canInlineMod = true;
				break;
			}
		}

		// if the group is unread and perhaps it shouldn't be, see if we can mark it as read
		if (\XF::visitor()->user_id
			&& $page == 1
			&& !$filters
			&& $group->isUnread()
		)
		{
			$hasNew = false;
			foreach ($discussions AS $discussion)
			{
				if ($discussion->isUnread() && !$discussion->isIgnored())
				{
					$hasNew = true;
					break;
				}
			}

			if (!$hasNew)
			{
				if ($section)
				{
					\XF::app()->repository(SectionRepository::class)->markSectionReadIfPossible($section);
				}
				else
				{
					\XF::app()->repository(GroupRepository::class)->markGroupReadIfPossible($group);
				}
			}
		}

		if (!empty($filters['starter_id']))
		{
			$starterFilter = \XF::app()->em()->find(User::class, $filters['starter_id']);
		}
		else
		{
			$starterFilter = null;
		}

		$isDateLimited = (empty($filters['no_date_limit']) && (!empty($filters['last_days']) || $group->list_date_limit_days));
		$discussionEndOffset = ($page - 1) * $perPage + count($discussions);
		$showDateLimitDisabler = ($isDateLimited && $discussionEndOffset >= $totalDiscussions);

		$canonicalFilters = [];
		if ($page > 1 && $group->list_date_limit_days && empty($filters['order']))
		{
			$cutOff = \XF::$time - ($group->list_date_limit_days * 86400);

			/** @var Discussion $lastDiscussion */
			$lastDiscussion = $discussions->last();
			if (
				$showDateLimitDisabler
				|| ($lastDiscussion && $lastDiscussion->last_message_date <= $cutOff)
			)
			{
				// we have removed the date limit and the last discussion here is only shown because of that
				$canonicalFilters['no_date_limit'] = 1;
			}
		}

		$viewParams = [
			'group' => $group,
			'section' => $section,

			'canInlineMod' => $canInlineMod,

			'stickyDiscussions' => $stickyDiscussions,
			'discussions' => $discussions,

			'hasDescendents' => $hasDescendents,

			'sectionTree' => $sectionTree,
			'sectionExtras' => $sectionExtras,

			'page' => $page,
			'perPage' => $perPage,
			'total' => $totalDiscussions,

			'filters' => $filters,
			'canonicalFilters' => $canonicalFilters,
			'starterFilter' => $starterFilter,
			'showDateLimitDisabler' => $showDateLimitDisabler,

			'sortInfo' => $this->getEffectiveSortInfo($group, $filters),

			'pendingApproval' => $this->filter('pending_approval', InputFilterer::BOOLEAN),
		];
		return $this->view(
			View\Group\ViewView::class,
			$template,
			$viewParams
		);
	}

	/**
	 * @return array
	 */
	protected function getGroupViewExtraWith(): array
	{
		$extraWith = [];
		$userId = \XF::visitor()->user_id;
		if ($userId)
		{
			$extraWith[] = 'Bookmarks|' . $userId;
			$extraWith[] = 'Watch|' . $userId;
		}

		return $extraWith;
	}

	/**
	 * @return array
	 */
	protected function getSectionViewExtraWith(): array
	{
		$extraWith = ['Group', 'Group.full'];
		$userId = \XF::visitor()->user_id;
		if ($userId)
		{
			$extraWith[] = 'Bookmarks|' . $userId;
			$extraWith[] = 'Watch|' . $userId;
		}

		return $extraWith;
	}

	/**
	 * @param Group $group
	 *
	 * @return string[]
	 */
	protected function getAvailableGroupSorts(Group $group): array
	{
		// maps [name of sort] => field in/relative to Discussion entity
		return [
			'last_message_date' => 'last_message_date',
			'message_date' => 'message_date',
			'title' => 'title',
			'reply_count' => 'reply_count',
			'view_count' => 'view_count',
			'first_message_reaction_score' => 'first_message_reaction_score',
		];
	}

	/**
	 * @param Group $group
	 *
	 * @return int[]
	 */
	protected function getAvailableDateLimits(Group $group): array
	{
		return [-1, 7, 14, 30, 60, 90, 182, 365];
	}

	protected function applyGroupFilters(
		Group            $group,
		DiscussionFinder $discussionFinder,
		array                                        $filters
	): void
	{
		// this function is only called in section-less context
		$discussionFinder->where('section_id', 0);

		//		if (!empty($filters['prefix_id']))
		//		{
		//			$discussionFinder->where('prefix_id', intval($filters['prefix_id']));
		//		}

		if (!empty($filters['starter_id']))
		{
			$discussionFinder->where('user_id', intval($filters['starter_id']));
		}

		$sorts = $this->getAvailableGroupSorts($group);

		if (!empty($filters['order']) && isset($sorts[$filters['order']]))
		{
			$discussionFinder->order($sorts[$filters['order']], $filters['direction']);
		}
		// else the default order has already been applied
	}

	protected function applySectionFilters(
		Section          $section,
		DiscussionFinder $discussionFinder,
		array                                        $filters
	): void
	{
		$discussionFinder->where('section_id', $section->section_id);

		//		if (!empty($filters['prefix_id']))
		//		{
		//			$discussionFinder->where('prefix_id', intval($filters['prefix_id']));
		//		}

		if (!empty($filters['starter_id']))
		{
			$discussionFinder->where('user_id', intval($filters['starter_id']));
		}

		$sorts = $this->plugin(SectionPlugin::class)->getAvailableSectionSorts($section);

		if (!empty($filters['order']) && isset($sorts[$filters['order']]))
		{
			$discussionFinder->order($sorts[$filters['order']], $filters['direction']);
		}
		// else the default order has already been applied
	}

	protected function applyDateLimitFilters(
		Group            $group,
		DiscussionFinder $discussionFinder,
		array                                        $filters
	): void
	{
		if (!empty($filters['last_days']) && empty($filters['no_date_limit']))
		{
			if ($filters['last_days'] > 0)
			{
				$discussionFinder->where('last_message_date', '>=', \XF::$time - ($filters['last_days'] * 86400));
			}
		}
		else if ($group->list_date_limit_days && empty($filters['no_date_limit']))
		{
			$discussionFinder->where('last_message_date', '>=', \XF::$time - ($group->list_date_limit_days * 86400));
		}
	}

	/**
	 * @param Group $group
	 *
	 * @return array
	 */
	protected function getGroupFilterInput(Group $group): array
	{
		$filters = [];

		$input = $this->filter([
			'prefix_id' => InputFilterer::UNSIGNED,
			'starter' => InputFilterer::STRING,
			'starter_id' => InputFilterer::UNSIGNED,
			'last_days' => InputFilterer::INT,
			'order' => InputFilterer::STRING,
			'direction' => InputFilterer::STRING,
			'no_date_limit' => InputFilterer::BOOLEAN,
		]);

		if ($input['no_date_limit'])
		{
			$filters['no_date_limit'] = $input['no_date_limit'];
		}

		//		if ($input['prefix_id'] && $group->isPrefixValid($input['prefix_id']))
		//		{
		//			$filters['prefix_id'] = $input['prefix_id'];
		//		}

		if ($input['starter_id'])
		{
			$filters['starter_id'] = $input['starter_id'];
		}
		else if ($input['starter'])
		{
			$user = \XF::app()->em()->findOne(User::class, ['username' => $input['starter']]);
			if ($user)
			{
				$filters['starter_id'] = $user->user_id;
			}
		}

		if (
			($input['last_days'] > 0 && $input['last_days'] != $group->list_date_limit_days)
			|| ($input['last_days'] < 0 && $group->list_date_limit_days)
		)
		{
			if (in_array($input['last_days'], $this->getAvailableDateLimits($group)))
			{
				$filters['last_days'] = $input['last_days'];
			}
		}

		$sorts = $this->getAvailableGroupSorts($group);

		if ($input['order'] && isset($sorts[$input['order']]))
		{
			if (!in_array($input['direction'], ['asc', 'desc']))
			{
				$input['direction'] = 'desc';
			}

			if ($input['order'] != $group->default_sort_order || $input['direction'] != $group->default_sort_direction)
			{
				$filters['order'] = $input['order'];
				$filters['direction'] = $input['direction'];
			}
		}

		return $filters;
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionBookmark(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);

		$bookmarkPlugin = $this->plugin(BookmarkPlugin::class);
		return $bookmarkPlugin->actionBookmark(
			$group,
			$this->buildLink('dbtech-social/bookmark', $group)
		);
	}



	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionFeature(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params->get('group_id'), ['Feature']);
		$breadcrumbs = $group->getBreadcrumbs();
		$confirmUrl = $this->buildLink('dbtech-social/feature', $group);
		$deleteUrl = $this->buildLink('dbtech-social/unfeature', $group);

		$featurePlugin = $this->plugin(FeaturedContentPlugin::class);
		return $featurePlugin->actionFeature(
			$group,
			$breadcrumbs,
			$confirmUrl,
			$deleteUrl
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionUnfeature(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params->get('group_id'), ['Feature']);
		$breadcrumbs = $group->getBreadcrumbs();
		$confirmUrl = $this->buildLink('dbtech-social/unfeature', $group);

		$featurePlugin = $this->plugin(FeaturedContentPlugin::class);
		return $featurePlugin->actionUnfeature(
			$group,
			$breadcrumbs,
			$confirmUrl
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionFilters(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);

		$filters = $this->getGroupFilterInput($group);

		if ($this->filter('apply', InputFilterer::BOOLEAN))
		{
			if (!empty($filters['last_days']))
			{
				unset($filters['no_date_limit']);
			}
			return $this->redirect($this->buildLink('dbtech-social/discussions/list', $group, $filters));
		}

		if (!empty($filters['starter_id']))
		{
			$starterFilter = \XF::app()->em()->find(User::class, $filters['starter_id']);
		}
		else
		{
			$starterFilter = null;
		}

		$viewParams = [
			'group' => $group,
			//			'prefixes' => $group->prefixes->groupBy('prefix_group_id'),
			'filters' => $filters,
			'starterFilter' => $starterFilter,
		];
		return $this->view(
			View\Group\FiltersView::class,
			'dbtech_social_groups_group_filters',
			$viewParams
		);
	}

	/**
	 * @return AbstractReply
	 */
	public function actionAutoComplete(): AbstractReply
	{
		$q = ltrim($this->filter('q', InputFilterer::STRING, ['no-trim']));

		if ($q !== '' && \mb_strlen($q) >= 2)
		{
			$groupFinder = \XF::app()->finder(GroupFinder::class)
				->searchTitleForAutoComplete($q)
			;

			$groups = $groupFinder->fetch();
		}
		else
		{
			$groups = [];
			$q = '';
		}

		$viewParams = [
			'q' => $q,
			'groups' => $groups,
		];
		return $this->view(
			View\Group\FindView::class,
			'',
			$viewParams
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 * @throws PrintableException
	 */
	public function actionJoin(ParameterBag $params): AbstractReply
	{
		$group = $this->assertGroupExists($params['group_id']);

		$plugin = $this->plugin(GroupPlugin::class);
		return $plugin->actionJoin(
			$group,
			$this->buildLink('dbtech-social/join', $group),
			$this->buildLink('dbtech-social', $group),
			$this->buildLink('dbtech-social', $group),
			$group->title
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 * @throws PrintableException
	 */
	public function actionLeave(ParameterBag $params): AbstractReply
	{
		$group = $this->assertGroupExists($params['group_id']);

		$params = [];
		if (!$group->allow_members)
		{
			$params['leaveImportantPhrase'] = 'dbtech_social_groups_this_group_invite_only_need_invited_back';
		}

		$redirect = $this->getDynamicRedirectIfNot(
			$this->buildLink('dbtech-social', $group),
			$this->buildLink('dbtech-social')
		);

		$plugin = $this->plugin(GroupPlugin::class);
		return $plugin->actionLeave(
			$group,
			$this->buildLink('dbtech-social/leave', $group),
			$this->buildLink('dbtech-social', $group),
			$redirect,
			$group->title,
			null,
			$params
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionMembers(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);

		$page = $this->filterPage($params['page']);
		$perPage = \XF::app()->options()->membersPerPage;

		$filterer = $this->setupGroupMemberFilterer($group);
		$finder = $filterer->apply()->limitByPage($page, $perPage);

		$linkParams = $filterer->getLinkParams();

		$filter = $this->filter('_xfFilter', [
			'text' => InputFilterer::STRING,
			'prefix' => InputFilterer::BOOLEAN,
		]);
		if (strlen($filter['text']))
		{
			$finder->where(
				$finder->columnUtf8('User.username'),
				'LIKE',
				$finder->escapeLike($filter['text'], $filter['prefix'] ? '?%' : '%?%'),
			);

			$linkParams['_xfFilter'] = $filter;
		}

		if ($this->isPost())
		{
			return $this->redirect(
				$this->buildLink('dbtech-social/members', $group, $linkParams),
				''
			);
		}

		$total = $finder->total();
		$this->assertValidPage($page, $perPage, $total, 'dbtech-social/members', $group);

		if ($group->canApproveRejectMembers())
		{
			$unapprovedMembers = \XF::app()->repository(GroupMemberRepository::class)
				->getUnapprovedMembersInGroup($group)
				->fetch()
			;
		}
		else
		{
			$unapprovedMembers = \XF::app()->em()->getEmptyCollection();
		}

		$viewParams = [
			'unapprovedMembers' => $unapprovedMembers,
			'members' => $finder->fetch(),
			'moderators' => $group->getRelationFinder('Moderators')->fetch(),
			'group' => $group,

			'total' => $total,
			'page' => $page,
			'perPage' => $perPage,

			'linkParams' => $linkParams,
			'filterDisplay' => $filterer->getDisplayValues(),
		];
		return $this->view(
			View\Group\MembersView::class,
			'dbtech_social_groups_group_members',
			$viewParams
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 * @throws \Exception
	 */
	public function actionMembersFilter(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);

		$filterer = $this->setupGroupMemberFilterer($group);

		$viewParams = [
			'conditions' => $filterer->getFiltersForForm(),
			'datePresets' => \XF::language()->getDatePresets(),
			'group' => $group,
		];
		return $this->view(
			View\Group\Members\FilterView::class,
			'dbtech_social_groups_group_members_filter',
			$viewParams
		);
	}

	/**
	 * @param Group $group
	 *
	 * @return GroupMemberFilterer
	 */
	protected function setupGroupMemberFilterer(Group $group): GroupMemberFilterer
	{
		$filterer = \XF::app()->filterer(GroupMemberFilterer::class, ['group_id' => $group->group_id]);
		$filterer->addFilters($this->request, $this->filter('_skipFilter', InputFilterer::STRING));

		return $filterer;
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionMembersLog(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);
		if (!$group->canEdit($error))
		{
			return $this->noPermission($error);
		}

		$page = $this->filterPage($params['page']);
		$perPage = 20;

		$groupMemberRepo = \XF::app()->repository(GroupMemberRepository::class);

		$logFinder = $groupMemberRepo->findLogsForListInGroup($group)
			->applyGlobalVisibilityChecks()
			->limitByPage($page, $perPage);

		$linkFilters = [];
		if ($actorId = $this->filter('actor_id', InputFilterer::UNSIGNED))
		{
			$linkFilters['actor_id'] = $actorId;
			$logFinder->where('actor_id', $actorId);
		}
		if ($userId = $this->filter('user_id', InputFilterer::UNSIGNED))
		{
			$linkFilters['user_id'] = $userId;
			$logFinder->where('user_id', $userId);
		}

		// TODO: support for other filters/sorting?

		if ($this->isPost())
		{
			// redirect to give a linkable page
			return $this->redirect($this->buildLink('dbtech-social/members/log', $group, $linkFilters));
		}

		$viewParams = [
			'group' => $group,

			'entries' => $logFinder->fetch(),
			'logActors' => $groupMemberRepo->getActorsInLogForGroup($group),
			'logUsers' => $groupMemberRepo->getUsersInLogForGroup($group),

			'actorId' => $actorId,
			'userId' => $userId,

			'page' => $page,
			'perPage' => $perPage,
			'total' => $logFinder->total(),
			'linkFilters' => $linkFilters,
		];
		return $this->view(
			View\Group\Members\LogView::class,
			'dbtech_social_groups_group_members_log',
			$viewParams
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 * @throws PrintableException
	 */
	public function actionApproveMembers(ParameterBag $params): AbstractReply
	{
		$this->assertPostOnly();
		$group = $this->assertViewableGroup($params['group_id']);

		if (!$group->canApproveRejectMembers($error))
		{
			return $this->noPermission();
		}

		/** @var AbstractCollection<GroupMember> $unapprovedMembers */
		$unapprovedMembers = \XF::app()->repository(GroupMemberRepository::class)
			->getUnapprovedMembersInGroup($group)
			->fetch()
		;
		foreach ($unapprovedMembers AS $groupMember)
		{
			$action = $this->filter('queue.' . $groupMember->group_member_id, InputFilterer::STRING, '');
			$reason = $this->filter('reason.' . $groupMember->group_member_id, InputFilterer::STRING, '');
			$notify = $this->filter('notify.' . $groupMember->group_member_id, InputFilterer::BOOLEAN, false);

			switch ($action)
			{
				case 'approve':
					$approver = \XF::app()->service(ApproverService::class, $groupMember);
					$approver->setNotify($notify);
					$approver->setNotifyRunTime(1); // may be a lot happening
					$approver->approve();
					break;

				case 'reject':
					$approver = \XF::app()->service(ApproverService::class, $groupMember);
					$approver->setNotify($notify);
					$approver->setNotifyRunTime(1); // may be a lot happening
					$approver->setReason($reason);
					$approver->reject();
					break;
			}
		}

		return $this->redirect($this->buildLink('dbtech-social/members', $group));
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionRelatedThreads(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);
		if (!$group->canManageRelatedThreads($error))
		{
			return $this->noPermission($error);
		}

		$visitor = \XF::visitor();

		$relatedThreads = $group->getRelationFinder('RelatedThreads')
			->with([
				'Thread',
				'Thread.fullForum',
				'Thread.Forum.Node',
				'Thread.Forum.Node.Permissions|' . $visitor->permission_combination_id,
			])
			->fetch();

		if ($this->isPost())
		{
			$input = $this->filter([
				'relatedThreads' => 'array-str',
			]);
			$relatedThreadService = \XF::app()->service(
				LinkRelatedThreadsService::class,
				$group,
				$input['relatedThreads']
			);
			if (!$relatedThreadService->validate($errors))
			{
				throw $this->exception($this->error($errors));
			}
			$relatedThreadService->save();

			return $this->redirect($this->buildLink('dbtech-social/related-threads', $group));
		}

		$viewParams = [
			'group' => $group,
			'relatedThreads' => $relatedThreads,
		];
		return $this->view(
			View\Group\RelatedThreadsView::class,
			'dbtech_social_groups_group_related_threads',
			$viewParams
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionRelatedThreadsSort(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);
		if (!$group->canManageRelatedThreads($error))
		{
			return $this->noPermission($error);
		}

		$visitor = \XF::visitor();

		$relatedThreads = $group->getRelationFinder('RelatedThreads')
			->with([
				'Thread',
				'Thread.fullForum',
				'Thread.Forum.Node',
				'Thread.Forum.Node.Permissions|' . $visitor->permission_combination_id,
			])
			->fetch();

		if ($this->isPost())
		{
			$sortData = $this->filter('relatedThreads', InputFilterer::JSON_ARRAY);

			$sorter = $this->plugin(SortPlugin::class);
			$sorter->sortFlat($sortData, $relatedThreads, ['jump' => 10]);

			return $this->redirect($this->buildLink('dbtech-social/related-threads', $group));
		}
		else
		{
			$viewParams = [
				'group' => $group,
				'relatedThreads' => $relatedThreads,
			];
			return $this->view(
				View\Group\RelatedThreads\SortView::class,
				'dbtech_social_groups_group_related_threads_sort',
				$viewParams
			);
		}
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 * @throws PrintableException
	 */
	public function actionRelatedThreadsDelete(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);
		if (!$group->canManageRelatedThreads($error))
		{
			return $this->noPermission($error);
		}

		$threadId = $this->filter('thread_id', InputFilterer::UNSIGNED);

		if (!$group->RelatedThreads->offsetExists($threadId))
		{
			return $this->notFound();
		}

		$relatedThread = $group->RelatedThreads[$threadId];

		if ($this->isPost())
		{
			$relatedThread->delete();
			return $this->redirect($this->buildLink('dbtech-social/related-threads', $group));
		}
		else
		{
			$viewParams = [
				'group' => $group,
				'relatedThread' => $relatedThread,
			];
			return $this->view(
				View\Group\RelatedThreads\DeleteView::class,
				'dbtech_social_groups_group_related_threads_delete',
				$viewParams
			);
		}
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionSupervisors(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);

		$viewParams = [
			'group' => $group,
		];
		return $this->view(
			View\Group\SupervisorsView::class,
			'dbtech_social_groups_group_supervisors',
			$viewParams
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionModerators(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);

		$viewParams = [
			'group' => $group,
		];
		return $this->view(
			View\Group\ModeratorsView::class,
			'dbtech_social_groups_group_moderators',
			$viewParams
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 * @throws PrintableException
	 */
	public function actionAddSupervisor(ParameterBag $params): AbstractReply
	{
		$this->assertValidSettings();

		$group = $this->assertViewableGroup($params['group_id']);
		if (!$group->canAddSupervisor())
		{
			return $this->noPermission();
		}

		$maximumPermissions = \json_decode(
			\XF::app()->options()->dbtechSocialDefaultPermissions['groupModerators'] ?: '[]',
			true
		);

		if ($this->isPost())
		{
			/** @var ExtendedUserEntity $visitor */
			$visitor = \XF::visitor();

			if (!$visitor->authenticate($this->filter('visitor_password', InputFilterer::STRING)))
			{
				return $this->error(\XF::phrase('your_existing_password_is_not_correct'));
			}

			$username = $this->filter('username', InputFilterer::STRING);
			if (!$username)
			{
				return $this->error(\XF::phrase('requested_user_not_found'), 404);
			}

			$user = \XF::app()->em()->findOne(User::class, ['username' => $username]);
			if (!$user)
			{
				return $this->error(\XF::phrase('requested_user_not_found'), 404);
			}
			if ($user->user_state !== 'valid' || $user->is_banned)
			{
				return $this->error(
					\XF::phrase('dbtech_social_groups_you_cannot_make_x_moderator_because_not_valid', [
						'user' => $user->username,
					]),
					403
				);
			}
			if (!$user->isMemberOfSocialGroup($group))
			{
				return $this->error(
					\XF::phrase('dbtech_social_groups_you_cannot_make_x_moderator_because_not_member', [
						'user' => $user->username,
					]),
					403
				);
			}

			/** @var GroupMember $groupMember */
			$groupMember = $group->Members[$user->user_id];

			if ($groupMember->member_state !== 'valid')
			{
				return $this->error(
					\XF::phrase('dbtech_social_groups_you_cannot_make_x_moderator_because_not_valid_member', [
						'user' => $user->username,
					]),
					403
				);
			}
			if ($groupMember->is_supervisor)
			{
				return $this->error(\XF::phrase('dbtech_social_groups_user_already_supervisor'));
			}

			\XF::app()->repository(GroupPermissionsRepository::class)->addModeratorPermissionsForGroup(
				$user,
				$group,
				\array_replace_recursive($maximumPermissions, $this->filter('permissions', InputFilterer::ARRAY))
			);

			\XF::app()->repository(GroupMemberRepository::class)
				->logAction($groupMember, 'supervisor_added', [], $visitor)
			;

			return $this->redirect($this->buildLink('dbtech-social/supervisors', $group));
		}

		$moderatorPermissionData = \XF::app()->repository(ModeratorRepository::class)
			->getModeratorPermissionData('dbtech_social_group')
		;

		$viewParams = [
			'group' => $group,

			'maximumPermissions' => $maximumPermissions,

			'interfaceGroups' => $moderatorPermissionData['interfaceGroups'],
			'globalPermissions' => $moderatorPermissionData['globalPermissions'],
			'contentPermissions' => $moderatorPermissionData['contentPermissions'],
		];
		return $this->view(
			View\Group\Supervisors\AddView::class,
			'dbtech_social_groups_group_supervisors_add',
			$viewParams
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 * @throws PrintableException
	 */
	public function actionEditSupervisor(ParameterBag $params): AbstractReply
	{
		$this->assertValidSettings();

		$group = $this->assertViewableGroup($params['group_id']);
		$groupMember = $this->assertGroupMemberExists($this->filter('group_member_id', InputFilterer::UNSIGNED));
		if ($groupMember->group_id !== $group->group_id || !$groupMember->is_supervisor)
		{
			return $this->notFound();
		}

		if (!$group->canEditSupervisor($groupMember))
		{
			return $this->noPermission();
		}

		$maximumPermissions = \json_decode(
			\XF::app()->options()->dbtechSocialDefaultPermissions['groupModerators'] ?: '[]',
			true
		);

		if ($this->isPost())
		{
			/** @var ExtendedUserEntity $visitor */
			$visitor = \XF::visitor();

			if (!$visitor->authenticate($this->filter('visitor_password', InputFilterer::STRING)))
			{
				return $this->error(\XF::phrase('your_existing_password_is_not_correct'));
			}

			\XF::app()->repository(GroupPermissionsRepository::class)->addModeratorPermissionsForGroup(
				$groupMember->User,
				$group,
				\array_replace_recursive($maximumPermissions, $this->filter('permissions', InputFilterer::ARRAY))
			);

			return $this->redirect($this->buildLink('dbtech-social/supervisors', $group));
		}

		$moderatorPermissionData = \XF::app()->repository(ModeratorRepository::class)
			->getModeratorPermissionData('dbtech_social_group')
		;

		$typeEntries = $groupMember->permissions['contentPermissions'] ?? [];

		$viewParams = [
			'group' => $group,
			'groupMember' => $groupMember,
			'user' => $groupMember->User,

			'maximumPermissions' => $maximumPermissions,

			'typeEntries' => $typeEntries,

			'interfaceGroups' => $moderatorPermissionData['interfaceGroups'],
			'globalPermissions' => $moderatorPermissionData['globalPermissions'],
			'contentPermissions' => $moderatorPermissionData['contentPermissions'],
		];
		return $this->view(
			View\Group\Supervisors\EditView::class,
			'dbtech_social_groups_group_supervisors_edit',
			$viewParams
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 * @throws PrintableException
	 */
	public function actionRemoveSupervisor(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);
		$groupMember = $this->assertGroupMemberExists($this->filter('group_member_id', InputFilterer::UNSIGNED));
		if ($groupMember->group_id !== $group->group_id)
		{
			return $this->notFound();
		}

		if (!$group->canRemoveSupervisor($groupMember))
		{
			return $this->noPermission();
		}

		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		/** @var GroupMemberPlugin $plugin */
		$plugin = $this->plugin(GroupMemberPlugin::class);
		return $plugin->actionRemoveSupervisor(
			$groupMember,
			$this->buildLink('dbtech-social/remove-supervisor', $group, ['group_member_id' => $groupMember->group_member_id]),
			$this->buildLink('dbtech-social/supervisors', $group),
			$this->buildLink('dbtech-social/supervisors', $group),
			($groupMember->user_id !== $visitor->user_id)
				? \sprintf(
					"%s %s%s%s",
					$groupMember->User->username,
					\XF::language()->parenthesis_open,
					$group->title,
					\XF::language()->parenthesis_close
				)
				: $group->title,
			'dbtech_social_groups_group_supervisor_delete_confirm'
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionRules(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);
		if (empty($group->rules))
		{
			return $this->notFound();
		}

		$viewParams = [
			'group' => $group,
		];
		return $this->view(
			View\Group\RulesView::class,
			'dbtech_social_groups_group_rules',
			$viewParams
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionInvited(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);
		if (!$group->canInvite())
		{
			return $this->noPermission();
		}

		$page = $this->filterPage($params['page']);
		$perPage = \XF::app()->options()->dbtechSocialGroupsPerPage;

		$inviteRepo = \XF::app()->repository(GroupInviteRepository::class);
		$inviteFinder = $inviteRepo->findGroupInvitesForList($group)->limitByPage($page, $perPage);
		$total = $inviteFinder->total();

		$this->assertValidPage($page, $perPage, $total, 'dbtech-social/invited', $group);

		$viewParams = [
			'group' => $group,
			'groupInvites' => $inviteFinder->fetch(),

			'page' => $page,
			'perPage' => $perPage,
			'total' => $total,
		];
		return $this->view(
			View\Group\InviteListingView::class,
			'dbtech_social_groups_group_invite_user_list',
			$viewParams
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 * @throws PrintableException
	 * @throws \Exception
	 */
	public function actionInvite(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);
		if (!$group->canInvite())
		{
			return $this->noPermission();
		}

		$permittedInvites = \XF::visitor()->hasPermission('dbtechSocial', 'maxInvitedUserBatch');
		$permittedInvites = $permittedInvites == 0 ? 1 : $permittedInvites;

		if ($this->isPost())
		{
			$usernames = $this->filter('usernames', 'array-str');

			/** @var AbstractCollection<ExtendedUserEntity> $users */
			$users = \XF::app()->finder(UserFinder::class)
				->with('SocialGroupBans|' . $group->group_id)
				->where('username', $usernames)
				->fetch()
			;

			if ($permittedInvites > 0)
			{
				$users = $users->slice(0, $permittedInvites);
			}

			if (!$users->count())
			{
				return $this->error(\XF::phrase('no_users_match_specified_criteria'), 404);
			}

			/** @var ExtendedUserEntity $visitor */
			$visitor = \XF::visitor();

			foreach ($users AS $user)
			{
				if ($user->SocialGroupBans[$group->group_id])
				{
					return $this->error(\XF::phrase('dbtech_social_groups_x_banned_from_this_group', [
						'user' => $user->username,
					]));
				}

				if (!$user->canViewDbtechSocialGroups())
				{
					return $this->error(\XF::phrase('dbtech_social_groups_x_invite_cannot_view_social_groups', [
						'user' => $user->username,
					]));
				}

				if (!$group->canInviteUser($user))
				{
					return $this->error(\XF::phrase('dbtech_social_groups_x_invite_cannot_join_social_group', [
						'user' => $user->username,
					]));
				}

				$existingMember = \XF::app()->em()->findOne(GroupMember::class, [
					'user_id' => $user->user_id,
					'group_id' => $group->group_id,
				]);
				if ($existingMember)
				{
					return $this->error(\XF::phrase('dbtech_social_groups_x_already_member', [
						'user' => $user->username,
					]));
				}

				$existingInvite = \XF::app()->em()->findOne(GroupInvite::class, [
					'user_id' => $user->user_id,
					'group_id' => $group->group_id,
				]);
				if ($existingInvite)
				{
					return $this->error(\XF::phrase('dbtech_social_groups_x_already_invited', [
						'user' => $user->username,
					]));
				}

				if ($user->isIgnoring($visitor->user_id))
				{
					return $this->error(\XF::phrase('dbtech_social_groups_cannot_invite_x', [
						'user' => $user->username,
					]));
				}
			}

			$db = \XF::app()->db();

			$db->beginTransaction();
			foreach ($users AS $user)
			{
				$invite = \XF::app()->em()->create(GroupInvite::class);
				$invite->user_id = $user->user_id;
				$invite->group_id = $group->group_id;
				$invite->invited_by_user_id = $visitor->user_id;
				$invite->reason = $this->filter('reason', InputFilterer::STRING);
				$invite->save(true, false);

				$groupMember = $group->getNewMember();
				$groupMember->user_id = $user->user_id;
				$groupMember->hydrateRelation('User', $user);

				if ($invite->reason)
				{
					\XF::app()->repository(GroupMemberRepository::class)
						->logAction($groupMember, 'invite_reason', [
							'reason' => $invite->reason,
						], \XF::visitor())
					;
				}
				else
				{
					\XF::app()->repository(GroupMemberRepository::class)
						->logAction($groupMember, 'invite', [], \XF::visitor())
					;
				}

				unset($groupMember);
			}

			$db->commit();

			return $this->redirect(
				$this->buildLink('dbtech-social/invited', $group),
				\XF::phrase('dbtech_social_groups_invited_users_successfully')
			);
		}

		$viewParams = [
			'group' => $group,
			'permittedInvites' => $permittedInvites,
		];
		return $this->view(
			View\Group\InviteView::class,
			'dbtech_social_groups_group_invite',
			$viewParams
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 * @throws PrintableException
	 */
	public function actionInviteCancel(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);
		if (!$group->canInvite())
		{
			return $this->noPermission();
		}

		$groupInvite = $this->assertGroupInviteExists($this->filter('group_invite_id', InputFilterer::UNSIGNED));

		if ($groupInvite->group_id !== $group->group_id)
		{
			return $this->noPermission();
		}

		if ($this->isPost())
		{
			$groupInvite->delete();

			return $this->redirect(
				$this->buildLink('dbtech-social/invited', $group),
				\XF::phrase('dbtech_social_groups_cancelled_invite_for_x_successfully', [
					'user' => $groupInvite->User->username,
				])
			);
		}

		$viewParams = [
			'group' => $group,
			'groupInvite' => $groupInvite,
		];
		return $this->view(
			View\Group\InviteCancelView::class,
			'dbtech_social_groups_group_invite_cancel',
			$viewParams
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 * @throws PrintableException
	 */
	public function actionKick(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);
		if (!$group->canKick())
		{
			return $this->noPermission();
		}

		$groupMember = $this->assertGroupMemberExists($this->filter('group_member_id', InputFilterer::UNSIGNED));
		if ($groupMember->group_id !== $group->group_id)
		{
			return $this->notFound();
		}

		if ($groupMember->user_id === $group->user_id)
		{
			return $this->noPermission();
		}

		if (!$group->canKickUser($groupMember->User, $error))
		{
			return $this->error($error);
		}

		/** @var GroupMemberPlugin $plugin */
		$plugin = $this->plugin(GroupMemberPlugin::class);
		return $plugin->actionKick(
			$groupMember,
			$this->buildLink('dbtech-social/kick', $group, ['group_member_id' => $groupMember->group_member_id]),
			$this->buildLink('dbtech-social/members', $group),
			$this->buildLink('dbtech-social/members', $group),
			\sprintf(
				"%s %s%s%s",
				$groupMember->User->username,
				\XF::language()->parenthesis_open,
				$group->title,
				\XF::language()->parenthesis_close
			)
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionBanned(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);
		if (!$group->canViewBannedUsers())
		{
			return $this->noPermission();
		}

		$page = $this->filterPage($params['page']);
		$perPage = \XF::app()->options()->membersPerPage;

		$banningRepo = \XF::app()->repository(BanningRepository::class);
		$banFinder = $banningRepo->findGroupBansForList($group)->limitByPage($page, $perPage);
		$total = $banFinder->total();

		$this->assertValidPage($page, $perPage, $total, 'dbtech-social/banned', $group);

		$viewParams = [
			'group' => $group,
			'groupBans' => $banFinder->fetch(),

			'page' => $page,
			'perPage' => $perPage,
			'total' => $total,
		];
		return $this->view(
			View\Group\BanListingView::class,
			'dbtech_social_groups_group_ban_user_list',
			$viewParams
		);
	}

	/**
	 * @param Group $group
	 * @param User $user
	 * @param GroupBan $groupBan
	 *
	 * @return AbstractReply
	 */
	public function groupBanAddEdit(
		Group $group,
		User $user,
		GroupBan $groupBan
	): AbstractReply
	{
		if (!$group->canBanUser($user, $error))
		{
			return $this->error($error);
		}

		if ($group->Moderators[$user->user_id])
		{
			return $this->error(\XF::phrase('this_user_is_an_admin_or_moderator_choose_another'));
		}

		$viewParams = [
			'user' => $user,
			'group' => $group,
			'groupBan' => $groupBan,
		];
		return $this->view(
			View\Group\Ban\EditView::class,
			'dbtech_social_groups_group_ban_edit',
			$viewParams
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionBanEdit(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);
		$user = $this->assertUserExists($this->filter('user_id', InputFilterer::UNSIGNED));

		$groupBan = \XF::app()->em()->find(GroupBan::class, [
			'user_id' => $user->user_id,
			'group_id' => $group->group_id,
		]);
		if (!$groupBan)
		{
			return $this->notFound();
		}

		return $this->groupBanAddEdit($group, $user, $groupBan);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionBan(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);
		if (!$group->canBan())
		{
			return $this->noPermission();
		}

		if ($this->isPost())
		{
			$user = \XF::app()->em()->findOne(User::class, ['username' => $this->filter('username', InputFilterer::STRING)]);
			if (!$user)
			{
				return $this->error(\XF::phrase('requested_user_not_found'), 404);
			}

			if ($user->user_id === \XF::visitor()->user_id)
			{
				return $this->error(\XF::phrase('dbtech_social_groups_cannot_manage_own_ban'), 403);
			}
		}
		else
		{
			$userId = $this->filter('user_id', InputFilterer::UNSIGNED);
			if (!$userId)
			{
				$groupMemberId = $this->filter('group_member_id', InputFilterer::UNSIGNED);
				if (!$groupMemberId)
				{
					$viewParams = [
						'group' => $group,
					];
					return $this->view(
						View\Group\BanChooserView::class,
						'dbtech_social_groups_group_ban_chooser',
						$viewParams
					);
				}
				else
				{
					$groupMember = $this->assertGroupMemberExists($groupMemberId);
					if ($groupMember->group_id !== $group->group_id)
					{
						return $this->notFound();
					}

					if ($groupMember->user_id === $group->user_id)
					{
						return $this->noPermission();
					}

					$user = $groupMember->User;
				}
			}
			else
			{
				$user = $this->assertUserExists($userId);
			}
		}

		$existingBan = \XF::app()->em()->findOne(GroupBan::class, [
			'user_id' => $user->user_id,
			'group_id' => $group->group_id,
		]);
		if ($existingBan)
		{
			return $this->rerouteController(__CLASS__, 'ban-edit', $params);
		}

		$groupBan = \XF::app()->em()->create(GroupBan::class);
		$groupBan->user_id = $user->user_id;
		$groupBan->group_id = $group->group_id;

		return $this->groupBanAddEdit($group, $user, $groupBan);
	}

	/**
	 * @param Group $group
	 * @param User $user
	 *
	 * @return FormAction
	 */
	protected function groupBanSaveProcess(Group $group, User $user): FormAction
	{
		$form = $this->formAction();

		$input = $this->filter([
			'ban_length' => InputFilterer::STRING,
			'end_date' => InputFilterer::DATETIME,
			'user_reason' => InputFilterer::STRING,
		]);

		$form->apply(function (FormAction $form) use ($input, $group, $user)
		{
			if ($input['ban_length'] == 'permanent')
			{
				$input['end_date'] = 0;
			}

			$banningRepo = \XF::app()->repository(BanningRepository::class);
			if (!$banningRepo->banUserFromGroup($user, $group, $input['end_date'], $input['user_reason'], $error))
			{
				throw $this->exception($this->error($error));
			}
		});

		return $form;
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 * @throws PrintableException
	 */
	public function actionBanSave(ParameterBag $params): AbstractReply
	{
		$this->assertPostOnly();

		$group = $this->assertViewableGroup($params['group_id']);
		if (!$group->canBan())
		{
			return $this->noPermission();
		}

		$user = $this->assertUserExists($this->filter('user_id', InputFilterer::UNSIGNED));

		if (!$group->canBanUser($user, $error))
		{
			return $this->error($error);
		}

		if ($group->Moderators[$user->user_id])
		{
			return $this->error(\XF::phrase('this_user_is_an_admin_or_moderator_choose_another'));
		}

		$this->groupBanSaveProcess($group, $user)->run();

		return $this->redirect($this->getDynamicRedirect());
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 * @throws PrintableException
	 */
	public function actionBanLift(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);
		if (!$group->canBan())
		{
			return $this->noPermission();
		}

		$user = $this->assertUserExists($this->filter('user_id', InputFilterer::UNSIGNED));

		$groupBan = \XF::app()->em()->find(GroupBan::class, [
			'user_id' => $user->user_id,
			'group_id' => $group->group_id,
		]);
		if (!$groupBan)
		{
			return $this->notFound();
		}

		if (!$group->canBanUser($user, $error))
		{
			return $this->error($error);
		}

		if ($group->Moderators[$user->user_id])
		{
			return $this->error(\XF::phrase('this_user_is_an_admin_or_moderator_choose_another'));
		}

		if ($this->isPost())
		{
			$groupBan->delete();

			/** @var GroupMember $groupMember */
			$groupMember = $groupBan->GroupMember;
			if ($groupMember)
			{
				\XF::app()->repository(GroupMemberRepository::class)
					->logAction($groupMember, 'unban', [], \XF::visitor())
				;
			}

			\XF::app()->repository(GroupRepository::class)
				->sendModeratorActionAlert(
					$groupBan->Group,
					'unban',
					'',
					[],
					$groupBan->User
				)
			;

			return $this->redirect($this->getDynamicRedirect());
		}
		else
		{
			$viewParams = [
				'user' => $user,
				'group' => $group,
				'groupBan' => $groupBan,
			];
			return $this->view(
				View\Group\Ban\LiftView::class,
				'dbtech_social_groups_group_ban_lift',
				$viewParams
			);
		}
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionFindMember(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);

		$q = ltrim($this->filter('q', InputFilterer::STRING, ['no-trim']));

		if ($q !== '' && \mb_strlen($q) >= 2)
		{
			$memberFinder = \XF::app()->finder(GroupMemberFinder::class);

			$members = $memberFinder
				->with('User')
				->where('group_id', $group->group_id)
				->where('User.username', 'like', $memberFinder->escapeLike($q, '?%'))
				->isValidUser(true)
				->fetch(10);
		}
		else
		{
			$members = [];
			$q = '';
		}

		$viewParams = [
			'q' => $q,
			'members' => $members,
		];
		return $this->view(
			View\Group\FindMemberView::class,
			'',
			$viewParams
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionDraft(ParameterBag $params): AbstractReply
	{
		$this->assertPostOnly();

		$group = $this->assertViewableGroup($params['group_id']);

		$creator = $this->setupDiscussionCreate($group);
		$discussion = $creator->getDiscussion();

		$extraData = [
			'title' => $discussion->title,
			'tags' => $this->filter('tags', InputFilterer::STRING),
			'attachment_hash' => $this->filter('attachment_hash', InputFilterer::STRING),
		];
		if ($group->canCreatePoll() && $this->filter('poll.question', InputFilterer::STRING))
		{
			$pollPlugin = $this->plugin(PollPlugin::class);
			$extraData['poll'] = $pollPlugin->getPollInput();
		}

		$draftPlugin = $this->plugin(DraftPlugin::class);
		return $draftPlugin->actionDraftMessage($group->draft_discussion, $extraData);
	}

	/**
	 * @param Group $group
	 *
	 * @return CreatorService
	 */
	protected function setupDiscussionCreate(
		Group $group
	): CreatorService
	{
		$title = $this->filter('title', InputFilterer::STRING);
		$message = $this->plugin(EditorPlugin::class)->fromInput('message');

		$creator = \XF::app()->service(CreatorService::class, $group);

		$creator->setContent($title, $message);

		if ($group->canEditTags())
		{
			$creator->setTags($this->filter('tags', InputFilterer::STRING));
		}

		if ($group->canUploadAndManageAttachments())
		{
			$creator->setAttachmentHash($this->filter('attachment_hash', InputFilterer::STRING));
		}

		$setOptions = $this->filter('_xfSet', 'array-bool');
		if ($setOptions)
		{
			$discussion = $creator->getDiscussion();

			if (isset($setOptions['discussion_open']) && $discussion->canLockUnlock())
			{
				$creator->setDiscussionOpen($this->filter('discussion_open', InputFilterer::BOOLEAN));
			}
			if (isset($setOptions['sticky']) && $discussion->canStickUnstick())
			{
				$creator->setSticky($this->filter('sticky', InputFilterer::BOOLEAN));
			}
		}

		$pollQuestion = $this->filter('poll.question', InputFilterer::STRING);
		if ($group->canCreatePoll() && strlen($pollQuestion))
		{
			$pollCreator = $this->plugin(PollPlugin::class)
				->setupPollCreate('dbtech_social_discussion', $creator->getDiscussion())
			;
			$creator->setPollCreator($pollCreator);
		}

		return $creator;
	}

	/**
	 * @param CreatorService $creator
	 *
	 * @throws PrintableException|DeadlockException
	 */
	protected function finalizeDiscussionCreate(CreatorService $creator): void
	{
		$creator->sendNotifications();

		$group = $creator->getGroup();
		$discussion = $creator->getDiscussion();
		$visitor = \XF::visitor();

		$setOptions = $this->filter('_xfSet', 'array-bool');
		if ($discussion->canWatch())
		{
			if (isset($setOptions['watch_discussion']))
			{
				$watch = $this->filter('watch_discussion', InputFilterer::BOOLEAN);
				if ($watch)
				{
					$state = $this->filter('watch_discussion_email', InputFilterer::BOOLEAN)
						? 'watch_email' : 'watch_no_email'
					;
					\XF::app()->repository(DiscussionWatchRepository::class)
						->setWatchState($discussion, $visitor, $state)
					;
				}
			}
			else
			{
				// use user preferences
				\XF::app()->repository(DiscussionWatchRepository::class)
					->autoWatchDiscussion($discussion, $visitor, true)
				;
			}
		}

		if ($visitor->user_id)
		{
			\XF::app()->repository(DiscussionRepository::class)->markDiscussionReadByVisitor($discussion, $discussion->message_date);

			$group->draft_discussion->delete();

			if ($discussion->discussion_state == 'moderated')
			{
				$this->session()->setHasContentPendingApproval();
			}
		}
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws DeadlockException
	 * @throws ReplyException
	 * @throws PrintableException
	 */
	public function actionStartDiscussion(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id'], ['DraftDiscussions|' . \XF::visitor()->user_id]);
		if (!$group->canStartDiscussion($error))
		{
			return $this->noPermission($error);
		}

		$this->assertCanonicalUrl($this->buildLink('dbtech-social/start-discussion', $group));

		$switches = $this->filter([
			'inline-mode' => InputFilterer::BOOLEAN,
			'more-options' => InputFilterer::BOOLEAN,
		]);
		if ($switches['more-options'])
		{
			$switches['inline-mode'] = false;
		}

		$discussion = null;
		$message = null;

		if ($this->isPost())
		{
			if (!$this->captchaIsValid())
			{
				return $this->error(\XF::phrase('did_not_complete_the_captcha_verification_properly'));
			}

			$creator = $this->setupDiscussionCreate($group);

			if ($switches['more-options'])
			{
				$discussion = $creator->getDiscussion();
				$message = $creator->getMessage();
			}
			else
			{
				$creator->checkForSpam();

				if (!$creator->validate($errors))
				{
					return $this->error($errors);
				}
				$this->assertNotFlooding(
					'dbtech_social_discussion',
					\XF::app()->options()->floodCheckLengthDiscussion ?: null
				);

				/** @var Discussion $discussion */
				$discussion = $creator->save();
				$this->finalizeDiscussionCreate($creator);

				if ($switches['inline-mode'])
				{
					$viewParams = [
						'discussion' => $discussion,
						'group' => $group,
						'inlineMode' => true,
					];
					return $this->view(
						View\Group\DiscussionItemView::class,
						'dbtech_social_groups_discussion_list_item',
						$viewParams
					);
				}
				else if (!$discussion->canView())
				{
					return $this->redirect($this->buildLink('dbtech-social/discussions/list', $group, ['pending_approval' => 1]));
				}
				else
				{
					return $this->redirect($this->buildLink('dbtech-social/discussions', $discussion));
				}
			}
		}

		if ($group->canUploadAndManageAttachments())
		{
			$attachmentData = \XF::app()->repository(AttachmentRepository::class)
				->getEditorData(
					'dbtech_social_message',
					$group,
					$group->draft_discussion['attachment_hash']
				)
			;
		}
		else
		{
			$attachmentData = null;
		}

		$templateName = $switches['inline-mode']
			? 'dbtech_social_groups_group_start_quick_discussion' : 'dbtech_social_groups_group_start_discussion'
		;

		if (!$discussion)
		{
			$discussion = $group->getNewDiscussion();
		}

		$viewParams = [
			'group' => $group,
			'discussion' => $discussion ?: $group->getNewDiscussion(),
			'message' => $message ?: null,
			'title' => $this->filter('title', InputFilterer::STRING),

			'attachmentData' => $attachmentData,
			'inlineMode' => $switches['inline-mode'],
		];
		return $this->view(
			View\Group\StartDiscussionView::class,
			$templateName,
			$viewParams
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionDiscussionPreview(ParameterBag $params): AbstractReply
	{
		$this->assertPostOnly();

		$group = $this->assertViewableGroup($params['group_id']);
		if (!$group->canStartDiscussion($error))
		{
			return $this->noPermission($error);
		}

		$creator = $this->setupDiscussionCreate($group);
		if (!$creator->validate($errors))
		{
			return $this->error($errors);
		}

		$discussion = $creator->getDiscussion();
		$message = $creator->getMessage();
		$attachments = null;

		$tempHash = $this->filter('attachment_hash', InputFilterer::STRING);
		if ($tempHash && $discussion->Group->canUploadAndManageAttachments())
		{
			$attachments = \XF::app()->repository(AttachmentRepository::class)
				->findAttachmentsByTempHash($tempHash)
				->fetch()
			;
		}

		return $this->plugin(BbCodePreviewPlugin::class)->actionPreview(
			$message->message,
			'dbtech_social_message',
			$message->User,
			$attachments,
			$discussion->canViewAttachments()
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws DeadlockException
	 * @throws ReplyException
	 */
	public function actionMarkRead(ParameterBag $params): AbstractReply
	{
		$visitor = \XF::visitor();
		if (!$visitor->user_id)
		{
			return $this->noPermission();
		}

		$markDate = $this->filter('date', InputFilterer::UNSIGNED);
		if (!$markDate)
		{
			$markDate = \XF::$time;
		}

		$groupRepo = \XF::app()->repository(GroupRepository::class);

		if ($params['group_id'])
		{
			$group = $this->assertViewableGroup($params['group_id']);
		}
		else
		{
			$group = null;
		}

		if ($this->isPost())
		{
			if ($group)
			{
				$groupRepo->markGroupReadByVisitor($group, $markDate);

				return $this->redirect(
					$this->buildLink('dbtech-social/discussions/list', $group),
					\XF::phrase('dbtech_social_groups_group_x_marked_as_read', ['group' => $group->title])
				);
			}
			else
			{
				$groupRepo->markAllGroupsReadByVisitor($markDate);

				return $this->redirect(
					$this->buildLink('dbtech-social'),
					\XF::phrase('dbtech_social_groups_all_groups_marked_as_read')
				);
			}
		}
		else
		{
			$viewParams = [
				'group' => $group,
				'date' => $markDate,
			];
			return $this->view(
				View\Group\MarkReadView::class,
				'dbtech_social_groups_group_mark_read',
				$viewParams
			);
		}
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 * @throws PrintableException
	 */
	public function actionWatch(ParameterBag $params): AbstractReply
	{
		$visitor = \XF::visitor();
		if (!$visitor->user_id)
		{
			return $this->noPermission();
		}

		$group = $this->assertViewableGroup($params['group_id']);
		if (!$group->canWatch($error))
		{
			return $this->noPermission($error);
		}

		if ($this->isPost())
		{
			if ($this->filter('stop', InputFilterer::BOOLEAN))
			{
				$notifyType = 'delete';
			}
			else
			{
				$notifyType = $this->filter('notify', InputFilterer::STRING);
				if ($notifyType != 'discussion' && $notifyType != 'message')
				{
					$notifyType = '';
				}

				if ($group->allowed_watch_notifications == 'none')
				{
					$notifyType = '';
				}
				else if ($group->allowed_watch_notifications == 'discussion' && $notifyType == 'message')
				{
					$notifyType = 'discussion';
				}
			}

			$sendAlert = $this->filter('send_alert', InputFilterer::BOOLEAN);
			$sendEmail = $this->filter('send_email', InputFilterer::BOOLEAN);

			\XF::app()->repository(GroupWatchRepository::class)
				->setWatchState($group, $visitor, $notifyType, $sendAlert, $sendEmail)
			;

			$redirect = $this->redirect($this->buildLink('dbtech-social/discussions/list', $group));
			$redirect->setJsonParam('switchKey', $notifyType == 'delete' ? 'watch' : 'unwatch');
			return $redirect;
		}
		else
		{
			$viewParams = [
				'group' => $group,
				'isWatched' => !empty($group->Watch[$visitor->user_id]),
			];
			return $this->view(
				View\Group\WatchView::class,
				'dbtech_social_groups_group_watch',
				$viewParams
			);
		}
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionReport(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);
		if (!$group->canReport($error))
		{
			return $this->noPermission($error);
		}

		$reportPlugin = $this->plugin(ReportPlugin::class);
		return $reportPlugin->actionReport(
			'dbtech_social_group',
			$group,
			$this->buildLink('dbtech-social/report', $group),
			$this->buildLink('dbtech-social', $group)
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionShare(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);

		$sharePlugin = $this->plugin(SharePlugin::class);
		return $sharePlugin->actionTooltipWithEmbed(
			$this->buildLink('canonical:dbtech-social', $group),
			\XF::phrase('dbtech_social_groups_group_x', ['title' => $group->title]),
			\XF::phrase('dbtech_social_groups_share_this_group'),
			null,
			$group->getEmbedCodeHtml()
		);
	}

	/**
	 * @param Group|null $group
	 *
	 * @return AbstractReply
	 */
	protected function getGroupRss(?Group $group = null): AbstractReply
	{
		$limit = \XF::app()->options()->discussionsPerPage;

		$discussionRepo = \XF::app()->repository(DiscussionRepository::class);
		$discussionList = $discussionRepo->findDiscussionsForRssFeed($group)->limit($limit * 3);

		$order = $this->filter('order', InputFilterer::STRING);
		switch ($order)
		{
			case 'message_date':
				break;

			default:
				$order = 'last_message_date';
				break;
		}
		$discussionList->order($order, 'DESC');

		$discussions = $discussionList->fetch()->filterViewable()->slice(0, $limit);

		return $this->view(
			View\Group\RssView::class,
			'',
			['group' => $group, 'discussions' => $discussions]
		);
	}

	/**
	 * @param Section|null $section
	 *
	 * @return AbstractReply
	 */
	protected function getSectionRss(?Section $section = null): AbstractReply
	{
		$limit = \XF::app()->options()->discussionsPerPage;

		$discussionRepo = \XF::app()->repository(DiscussionRepository::class);
		$discussionList = $discussionRepo->findDiscussionsForSectionRssFeed($section)->limit($limit * 3);

		$order = $this->filter('order', InputFilterer::STRING);
		switch ($order)
		{
			case 'message_date':
				break;

			default:
				$order = 'last_message_date';
				break;
		}
		$discussionList->order($order, 'DESC');

		$discussions = $discussionList->fetch()->filterViewable()->slice(0, $limit);

		return $this->view(
			View\Section\RssView::class,
			'',
			['section' => $section, 'discussions' => $discussions]
		);
	}

	/**
	 * @param Group $group
	 * @param array                             $filters
	 *
	 * @return array [order, direction]
	 */
	protected function getEffectiveSortInfo(Group $group, array $filters): array
	{
		$sortInfo = [
			'order' => $group->default_sort_order,
			'direction' => $group->default_sort_direction,
		];

		if (isset($filters['order']))
		{
			$sortInfo['order'] = $filters['order'];
		}

		if (isset($filters['direction']))
		{
			$sortInfo['direction'] = $filters['direction'];
		}

		return $sortInfo;
	}

	/**
	 * @param array $activities
	 *
	 * @return array
	 */
	public static function getActivityDetails(array $activities): array
	{
		return self::getActivityDetailsForContent(
			$activities,
			\XF::phrase('dbtech_social_groups_viewing_group'),
			'group_id',
			function (array $ids): array
			{
				/** @var AbstractCollection<Group> $groups */
				$groups = \XF::app()->em()->findByIds(
					Group::class,
					$ids,
					['Permissions|' . \XF::visitor()->permission_combination_id]
				);

				$router = \XF::app()->router('public');
				$data = [];

				/** @var Group $group */
				foreach ($groups->filterViewable() AS $id => $group)
				{
					$data[$id] = [
						'title' => $group->title,
						'url' => $router->buildLink('dbtech-social', $group),
					];
				}

				return $data;
			},
			\XF::phrase('dbtech_social_groups_viewing_groups')
		);
	}

	public static function getResolvableActions(): array
	{
		return ['index', 'group'];
	}

	/**
	 * @param ParameterBag $params
	 * @param RouteMatch $routeMatch
	 *
	 * @return Group|null
	 */
	public static function resolveToEmbeddableContent(ParameterBag $params, RouteMatch $routeMatch): ?Group
	{
		$content = null;

		if ($params['group_id'])
		{
			$content = \XF::em()->find(Group::class, $params['group_id']);
		}

		if (!$content || !$content->canView())
		{
			$content = null;
		}

		return $content;
	}
}