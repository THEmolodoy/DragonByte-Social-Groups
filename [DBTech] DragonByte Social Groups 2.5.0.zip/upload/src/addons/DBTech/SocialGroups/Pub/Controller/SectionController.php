<?php

namespace DBTech\SocialGroups\Pub\Controller;

use DBTech\SocialGroups\ControllerPlugin\SectionPlugin;
use DBTech\SocialGroups\Entity\Discussion;
use DBTech\SocialGroups\Entity\Section;
use DBTech\SocialGroups\Pub\View;
use DBTech\SocialGroups\Repository\DiscussionRepository;
use DBTech\SocialGroups\Repository\DiscussionWatchRepository;
use DBTech\SocialGroups\Repository\SectionRepository;
use DBTech\SocialGroups\Repository\SectionWatchRepository;
use DBTech\SocialGroups\Service\Discussion\CreatorService;
use XF\Behavior\TreeStructured;
use XF\ControllerPlugin\BbCodePreviewPlugin;
use XF\ControllerPlugin\BookmarkPlugin;
use XF\ControllerPlugin\DraftPlugin;
use XF\ControllerPlugin\EditorPlugin;
use XF\ControllerPlugin\PollPlugin;
use XF\Db\DeadlockException;
use XF\Entity\User;
use XF\InputFilterer;
use XF\Mvc\FormAction;
use XF\Mvc\ParameterBag;
use XF\Mvc\Reply\AbstractReply;
use XF\Mvc\Reply\Exception as ReplyException;
use XF\PrintableException;
use XF\Repository\AttachmentRepository;

use function intval, strlen;

class SectionController extends AbstractGroupController
{
	/**
	 * @param $action
	 * @param ParameterBag $params
	 *
	 * @return void
	 * @throws ReplyException
	 */
	protected function preDispatchController($action, ParameterBag $params): void
	{
		parent::preDispatchController($action, $params);

		if (!\XF::app()->options()->dbtechSocialGroupsEnableSections)
		{
			throw $this->exception($this->notFound());
		}
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 */
	public function actionIndex(ParameterBag $params): AbstractReply
	{
		return $this->rerouteController(GroupController::class, 'Discussions', $params);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionManage(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);
		if (!$group->canManageSections())
		{
			return $this->noPermission();
		}

		$sectionRepo = \XF::app()->repository(SectionRepository::class);
		$sectionTree = $sectionRepo->createSectionTree($sectionRepo->findSectionsInGroup($group)->fetch());

		$viewParams = [
			'group' => $group,
			'sectionTree' => $sectionTree,
		];
		return $this->view(
			View\Section\ManageView::class,
			'dbtech_social_groups_section_manage',
			$viewParams
		);
	}

	/**
	 * @param Section $section
	 *
	 * @return AbstractReply
	 */
	protected function sectionAddEdit(Section $section): AbstractReply
	{
		$sectionRepo = \XF::app()->repository(SectionRepository::class);
		$sectionTree = $sectionRepo->createSectionTree($sectionRepo->findSectionsInGroup($section->Group)->fetch());

		$viewParams = [
			'section' => $section,
			'group' => $section->Group,
			'sectionTree' => $sectionTree,
		];
		return $this->view(
			View\Section\EditView::class,
			'dbtech_social_groups_section_edit',
			$viewParams
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionAdd(ParameterBag $params): AbstractReply
	{
		$group = $this->assertGroupExists($params['group_id']);
		if (!$group->canManageSections())
		{
			return $this->noPermission();
		}

		if (!$group->canAddSection($error))
		{
			return $this->noPermission($error);
		}

		$section = \XF::app()->em()->create(Section::class);
		$section->hydrateRelation('Group', $group);

		if ($group->canAddNestedSection())
		{
			$section->parent_section_id = $this->filter('parent_section_id', InputFilterer::UNSIGNED);
		}

		if (empty($section->parent_section_id))
		{
			$section->display_order = intval(\XF::app()->db()->fetchOne('
				SELECT MAX(`display_order`) 
				FROM `xf_dbtech_social_groups_section` 
				WHERE `group_id` = ?
			', $group->group_id)) + 10;
		}

		return $this->sectionAddEdit($section);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionEdit(ParameterBag $params): AbstractReply
	{
		$group = $this->assertGroupExists($params['group_id']);
		if (!$group->canManageSections())
		{
			return $this->noPermission();
		}

		$section = $this->assertSectionExists($this->filter('section_id', InputFilterer::UNSIGNED));
		return $this->sectionAddEdit($section);
	}

	/**
	 * @param Section $section
	 *
	 * @return FormAction
	 */
	protected function sectionSaveProcess(Section $section): FormAction
	{
		$form = $this->formAction();

		$input = $this->filter([
			'title' => InputFilterer::STRING,
			'description' => InputFilterer::STRING,
			'display_order' => InputFilterer::UNSIGNED,

			'staff_only' => InputFilterer::BOOLEAN,
			'allow_posting' => InputFilterer::BOOLEAN,
			'allow_discussions' => InputFilterer::BOOLEAN,
			'allow_poll' => InputFilterer::BOOLEAN,
			'find_new' => InputFilterer::BOOLEAN,
			//			'default_prefix_id' => InputFilterer::UNSIGNED,
			//			'require_prefix' => InputFilterer::BOOLEAN,
		]);

		if (!$section->Group->canAddNestedSection())
		{
			if (!$section->exists())
			{
				$input['parent_section_id'] = 0;
			}
		}
		else
		{
			$input['parent_section_id'] = $this->filter('parent_section_id', InputFilterer::UNSIGNED);
		}

		if (!(\XF::app()->options()->dbtechSocialEnabledGroupOwnerFeatures['moderation'] ?? true))
		{
			if (!$section->exists())
			{
				$input['moderate_discussions'] = false;
				$input['moderate_replies'] = false;
			}
		}
		else
		{
			$input['moderate_discussions'] = $this->filter('moderate_discussions', InputFilterer::BOOLEAN);
			$input['moderate_replies'] = $this->filter('moderate_replies', InputFilterer::BOOLEAN);
		}

		if (!(\XF::app()->options()->dbtechSocialEnabledGroupOwnerFeatures['allowed_watch_notifications'] ?? true))
		{
			if (!$section->exists())
			{
				$input['allowed_watch_notifications'] = 'all';
			}
		}
		else
		{
			$input['allowed_watch_notifications'] = $this->filter('allowed_watch_notifications', InputFilterer::STRING);
		}

		if (!(\XF::app()->options()->dbtechSocialEnabledGroupOwnerFeatures['min_tags'] ?? true))
		{
			if (!$section->exists())
			{
				$input['min_tags'] = 0;
			}
		}
		else
		{
			$input['min_tags'] = $this->filter('min_tags', InputFilterer::UNSIGNED);
		}

		if (!(\XF::app()->options()->dbtechSocialEnabledGroupOwnerFeatures['default_sort'] ?? true))
		{
			if (!$section->exists())
			{
				$input['default_sort_order'] = 'last_message_date';
				$input['default_sort_direction'] = 'desc';
			}
		}
		else
		{
			$input['default_sort_order'] = $this->filter('default_sort_order', InputFilterer::STRING);
			$input['default_sort_direction'] = $this->filter('default_sort_direction', InputFilterer::STRING);
		}

		if (!(\XF::app()->options()->dbtechSocialEnabledGroupOwnerFeatures['list_date_limit_days'] ?? true))
		{
			if (!$section->exists())
			{
				$input['list_date_limit_days'] = 0;
			}
		}
		else
		{
			$input['list_date_limit_days'] = $this->filter('list_date_limit_days', InputFilterer::UNSIGNED);
		}

		$form->basicEntitySave($section, $input);

		return $form;
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 * @throws PrintableException
	 */
	public function actionSave(ParameterBag $params): AbstractReply
	{
		$group = $this->assertGroupExists($params['group_id']);
		if (!$group->canManageSections())
		{
			return $this->noPermission();
		}

		$sectionId = $this->filter('section_id', InputFilterer::UNSIGNED);
		if ($sectionId)
		{
			$section = $this->assertSectionExists($sectionId);
		}
		else
		{
			if (!$group->canAddSection($error))
			{
				return $this->noPermission($error);
			}

			$section = \XF::app()->em()->create(Section::class);
			$section->group_id = $group->group_id;

			$section->hydrateRelation('Group', $group);
		}

		$this->sectionSaveProcess($section)->run();

		return $this->redirect($this->buildLink('dbtech-social/sections/manage', $group) . $this->buildLinkHash($section->section_id));
	}

	/**
	 * @param Section $section
	 *
	 * @return void
	 * @throws PrintableException
	 */
	protected function sectionDelete(Section $section): void
	{
		$section->delete();
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 * @throws PrintableException
	 */
	public function actionDelete(ParameterBag $params): AbstractReply
	{
		$group = $this->assertGroupExists($params['group_id']);
		if (!$group->canManageSections())
		{
			return $this->noPermission();
		}

		$section = $this->assertSectionExists($this->filter('section_id', InputFilterer::UNSIGNED));

		if (!$section->preDelete())
		{
			return $this->error($section->getErrors());
		}

		if ($this->isPost())
		{
			$childAction = $this->filter('child_sections_action', InputFilterer::STRING);
			$section->getBehavior(TreeStructured::class)->setOption('deleteChildAction', $childAction);

			$this->sectionDelete($section);
			return $this->redirect($this->buildLink('dbtech-social/sections/manage', $group));
		}

		$sectionRepo = \XF::app()->repository(SectionRepository::class);

		$sectionTree = $sectionRepo->createSectionTree($sectionRepo->findSectionsInGroup($section->Group)->fetch());
		$sectionTree = $sectionTree->filter(function ($sectionId) use ($section)
		{
			// Filter out the current section from the section tree.
			return !($sectionId == $section->section_id);
		});

		$viewParams = [
			'group' => $group,
			'section' => $section,
			'sectionTree' => $sectionTree,
		];
		return $this->view(
			View\Section\DeleteView::class,
			'dbtech_social_groups_section_delete',
			$viewParams
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionFilters(ParameterBag $params): AbstractReply
	{
		$section = $this->assertViewableSection($params['section_id']);

		$filters = $this->plugin(SectionPlugin::class)->getSectionFilterInput($section);

		if ($this->filter('apply', InputFilterer::BOOLEAN))
		{
			if (!empty($filters['last_days']))
			{
				unset($filters['no_date_limit']);
			}
			return $this->redirect($this->buildLink('dbtech-social/sections', $section, $filters));
		}

		if (!empty($filters['starter_id']))
		{
			$starterFilter = \XF::app()->em()->find(User::class, $filters['starter_id']);
		}
		else
		{
			$starterFilter = null;
		}

		$viewParams = [
			'section' => $section,
			//			'prefixes' => $section->prefixes->groupBy('prefix_group_id'),
			'filters' => $filters,
			'starterFilter' => $starterFilter,
		];
		return $this->view(
			View\Section\FiltersView::class,
			'dbtech_social_groups_section_filters',
			$viewParams
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionDraft(ParameterBag $params): AbstractReply
	{
		$this->assertPostOnly();

		$section = $this->assertViewableSection($params['section_id']);

		$creator = $this->setupDiscussionCreate($section);
		$discussion = $creator->getDiscussion();

		$extraData = [
			'title' => $discussion->title,
			'tags' => $this->filter('tags', InputFilterer::STRING),
			'attachment_hash' => $this->filter('attachment_hash', InputFilterer::STRING),
		];
		if ($section->canCreatePoll() && $this->filter('poll.question', InputFilterer::STRING))
		{
			$pollPlugin = $this->plugin(PollPlugin::class);
			$extraData['poll'] = $pollPlugin->getPollInput();
		}

		$draftPlugin = $this->plugin(DraftPlugin::class);
		return $draftPlugin->actionDraftMessage($section->draft_discussion, $extraData);
	}

	/**
	 * @param Section $section
	 *
	 * @return CreatorService
	 */
	protected function setupDiscussionCreate(
		Section $section
	): CreatorService
	{
		$title = $this->filter('title', InputFilterer::STRING);
		$message = $this->plugin(EditorPlugin::class)->fromInput('message');

		$creator = \XF::app()->service(CreatorService::class, $section->Group, $section);
		$creator->setContent($title, $message);

		if ($section->canUploadAndManageAttachments())
		{
			$creator->setAttachmentHash($this->filter('attachment_hash', InputFilterer::STRING));
		}

		$setOptions = $this->filter('_xfSet', 'array-bool');
		if ($setOptions)
		{
			$discussion = $creator->getDiscussion();

			if (isset($setOptions['discussion_open']) && $discussion->canLockUnlock())
			{
				$creator->setDiscussionOpen($this->filter('discussion_open', InputFilterer::BOOLEAN));
			}
			if (isset($setOptions['sticky']) && $discussion->canStickUnstick())
			{
				$creator->setSticky($this->filter('sticky', InputFilterer::BOOLEAN));
			}
		}

		$pollQuestion = $this->filter('poll.question', InputFilterer::STRING);
		if ($section->canCreatePoll() && strlen($pollQuestion))
		{
			$pollCreator = $this->plugin(PollPlugin::class)
				->setupPollCreate('dbtech_social_discussion', $creator->getDiscussion())
			;
			$creator->setPollCreator($pollCreator);
		}

		return $creator;
	}



	/**
	 * @param CreatorService $creator
	 *
	 * @throws PrintableException|DeadlockException
	 */
	protected function finalizeDiscussionCreate(CreatorService $creator): void
	{
		$creator->sendNotifications();

		$section = $creator->getSection();
		$discussion = $creator->getDiscussion();
		$visitor = \XF::visitor();

		$setOptions = $this->filter('_xfSet', 'array-bool');
		if ($discussion->canWatch())
		{
			if (isset($setOptions['watch_discussion']))
			{
				$watch = $this->filter('watch_discussion', InputFilterer::BOOLEAN);
				if ($watch)
				{
					$state = $this->filter('watch_discussion_email', InputFilterer::BOOLEAN)
						? 'watch_email' : 'watch_no_email'
					;
					\XF::app()->repository(DiscussionWatchRepository::class)
						->setWatchState($discussion, $visitor, $state)
					;
				}
			}
			else
			{
				// use user preferences
				\XF::app()->repository(DiscussionWatchRepository::class)
					->autoWatchDiscussion($discussion, $visitor, true)
				;
			}
		}

		if ($visitor->user_id)
		{
			\XF::app()->repository(DiscussionRepository::class)->markDiscussionReadByVisitor($discussion, $discussion->message_date);

			$section->draft_discussion->delete();

			if ($discussion->discussion_state == 'moderated')
			{
				$this->session()->setHasContentPendingApproval();
			}
		}
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws DeadlockException
	 * @throws ReplyException
	 * @throws PrintableException
	 */
	public function actionStartDiscussion(ParameterBag $params): AbstractReply
	{
		$section = $this->assertViewableSection($params['section_id'], ['DraftDiscussions|' . \XF::visitor()->user_id]);
		if (!$section->canStartDiscussion($error))
		{
			return $this->noPermission($error);
		}

		$this->assertCanonicalUrl($this->buildLink('dbtech-social/sections/start-discussion', $section));

		$switches = $this->filter([
			'inline-mode' => InputFilterer::BOOLEAN,
			'more-options' => InputFilterer::BOOLEAN,
		]);
		if ($switches['more-options'])
		{
			$switches['inline-mode'] = false;
		}

		$discussion = null;
		$message = null;

		if ($this->isPost())
		{
			if (!$this->captchaIsValid())
			{
				return $this->error(\XF::phrase('did_not_complete_the_captcha_verification_properly'));
			}

			$creator = $this->setupDiscussionCreate($section);

			if ($switches['more-options'])
			{
				$discussion = $creator->getDiscussion();
				$message = $creator->getMessage();
			}
			else
			{
				$creator->checkForSpam();

				if (!$creator->validate($errors))
				{
					return $this->error($errors);
				}
				$this->assertNotFlooding(
					'dbtech_social_discussion',
					\XF::app()->options()->floodCheckLengthDiscussion ?: null
				);

				/** @var Discussion $discussion */
				$discussion = $creator->save();
				$this->finalizeDiscussionCreate($creator);

				if ($switches['inline-mode'])
				{
					$viewParams = [
						'discussion' => $discussion,
						'section' => $section,
						'inlineMode' => true,
					];
					return $this->view(
						View\Section\DiscussionItemView::class,
						'dbtech_social_groups_discussion_list_item',
						$viewParams
					);
				}
				else if (!$discussion->canView())
				{
					return $this->redirect($this->buildLink('dbtech-social/sections', $section, ['pending_approval' => 1]));
				}
				else
				{
					return $this->redirect($this->buildLink('dbtech-social/discussions', $discussion));
				}
			}
		}

		if ($section->canUploadAndManageAttachments())
		{
			$attachmentData = \XF::app()->repository(AttachmentRepository::class)
				->getEditorData(
					'dbtech_social_message',
					$section,
					$section->draft_discussion['attachment_hash']
				)
			;
		}
		else
		{
			$attachmentData = null;
		}

		$templateName = $switches['inline-mode']
			? 'dbtech_social_groups_section_start_quick_discussion' : 'dbtech_social_groups_section_start_discussion'
		;

		if (!$discussion)
		{
			$discussion = $section->getNewDiscussion();
		}

		$viewParams = [
			'section' => $section,
			'discussion' => $discussion ?: $section->getNewDiscussion(),
			'message' => $message ?: null,
			'title' => $this->filter('title', InputFilterer::STRING),

			'attachmentData' => $attachmentData,
			'inlineMode' => $switches['inline-mode'],
		];
		return $this->view(
			View\Section\StartDiscussionView::class,
			$templateName,
			$viewParams
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionDiscussionPreview(ParameterBag $params): AbstractReply
	{
		$this->assertPostOnly();

		$section = $this->assertViewableSection($params['section_id']);
		if (!$section->canStartDiscussion($error))
		{
			return $this->noPermission($error);
		}

		$creator = $this->setupDiscussionCreate($section);
		if (!$creator->validate($errors))
		{
			return $this->error($errors);
		}

		$discussion = $creator->getDiscussion();
		$message = $creator->getMessage();
		$attachments = null;

		$tempHash = $this->filter('attachment_hash', InputFilterer::STRING);
		if ($tempHash && $discussion->Group->canUploadAndManageAttachments())
		{
			$attachments = \XF::app()->repository(AttachmentRepository::class)
				->findAttachmentsByTempHash($tempHash)
				->fetch()
			;
		}

		return $this->plugin(BbCodePreviewPlugin::class)->actionPreview(
			$message->message,
			'dbtech_social_message',
			$message->User,
			$attachments,
			$discussion->canViewAttachments()
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionBookmark(ParameterBag $params): AbstractReply
	{
		$section = $this->assertViewableSection($params['section_id']);

		$bookmarkPlugin = $this->plugin(BookmarkPlugin::class);
		return $bookmarkPlugin->actionBookmark(
			$section,
			$this->buildLink('dbtech-social/sections/bookmark', $section)
		);
	}


	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 * @throws PrintableException
	 */
	public function actionWatch(ParameterBag $params): AbstractReply
	{
		$visitor = \XF::visitor();
		if (!$visitor->user_id)
		{
			return $this->noPermission();
		}

		$section = $this->assertViewableSection($params['section_id']);
		if (!$section->canWatch($error))
		{
			return $this->noPermission($error);
		}

		if ($this->isPost())
		{
			if ($this->filter('stop', InputFilterer::BOOLEAN))
			{
				$notifyType = 'delete';
			}
			else
			{
				$notifyType = $this->filter('notify', InputFilterer::STRING);
				if ($notifyType != 'discussion' && $notifyType != 'message')
				{
					$notifyType = '';
				}

				if ($section->allowed_watch_notifications == 'none')
				{
					$notifyType = '';
				}
				else if ($section->allowed_watch_notifications == 'discussion' && $notifyType == 'message')
				{
					$notifyType = 'discussion';
				}
			}

			$sendAlert = $this->filter('send_alert', InputFilterer::BOOLEAN);
			$sendEmail = $this->filter('send_email', InputFilterer::BOOLEAN);

			\XF::app()->repository(SectionWatchRepository::class)
				->setWatchState($section, $visitor, $notifyType, $sendAlert, $sendEmail)
			;

			$redirect = $this->redirect($this->buildLink('dbtech-social/sections', $section));
			$redirect->setJsonParam('switchKey', $notifyType == 'delete' ? 'watch' : 'unwatch');
			return $redirect;
		}
		else
		{
			$viewParams = [
				'section' => $section,
				'isWatched' => !empty($section->Watch[$visitor->user_id]),
			];
			return $this->view(
				View\Section\WatchView::class,
				'dbtech_social_groups_section_watch',
				$viewParams
			);
		}
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws DeadlockException
	 * @throws ReplyException
	 */
	public function actionMarkRead(ParameterBag $params): AbstractReply
	{
		$visitor = \XF::visitor();
		if (!$visitor->user_id)
		{
			return $this->noPermission();
		}

		$markDate = $this->filter('date', InputFilterer::UNSIGNED);
		if (!$markDate)
		{
			$markDate = \XF::$time;
		}

		if (empty($params['section_id']))
		{
			return $this->notFound();
		}

		$section = $this->assertViewableSection($params['section_id']);

		if ($this->isPost())
		{
			$sectionRepo = \XF::app()->repository(SectionRepository::class);
			$sectionRepo->markSectionTreeReadByVisitor($section, $markDate);

			return $this->redirect(
				$this->buildLink('dbtech-social/sections', $section),
				\XF::phrase('dbtech_social_groups_section_x_marked_as_read', ['section' => $section->title])
			);
		}
		else
		{
			$viewParams = [
				'section' => $section,
				'date' => $markDate,
			];
			return $this->view(
				View\Section\MarkReadView::class,
				'dbtech_social_groups_section_mark_read',
				$viewParams
			);
		}
	}
}