<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\Pub\Controller;

use XF\Pub\Controller\AbstractWhatsNewFindType;

class WhatsNewMessageController extends AbstractWhatsNewFindType
{
	protected function getContentType()
	{
		// This returns threads, so we attach to the thread content type. However, as it's really individual posts
		// that generally bump things up, we refer to this in the interface as "new posts".
		return 'dbtech_social_discussion';
	}
}