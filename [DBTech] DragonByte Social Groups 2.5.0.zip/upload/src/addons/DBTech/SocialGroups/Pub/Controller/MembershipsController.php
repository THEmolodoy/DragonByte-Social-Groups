<?php

namespace DBTech\SocialGroups\Pub\Controller;

use DBTech\SocialGroups\ControllerPlugin\GroupInvitePlugin;
use DBTech\SocialGroups\Finder\GroupFinder;
use DBTech\SocialGroups\Finder\GroupMemberFinder;
use DBTech\SocialGroups\Pub\View;
use DBTech\SocialGroups\Repository\GroupInviteRepository;
use DBTech\SocialGroups\Repository\GroupMemberRepository;
use DBTech\SocialGroups\XF\Entity\User as ExtendedUserEntity;
use XF\Entity\User;
use XF\Mvc\ParameterBag;
use XF\Mvc\Reply\AbstractReply;
use XF\Mvc\Reply\Exception as ReplyException;
use XF\Phrase;
use XF\PrintableException;

class MembershipsController extends AbstractGroupController
{
	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 */
	public function actionIndex(ParameterBag $params): AbstractReply
	{
		if ($params['user_id'])
		{
			return $this->rerouteController(__CLASS__, 'Memberships', $params);
		}

		return $this->redirect($this->buildLink('dbtech-social'));
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws \InvalidArgumentException
	 * @throws ReplyException
	 */
	public function actionMemberships(ParameterBag $params): AbstractReply
	{
		/** @var ExtendedUserEntity $user */
		$user = $this->assertRecordExists(User::class, $params['user_id']);

		if (!$user->canViewFullProfile($error))
		{
			throw $this->exception($this->noPermission($error));
		}

		$finder = \XF::app()->repository(GroupMemberRepository::class)
			->getGroupMembershipsForUser($user)
			->with('Group.full')
			->with('Group.Moderators|' . $user->user_id)
		;
		$total = $finder->total();

		$page = $this->filterPage();
		$perPage = \XF::app()->options()->dbtechSocialGroupsPerPage;

		$this->assertValidPage($page, $perPage, $total, 'dbtech-social/memberships', $user);
		$this->assertCanonicalUrl($this->buildLink('dbtech-social/memberships', $user, ['page' => $page]));

		$groupMemberships = $finder->limitByPage($page, $perPage)->fetch();
		if ($user->user_id !== \XF::visitor()->user_id)
		{
			$groupMemberships = $groupMemberships->filterViewable();
			$joinRequests = \XF::app()->em()->getEmptyCollection();
		}
		else
		{
			$joinRequests = \XF::app()->finder(GroupMemberFinder::class)
				->where('user_id', $user->user_id)
				->where('member_state', 'moderated')
				->fetch()
			;
		}

		$viewParams = [
			'user' => $user,
			'groupMemberships' => $groupMemberships,
			'joinRequests' => $joinRequests,
			'page' => $page,
			'perPage' => $perPage,
			'total' => $total,
		];
		return $this->view(
			View\Memberships\ViewView::class,
			'dbtech_social_groups_membership_view',
			$viewParams
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws \InvalidArgumentException
	 * @throws ReplyException
	 */
	public function actionPending(ParameterBag $params): AbstractReply
	{
		/** @var ExtendedUserEntity $user */
		$user = $this->assertRecordExists(User::class, $params['user_id']);

		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		if ($visitor->user_id !== $user->user_id && !$visitor->canViewAnyDbtechSocialGroupLogs($error))
		{
			throw $this->exception($this->noPermission($error));
		}

		$finder = \XF::app()->repository(GroupMemberRepository::class)
			->getUnapprovedGroupMembershipsForUser($user)
			->with('Group.full')
			->with('Group.Moderators|' . $user->user_id)
		;
		$total = $finder->total();

		$page = $this->filterPage();
		$perPage = \XF::app()->options()->dbtechSocialGroupsPerPage;

		$this->assertValidPage($page, $perPage, $total, 'dbtech-social/memberships/pending', $user);
		$this->assertCanonicalUrl($this->buildLink('dbtech-social/memberships/pending', $user, ['page' => $page]));

		$groupMemberships = $finder->limitByPage($page, $perPage)->fetch();
		if ($user->user_id !== \XF::visitor()->user_id)
		{
			$groupMemberships = $groupMemberships->filterViewable();
		}

		$viewParams = [
			'user' => $user,
			'groupMemberships' => $groupMemberships,
			'page' => $page,
			'perPage' => $perPage,
			'total' => $total,
		];
		return $this->view(
			View\Memberships\PendingView::class,
			'dbtech_social_groups_membership_view_pending',
			$viewParams
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws \InvalidArgumentException
	 * @throws ReplyException
	 */
	public function actionBans(ParameterBag $params): AbstractReply
	{
		/** @var ExtendedUserEntity $user */
		$user = $this->assertRecordExists(User::class, $params['user_id']);

		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		if ($visitor->user_id !== $user->user_id && !$visitor->canViewAnyDbtechSocialGroupLogs($error))
		{
			throw $this->exception($this->noPermission());
		}

		$finder = \XF::app()->repository(GroupMemberRepository::class)
			->getBannedGroupMembershipsForUser($user)
			->with('Group.full')
			->with('Group.Moderators|' . $user->user_id)
		;
		$total = $finder->total();

		$page = $this->filterPage();
		$perPage = \XF::app()->options()->dbtechSocialGroupsPerPage;

		$this->assertValidPage($page, $perPage, $total, 'dbtech-social/memberships/bans', $user);
		$this->assertCanonicalUrl($this->buildLink('dbtech-social/memberships/bans', $user, ['page' => $page]));

		$groupMemberships = $finder->limitByPage($page, $perPage)->fetch();
		if ($user->user_id !== \XF::visitor()->user_id)
		{
			$groupMemberships = $groupMemberships->filterViewable();
		}

		$viewParams = [
			'user' => $user,
			'groupMemberships' => $groupMemberships,
			'page' => $page,
			'perPage' => $perPage,
			'total' => $total,
		];
		return $this->view(
			View\Memberships\BannedView::class,
			'dbtech_social_groups_membership_view_bans',
			$viewParams
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws \InvalidArgumentException
	 * @throws ReplyException
	 */
	public function actionOwned(ParameterBag $params): AbstractReply
	{
		/** @var ExtendedUserEntity $user */
		$user = $this->assertRecordExists(User::class, $params['user_id']);

		if (!$user->canViewFullProfile($error))
		{
			throw $this->exception($this->noPermission($error));
		}

		/** @var GroupFinder $finder */
		$finder = $user->getRelationFinder('OwnedSocialGroups');

		$finder->applyGlobalVisibilityChecks()
			->with('full')
		;
		$total = $finder->total();

		$page = $this->filterPage();
		$perPage = \XF::app()->options()->dbtechSocialGroupsPerPage;

		$this->assertValidPage($page, $perPage, $total, 'dbtech-social/memberships/owned', $user);
		$this->assertCanonicalUrl($this->buildLink('dbtech-social/memberships/owned', $user, ['page' => $page]));

		$groups = $finder->limitByPage($page, $perPage)->fetch();
		$groups = $groups->filterViewable();

		$viewParams = [
			'user' => $user,
			'groups' => $groups,
			'page' => $page,
			'perPage' => $perPage,
			'total' => $total,
		];
		return $this->view(
			View\Memberships\ViewOwnedView::class,
			'dbtech_social_groups_membership_owned_view',
			$viewParams
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws \InvalidArgumentException
	 * @throws ReplyException
	 */
	public function actionManaged(ParameterBag $params): AbstractReply
	{
		/** @var ExtendedUserEntity $user */
		$user = $this->assertRecordExists(User::class, $params['user_id']);

		if (!$user->canViewFullProfile($error))
		{
			throw $this->exception($this->noPermission($error));
		}

		$finder = \XF::app()->finder(GroupMemberFinder::class);

		$finder->applyGlobalGroupVisibilityChecks()
			->where('user_id', $user->user_id)
			->where('is_supervisor', true)
			->with('Group.full')
		;
		$total = $finder->total();

		$page = $this->filterPage();
		$perPage = \XF::app()->options()->dbtechSocialGroupsPerPage;

		$this->assertValidPage($page, $perPage, $total, 'dbtech-social/memberships/managed', $user);
		$this->assertCanonicalUrl($this->buildLink('dbtech-social/memberships/managed', $user, ['page' => $page]));

		$memberships = $finder->limitByPage($page, $perPage)->fetch();
		$memberships = $memberships->filterViewable();

		$viewParams = [
			'user' => $user,
			'memberships' => $memberships,
			'page' => $page,
			'perPage' => $perPage,
			'total' => $total,
		];
		return $this->view(
			View\Memberships\ViewManagedView::class,
			'dbtech_social_groups_membership_managed_view',
			$viewParams
		);
	}

	/**
	 * @return AbstractReply
	 * @throws \InvalidArgumentException
	 * @throws ReplyException
	 */
	public function actionInvitations(): AbstractReply
	{
		$this->assertRegistrationRequired();

		$this->assertCanonicalUrl($this->buildLink('dbtech-social/memberships/invitations'));

		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		$invitations = \XF::app()->repository(GroupInviteRepository::class)->findGroupInvitesForUser($visitor)
			->isValidGroup()
			->with('Group.full')
			->fetch()
			->filterViewable()
		;

		$viewParams = [
			'invitations' => $invitations,
		];
		return $this->view(
			View\Memberships\InvitationsView::class,
			'dbtech_social_groups_membership_invitations',
			$viewParams
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 * @throws PrintableException
	 */
	public function actionRejectInvite(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);

		/** @var GroupInvitePlugin $plugin */
		$plugin = $this->plugin(GroupInvitePlugin::class);
		return $plugin->actionReject(
			$group,
			$this->buildLink('dbtech-social/memberships/reject-invite', $group),
			$this->buildLink('dbtech-social', $group),
			$this->getDynamicRedirect($this->buildLink('dbtech-social', $group)),
			$group->title
		);
	}

	/**
	 * @param array $activities
	 *
	 * @return array|Phrase
	 */
	public static function getActivityDetails(array $activities): Phrase|array
	{
		$userIds = [];
		$userData = [];

		$router = \XF::app()->router('public');
		$defaultPhrase = \XF::phrase('dbtech_social_groups_viewing_group_membership_profile');

		if (!\XF::visitor()->hasPermission('general', 'viewProfile'))
		{
			return $defaultPhrase;
		}

		foreach ($activities AS $activity)
		{
			$userId = $activity->pluckParam('user_id');
			if ($userId)
			{
				$userIds[$userId] = $userId;
			}
		}

		if ($userIds)
		{
			$users = \XF::app()->em()->findByIds(User::class, $userIds, ['Privacy']);
			foreach ($users AS $user)
			{
				$userData[$user->user_id] = [
					'username' => $user->username,
					'url' => $router->buildLink('members', $user),
				];
			}
		}

		$output = [];

		foreach ($activities AS $key => $activity)
		{
			$userId = $activity->pluckParam('user_id');
			$user = $userId && isset($userData[$userId]) ? $userData[$userId] : null;
			if ($user)
			{
				$output[$key] = [
					'description' => \XF::phrase('dbtech_social_groups_viewing_group_membership_profile'),
					'title' => $user['username'],
					'url' => $user['url'],
				];
			}
			else
			{
				$output[$key] = $defaultPhrase;
			}
		}

		return $output;
	}
}