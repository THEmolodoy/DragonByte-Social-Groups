<?php

namespace DBTech\SocialGroups\Pub\Controller;

use DBTech\SocialGroups\ControllerPlugin\DiscussionPlugin;
use DBTech\SocialGroups\Entity\Discussion;
use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Entity\Message;
use DBTech\SocialGroups\Pub\View;
use DBTech\SocialGroups\Service\Discussion\EditorService as DiscussionEditorService;
use DBTech\SocialGroups\Service\Message\DeleterService as MessageDeleterService;
use DBTech\SocialGroups\Service\Message\EditorService as MessageEditorService;
use XF\ControllerPlugin\BbCodePreviewPlugin;
use XF\ControllerPlugin\BookmarkPlugin;
use XF\ControllerPlugin\EditorPlugin;
use XF\ControllerPlugin\InlineModPlugin;
use XF\ControllerPlugin\IpPlugin;
use XF\ControllerPlugin\QuotePlugin;
use XF\ControllerPlugin\ReactionPlugin;
use XF\ControllerPlugin\ReportPlugin;
use XF\ControllerPlugin\SharePlugin;
use XF\ControllerPlugin\UndeletePlugin;
use XF\ControllerPlugin\WarnPlugin;
use XF\InputFilterer;
use XF\Mvc\ParameterBag;
use XF\Mvc\Reply\AbstractReply;
use XF\Mvc\Reply\Exception as ReplyException;
use XF\Mvc\RouteMatch;
use XF\Phrase;
use XF\PrintableException;
use XF\Pub\Controller\EditHistoryController;
use XF\Repository\AttachmentRepository;

class MessageController extends AbstractGroupController
{
	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionIndex(ParameterBag $params): AbstractReply
	{
		$message = $this->assertViewableMessage($params['message_id']);

		return $this->redirectPermanently(
			$this->plugin(DiscussionPlugin::class)
				->getMessageLink($message)
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionShow(ParameterBag $params): AbstractReply
	{
		$message = $this->assertViewableMessage($params['message_id']);

		$viewParams = [
			'message' => $message,
			'discussion' => $message->Discussion,
			'group' => $message->Discussion->Group,
			'canInlineMod' => $message->canUseInlineModeration(),
		];
		return $this->view(
			View\Message\ShowView::class,
			'dbtech_social_groups_message',
			$viewParams
		);
	}

	/**
	 * @param Message $message
	 *
	 * @return MessageEditorService
	 */
	protected function setupMessageEdit(
		Message $message
	): MessageEditorService
	{
		$messageContent = $this->plugin(EditorPlugin::class)->fromInput('message');

		$editor = \XF::app()->service(MessageEditorService::class, $message);
		if ($message->canEditSilently())
		{
			$silentEdit = $this->filter('silent', InputFilterer::BOOLEAN);
			if ($silentEdit)
			{
				$editor->logEdit(false);
				if ($this->filter('clear_edit', InputFilterer::BOOLEAN))
				{
					$message->last_edit_date = 0;
				}
			}
		}
		$editor->setMessageContent($messageContent);

		$group = $message->Discussion->Group;
		if ($group->canUploadAndManageAttachments())
		{
			$editor->setAttachmentHash($this->filter('attachment_hash', InputFilterer::STRING));
		}

		if ($this->filter('author_alert', InputFilterer::BOOLEAN) && $message->canSendModeratorActionAlert())
		{
			$editor->setSendAlert(true, $this->filter('author_alert_reason', InputFilterer::STRING));
		}

		return $editor;
	}

	/**
	 * @param Discussion $discussion
	 * @param array|null $discussionChanges Returns a list of whether certain important discussion fields are changed
	 *
	 * @return DiscussionEditorService
	 */
	protected function setupFirstMessageDiscussionEdit(
		Discussion $discussion,
		?array &$discussionChanges
	): DiscussionEditorService
	{
		$discussionEditor = \XF::app()->service(
			DiscussionEditorService::class,
			$discussion
		);
		$discussionEditor->setTitle($this->filter('title', InputFilterer::STRING));

		$discussionChanges = [
			'title' => $discussion->isChanged(['title', 'prefix_id']),
		];

		return $discussionEditor;
	}

	protected function finalizeMessageEdit(
		MessageEditorService $editor,
		?DiscussionEditorService $discussionEditor = null
	)
	{
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionEdit(ParameterBag $params): AbstractReply
	{
		$message = $this->assertViewableMessage($params['message_id']);
		if (!$message->canEdit($error))
		{
			return $this->noPermission($error);
		}

		$discussion = $message->Discussion;

		if ($this->isPost())
		{
			$editor = $this->setupMessageEdit($message);
			$editor->checkForSpam();

			if ($message->isFirstMessage() && $discussion->canEdit())
			{
				$discussionEditor = $this->setupFirstMessageDiscussionEdit($discussion, $discussionChanges);
				$editor->setDiscussionEditor($discussionEditor);
			}
			else
			{
				$discussionEditor = null;
				$discussionChanges = [];
			}

			if (!$editor->validate($errors))
			{
				return $this->error($errors);
			}

			$editor->save();

			$this->finalizeMessageEdit($editor, $discussionEditor);

			if ($this->filter('_xfWithData', InputFilterer::BOOLEAN) && $this->filter('_xfInlineEdit', InputFilterer::BOOLEAN))
			{
				\XF::app()->repository(AttachmentRepository::class)
					->addAttachmentsToContent(
						[$message->message_id => $message],
						'dbtech_social_message'
					)
				;

				$viewParams = [
					'message' => $message,
					'discussion' => $discussion,
				];
				$reply = $this->view(
					View\Message\EditNewMessageView::class,
					'dbtech_social_groups_message_edit_new_message',
					$viewParams
				);
				$reply->setJsonParams([
					'message' => \XF::phrase('your_changes_have_been_saved'),
					'discussionChanges' => $discussionChanges,
				]);
				return $reply;
			}
			else
			{
				return $this->redirect($this->buildLink('dbtech-social/messages', $message));
			}
		}
		else
		{
			/** @var Group $group */
			$group = $message->Discussion->Group;
			if ($group->canUploadAndManageAttachments())
			{
				$attachmentData = \XF::app()->repository(AttachmentRepository::class)
					->getEditorData('dbtech_social_message', $message)
				;
			}
			else
			{
				$attachmentData = null;
			}

			$viewParams = [
				'message' => $message,
				'discussion' => $discussion,
				'group' => $group,
				'attachmentData' => $attachmentData,
				'quickEdit' => $this->filter('_xfWithData', InputFilterer::BOOLEAN),
			];
			return $this->view(
				View\Message\EditView::class,
				'dbtech_social_groups_message_edit',
				$viewParams
			);
		}
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionPreview(ParameterBag $params): AbstractReply
	{
		$this->assertPostOnly();

		$message = $this->assertViewableMessage($params['message_id']);
		if (!$message->canEdit($error))
		{
			return $this->noPermission($error);
		}

		$discussion = $message->Discussion;

		$editor = $this->setupMessageEdit($message);

		if (!$editor->validate($errors))
		{
			return $this->error($errors);
		}

		$attachments = [];
		$tempHash = $this->filter('attachment_hash', InputFilterer::STRING);

		if ($discussion->Group->canUploadAndManageAttachments())
		{
			$attachmentData = \XF::app()->repository(AttachmentRepository::class)
				->getEditorData('dbtech_social_message', $message, $tempHash)
			;
			$attachments = $attachmentData['attachments'];
		}

		return $this->plugin(BbCodePreviewPlugin::class)->actionPreview(
			$message->message,
			'dbtech_social_message',
			$message->User,
			$attachments,
			$discussion->canViewAttachments()
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 * @throws PrintableException
	 */
	public function actionDelete(ParameterBag $params): AbstractReply
	{
		$message = $this->assertViewableMessage($params['message_id']);
		if (!$message->canDelete('soft', $error))
		{
			return $this->noPermission($error);
		}

		if ($this->isPost())
		{
			$type = $this->filter('hard_delete', InputFilterer::BOOLEAN) ? 'hard' : 'soft';
			$reason = $this->filter('reason', InputFilterer::STRING);

			if (!$message->canDelete($type, $error))
			{
				return $this->noPermission($error);
			}

			/** @var Discussion $discussion */
			$discussion = $message->Discussion;

			$deleter = \XF::app()->service(MessageDeleterService::class, $message);

			if ($this->filter('author_alert', InputFilterer::BOOLEAN) && $message->canSendModeratorActionAlert())
			{
				$deleter->setSendAlert(true, $this->filter('author_alert_reason', InputFilterer::STRING));
			}

			$deleter->delete($type, $reason);

			$this->plugin(InlineModPlugin::class)
				->clearIdFromCookie('dbtech_social_message', $message->message_id)
			;

			if ($deleter->wasDiscussionDeleted())
			{
				$this->plugin(InlineModPlugin::class)
					->clearIdFromCookie('dbtech_social_discussion', $message->discussion_id)
				;

				return $this->redirect(
					$discussion && $discussion->Group
						? $this->buildLink('dbtech-social', $discussion->Group)
						: $this->buildLink('dbtech-social')
				);
			}
			else
			{
				return $this->redirect(
					$this->getDynamicRedirect(
						$this->buildLink('dbtech-social/discussions', $discussion),
						false
					)
				);
			}
		}
		else
		{
			$viewParams = [
				'message' => $message,
				'discussion' => $message->Discussion,
				'group' => $message->Discussion->Group,
			];
			return $this->view(
				View\Message\DeleteView::class,
				'dbtech_social_groups_message_delete',
				$viewParams
			);
		}
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionUndelete(ParameterBag $params): AbstractReply
	{
		$message = $this->assertViewableMessage($params['message_id']);

		$plugin = $this->plugin(UndeletePlugin::class);
		return $plugin->actionUndelete(
			$message,
			$this->buildLink('dbtech-social/messages/undelete', $message),
			$this->buildLink('dbtech-social/messages', $message),
			\XF::phrase('dbtech_social_groups_message_in_discussion_x', [
				'title' => $message->Discussion->title,
			]),
			'message_state'
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionIp(ParameterBag $params): AbstractReply
	{
		$message = $this->assertViewableMessage($params['message_id']);
		$breadcrumbs = $message->Discussion->getBreadcrumbs();

		$ipPlugin = $this->plugin(IpPlugin::class);
		return $ipPlugin->actionIp($message, $breadcrumbs);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionReport(ParameterBag $params): AbstractReply
	{
		$message = $this->assertViewableMessage($params['message_id']);
		if (!$message->canReport($error))
		{
			return $this->noPermission($error);
		}

		$reportPlugin = $this->plugin(ReportPlugin::class);
		return $reportPlugin->actionReport(
			'dbtech_social_message',
			$message,
			$this->buildLink('dbtech-social/messages/report', $message),
			$this->buildLink('dbtech-social/messages', $message)
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionQuote(ParameterBag $params): AbstractReply
	{
		$message = $this->assertViewableMessage($params['message_id']);
		if (!$message->Discussion->canReply($error))
		{
			return $this->noPermission($error);
		}

		return $this->plugin(QuotePlugin::class)
			->actionQuote($message, 'dbtech_social_message')
		;
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 */
	public function actionHistory(ParameterBag $params): AbstractReply
	{
		return $this->rerouteController(EditHistoryController::class, 'index', [
			'content_type' => 'dbtech_social_message',
			'content_id' => $params['message_id'],
		]);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionBookmark(ParameterBag $params): AbstractReply
	{
		$message = $this->assertViewableMessage($params['message_id']);

		$bookmarkPlugin = $this->plugin(BookmarkPlugin::class);
		return $bookmarkPlugin->actionBookmark(
			$message,
			$this->buildLink('dbtech-social/messages/bookmark', $message)
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionReact(ParameterBag $params): AbstractReply
	{
		$message = $this->assertViewableMessage($params['message_id']);

		$reactionPlugin = $this->plugin(ReactionPlugin::class);
		return $reactionPlugin->actionReactSimple($message, 'dbtech-social/messages');
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionReactions(ParameterBag $params): AbstractReply
	{
		$message = $this->assertViewableMessage($params['message_id']);

		$breadcrumbs = $message->Discussion->getBreadcrumbs();
		$title = \XF::phrase('members_who_reacted_to_message_x', ['position' => ($message->position + 1)]);

		$reactionPlugin = $this->plugin(ReactionPlugin::class);
		return $reactionPlugin->actionReactions(
			$message,
			'dbtech-social/messages/reactions',
			$title,
			$breadcrumbs
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionWarn(ParameterBag $params): AbstractReply
	{
		$message = $this->assertViewableMessage($params['message_id']);

		if (!$message->canWarn($error))
		{
			return $this->noPermission($error);
		}

		$breadcrumbs = $message->Discussion->getBreadcrumbs();

		$warnPlugin = $this->plugin(WarnPlugin::class);
		return $warnPlugin->actionWarn(
			'dbtech_social_message',
			$message,
			$this->buildLink('dbtech-social/messages/warn', $message),
			$breadcrumbs
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionShare(ParameterBag $params): AbstractReply
	{
		$message = $this->assertViewableMessage($params['message_id']);
		$discussion = $message->Discussion;

		$sharePlugin = $this->plugin(SharePlugin::class);
		return $sharePlugin->actionTooltipWithEmbed(
			$message->isFirstMessage()
				? $this->buildLink('canonical:dbtech-social/discussions', $discussion)
				: $this->buildLink('canonical:dbtech-social/discussions/message', $discussion, [
					'message_id' => $message->message_id,
				]),
			$message->isFirstMessage()
				? \XF::phrase('dbtech_social_groups_discussion_x', ['title' => $discussion->title])
				: \XF::phrase('dbtech_social_groups_message_in_discussion_x', ['title' => $discussion->title]),
			$message->isFirstMessage()
				? \XF::phrase('dbtech_social_groups_share_this_discussion')
				: \XF::phrase('dbtech_social_groups_share_this_message'),
			null,
			$message->isFirstMessage()
				? $discussion->getEmbedCodeHtml()
				: $message->getEmbedCodeHtml()
		);
	}

	/**
	 * @param int|null $messageId
	 * @param array $extraWith
	 *
	 * @return Message
	 *
	 * @throws ReplyException
	 */
	protected function assertViewableMessage(?int $messageId, array $extraWith = []): Message
	{
		$visitor = \XF::visitor();
		$extraWith[] = 'Discussion';
		$extraWith[] = 'Discussion.Group';
		$extraWith[] = 'Discussion.Group.Permissions|' . $visitor->permission_combination_id;

		$message = \XF::app()->em()->find(Message::class, $messageId, $extraWith);
		if (!$message)
		{
			throw $this->exception(
				$this->notFound(\XF::phrase('dbtech_social_groups_requested_message_not_found'))
			);
		}
		if (!$message->canView($error))
		{
			throw $this->exception($this->noPermission($error));
		}

		$this->groupContext = $message->Discussion->Group;

		return $message;
	}

	/**
	 * @param array $activities
	 *
	 * @return Phrase
	 */
	public static function getActivityDetails(array $activities): Phrase
	{
		return \XF::phrase('dbtech_social_groups_viewing_discussion');
	}

	/**
	 * @return string[]
	 */
	public static function getResolvableActions(): array
	{
		return ['index', 'show'];
	}

	/**
	 * @param ParameterBag $params
	 * @param RouteMatch $routeMatch
	 *
	 * @return Message|null
	 */
	public static function resolveToEmbeddableContent(ParameterBag $params, RouteMatch $routeMatch): ?Message
	{
		$content = null;

		if ($params['message_id'])
		{
			$content = \XF::em()->find(Message::class, $params['message_id']);
		}

		if (!$content || !$content->canView())
		{
			$content = null;
		}

		return $content;
	}
}