<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\Pub\Controller;

use XF\Pub\Controller\AbstractWhatsNewFindType;

class WhatsNewGroupController extends AbstractWhatsNewFindType
{
	protected function getContentType()
	{
		return 'dbtech_social_group';
	}
}