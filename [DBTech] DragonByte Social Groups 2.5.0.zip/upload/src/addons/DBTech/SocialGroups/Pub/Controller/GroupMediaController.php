<?php

namespace DBTech\SocialGroups\Pub\Controller;

use DBTech\SocialGroups\Pub\View;
use DBTech\SocialGroups\Service\Group\LinkAlbumsService;
use DBTech\SocialGroups\XF\Entity\User as ExtendedUserEntity;
use XF\Entity\User;
use XF\InputFilterer;
use XF\Mvc\ParameterBag;
use XF\Mvc\Reply\AbstractReply;
use XF\Mvc\Reply\Exception as ReplyException;
use XFMG\ControllerPlugin\AlbumList;
use XFMG\ControllerPlugin\MediaList;
use XFMG\Pub\Controller\Album;
use XFMG\Pub\Controller\Media;

class GroupMediaController extends AbstractGroupController
{
	/**
	 * @param $action
	 * @param ParameterBag $params
	 *
	 * @return void
	 * @throws ReplyException
	 */
	protected function preDispatchController($action, ParameterBag $params): void
	{
		parent::preDispatchController($action, $params);

		switch (\strtolower($action))
		{
			case 'index':
			case 'add':
			case 'album':
			case 'albumadd':
			case 'users':
				if (!\XF::app()->options()->dbtechSocialEnableMediaGallery
					|| !\XF::isAddOnActive('XFMG')
				)
				{
					throw $this->exception($this->noPermission());
				}
				break;
		}
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionIndex(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);
		if (!$group->canViewMedia())
		{
			$viewParams = [
				'group' => $group,
			];
			if (!empty($params['media_id']))
			{
				return $this->view(
					View\Group\Media\ViewView::class,
					'dbtech_social_groups_group_media_media_view',
					$viewParams
				);
			}

			return $this->view(
				View\Group\MediaView::class,
				'dbtech_social_groups_group_media',
				$viewParams
			);
		}

		if (!empty($params['media_id']))
		{
			return $this->rerouteController(Media::class, 'view', $params);
		}

		$this->assertNotEmbeddedImageRequest();

		/** @var \DBTech\SocialGroups\XFMG\ControllerPlugin\AlbumList $albumListPlugin */
		$albumListPlugin = $this->plugin(AlbumList::class);

		$listParams = $albumListPlugin->getDbtechSocialGroupAlbumListData($group, $params['page'] ?? 1);

		$this->assertValidPage(
			$listParams['page'],
			$listParams['perPage'],
			$listParams['totalItems'],
			'dbtech-social/media',
			$group
		);
		$this->assertCanonicalUrl($this->buildLink('dbtech-social/media', $group, ['page' => $listParams['page']]));

		$viewParams = $listParams;
		return $this->view(
			View\Group\MediaView::class,
			'dbtech_social_groups_group_media',
			$viewParams
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionAdd(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);
		if (!$group->canCreateAlbum($error))
		{
			return $this->noPermission($error);
		}

		if ($this->isPost())
		{
			$input = $this->filter([
				'action' => InputFilterer::STRING,
				'albumIds' => 'array-str',
			]);
			if ($input['action'] === 'link')
			{
				$albumLinkService = \XF::app()->service(
					LinkAlbumsService::class,
					$group,
					$input['albumIds']
				);
				if (!$albumLinkService->validate($errors))
				{
					throw $this->exception($this->error($errors));
				}
				$albumLinkService->save();

				return $this->redirect($this->buildLink('dbtech-social/media', $group));
			}
			else
			{
				$this->request->set('dbtech_social_group_id', $group->group_id);
				return $this->rerouteController(Album::class, 'create');
			}
		}

		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		$viewParams = [
			'group' => $group,
			'maxAlbumsPerGroup' => $visitor->hasPermission('dbtechSocial', 'maxAlbumsPerGroup'),
			'albumCount' => $visitor->SocialGroupMemberships[$group->group_id]->album_count,
		];
		return $this->view(
			View\Group\Media\AddView::class,
			'dbtech_social_groups_group_media_add',
			$viewParams
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionAlbum(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);
		if (!$group->canViewMedia())
		{
			$viewParams = [
				'group' => $group,
			];
			return $this->view(
				View\Group\Media\AlbumView::class,
				'dbtech_social_groups_group_media_album_view',
				$viewParams
			);
		}

		return $this->rerouteController(Album::class, 'view', $params);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionAlbumAdd(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);
		if (!$group->canViewMedia())
		{
			return $this->noPermission();
		}

		return $this->rerouteController(Album::class, 'add', $params);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionAlbumUnlink(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);
		if (!$group->canViewMedia())
		{
			return $this->noPermission();
		}

		return $this->rerouteController(Album::class, 'dbtech-social-unlink', $params);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionUsers(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);
		if (!$group->canViewMedia())
		{
			return $this->noPermission();
		}

		$user = $this->assertRecordExists(
			User::class,
			$this->filter('user_id', InputFilterer::UINT)
		);

		$mediaListPlugin = $this->plugin(MediaList::class);

		$categoryParams = $mediaListPlugin->getCategoryListData();

		$listParams = $mediaListPlugin->getDbtechSocialGroupMediaListData(
			$group,
			$params['page'] ?: 1,
			$user
		);

		$this->assertValidPage(
			$listParams['page'],
			$listParams['perPage'],
			$listParams['totalItems'],
			'dbtech-social/media/users',
			$user
		);

		$this->assertCanonicalUrl(
			$this->buildLink(
				'dbtech-social/media/users',
				$group,
				['user_id' => $user->user_id, 'page' => $listParams['page']]
			)
		);

		$listParams['prevPage'] = ($listParams['page'] > 1)
			? $this->buildLink(
				'dbtech-social/media/users',
				$group,
				['user_id' => $user->user_id, 'page' => $listParams['page'] - 1]
			)
			: null
		;
		$listParams['nextPage'] = ($listParams['page'] < ceil($listParams['totalItems'] / $listParams['perPage']))
			? $this->buildLink(
				'dbtech-social/media/users',
				$group,
				['user_id' => $user->user_id, 'page' => $listParams['page'] + 1]
			)
			: null
		;

		$viewParams = $categoryParams + $listParams;

		return $this->view(
			View\Group\Media\UserIndexView::class,
			'dbtech_social_groups_group_media_user_index',
			$viewParams
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionAlbumsUsers(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);
		if (!$group->canViewMedia())
		{
			return $this->noPermission();
		}

		$user = $this->assertRecordExists(
			User::class,
			$this->filter('user_id', InputFilterer::UINT)
		);

		$albumListPlugin = $this->plugin(AlbumList::class);

		$categoryParams = $albumListPlugin->getCategoryListData();

		$listParams = $albumListPlugin->getDbtechSocialGroupAlbumListData(
			$group,
			$params['page'] ?: 1,
			$user
		);

		$this->assertValidPage(
			$listParams['page'],
			$listParams['perPage'],
			$listParams['totalItems'],
			'dbtech-social/media/albums/users',
			$group
		);
		$this->assertCanonicalUrl(
			$this->buildLink(
				'dbtech-social/media/albums/users',
				$group,
				['user_id' => $user->user_id, 'page' => $listParams['page']]
			)
		);

		$viewParams = $categoryParams + $listParams;

		return $this->view(
			View\Group\Media\AlbumUserIndexView::class,
			'dbtech_social_groups_group_media_album_user_index',
			$viewParams
		);
	}
}