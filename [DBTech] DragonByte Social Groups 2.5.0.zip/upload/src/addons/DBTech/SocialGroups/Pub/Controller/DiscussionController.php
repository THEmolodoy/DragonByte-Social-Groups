<?php

namespace DBTech\SocialGroups\Pub\Controller;

use DBTech\SocialGroups\ControllerPlugin\DiscussionPlugin;
use DBTech\SocialGroups\Entity\Discussion;
use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Entity\Message;
use DBTech\SocialGroups\Entity\Section;
use DBTech\SocialGroups\Finder\MessageFinder;
use DBTech\SocialGroups\Pub\View;
use DBTech\SocialGroups\Repository\DiscussionReplyBanRepository;
use DBTech\SocialGroups\Repository\DiscussionRepository;
use DBTech\SocialGroups\Repository\DiscussionWatchRepository;
use DBTech\SocialGroups\Repository\MessageRepository;
use DBTech\SocialGroups\Repository\SectionRepository;
use DBTech\SocialGroups\Service\Discussion\ApproverService;
use DBTech\SocialGroups\Service\Discussion\DeleterService;
use DBTech\SocialGroups\Service\Discussion\EditorService;
use DBTech\SocialGroups\Service\Discussion\MoverService;
use DBTech\SocialGroups\Service\Discussion\ReplierService;
use DBTech\SocialGroups\Service\Discussion\ReplyBanService;
use XF\ControllerPlugin\BbCodePreviewPlugin;
use XF\ControllerPlugin\DraftPlugin;
use XF\ControllerPlugin\EditorPlugin;
use XF\ControllerPlugin\InlineModPlugin;
use XF\ControllerPlugin\ModeratorLogPlugin;
use XF\ControllerPlugin\PollPlugin;
use XF\ControllerPlugin\QuotePlugin;
use XF\ControllerPlugin\UndeletePlugin;
use XF\Db\DeadlockException;
use XF\Db\Exception as DbException;
use XF\Finder\UserFinder;
use XF\InputFilterer;
use XF\Mvc\Entity\Finder;
use XF\Mvc\ParameterBag;
use XF\Mvc\Reply\AbstractReply;
use XF\Mvc\Reply\Exception as ReplyException;
use XF\Mvc\RouteMatch;
use XF\PrintableException;
use XF\Pub\Controller\EmbedResolverTrait;
use XF\Repository\AttachmentRepository;
use XF\Repository\EmbedResolverRepository;
use XF\Repository\UnfurlRepository;
use XF\Repository\UserAlertRepository;
use XF\Service\Tag\ChangerService;

use function intval;

class DiscussionController extends AbstractGroupController
{
	use EmbedResolverTrait;

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws DeadlockException
	 * @throws DbException
	 * @throws ReplyException
	 */
	public function actionIndex(ParameterBag $params): AbstractReply
	{
		if (!$params['discussion_id'])
		{
			return $this->rerouteController(GroupController::class, 'discussions', $params);
		}

		$discussion = $this->assertViewableDiscussion($params['discussion_id'], $this->getDiscussionViewExtraWith());
		$discussionRepo = \XF::app()->repository(DiscussionRepository::class);

		$page = $params['page'] ?? 1;
		$perPage = \XF::app()->options()->messagesPerPage;

		$this->assertValidPage($page, $perPage, $discussion->reply_count + 1, 'dbtech-social/discussions', $discussion);
		$this->assertCanonicalUrl($this->buildLink('dbtech-social/discussions', $discussion, ['page' => $page]));

		$messageRepo = \XF::app()->repository(MessageRepository::class);

		$messageList = $messageRepo->findMessagesForDiscussionView($discussion)->onPage($page, $perPage);
		$messages = $messageList->fetch();

		$lastMessage = $messages->last();
		if (!$lastMessage)
		{
			if ($page > 1)
			{
				return $this->redirect($this->buildLink('dbtech-social/discussions', $discussion));
			}
			else
			{
				// should never really happen
				return $this->error(\XF::phrase('something_went_wrong_please_try_again'));
			}
		}

		\XF::app()->repository(AttachmentRepository::class)
			->addAttachmentsToContent($messages, 'dbtech_social_message')
		;

		\XF::app()->repository(UserAlertRepository::class)
			->markUserAlertsReadForContent('dbtech_social_message', $messages->keys())
		;

		\XF::app()->repository(UnfurlRepository::class)
			->addUnfurlsToContent($messages, $this->isRobot())
		;

		\XF::app()->repository(EmbedResolverRepository::class)
			->addEmbedsToContent($messages)
		;

		$firstMessage = $messages->first();

		/** @var Message $message */

		$canInlineMod = false;
		foreach ($messages AS $message)
		{
			if ($message->canUseInlineModeration())
			{
				$canInlineMod = true;
				break;
			}
		}

		$firstUnread = null;
		foreach ($messages AS $message)
		{
			if ($message->isUnread())
			{
				$firstUnread = $message;
				break;
			}
		}

		$poll = ($discussion->discussion_type == 'poll' ? $discussion->Poll : null);

		$discussionRepo->markDiscussionReadByVisitor($discussion, $lastMessage->message_date);
		$discussionRepo->logDiscussionView($discussion);

		$viewParams = [
			'discussion' => $discussion,
			'group' => $discussion->Group,
			'messages' => $messages,
			'firstMessage' => $firstMessage,
			'lastMessage' => $lastMessage,
			'firstUnread' => $firstUnread,

			// Cache these two relations so that group user banner checks cause no extra queries
			'groupModerators' => $discussion->Group->Moderators->populate(),
			'groupSupervisors' => $discussion->Group->Supervisors->populate(),
			'groupBanned' => $discussion->Group->Bans->populate(),

			'poll' => $poll,

			'canInlineMod' => $canInlineMod,

			'page' => $page,
			'perPage' => $perPage,

			'attachmentData' => $this->getReplyAttachmentData($discussion),

			'pendingApproval' => $this->filter('pending_approval', InputFilterer::BOOLEAN),
		];
		return $this->view(
			View\Discussion\ViewView::class,
			'dbtech_social_groups_discussion_view',
			$viewParams
		);
	}

	/**
	 * @return string[]
	 */
	protected function getDiscussionViewExtraWith(): array
	{
		$extraWith = ['User'];
		$userId = \XF::visitor()->user_id;
		if ($userId)
		{
			$extraWith[] = 'Watch|' . $userId;
			$extraWith[] = 'DraftReplies|' . $userId;
			$extraWith[] = 'ReplyBans|' . $userId;
		}

		return $extraWith;
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionUnread(ParameterBag $params): AbstractReply
	{
		$discussion = $this->assertViewableDiscussion($params['discussion_id'], ['LastMessage']);

		if (!\XF::visitor()->user_id)
		{
			return $this->redirect($this->buildLink('dbtech-social/discussions', $discussion));
		}

		$messageRepo = \XF::app()->repository(MessageRepository::class);
		$firstUnreadDate = $discussion->getVisitorReadDate();

		// this would force us to go to a new message, even if we have no read marking data for this discussion
		$forceNew = $this->filter('new', InputFilterer::BOOLEAN);

		if (!$forceNew && $firstUnreadDate <= \XF::app()->repository(DiscussionRepository::class)->getReadMarkingCutOff())
		{
			// We have no read marking data for this person, so we don't know whether they've read this discussion before.
			// More than likely, they haven't so we have to take them to the beginning.
			return $this->redirect($this->buildLink('dbtech-social/discussions', $discussion));
		}

		$findFirstUnread = $messageRepo->findNextMessagesInDiscussion($discussion, $firstUnreadDate);
		$firstUnread = $findFirstUnread->skipIgnored()->fetchOne();

		if (!$firstUnread)
		{
			$firstUnread = $discussion->LastMessage;
		}

		if (!$firstUnread)
		{
			// sanity check, probably shouldn't happen
			return $this->redirect($this->buildLink('dbtech-social/discussions', $discussion));
		}

		if ($firstUnread->message_id == $discussion->first_message_id)
		{
			return $this->redirect($this->buildLink('dbtech-social/discussions', $discussion));
		}

		return $this->redirect($this->plugin(DiscussionPlugin::class)->getMessageLink($firstUnread));
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionLatest(ParameterBag $params): AbstractReply
	{
		$discussion = $this->assertViewableDiscussion($params['discussion_id'], ['LastMessage']);
		$message = $discussion->LastMessage;

		if ($message)
		{
			return $this->redirect($this->plugin(DiscussionPlugin::class)->getMessageLink($message));
		}
		else
		{
			return $this->redirect($this->buildLink('dbtech-social/discussions', $discussion));
		}
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 */
	public function actionMessage(ParameterBag $params): AbstractReply
	{
		$messageId = max(0, intval($params['message_id']));
		if (!$messageId)
		{
			return $this->notFound();
		}

		$visitor = \XF::visitor();
		$with = [
			'Discussion',
			'Discussion.Group',
			'Discussion.Group.Permissions|' . $visitor->permission_combination_id,
		];

		$message = \XF::app()->em()->find(Message::class, $messageId, $with);
		if (!$message)
		{
			$discussion = \XF::app()->em()->find(Discussion::class, $params['discussion_id']);
			if ($discussion)
			{
				return $this->redirect($this->buildLink('dbtech-social/discussions', $discussion));
			}
			else
			{
				return $this->notFound();
			}
		}
		if (!$message->canView($error))
		{
			return $this->noPermission($error);
		}

		return $this->redirectPermanently($this->plugin(DiscussionPlugin::class)->getMessageLink($message));
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws DeadlockException
	 * @throws ReplyException
	 */
	public function actionNewMessages(ParameterBag $params): AbstractReply
	{
		$discussion = $this->assertViewableDiscussion($params['discussion_id'], ['FirstMessage']);

		$after = $this->filter('after', InputFilterer::UNSIGNED);

		if (!$this->request->isXhr())
		{
			if (!$after)
			{
				return $this->redirect($this->buildLink('dbtech-social/discussions', $discussion));
			}

			$findFirstUnread = \XF::app()->repository(MessageRepository::class)->findNextMessagesInDiscussion($discussion, $after);
			$firstMessage = $findFirstUnread->skipIgnored()->fetchOne();

			if (!$firstMessage)
			{
				$firstMessage = $discussion->LastMessage;
			}

			return $this->redirect($this->plugin(DiscussionPlugin::class)->getMessageLink($firstMessage));
		}

		return $this->getNewMessagesReply($discussion, $after);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionPreview(ParameterBag $params): AbstractReply
	{
		$discussion = $this->assertViewableDiscussion($params['discussion_id'], ['FirstMessage']);
		$firstMessage = $discussion->FirstMessage;

		$viewParams = [
			'discussion' => $discussion,
			'firstMessage' => $firstMessage,
		];
		return $this->view(
			View\Discussion\PreviewView::class,
			'dbtech_social_groups_discussion_preview',
			$viewParams
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionDraft(ParameterBag $params): AbstractReply
	{
		$discussion = $this->assertViewableDiscussion($params['discussion_id']);

		$draftPlugin = $this->plugin(DraftPlugin::class);

		$extraData = $this->filter([
			'attachment_hash' => InputFilterer::STRING,
		]);

		$draftAction = $draftPlugin->updateMessageDraft($discussion->draft_reply, $extraData);

		$lastDate = $this->filter('last_date', InputFilterer::UNSIGNED);
		$lastKnownDate = $this->filter('last_known_date', InputFilterer::UNSIGNED);
		$lastKnownDate = max($lastDate, $lastKnownDate);

		// the check for last date here is to make sure that we have a date we can log in a link
		if ($lastDate)
		{
			/** @var Finder $messageList */
			$messageList = \XF::app()->repository(MessageRepository::class)->findNewestMessagesInDiscussion($discussion, $lastKnownDate)->skipIgnored();
			$hasNewMessage = ($messageList->total() > 0);
		}
		else
		{
			$hasNewMessage = false;
		}

		$viewParams = [
			'discussion' => $discussion,
			'hasNewMessage' => $hasNewMessage,
			'lastDate' => $lastDate,
			'lastKnownDate' => $lastKnownDate,
		];
		$view = $this->view(
			View\Discussion\DraftView::class,
			'dbtech_social_groups_discussion_save_draft',
			$viewParams
		);
		$view->setJsonParam('hasNew', $hasNewMessage);
		$draftPlugin->addDraftJsonParams($view, $draftAction);

		return $view;
	}

	/**
	 * @param Discussion $discussion
	 *
	 * @return ReplierService
	 */
	protected function setupDiscussionReply(Discussion $discussion): ReplierService
	{
		$message = $this->plugin(EditorPlugin::class)->fromInput('message');

		$replier = \XF::app()->service(ReplierService::class, $discussion);
		$replier->setMessageContent($message);

		if ($discussion->Group->canUploadAndManageAttachments())
		{
			$replier->setAttachmentHash($this->filter('attachment_hash', InputFilterer::STRING));
		}

		return $replier;
	}

	/**
	 * @param ReplierService $replier
	 *
	 * @throws DeadlockException
	 * @throws PrintableException
	 */
	protected function finalizeDiscussionReply(ReplierService $replier): void
	{
		$replier->sendNotifications();

		$discussion = $replier->getDiscussion();
		$message = $replier->getMessage();
		$visitor = \XF::visitor();

		$setOptions = $this->filter('_xfSet', 'array-bool');
		if ($discussion->canWatch())
		{
			if (isset($setOptions['watch_discussion']))
			{
				$watch = $this->filter('watch_discussion', InputFilterer::BOOLEAN);
				if ($watch)
				{
					$state = $this->filter('watch_discussion_email', InputFilterer::BOOLEAN)
						? 'watch_email'
						: 'watch_no_email'
					;

					\XF::app()->repository(DiscussionWatchRepository::class)
						->setWatchState($discussion, $visitor, $state)
					;
				}
			}
			else
			{
				// use user preferences
				\XF::app()->repository(DiscussionWatchRepository::class)
					->autoWatchDiscussion($discussion, $visitor)
				;
			}
		}

		if ($discussion->canLockUnlock() && isset($setOptions['discussion_open']))
		{
			$discussion->discussion_open = $this->filter('discussion_open', InputFilterer::BOOLEAN);
		}
		if ($discussion->canStickUnstick() && isset($setOptions['sticky']))
		{
			$discussion->sticky = $this->filter('sticky', InputFilterer::BOOLEAN);
		}

		$discussion->saveIfChanged($null, false);

		if ($visitor->user_id)
		{
			$readDate = $discussion->getVisitorReadDate();
			if ($readDate && $readDate >= $discussion->getPreviousValue('last_message_date'))
			{
				$message = $replier->getMessage();
				\XF::app()->repository(DiscussionRepository::class)->markDiscussionReadByVisitor($discussion, $message->message_date);
			}

			$discussion->draft_reply->delete();

			if ($message->message_state == 'moderated')
			{
				$this->session()->setHasContentPendingApproval();
			}
		}
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionReply(ParameterBag $params): AbstractReply
	{
		$visitor = \XF::visitor();

		$discussion = $this->assertViewableDiscussion($params['discussion_id'], ['Watch|' . $visitor->user_id]);
		if (!$discussion->canReply($error))
		{
			return $this->noPermission($error);
		}

		$defaultMessage = '';
		$forceAttachmentHash = null;

		$quote = $this->filter('quote', InputFilterer::UNSIGNED);
		if ($quote)
		{
			$message = \XF::app()->em()->find(Message::class, $quote, ['User']);
			if ($message && $message->discussion_id == $discussion->discussion_id && $message->canView())
			{
				$defaultMessage = $message->getQuoteWrapper(
					\XF::app()->stringFormatter()->getBbCodeForQuote($message->message, 'dbtech_social_message')
				);
				$forceAttachmentHash = '';
			}
		}
		else if ($this->request->exists('requires_captcha'))
		{
			$defaultMessage = $this->plugin(EditorPlugin::class)->fromInput('message');
			$forceAttachmentHash = $this->filter('attachment_hash', InputFilterer::STRING);
		}
		else
		{
			$defaultMessage = $discussion->draft_reply->message;
		}

		$viewParams = [
			'discussion' => $discussion,
			'group' => $discussion->Group,
			'attachmentData' => $this->getReplyAttachmentData($discussion, $forceAttachmentHash),
			'defaultMessage' => $defaultMessage,
		];
		return $this->view(
			View\Discussion\ReplyView::class,
			'dbtech_social_groups_discussion_reply',
			$viewParams
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws DeadlockException
	 * @throws ReplyException
	 * @throws PrintableException
	 */
	public function actionAddReply(ParameterBag $params): AbstractReply
	{
		$this->assertPostOnly();

		$visitor = \XF::visitor();
		$discussion = $this->assertViewableDiscussion($params['discussion_id'], ['Watch|' . $visitor->user_id]);
		if (!$discussion->canReply($error))
		{
			return $this->noPermission($error);
		}

		if ($this->filter('no_captcha', InputFilterer::BOOLEAN))
		{ // JS is disabled so user hasn't seen Captcha.
			$this->request->set('requires_captcha', true);
			return $this->rerouteController(__CLASS__, 'reply', $params);
		}
		else if (!$this->captchaIsValid())
		{
			return $this->error(\XF::phrase('did_not_complete_the_captcha_verification_properly'));
		}

		$replier = $this->setupDiscussionReply($discussion);
		$replier->checkForSpam();

		if (!$replier->validate($errors))
		{
			return $this->error($errors);
		}
		$this->assertNotFlooding('dbtech_social_message');
		$message = $replier->save();

		$this->finalizeDiscussionReply($replier);

		if ($this->filter('_xfWithData', InputFilterer::BOOLEAN) && $this->request->exists('last_date') && $message->canView())
		{
			// request was from quick reply
			$lastDate = $this->filter('last_date', InputFilterer::UNSIGNED);
			return $this->getNewMessagesReply($discussion, $lastDate);
		}
		else
		{
			\XF::app()->repository(DiscussionRepository::class)->markDiscussionReadByVisitor($discussion);
			$confirmation = \XF::phrase('your_message_has_been_posted');

			if ($message->canView())
			{
				return $this->redirect($this->buildLink('dbtech-social/messages', $message), $confirmation);
			}
			else
			{
				return $this->redirect($this->buildLink('dbtech-social/discussions', $discussion, ['pending_approval' => 1]), $confirmation);
			}
		}
	}

	/**
	 * @param Discussion $discussion
	 * @param $lastDate
	 *
	 * @return AbstractReply
	 * @throws DeadlockException
	 */
	protected function getNewMessagesReply(Discussion $discussion, $lastDate): AbstractReply
	{
		$messageRepo = \XF::app()->repository(MessageRepository::class);

		$limit = 3;

		/** @var Finder $messageList */
		$messageList = $messageRepo->findNewestMessagesInDiscussion($discussion, $lastDate)->skipIgnored()->with('full');
		$messages = $messageList->fetch($limit + 1);

		// We fetched one more message than needed, if more than $limit messages were returned,
		// we can show the 'there are more messages' notice
		if ($messages->count() > $limit)
		{
			$firstUnshownMessage = $messageRepo->findNextMessagesInDiscussion($discussion, $lastDate)->skipIgnored()->fetchOne();

			// Remove the extra message
			$messages = $messages->pop();
		}
		else
		{
			$firstUnshownMessage = null;
		}

		// put the messages into oldest-first order
		$messages = $messages->reverse();

		\XF::app()->repository(AttachmentRepository::class)
			->addAttachmentsToContent($messages, 'dbtech_social_message')
		;

		$visitor = \XF::visitor();
		$discussionRead = $discussion->Read[$visitor->user_id];

		if ($visitor->user_id)
		{
			if (!$firstUnshownMessage
				|| ($discussionRead && $firstUnshownMessage->message_date <= $discussionRead->discussion_read_date)
			)
			{
				\XF::app()->repository(DiscussionRepository::class)->markDiscussionReadByVisitor($discussion);
			}
		}

		\XF::app()->repository(UserAlertRepository::class)
			->markUserAlertsReadForContent('dbtech_social_message', $messages->keys())
		;

		/** @var Message $last */
		$last = $messages->last();
		if ($last)
		{
			$lastDate = $last->message_date;
		}

		$viewParams = [
			'discussion' => $discussion,
			'messages' => $messages,
			'firstUnshownMessage' => $firstUnshownMessage,
		];
		$view = $this->view(
			View\Discussion\NewMessagesView::class,
			'dbtech_social_groups_discussion_new_messages',
			$viewParams
		);
		$view->setJsonParam('lastDate', $lastDate);
		return $view;
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionReplyPreview(ParameterBag $params): AbstractReply
	{
		$this->assertPostOnly();

		$discussion = $this->assertViewableDiscussion($params['discussion_id']);
		if (!$discussion->canReply($error))
		{
			return $this->noPermission($error);
		}

		$replier = $this->setupDiscussionReply($discussion);
		if (!$replier->validate($errors))
		{
			return $this->error($errors);
		}

		$message = $replier->getMessage();
		$attachments = [];

		$tempHash = $this->filter('attachment_hash', InputFilterer::STRING);
		if ($tempHash && $discussion->Group->canUploadAndManageAttachments())
		{
			$attachments = \XF::app()->repository(AttachmentRepository::class)
				->findAttachmentsByTempHash($tempHash)
				->fetch()
			;
		}

		return $this->plugin(BbCodePreviewPlugin::class)->actionPreview(
			$message->message,
			'dbtech_social_message',
			$message->User,
			$attachments,
			$discussion->canViewAttachments()
		);
	}

	/**
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionMultiQuote(): AbstractReply
	{
		$this->assertPostOnly();

		$quotePlugin = $this->plugin(QuotePlugin::class);

		$quotes = $this->filter('quotes', InputFilterer::JSON_ARRAY);
		if (!$quotes)
		{
			return $this->error(\XF::phrase('no_messages_selected'));
		}
		$quotes = $quotePlugin->prepareQuotes($quotes);

		$messageFinder = \XF::app()->finder(MessageFinder::class);

		$messages = $messageFinder
			->with(['User', 'Discussion', 'Discussion.Group'])
			->where('message_id', array_keys($quotes))
			->order('message_date', 'DESC')
			->fetch()
			->filterViewable();

		if ($this->request->exists('insert'))
		{
			$insertOrder = $this->filter('insert', InputFilterer::ARRAY);
			return $quotePlugin->actionMultiQuote($messages, $insertOrder, $quotes, 'dbtech_social_message');
		}
		else
		{
			$viewParams = [
				'quotes' => $quotes,
				'messages' => $messages,
			];
			return $this->view(
				View\Discussion\MultiQuoteView::class,
				'dbtech_social_groups_discussion_multi_quote',
				$viewParams
			);
		}
	}

	/**
	 * @param Discussion $discussion
	 *
	 * @return EditorService
	 */
	protected function setupDiscussionEdit(
		Discussion $discussion
	): EditorService
	{
		$editor = $this->getEditorService($discussion);

		$editor->setTitle($this->filter('title', InputFilterer::STRING));

		$canLockUnlock = $discussion->canLockUnlock();
		if ($canLockUnlock)
		{
			$editor->setDiscussionOpen($this->filter('discussion_open', InputFilterer::BOOLEAN));
		}

		$canStickUnstick = $discussion->canStickUnstick($error);
		if ($canStickUnstick)
		{
			$editor->setSticky($this->filter('sticky', InputFilterer::BOOLEAN));
		}

		return $editor;
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionEdit(ParameterBag $params): AbstractReply
	{
		$discussion = $this->assertViewableDiscussion($params['discussion_id']);
		if (!$discussion->canEdit($error))
		{
			return $this->noPermission($error);
		}
		$group = $discussion->Group;

		$noInlineMod = $this->filter('_xfNoInlineMod', InputFilterer::BOOLEAN);
		$groupName = $this->filter('_xfGroupName', InputFilterer::BOOLEAN);

		if ($this->isPost())
		{
			$editor = $this->setupDiscussionEdit($discussion);

			if (!$editor->validate($errors))
			{
				return $this->error($errors);
			}

			$editor->save();

			if ($this->filter('_xfWithData', InputFilterer::BOOLEAN) && $this->filter('_xfInlineEdit', InputFilterer::BOOLEAN))
			{
				$viewParams = [
					'discussion' => $discussion,
					'group' => $group,

					'noInlineMod' => $noInlineMod,
					'groupName' => $groupName,
				];
				$reply = $this->view(
					View\Discussion\EditInlineView::class,
					'dbtech_social_groups_discussion_edit_new_discussion',
					$viewParams
				);
				$reply->setJsonParam('message', \XF::phrase('your_changes_have_been_saved'));
				return $reply;
			}
			return $this->redirect($this->buildLink('dbtech-social/discussions', $discussion));
		}
		else
		{
			$viewParams = [
				'discussion' => $discussion,
				'group' => $group,

				'noInlineMod' => $noInlineMod,
				'groupName' => $groupName,
			];
			return $this->view(
				View\Discussion\EditView::class,
				'dbtech_social_groups_discussion_edit',
				$viewParams
			);
		}
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionQuickClose(ParameterBag $params): AbstractReply
	{
		$this->assertPostOnly();

		$discussion = $this->assertViewableDiscussion($params['discussion_id']);
		if (!$discussion->canLockUnlock($error))
		{
			return $this->noPermission($error);
		}

		$editor = $this->getEditorService($discussion);

		if ($discussion->discussion_open)
		{
			$editor->setDiscussionOpen(false);
			$text = \XF::phrase('dbtech_social_groups_unlock_discussion');
		}
		else
		{
			$editor->setDiscussionOpen(true);
			$text = \XF::phrase('dbtech_social_groups_lock_discussion');
		}

		if (!$editor->validate($errors))
		{
			return $this->error($errors);
		}

		$editor->save();

		$reply = $this->redirect($this->getDynamicRedirect());
		$reply->setJsonParams([
			'text' => $text,
			'discussion_open' => $discussion->discussion_open,
		]);
		return $reply;
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionQuickStick(ParameterBag $params): AbstractReply
	{
		$discussion = $this->assertViewableDiscussion($params['discussion_id']);
		if (!$discussion->canStickUnstick($error))
		{
			return $this->noPermission($error);
		}

		$editor = $this->getEditorService($discussion);

		if ($discussion->sticky)
		{
			$editor->setSticky(false);
			$text = \XF::phrase('dbtech_social_groups_stick_discussion');
		}
		else
		{
			$editor->setSticky(true);
			$text = \XF::phrase('dbtech_social_groups_unstick_discussion');
		}

		if (!$editor->validate($errors))
		{
			return $this->error($errors);
		}

		$editor->save();

		if ($this->filter('_xfWithData', InputFilterer::BOOLEAN) && !$this->filter('_xfRedirect', InputFilterer::STRING))
		{
			$reply = $this->view(
				View\Discussion\QuickStickView::class
			);
			$reply->setJsonParams([
				'text' => $text,
				'sticky' => $discussion->sticky,
				'message' => \XF::phrase('redirect_changes_saved_successfully'),
			]);
			return $reply;
		}
		else
		{
			return $this->redirect($this->getDynamicRedirect());
		}
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionPollCreate(ParameterBag $params): AbstractReply
	{
		$discussion = $this->assertViewableDiscussion($params['discussion_id']);

		$breadcrumbs = $discussion->getBreadcrumbs();

		$pollPlugin = $this->plugin(PollPlugin::class);
		return $pollPlugin->actionCreate('dbtech_social_discussion', $discussion, $breadcrumbs);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionPollEdit(ParameterBag $params): AbstractReply
	{
		$discussion = $this->assertViewableDiscussion($params['discussion_id']);
		$poll = $discussion->Poll;

		$breadcrumbs = $discussion->getBreadcrumbs();

		$pollPlugin = $this->plugin(PollPlugin::class);
		return $pollPlugin->actionEdit($poll, $breadcrumbs);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionPollDelete(ParameterBag $params): AbstractReply
	{
		$discussion = $this->assertViewableDiscussion($params['discussion_id']);
		$poll = $discussion->Poll;

		$breadcrumbs = $discussion->getBreadcrumbs();

		$pollPlugin = $this->plugin(PollPlugin::class);
		return $pollPlugin->actionDelete($poll, $breadcrumbs);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionPollVote(ParameterBag $params): AbstractReply
	{
		$discussion = $this->assertViewableDiscussion($params['discussion_id']);
		$poll = $discussion->Poll;

		$breadcrumbs = $discussion->getBreadcrumbs();

		$pollPlugin = $this->plugin(PollPlugin::class);
		return $pollPlugin->actionVote($poll, $breadcrumbs);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionPollResults(ParameterBag $params): AbstractReply
	{
		$discussion = $this->assertViewableDiscussion($params['discussion_id']);
		$poll = $discussion->Poll;

		$breadcrumbs = $discussion->getBreadcrumbs();

		$pollPlugin = $this->plugin(PollPlugin::class);
		return $pollPlugin->actionResults($poll, $breadcrumbs);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 * @throws PrintableException
	 */
	public function actionDelete(ParameterBag $params): AbstractReply
	{
		$discussion = $this->assertViewableDiscussion($params['discussion_id']);
		if (!$discussion->canDelete('soft', $error))
		{
			return $this->noPermission($error);
		}

		if ($this->isPost())
		{
			$type = $this->filter('hard_delete', InputFilterer::BOOLEAN) ? 'hard' : 'soft';
			$reason = $this->filter('reason', InputFilterer::STRING);

			if (!$discussion->canDelete($type, $error))
			{
				return $this->noPermission($error);
			}

			$deleter = \XF::app()->service(DeleterService::class, $discussion);

			if ($this->filter('starter_alert', InputFilterer::BOOLEAN))
			{
				$deleter->setSendAlert(true, $this->filter('starter_alert_reason', InputFilterer::STRING));
			}

			$deleter->delete($type, $reason);

			$this->plugin(InlineModPlugin::class)
				->clearIdFromCookie('dbtech_social_discussion', $discussion->discussion_id)
			;

			return $this->redirect($this->buildLink('dbtech-social', $discussion->Group));
		}
		else
		{
			$viewParams = [
				'discussion' => $discussion,
				'group' => $discussion->Group,
			];
			return $this->view(
				View\Discussion\DeleteView::class,
				'dbtech_social_groups_discussion_delete',
				$viewParams
			);
		}
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionUndelete(ParameterBag $params): AbstractReply
	{
		$discussion = $this->assertViewableDiscussion($params['discussion_id']);

		$plugin = $this->plugin(UndeletePlugin::class);
		return $plugin->actionUndelete(
			$discussion,
			$this->buildLink('dbtech-social/discussions/undelete', $discussion),
			$this->buildLink('dbtech-social/discussions', $discussion),
			$discussion->title,
			'discussion_state'
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 * @throws PrintableException
	 */
	public function actionApprove(ParameterBag $params): AbstractReply
	{
		$this->assertValidCsrfToken($this->filter('t', InputFilterer::STRING));

		$discussion = $this->assertViewableDiscussion($params['discussion_id']);
		if (!$discussion->canApproveUnapprove($error))
		{
			return $this->noPermission($error);
		}

		if ($this->isPost())
		{
			$approver = \XF::app()->service(ApproverService::class, $discussion);
			$approver->approve();

			return $this->redirect($this->buildLink('dbtech-social/discussions', $discussion));
		}
		else
		{
			$viewParams = [
				'discussion' => $discussion,
				'group' => $discussion->Group,
			];
			return $this->view(
				View\Discussion\ApproveView::class,
				'dbtech_social_groups_discussion_approve',
				$viewParams
			);
		}
	}



	/**
	 * @param Discussion $discussion
	 * @param ?Section $section
	 *
	 * @return MoverService
	 */
	protected function setupDiscussionMove(
		Discussion $discussion,
		?Section $section
	): MoverService
	{
		$options = $this->filter([
			'notify_watchers' => InputFilterer::BOOLEAN,
			'starter_alert' => InputFilterer::BOOLEAN,
			'starter_alert_reason' => InputFilterer::STRING,
			'prefix_id' => InputFilterer::UNSIGNED,
		]);

		$redirectType = $this->filter('redirect_type', InputFilterer::STRING);
		if ($redirectType == 'permanent')
		{
			$options['redirect'] = true;
			$options['redirect_length'] = 0;
		}
		else if ($redirectType == 'temporary')
		{
			$options['redirect'] = true;
			$options['redirect_length'] = $this->filter('redirect_length', InputFilterer::TIME_OFFSET);
		}
		else
		{
			$options['redirect'] = false;
			$options['redirect_length'] = 0;
		}

		$mover = \XF::app()->service(MoverService::class, $discussion);

		if ($options['starter_alert'])
		{
			$mover->setSendAlert(true, $options['starter_alert_reason']);
		}

		if ($options['notify_watchers'])
		{
			$mover->setNotifyWatchers();
		}

		//		if ($options['redirect'])
		//		{
		//			$mover->setRedirect(true, $options['redirect_length']);
		//		}
		//
		//		if ($options['prefix_id'] !== null)
		//		{
		//			$mover->setPrefix($options['prefix_id']);
		//		}

		$mover->addExtraSetup(function (
			Discussion $discussion,
			?Section   $section,
			int        $newSectionId
		)
		{
			$discussion->title = $this->filter('title', InputFilterer::STRING);
		});

		return $mover;
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 * @throws PrintableException
	 * @throws DeadlockException
	 */
	public function actionMove(ParameterBag $params): AbstractReply
	{
		$discussion = $this->assertViewableDiscussion($params['discussion_id']);
		if (!$discussion->canMove($error))
		{
			return $this->noPermission($error);
		}
		$section = $discussion->Section;

		if ($this->isPost())
		{
			$targetSectionId = $this->filter('target_section_id', InputFilterer::UNSIGNED);
			$targetSection = null;

			if ($targetSectionId)
			{
				$targetSection = \XF::app()->em()->find(Section::class, $targetSectionId);
				if (!$targetSection || !$targetSection->canView())
				{
					return $this->error(\XF::phrase('dbtech_social_groups_requested_section_not_found'));
				}

				if ($targetSection->group_id !== $discussion->group_id)
				{
					return $this->error(\XF::phrase('dbtech_social_groups_target_section_not_same_group'));
				}
			}

			$this->setupDiscussionMove($discussion, $targetSection)->move($targetSection);

			return $this->redirect($this->buildLink('dbtech-social/discussions', $discussion));
		}

		$sectionRepo = \XF::app()->repository(SectionRepository::class);
		$sections = $sectionRepo->findSectionsInGroup($discussion->Group)->fetch()->filterViewable();

		$viewParams = [
			'discussion' => $discussion,
			'section' => $section,
			//			'prefixes' => $forum->getUsablePrefixes($discussion->Prefix),
			'sectionTree' => $sectionRepo->createSectionTree($sections),
		];
		return $this->view(
			View\Discussion\MoveView::class,
			'dbtech_social_groups_discussion_move',
			$viewParams
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionTags(ParameterBag $params): AbstractReply
	{
		$discussion = $this->assertViewableDiscussion($params['discussion_id']);
		if (!$discussion->canEditTags($error))
		{
			return $this->noPermission($error);
		}

		$tagger = \XF::app()->service(ChangerService::class, 'dbtech_social_discussion', $discussion);

		if ($this->isPost())
		{
			$tagger->setEditableTags($this->filter('tags', InputFilterer::STRING));
			if ($tagger->hasErrors())
			{
				return $this->error($tagger->getErrors());
			}

			$tagger->save();

			if ($this->filter('_xfInlineEdit', InputFilterer::BOOLEAN))
			{
				$viewParams = [
					'discussion' => $discussion,
				];
				$reply = $this->view(
					View\Discussion\TagsInlineView::class,
					'dbtech_social_groups_discussion_tags_list',
					$viewParams
				);
				$reply->setJsonParam('message', \XF::phrase('your_changes_have_been_saved'));
				return $reply;
			}
			else
			{
				return $this->redirect($this->buildLink('dbtech-social/discussions', $discussion));
			}
		}
		else
		{
			$grouped = $tagger->getExistingTagsByEditability();

			$viewParams = [
				'discussion'     => $discussion,
				'group'          => $discussion->Group,
				'editableTags'   => $grouped['editable'],
				'uneditableTags' => $grouped['uneditable'],
			];

			return $this->view(
				View\Discussion\TagsView::class,
				'dbtech_social_groups_discussion_tags',
				$viewParams
			);
		}
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 * @throws PrintableException
	 */
	public function actionWatch(ParameterBag $params): AbstractReply
	{
		$visitor = \XF::visitor();
		if (!$visitor->user_id)
		{
			return $this->noPermission();
		}

		$discussion = $this->assertViewableDiscussion($params['discussion_id']);
		if (!$discussion->canWatch($error))
		{
			return $this->noPermission($error);
		}

		if ($this->isPost())
		{
			if ($this->filter('stop', InputFilterer::BOOLEAN))
			{
				$newState = 'delete';
			}
			else if ($this->filter('email_subscribe', InputFilterer::BOOLEAN))
			{
				$newState = 'watch_email';
			}
			else
			{
				$newState = 'watch_no_email';
			}

			\XF::app()->repository(DiscussionWatchRepository::class)
				->setWatchState($discussion, $visitor, $newState)
			;

			$redirect = $this->redirect($this->buildLink('dbtech-social/discussions', $discussion));
			$redirect->setJsonParam('switchKey', $newState == 'delete' ? 'watch' : 'unwatch');
			return $redirect;
		}
		else
		{
			$viewParams = [
				'discussion' => $discussion,
				'isWatched' => !empty($discussion->Watch[$visitor->user_id]),
				'group' => $discussion->Group,
			];
			return $this->view(
				View\Discussion\WatchView::class,
				'dbtech_social_groups_discussion_watch',
				$viewParams
			);
		}
	}

	/**
	 * @param Discussion $discussion
	 *
	 * @return ReplyBanService|null
	 * @throws ReplyException
	 */
	protected function setupDiscussionReplyBan(
		Discussion $discussion
	): ?ReplyBanService
	{
		$input = $this->filter([
			'username' => InputFilterer::STRING,
			'ban_length' => InputFilterer::STRING,
			'ban_length_value' => InputFilterer::UNSIGNED,
			'ban_length_unit' => InputFilterer::STRING,

			'send_alert' => InputFilterer::BOOLEAN,
			'reason' => InputFilterer::STRING,
		]);

		if (!$input['username'])
		{
			return null;
		}

		$user = \XF::app()->finder(UserFinder::class)->where('username', $input['username'])->fetchOne();
		if (!$user)
		{
			throw $this->exception(
				$this->notFound(\XF::phrase('requested_user_x_not_found', ['name' => $input['username']]))
			);
		}

		$replyBanService = \XF::app()->service(ReplyBanService::class, $discussion, $user);

		if ($input['ban_length'] == 'temporary')
		{
			$replyBanService->setExpiryDate($input['ban_length_unit'], $input['ban_length_value']);
		}
		else
		{
			$replyBanService->setExpiryDate(0);
		}

		$replyBanService->setSendAlert($input['send_alert']);
		$replyBanService->setReason($input['reason']);

		return $replyBanService;
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 * @throws PrintableException
	 */
	public function actionReplyBans(ParameterBag $params): AbstractReply
	{
		$discussion = $this->assertViewableDiscussion($params['discussion_id']);
		if (!$discussion->canReplyBan($error))
		{
			return $this->noPermission($error);
		}

		if ($this->isPost())
		{
			$delete = $this->filter('delete', 'array-bool');
			$delete = array_filter($delete);

			$replyBanService = $this->setupDiscussionReplyBan($discussion);
			if ($replyBanService)
			{
				if (!$replyBanService->validate($errors))
				{
					return $this->error($errors);
				}

				$replyBanService->save();

				// don't try to delete the record we just added
				unset($delete[$replyBanService->getUser()->user_id]);
			}

			if ($delete)
			{
				$replyBans = $discussion->ReplyBans;
				foreach (array_keys($delete) AS $userId)
				{
					if (isset($replyBans[$userId]))
					{
						$replyBans[$userId]->delete();
					}
				}
			}

			return $this->redirect(
				$this->getDynamicRedirect(
					$this->buildLink('dbtech-social/discussions', $discussion),
					false
				)
			);
		}
		else
		{
			$replyBanFinder = \XF::app()->repository(DiscussionReplyBanRepository::class)
				->findReplyBansForDiscussion($discussion)
				->order('ban_date')
			;

			$viewParams = [
				'discussion' => $discussion,
				'group' => $discussion->Group,
				'bans' => $replyBanFinder->fetch(),
			];
			return $this->view(
				View\Discussion\ReplyBansView::class,
				'dbtech_social_groups_discussion_reply_bans',
				$viewParams
			);
		}
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionModeratorActions(ParameterBag $params): AbstractReply
	{
		$discussion = $this->assertViewableDiscussion($params['discussion_id']);
		if (!$discussion->canViewModeratorLogs($error))
		{
			return $this->noPermission($error);
		}

		$breadcrumbs = $discussion->getBreadcrumbs();
		$title = $discussion->title;

		$this->request()->set('page', $params['page']);

		$modLogPlugin = $this->plugin(ModeratorLogPlugin::class);
		return $modLogPlugin->actionModeratorActions(
			$discussion,
			['dbtech-social/discussions/moderator-actions', $discussion],
			$title,
			$breadcrumbs
		);
	}

	/**
	 * @param $discussionId
	 * @param array $extraWith
	 *
	 * @return Discussion
	 *
	 * @throws ReplyException
	 */
	protected function assertViewableDiscussion(
		$discussionId,
		array $extraWith = []
	): Discussion
	{
		$visitor = \XF::visitor();

		$extraWith[] = 'Group';
		$extraWith[] = 'Group.Permissions|' . $visitor->permission_combination_id;
		if ($visitor->user_id)
		{
			$extraWith[] = 'Read|' . $visitor->user_id;
			$extraWith[] = 'Group.Read|' . $visitor->user_id;
			$extraWith[] = 'Group.Members|' . $visitor->user_id;
		}

		$discussion = \XF::app()->em()->find(Discussion::class, $discussionId, $extraWith);
		if (!$discussion)
		{
			throw $this->exception($this->notFound(\XF::phrase('dbtech_social_groups_requested_discussion_not_found')));
		}

		if (!$discussion->canView($error))
		{
			throw $this->exception($this->noPermission($error));
		}

		$this->setContentKey('dbtech-social-discussion-' . $discussion->discussion_id);

		$this->groupContext = $discussion->Group;

		return $discussion;
	}

	/**
	 * @param Discussion $discussion
	 * @param null $forceAttachmentHash
	 *
	 * @return array|null
	 */
	protected function getReplyAttachmentData(
		Discussion $discussion,
		$forceAttachmentHash = null
	): ?array
	{
		/** @var Group $group */
		$group = $discussion->Group;

		if ($group && $group->canUploadAndManageAttachments())
		{
			if ($forceAttachmentHash !== null)
			{
				$attachmentHash = $forceAttachmentHash;
			}
			else
			{
				$attachmentHash = $discussion->draft_reply->attachment_hash;
			}

			return \XF::app()->repository(AttachmentRepository::class)
				->getEditorData('dbtech_social_message', $discussion, $attachmentHash)
			;
		}
		else
		{
			return null;
		}
	}

	/**
	 * @param Discussion $discussion
	 *
	 * @return EditorService $editor
	 */
	protected function getEditorService(
		Discussion $discussion
	): EditorService
	{
		return \XF::app()->service(EditorService::class, $discussion);
	}

	/**
	 * @param $action
	 * @param ParameterBag $params
	 * @param AbstractReply $reply
	 * @param $viewState
	 *
	 * @return bool
	 */
	protected function canUpdateSessionActivity(
		$action,
		ParameterBag $params,
		AbstractReply &$reply,
		&$viewState
	): bool
	{
		if (strtolower($action) == 'addreply')
		{
			$viewState = 'valid';
			return true;
		}
		return parent::canUpdateSessionActivity($action, $params, $reply, $viewState);
	}

	/**
	 * @param array $activities
	 *
	 * @return array
	 */
	public static function getActivityDetails(array $activities): array
	{
		return self::getActivityDetailsForContent(
			$activities,
			\XF::phrase('dbtech_social_groups_viewing_discussion'),
			'discussion_id',
			function (array $ids)
			{
				$discussions = \XF::app()->em()->findByIds(
					Discussion::class,
					$ids,
					['Group', 'Group.Permissions|' . \XF::visitor()->permission_combination_id]
				);

				$router = \XF::app()->router('public');
				$data = [];

				foreach ($discussions->filterViewable() AS $id => $discussion)
				{
					/** @var Discussion $discussion */
					$data[$id] = [
						'title' => $discussion->title,
						'url' => $router->buildLink('dbtech-social/discussions', $discussion),
					];
				}

				return $data;
			}
		);
	}

	public static function getResolvableActions(): array
	{
		return ['index', 'message'];
	}

	/**
	 * @param ParameterBag $params
	 * @param RouteMatch $routeMatch
	 *
	 * @return Message|Discussion|null
	 */
	public static function resolveToEmbeddableContent(ParameterBag $params, RouteMatch $routeMatch): Message|Discussion|null
	{
		$content = null;

		if ($params['message_id'] && $params['discussion_id'])
		{
			$content = \XF::em()->find(Message::class, $params['message_id']);
		}
		else if ($routeMatch->getAnchor() && preg_match('/^#message-(\d+)$/', $routeMatch->getAnchor(), $match))
		{
			$content = \XF::em()->find(Message::class, $match[1]);
		}
		else if ($params['discussion_id'])
		{
			$content = \XF::em()->find(Discussion::class, $params['discussion_id']);
		}

		if (!$content || !$content->canView())
		{
			$content = null;
		}

		return $content;
	}
}