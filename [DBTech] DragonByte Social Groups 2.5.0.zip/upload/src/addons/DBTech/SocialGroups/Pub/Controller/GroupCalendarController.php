<?php

namespace DBTech\SocialGroups\Pub\Controller;

use NF\Calendar\Pub\Controller\CalendarController;
use NF\Calendar\Pub\Controller\EventController;
use XF\Mvc\ParameterBag;
use XF\Mvc\Reply\AbstractReply;
use XF\Mvc\Reply\Exception as ReplyException;

class GroupCalendarController extends AbstractGroupController
{
	/**
	 * @param $action
	 * @param ParameterBag $params
	 *
	 * @return void
	 * @throws ReplyException
	 */
	protected function preDispatchController($action, ParameterBag $params): void
	{
		parent::preDispatchController($action, $params);

		if (!\XF::app()->options()->dbtechSocialEnableCalendar
			|| !\XF::isAddOnActive('NF/Calendar', 2060070)
		)
		{
			throw $this->exception($this->noPermission());
		}
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionIndex(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);

		if (!$group->calendar_id || !$group->Calendar)
		{
			return $this->notFound();
		}

		if (!$group->canViewCalendar())
		{
			return $this->noPermission();
		}

		if (!empty($params['event_id']))
		{
			return $this->rerouteController(EventController::class, 'view', $params);
		}

		$params->offsetSet('category_id', $group->calendar_id);
		return $this->rerouteController(CalendarController::class, 'index', $params);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionAdd(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);

		if (!$group->calendar_id || !$group->Calendar)
		{
			return $this->notFound();
		}

		$this->request->set('category_id', $group->calendar_id);
		return $this->rerouteController(EventController::class, 'add', $params);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionEdit(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);

		if (!$group->calendar_id || !$group->Calendar)
		{
			return $this->notFound();
		}

		return $this->rerouteController(EventController::class, 'edit', $params);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionField(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);

		if (!$group->calendar_id || !$group->Calendar)
		{
			return $this->notFound();
		}

		return $this->rerouteController(EventController::class, 'field', $params);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionResponses(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);

		if (!$group->calendar_id || !$group->Calendar)
		{
			return $this->notFound();
		}

		return $this->rerouteController(EventController::class, 'responses', $params);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionDates(ParameterBag $params): AbstractReply
	{
		$group = $this->assertViewableGroup($params['group_id']);

		if (!$group->calendar_id || !$group->Calendar)
		{
			return $this->notFound();
		}

		return $this->rerouteController(EventController::class, 'dates', $params);
	}
}