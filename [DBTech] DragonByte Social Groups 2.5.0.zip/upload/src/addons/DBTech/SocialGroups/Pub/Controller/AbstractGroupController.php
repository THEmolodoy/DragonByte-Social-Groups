<?php

namespace DBTech\SocialGroups\Pub\Controller;

use DBTech\SocialGroups\ControllerPlugin\GroupPlugin;
use DBTech\SocialGroups\ControllerPlugin\SectionPlugin;
use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Entity\GroupInvite;
use DBTech\SocialGroups\Entity\GroupMember;
use DBTech\SocialGroups\Entity\Section;
use DBTech\SocialGroups\Entity\Section as SectionEntity;
use GuzzleHttp\Exception\InvalidArgumentException;
use XF\Db\Exception as DbException;
use XF\Entity\User;
use XF\Mvc\ParameterBag;
use XF\Mvc\Reply\AbstractReply;
use XF\Mvc\Reply\Exception as ReplyException;
use XF\Mvc\Reply\Message;
use XF\Mvc\Reply\Redirect;
use XF\Mvc\Reply\View;
use XF\Pub\Controller\AbstractController;

abstract class AbstractGroupController extends AbstractController
{
	protected ?Group $groupContext = null;

	/**
	 * @param $action
	 *
	 * @return void
	 * @throws ReplyException
	 */
	public function assertViewingPermissions($action): void
	{
		parent::assertViewingPermissions($action);

		if (!\XF::visitor()->hasPermission('dbtechSocial', 'view'))
		{
			$reply = $this->noPermission();
			$reply->setPageParam('skipSidebarWidgets', true);

			throw $this->exception($reply);
		}
	}

	/**
	 * @param string $action
	 * @param ParameterBag $params
	 * @param AbstractReply $reply
	 *
	 * @return void
	 * @throws DbException
	 * @noinspection PhpMissingReturnTypeInspection
	 */
	protected function updateSessionActivity($action, ParameterBag $params, AbstractReply &$reply)
	{
		parent::updateSessionActivity($action, $params, $reply);

		if (!$this->canUpdateSocialGroupActivity($action, $params, $reply, $viewState))
		{
			return;
		}

		/** @var Group|null $group */
		$group = $this->groupContext;
		if (!$group)
		{
			return;
		}

		$db = \XF::db();

		$columnData = [
			'last_activity_date = ' . $db->quote(\XF::$time),
		];

		if (($this instanceof DiscussionController) && strtolower($action) == 'addreply')
		{
			$columnData[] = 'last_message_date = ' . $db->quote(\XF::$time);
		}

		$db->query('
			-- XFDB=noForceAllWrite
			UPDATE xf_dbtech_social_groups_group_member
			SET ' . implode(', ', $columnData) . '
			WHERE group_id = ?
				AND user_id = ?
		', [
			$group->group_id,
			\XF::visitor()->user_id,
		]);
	}

	/**
	 * @param string $action
	 * @param ParameterBag $params
	 * @param AbstractReply $reply
	 * @param string|null $viewState
	 *
	 * @return bool
	 */
	protected function canUpdateSocialGroupActivity(
		string $action,
		ParameterBag $params,
		AbstractReply &$reply,
		?string &$viewState
	): bool
	{
		// don't update session activity for an AJAX request
		if ($this->request->isXhr())
		{
			return false;
		}

		$viewState = 'error';

		switch (get_class($reply))
		{
			case Redirect::class:
				return false; // don't update anything, assume the next page will do it

			case Message::class:
			case View::class:
				$viewState = 'valid';
				break;
		}

		if ($reply->getResponseCode() >= 400)
		{
			$viewState = 'error';
		}

		return true;
	}

	/**
	 * @param int|null $groupId
	 * @param array $extraWith
	 *
	 * @return Group
	 *
	 * @throws ReplyException
	 */
	protected function assertGroupExists(?int $groupId, array $extraWith = []): Group
	{
		return $this->plugin(GroupPlugin::class)->assertGroupExists($groupId, $extraWith);
	}

	/**
	 * @param int|null $id
	 * @param array $with
	 * @param string|null $phraseKey
	 *
	 * @return Section
	 * @throws ReplyException
	 */
	protected function assertSectionExists(?int $id, array $with = [], ?string $phraseKey = null): SectionEntity
	{
		return $this->assertRecordExists(SectionEntity::class, $id, $with, $phraseKey);
	}

	/**
	 * @param int|null $groupId
	 * @param array $extraWith
	 *
	 * @return Group
	 *
	 * @throws ReplyException
	 */
	protected function assertViewableGroup(?int $groupId, array $extraWith = []): Group
	{
		$this->groupContext = $this->plugin(GroupPlugin::class)
			->assertViewableGroup($groupId, $extraWith)
		;
		return $this->groupContext;
	}

	/**
	 * @param int|null $sectionId
	 * @param array $extraWith
	 *
	 * @return Section
	 *
	 * @throws ReplyException
	 */
	protected function assertViewableSection(?int $sectionId, array $extraWith = []): SectionEntity
	{
		return $this->plugin(SectionPlugin::class)->assertViewableSection($sectionId, $extraWith);
	}

	/**
	 * @return void
	 * @throws ReplyException
	 */
	protected function assertValidSettings(): void
	{
		try
		{
			\json_decode(
				\XF::options()->dbtechSocialDefaultPermissions['groupOwner'],
				true
			);
			\json_decode(
				\XF::options()->dbtechSocialDefaultPermissions['groupModerators'],
				true
			);
		}
		catch (InvalidArgumentException $e)
		{
			throw $this->errorException(\XF::phrase('dbtech_social_groups_permission_settings_not_configured'));
		}
	}

	/**
	 * @param int|null $id
	 * @param array $with
	 * @param null|string $phraseKey
	 *
	 * @return GroupMember
	 * @throws ReplyException
	 */
	protected function assertGroupMemberExists(?int $id, array $with = [], ?string $phraseKey = null): GroupMember
	{
		return $this->assertRecordExists(GroupMember::class, $id, $with, $phraseKey);
	}

	/**
	 * @param int|null $id
	 * @param array $with
	 * @param null|string $phraseKey
	 *
	 * @return GroupInvite
	 * @throws ReplyException
	 */
	protected function assertGroupInviteExists(?int $id, array $with = [], ?string $phraseKey = null): GroupInvite
	{
		return $this->assertRecordExists(GroupInvite::class, $id, $with, $phraseKey);
	}

	/**
	 * @param int|null $id
	 * @param array $with
	 * @param null|string $phraseKey
	 *
	 * @return User
	 * @throws ReplyException
	 */
	protected function assertUserExists(?int $id, array $with = [], ?string $phraseKey = null): User
	{
		return $this->assertRecordExists(User::class, $id, $with, $phraseKey);
	}
}