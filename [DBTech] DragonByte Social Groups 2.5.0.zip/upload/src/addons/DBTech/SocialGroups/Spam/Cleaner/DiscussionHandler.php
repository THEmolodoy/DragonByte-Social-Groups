<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\Spam\Cleaner;

use DBTech\SocialGroups\Entity\Discussion;
use DBTech\SocialGroups\Finder\DiscussionFinder;
use XF\PrintableException;
use XF\Spam\Cleaner\AbstractHandler;

class DiscussionHandler extends AbstractHandler
{
	/**
	 * @param array $options
	 *
	 * @return bool
	 */
	public function canCleanUp(array $options = [])
	{
		return !empty($options['action_discussions']);
	}

	/**
	 * @param array $log
	 * @param $error
	 *
	 * @return bool
	 * @throws PrintableException
	 */
	public function cleanUp(array &$log, &$error = null)
	{
		$app = \XF::app();

		$discussionsFinder = \XF::app()->finder(DiscussionFinder::class);
		$discussions = $discussionsFinder->where('user_id', $this->user->user_id)->fetch();

		if ($discussions->count())
		{
			$submitter = $app->container('spam.contentSubmitter');
			$submitter->submitSpam('dbtech_social_discussion', $discussions->keys());

			$action = $app->options()->dbtechSocialSpamDiscussionAction;
			$deleteType = ($action['action'] == 'delete' ? 'hard' : 'soft');

			$log['dbtech_social_discussion'] = [
				'action' => 'deleted',
				'deleteType' => $deleteType,
				'discussionIds' => [],
			];

			foreach ($discussions AS $discussionId => $discussion)
			{
				/** @var Discussion $discussion */
				if ($discussion->isDeleted())
				{
					// Probably a redirect, which would've been deleted when its target was deleted.
					continue;
				}

				$log['dbtech_social_discussion']['discussionIds'][] = $discussionId;

				$discussion->setOption('log_moderator', false);
				if ($deleteType == 'soft')
				{
					$discussion->softDelete();
				}
				else
				{
					$discussion->delete();
				}
			}
		}

		return true;
	}

	/**
	 * @param array $log
	 * @param $error
	 *
	 * @return bool
	 * @throws PrintableException
	 */
	public function restore(array $log, &$error = null)
	{
		if ($log['deleteType'] == 'soft')
		{
			$discussionsFinder = \XF::app()->finder(DiscussionFinder::class);
			$discussions = $discussionsFinder->where('discussion_id', $log['discussionIds'])->fetch();
			foreach ($discussions AS $discussion)
			{
				/** @var Discussion $discussion */
				$discussion->setOption('log_moderator', false);
				$discussion->discussion_state = 'visible';
				$discussion->save();
			}
		}

		return true;
	}
}