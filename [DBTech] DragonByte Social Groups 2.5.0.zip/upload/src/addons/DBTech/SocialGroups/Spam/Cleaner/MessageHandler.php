<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\Spam\Cleaner;

use DBTech\SocialGroups\Entity\Message;
use DBTech\SocialGroups\Finder\MessageFinder;
use XF\PrintableException;
use XF\Spam\Cleaner\AbstractHandler;

class MessageHandler extends AbstractHandler
{
	/**
	 * @param array $options
	 *
	 * @return bool
	 */
	public function canCleanUp(array $options = [])
	{
		return !empty($options['delete_messages']);
	}

	/**
	 * @param array $log
	 * @param $error
	 *
	 * @return bool
	 * @throws PrintableException
	 */
	public function cleanUp(array &$log, &$error = null)
	{
		$app = \XF::app();

		$messagesFinder = \XF::app()->finder(MessageFinder::class);
		$messages = $messagesFinder
			->with('Discussion', true)
			->where('user_id', $this->user->user_id)
			->isNotFirstMessage()
			->fetch();

		if ($messages->count())
		{
			$messageIds = $messages->pluckNamed('message_id');
			$submitter = $app->container('spam.contentSubmitter');
			$submitter->submitSpam('dbtech_social_message', $messageIds);

			$deleteType = $app->options()->spamMessageAction == 'delete' ? 'hard' : 'soft';

			$log['dbtech_social_message'] = [
				'deleteType' => $deleteType,
				'messageIds' => [],
			];

			foreach ($messages AS $messageId => $message)
			{
				$log['dbtech_social_message']['messageIds'][] = $messageId;

				/** @var Message $message */
				$message->setOption('log_moderator', false);
				if ($deleteType == 'soft')
				{
					$message->softDelete();
				}
				else
				{
					$message->delete();
				}
			}
		}

		return true;
	}

	/**
	 * @param array $log
	 * @param $error
	 *
	 * @return bool
	 * @throws PrintableException
	 */
	public function restore(array $log, &$error = null)
	{
		$messagesFinder = \XF::app()->finder(MessageFinder::class);

		if ($log['deleteType'] == 'soft')
		{
			$messages = $messagesFinder->where('message_id', $log['messageIds'])->fetch();
			foreach ($messages AS $message)
			{
				/** @var Message $message */
				$message->setOption('log_moderator', false);
				$message->message_state = 'visible';
				$message->save();
			}
		}

		return true;
	}
}