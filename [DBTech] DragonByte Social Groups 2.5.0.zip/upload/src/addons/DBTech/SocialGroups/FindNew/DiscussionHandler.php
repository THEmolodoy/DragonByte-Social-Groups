<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\FindNew;

use DBTech\SocialGroups\Entity\Discussion;
use DBTech\SocialGroups\Finder\DiscussionFinder;
use DBTech\SocialGroups\Pub\View\WhatsNew\MessagesView;
use XF\Entity\FindNew;
use XF\FindNew\AbstractHandler;
use XF\Http\Request;
use XF\InputFilterer;
use XF\Mvc\Controller;
use XF\Mvc\Entity\AbstractCollection;
use XF\Mvc\Reply\AbstractReply;

/**
 * @extends AbstractHandler<Discussion>
 */
class DiscussionHandler extends AbstractHandler
{
	/**
	 * @return string
	 */
	public function getRoute()
	{
		// This returns discussions, so we attach to the discussion content type. However, as it's really individual messages
		// that generally bump things up, we refer to this in the interface as "new messages".
		return 'whats-new/dbtech-social-messages';
	}

	/**
	 * @param Controller $controller
	 * @param FindNew $findNew
	 * @param array $results
	 * @param $page
	 * @param $perPage
	 *
	 * @return AbstractReply
	 */
	public function getPageReply(Controller $controller, FindNew $findNew, array $results, $page, $perPage)
	{
		$canInlineMod = false;

		/** @var Discussion $discussion */
		foreach ($results AS $discussion)
		{
			if ($discussion->canUseInlineModeration())
			{
				$canInlineMod = true;
				break;
			}
		}

		$viewParams = [
			'findNew' => $findNew,

			'page' => $page,
			'perPage' => $perPage,

			'discussions' => $results,
			'canInlineMod' => $canInlineMod,
		];
		return $controller->view(
			MessagesView::class,
			'dbtech_social_groups_whats_new_messages',
			$viewParams
		);
	}

	/**
	 * @param Request $request
	 *
	 * @return array
	 */
	public function getFiltersFromInput(Request $request)
	{
		$filters = [];

		$visitor = \XF::visitor();

		$unread = $request->filter('unread', InputFilterer::BOOLEAN);
		if ($unread && $visitor->user_id)
		{
			$filters['unread'] = true;
		}

		$watched = $request->filter('watched', InputFilterer::BOOLEAN);
		if ($watched && $visitor->user_id)
		{
			$filters['watched'] = true;
		}

		$participated = $request->filter('participated', InputFilterer::BOOLEAN);
		if ($participated && $visitor->user_id)
		{
			$filters['participated'] = true;
		}

		$started = $request->filter('started', InputFilterer::BOOLEAN);
		if ($started && $visitor->user_id)
		{
			$filters['started'] = true;
		}

		$unanswered = $request->filter('unanswered', InputFilterer::BOOLEAN);
		if ($unanswered)
		{
			$filters['unanswered'] = true;
		}

		return $filters;
	}

	/**
	 * @return array|bool[]
	 */
	public function getDefaultFilters()
	{
		$visitor = \XF::visitor();

		if ($visitor->user_id)
		{
			return ['unread' => true];
		}
		else
		{
			return [];
		}
	}

	/**
	 * @param array $filters
	 * @param int $maxResults
	 *
	 * @return int[]|string[]
	 */
	public function getResultIds(array $filters, $maxResults)
	{
		$visitor = \XF::visitor();

		$discussionFinder = \XF::app()->finder(DiscussionFinder::class)
			->with('Group', true)
			->with('Group.Permissions|' . $visitor->permission_combination_id)
			->where('Group.find_new', true)
			->where('discussion_type', '<>', 'redirect')
			->where('discussion_state', '<>', 'deleted')
			->order('last_message_date', 'DESC');

		$this->applyFilters($discussionFinder, $filters);

		$discussions = $discussionFinder->fetch($maxResults);
		$discussions = $this->filterResults($discussions);

		// TODO: consider overfetching or some other permission limits within the query

		return $discussions->keys();
	}

	/**
	 * @param array $ids
	 *
	 * @return AbstractCollection
	 */
	public function getPageResultsEntities(array $ids): AbstractCollection
	{
		$visitor = \XF::visitor();

		$ids = array_map('intval', $ids);

		return \XF::app()->finder(DiscussionFinder::class)
			->where('discussion_id', $ids)
			->with('fullGroup')
			->with('Group.Permissions|' . $visitor->permission_combination_id)
			->fetch()
		;
	}

	/**
	 * @param AbstractCollection $results
	 *
	 * @return AbstractCollection
	 */
	protected function filterResults(AbstractCollection $results): AbstractCollection
	{
		return $results->filter(function (Discussion $discussion)
		{
			return ($discussion->canView() && !$discussion->isIgnored());
		});
	}

	/**
	 * @param DiscussionFinder $discussionFinder
	 * @param array $filters
	 */
	protected function applyFilters(DiscussionFinder $discussionFinder, array $filters)
	{
		$visitor = \XF::visitor();

		if (!empty($filters['unread']))
		{
			$discussionFinder->unreadOnly($visitor->user_id);
		}
		else
		{
			$discussionFinder->where(
				'last_message_date',
				'>',
				\XF::$time - (86400 * \XF::options()->readMarkingDataLifetime)
			);
		}

		if (!empty($filters['watched']))
		{
			$discussionFinder->watchedOnly($visitor->user_id);
		}

		if (!empty($filters['participated']))
		{
			$discussionFinder->exists('UserMessages|' . $visitor->user_id);
		}

		if (!empty($filters['started']))
		{
			$discussionFinder->where('user_id', $visitor->user_id);
		}

		if (!empty($filters['unanswered']))
		{
			$discussionFinder->where('reply_count', 0);
		}
	}

	/**
	 * @return int
	 */
	public function getResultsPerPage()
	{
		return \XF::options()->discussionsPerPage;
	}
}