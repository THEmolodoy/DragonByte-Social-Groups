<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\FindNew;

use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Finder\GroupFinder;
use DBTech\SocialGroups\Pub\View\WhatsNew\GroupsView;
use XF\Entity\FindNew;
use XF\FindNew\AbstractHandler;
use XF\Http\Request;
use XF\InputFilterer;
use XF\Mvc\Controller;
use XF\Mvc\Entity\AbstractCollection;
use XF\Mvc\Reply\AbstractReply;

/**
 * @extends AbstractHandler<Group>
 */
class GroupHandler extends AbstractHandler
{
	/**
	 * @return string
	 */
	public function getRoute()
	{
		return 'whats-new/dbtech-social-groups';
	}

	/**
	 * @param Controller $controller
	 * @param FindNew $findNew
	 * @param array $results
	 * @param $page
	 * @param $perPage
	 *
	 * @return AbstractReply
	 */
	public function getPageReply(Controller $controller, FindNew $findNew, array $results, $page, $perPage)
	{
		$viewParams = [
			'findNew' => $findNew,

			'page' => $page,
			'perPage' => $perPage,

			'groups' => $results,
		];
		return $controller->view(
			GroupsView::class,
			'dbtech_social_groups_whats_new_groups',
			$viewParams
		);
	}

	/**
	 * @param Request $request
	 *
	 * @return array
	 */
	public function getFiltersFromInput(Request $request)
	{
		$filters = [];

		$visitor = \XF::visitor();

		$unread = $request->filter('unread', InputFilterer::BOOLEAN);
		if ($unread && $visitor->user_id)
		{
			$filters['unread'] = true;
		}

		$watched = $request->filter('watched', InputFilterer::BOOLEAN);
		if ($watched && $visitor->user_id)
		{
			$filters['watched'] = true;
		}

		$created = $request->filter('created', InputFilterer::BOOLEAN);
		if ($created && $visitor->user_id)
		{
			$filters['created'] = true;
		}

		return $filters;
	}

	/**
	 * @return array|bool[]
	 */
	public function getDefaultFilters()
	{
		$visitor = \XF::visitor();

		if ($visitor->user_id)
		{
			return ['unread' => true];
		}
		else
		{
			return [];
		}
	}

	/**
	 * @param array $filters
	 * @param int $maxResults
	 *
	 * @return int[]|string[]
	 */
	public function getResultIds(array $filters, $maxResults)
	{
		$visitor = \XF::visitor();

		$groupFinder = \XF::app()->finder(GroupFinder::class)
			->with('Permissions|' . $visitor->permission_combination_id)
			->where('find_new', true)
			->order('creation_date', 'DESC');

		$this->applyFilters($groupFinder, $filters);

		$groups = $groupFinder->fetch($maxResults);
		$groups = $this->filterResults($groups);

		// TODO: consider overfetching or some other permission limits within the query

		return $groups->keys();
	}

	/**
	 * @param array $ids
	 *
	 * @return AbstractCollection
	 */
	public function getPageResultsEntities(array $ids): AbstractCollection
	{
		$visitor = \XF::visitor();

		$ids = array_map('intval', $ids);

		$groupFinder = \XF::app()->finder(GroupFinder::class)
			->where('group_id', $ids)
			->with('full')
			->with('Permissions|' . $visitor->permission_combination_id);

		return $groupFinder->fetch();
	}

	/**
	 * @param AbstractCollection $results
	 *
	 * @return AbstractCollection
	 */
	protected function filterResults(AbstractCollection $results): AbstractCollection
	{
		return $results->filter(function (Group $group)
		{
			return ($group->canView() && !$group->isIgnored());
		});
	}

	/**
	 * @param GroupFinder $groupFinder
	 * @param array $filters
	 */
	protected function applyFilters(GroupFinder $groupFinder, array $filters)
	{
		$visitor = \XF::visitor();

		if (!empty($filters['unread']))
		{
			$groupFinder->unreadOnly($visitor->user_id);
		}
		else
		{
			$groupFinder->where(
				'last_message_date',
				'>',
				\XF::$time - (86400 * \XF::options()->readMarkingDataLifetime)
			);
		}

		if (!empty($filters['watched']))
		{
			$groupFinder->watchedOnly($visitor->user_id);
		}

		if (!empty($filters['owned']))
		{
			$groupFinder->where('user_id', $visitor->user_id);
		}
	}

	/**
	 * @return int
	 */
	public function getResultsPerPage()
	{
		return \XF::options()->dbtechSocialGroupsPerPage;
	}
}