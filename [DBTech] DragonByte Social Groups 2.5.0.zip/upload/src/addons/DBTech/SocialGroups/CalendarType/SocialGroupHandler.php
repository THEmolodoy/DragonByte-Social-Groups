<?php

namespace DBTech\SocialGroups\CalendarType;

use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Pub\View\Group\CalendarView;
use NF\Calendar\CalendarType\AbstractHandler;
use NF\Calendar\Entity\Calendar;
use XF\Api\Result\EntityResult;
use XF\Http\Request;
use XF\InputFiltererArray;
use XF\Mvc\Entity\ArrayValidator;
use XF\Mvc\Entity\Entity;
use XF\Mvc\FormAction;
use XF\Mvc\Reply\View;
use XF\Phrase;

/**
 * @extends AbstractHandler<Group>
 */
class SocialGroupHandler extends AbstractHandler
{
	/**
	 * @inheritDoc
	 */
	public function getDefaultEventType(Calendar $calendar): string
	{
		return 'dbtech_social_group';
	}

	/**
	 * @inheritDoc
	 */
	public function getTypeTitle(): Phrase
	{
		return \XF::phrase('dbtech_social_groups_calendar_type.' . $this->type);
	}

	/**
	 * @inheritDoc
	 */
	public function getTypeDescription(): Phrase
	{
		return \XF::phrase('dbtech_social_groups_calendar_type_desc.' . $this->type);
	}

	/**
	 * @inheritDoc
	 */
	public function getDefaultTypeConfig(): array
	{
		return [
			'group_id' => 0,
		];
	}

	/**
	 * @inheritDoc
	 */
	protected function getTypeConfigColumnDefinitions(): array
	{
		return [
			'group_id' => ['type' => Entity::UINT],
		];
	}

	/**
	 * @inheritDoc
	 */
	public function setupTypeConfigEdit(
		View $reply,
		Calendar $calendar,
		array &$typeConfig
	): ?string
	{
		$group = null;
		if (!empty($typeConfig['group_id']))
		{
			$group = \XF::app()->em()->find(Group::class, $typeConfig['group_id']);
		}

		$reply->setParams([
			'group' => $group,
		]);

		return 'dbtech_social_groups_calendar_type_config';
	}

	/**
	 * @inheritDoc
	 */
	public function setupTypeConfigSave(FormAction $form, Calendar $calendar, Request $request): array|ArrayValidator
	{
		$validator = $this->getTypeConfigValidator($calendar);
		$validator->group_id = $request->filter('type_config.group_id', 'uint');

		return $validator;
	}

	/**
	 * @inheritDoc
	 */
	public function setupTypeConfigApiSave(
		FormAction $form,
		Calendar $calendar,
		InputFiltererArray $typeInputFilterer
	): array|ArrayValidator
	{
		$validator = $this->getTypeConfigValidator($calendar);

		$groupId = $typeInputFilterer->filter('type_config.group_id', '?uint');
		if ($groupId !== null)
		{
			$validator->group_id = $groupId;
		}

		return $validator;
	}

	/**
	 * @inheritDoc
	 */
	public function addTypeConfigToApiResult(
		Calendar $calendar,
		EntityResult $result,
		int $verbosity = Entity::VERBOSITY_NORMAL,
		array $options = []
	): void
	{
		$result->socialGroup = [
			'group_id' => $calendar->type_config['group_id'],
		];
	}

	/**
	 * @inheritDoc
	 */
	public function getCalendarLink(
		Calendar $calendar,
		string $path = '',
		bool $canonical = false,
		array $linkParams = []
	): string
	{
		$group = \XF::app()->em()->find(Group::class, $calendar->type_config['group_id']);

		return \XF::app()->router('public')->buildLink(
			($canonical ? 'canonical:dbtech-social/calendar' : 'dbtech-social/calendar') . ($path ? '/' : '') . $path,
			$group,
			$linkParams
		);
	}

	/**
	 * @inheritDoc
	 */
	public function getCalendarViewAndTemplate(Calendar $calendar): array
	{
		return [
			CalendarView::class,
			'dbtech_social_groups_group_calendar',
		];
	}

	/**
	 * @inheritDoc
	 */
	public function adjustCalendarViewParams(Calendar $calendar, array $viewParams, Request $request): array
	{
		$group = \XF::app()->em()->find(Group::class, $calendar->type_config['group_id']);
		$viewParams['group'] = $group;

		return $viewParams;
	}

	public function hasCalendarPermission(Calendar $calendar, string $permission): bool
	{
		$group = \XF::app()->em()->find(Group::class, $calendar->type_config['group_id']);

		return match ($permission)
		{
			'view' => $group->canViewCalendar(),
			'create' => $group->canCreateCalendarEvent(),
			default => parent::hasCalendarPermission($calendar, $permission),
		};
	}
}