<?php

namespace DBTech\SocialGroups\Admin\View\Delete;

use XF\Mvc\View;

class StateView extends View
{
}