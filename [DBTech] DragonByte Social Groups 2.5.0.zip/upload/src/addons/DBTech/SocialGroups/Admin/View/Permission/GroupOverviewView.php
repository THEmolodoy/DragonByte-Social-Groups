<?php

namespace DBTech\SocialGroups\Admin\View\Permission;

use XF\Mvc\View;

class GroupOverviewView extends View
{
}