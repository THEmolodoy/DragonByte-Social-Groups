<?php

namespace DBTech\SocialGroups\Admin\View\Discussion\ReplyBan;

use XF\Mvc\View;

class ListingView extends View
{
}