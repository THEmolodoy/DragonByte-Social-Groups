<?php

namespace DBTech\SocialGroups\Admin\View\Group;

use XF\Mvc\View;

class ListingView extends View
{
}