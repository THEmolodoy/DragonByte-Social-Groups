<?php

namespace DBTech\SocialGroups\Admin\View\Options;

use XF\Mvc\View;

class DefaultPermissionsView extends View
{
}