<?php

namespace DBTech\SocialGroups\Admin\View;

use XF\Mvc\View;

class IndexView extends View
{
}