<?php

namespace DBTech\SocialGroups\Admin\View\Group;

use XF\Mvc\View;

class ReassignView extends View
{
}