<?php

namespace DBTech\SocialGroups\Admin\View\Section;

use XF\Mvc\View;

class EditView extends View
{
}