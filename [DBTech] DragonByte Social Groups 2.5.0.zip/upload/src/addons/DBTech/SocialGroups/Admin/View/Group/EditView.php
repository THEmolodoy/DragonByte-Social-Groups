<?php

namespace DBTech\SocialGroups\Admin\View\Group;

use XF\Mvc\View;

class EditView extends View
{
}