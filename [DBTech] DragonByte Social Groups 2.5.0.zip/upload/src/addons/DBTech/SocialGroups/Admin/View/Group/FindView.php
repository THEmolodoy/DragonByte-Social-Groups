<?php

namespace DBTech\SocialGroups\Admin\View\Group;

use DBTech\SocialGroups\Entity\Group;
use XF\Mvc\View;

class FindView extends View
{
	/**
	 * @return array{
	 *     results: array<string, array{
	 *         id: string,
	 *         text: string,
	 *         q: string,
	 *         desc?: string,
	 *         icon?: string,
	 *         iconHtml?: string,
	 *     }>,
	 *     q: string,
	 * }
	 */
	public function renderJson(): array
	{
		$templater = $this->renderer->getTemplater();

		$results = [];

		/** @var Group $group */
		foreach ($this->params['groups'] AS $group)
		{
			$iconArgs = [$group, 'xs'];

			$formatter = \XF::app()->stringFormatter();
			$string = $formatter->snippetString($group->tagline, 100, ['stripQuote' => true]);

			$results[] = [
				'id' => $group->group_id,
				'iconHtml' => $templater->func('dbtech_social_groups_group_icon', $iconArgs, false),
				'text' => $group->title,
				'q' => $this->params['q'],
				'desc' => $string,
			];
		}

		return [
			'results' => $results,
			'q' => $this->params['q'],
		];
	}
}