<?php

namespace DBTech\SocialGroups\Admin\Controller;

use DBTech\SocialGroups\Admin\View;
use DBTech\SocialGroups\Entity\DiscussionReplyBan;
use DBTech\SocialGroups\Repository\DiscussionReplyBanRepository;
use XF\Admin\Controller\AbstractController;
use XF\ControllerPlugin\DeletePlugin;
use XF\Entity\User;
use XF\Finder\UserFinder;
use XF\InputFilterer;
use XF\Mvc\ParameterBag;
use XF\Mvc\Reply\AbstractReply;
use XF\Mvc\Reply\Exception as ReplyException;

class DiscussionController extends AbstractController
{
	/**
	 * @param $action
	 * @param ParameterBag $params
	 *
	 * @return void
	 * @throws ReplyException
	 */
	protected function preDispatchController($action, ParameterBag $params): void
	{
		$this->assertAdminPermission('dbtechSocial');
	}

	/**
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionReplyBans(): AbstractReply
	{
		$replyBanRepo = \XF::app()->repository(DiscussionReplyBanRepository::class);
		$replyBanFinder = $replyBanRepo->findReplyBansForList();

		$user = null;
		$linkParams = [];
		if ($username = $this->filter('username', InputFilterer::STRING))
		{
			/** @var User $user */
			$user = \XF::app()->finder(UserFinder::class)->where('username', $username)->fetchOne();
			if ($user)
			{
				$replyBanFinder->where('user_id', $user->user_id);
				$linkParams['username'] = $user->username;
			}
		}

		$page = $this->filterPage();
		$perPage = 25;

		$replyBanFinder->limitByPage($page, $perPage);
		$total = $replyBanFinder->total();

		$this->assertValidPage($page, $perPage, $total, 'dbtech-social/discussions/reply-bans');

		$viewParams = [
			'bans' => $replyBanFinder->fetch(),
			'user' => $user,

			'page' => $page,
			'perPage' => $perPage,
			'total' => $total,

			'linkParams' => $linkParams,
		];
		return $this->view(
			View\Discussion\ReplyBan\ListingView::class,
			'dbtech_social_groups_discussion_reply_ban_list',
			$viewParams
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionReplyBansDelete(ParameterBag $params): AbstractReply
	{
		$replyBan = $this->assertReplyBanExists($params->discussion_reply_ban_id);

		$plugin = $this->plugin(DeletePlugin::class);
		return $plugin->actionDelete(
			$replyBan,
			$this->buildLink('dbtech-social/discussions/reply-bans/delete', $replyBan),
			null,
			$this->buildLink('dbtech-social/discussions/reply-bans'),
			"{$replyBan->Discussion->title} - {$replyBan->User->username}"
		);
	}

	/**
	 * @param int|null $id
	 * @param array $extraWith
	 * @param null|string $phraseKey
	 *
	 * @return DiscussionReplyBan
	 * @throws ReplyException
	 */
	protected function assertReplyBanExists(?int $id, array $extraWith = [], ?string $phraseKey = null): DiscussionReplyBan
	{
		$extraWith[] = 'Discussion';
		$extraWith[] = 'User';
		return $this->assertRecordExists(DiscussionReplyBan::class, $id, $extraWith, $phraseKey);
	}
}