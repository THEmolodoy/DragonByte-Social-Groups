<?php

namespace DBTech\SocialGroups\Admin\Controller;

use DBTech\SocialGroups\Admin\View;
use XF\Admin\Controller\AbstractController;
use XF\Mvc\Reply\AbstractReply;
use XF\Mvc\Reply\Exception as ReplyException;

class IndexController extends AbstractController
{
	/**
	 * @return AbstractReply
	 */
	public function actionIndex(): AbstractReply
	{
		return $this->view(
			View\IndexView::class,
			'dbtech_social_groups'
		);
	}

	/**
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionMaintenance(): AbstractReply
	{
		$this->setSectionContext('dbtechSocialMaintenance');
		$this->assertAdminPermission('rebuildCache');

		return $this->view(
			View\MaintenanceView::class,
			'dbtech_social_groups_maintenance'
		);
	}
}