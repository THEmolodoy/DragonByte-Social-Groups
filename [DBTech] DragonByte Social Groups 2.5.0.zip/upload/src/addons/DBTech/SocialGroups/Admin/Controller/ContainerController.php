<?php

namespace DBTech\SocialGroups\Admin\Controller;

use XF\Admin\Controller\AbstractNode;

class ContainerController extends AbstractNode
{
	protected function getNodeTypeId(): string
	{
		return 'DBTechSocialContainer';
	}

	protected function getDataParamName(): string
	{
		return 'container';
	}

	protected function getTemplatePrefix(): string
	{
		return 'dbtech_social_groups_container';
	}

	protected function getViewClassPrefix(): string
	{
		return 'DBTech\SocialGroups:Container';
	}
}