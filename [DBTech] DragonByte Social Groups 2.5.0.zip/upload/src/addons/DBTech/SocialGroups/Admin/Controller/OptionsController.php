<?php

namespace DBTech\SocialGroups\Admin\Controller;

use DBTech\SocialGroups\Admin\View;
use XF\Admin\Controller\AbstractController;
use XF\InputFilterer;
use XF\Mvc\Reply\AbstractReply;
use XF\Repository\ModeratorRepository;
use XF\Repository\OptionRepository;

class OptionsController extends AbstractController
{
	/**
	 * @return AbstractReply
	 */
	public function actionGroupOwner(): AbstractReply
	{
		return $this->defaultPermissionsEdit('groupOwner');
	}

	/**
	 * @return AbstractReply
	 */
	public function actionGroupModerators(): AbstractReply
	{
		return $this->defaultPermissionsEdit('groupModerators');
	}

	/**
	 * @param string $subOption
	 *
	 * @return AbstractReply
	 */
	protected function defaultPermissionsEdit(string $subOption): AbstractReply
	{
		if ($this->isPost())
		{
			$defaultPermissions = \XF::app()->options()->dbtechSocialDefaultPermissions;
			$defaultPermissions[$subOption] = \json_encode([
				//				'globalPermissions' => $this->filter('globalPermissions', InputFilterer::ARRAY),
				'contentPermissions' => $this->filter('contentPermissions', InputFilterer::ARRAY),
			]);

			\XF::app()->repository(OptionRepository::class)
				->updateOption('dbtechSocialDefaultPermissions', $defaultPermissions)
			;

			return $this->redirect($this->getDynamicRedirect());
		}

		$moderatorPermissionData = \XF::app()->repository(ModeratorRepository::class)
			->getModeratorPermissionData('dbtech_social_group')
		;

		$viewParams = [
			'action' => $subOption,

			'existingValues' => \json_decode(
				\XF::app()->options()->dbtechSocialDefaultPermissions[$subOption] ?: '[]',
				true
			),

			'interfaceGroups' => $moderatorPermissionData['interfaceGroups'],
			'globalPermissions' => $moderatorPermissionData['globalPermissions'],
			'contentPermissions' => $moderatorPermissionData['contentPermissions'],
		];
		return $this->view(
			View\Options\DefaultPermissionsView::class,
			'dbtech_social_groups_options_default_permissions',
			$viewParams
		);
	}
}