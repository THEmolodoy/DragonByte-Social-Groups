<?php

namespace DBTech\SocialGroups\Admin\Controller;

use DBTech\SocialGroups\Admin\View;
use DBTech\SocialGroups\ControllerPlugin\DeletePlugin;
use DBTech\SocialGroups\ControllerPlugin\GroupPermissionPlugin;
use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Entity\Section;
use DBTech\SocialGroups\Finder\GroupFinder;
use DBTech\SocialGroups\Finder\SectionFinder;
use DBTech\SocialGroups\Repository\GroupMemberRepository;
use DBTech\SocialGroups\Repository\SectionRepository;
use DBTech\SocialGroups\Service\Group\ReassignService;
use XF\Admin\Controller\AbstractController;
use XF\Behavior\TreeStructured;
use XF\ControllerPlugin\EditorPlugin;
use XF\ControllerPlugin\SortPlugin;
use XF\Entity\Option;
use XF\Entity\User;
use XF\Finder\UserFinder;
use XF\InputFilterer;
use XF\Mvc\FormAction;
use XF\Mvc\ParameterBag;
use XF\Mvc\Reply\AbstractReply;
use XF\Mvc\Reply\Exception as ReplyException;
use XF\PrintableException;
use XF\Repository\ModeratorRepository;
use XF\Service\Tag\ChangerService;

use function intval, strlen;

class GroupController extends AbstractController
{
	/**
	 * @param $action
	 * @param ParameterBag $params
	 *
	 * @throws ReplyException
	 */
	protected function preDispatchController($action, ParameterBag $params): void
	{
		$this->assertAdminPermission('dbtechSocial');

		switch (\strtolower($action))
		{
			case 'sections':
			case 'sectionsadd':
			case 'sectionsedit':
				if (!\XF::app()->options()->dbtechSocialGroupsEnableSections)
				{
					throw $this->exception($this->notFound());
				}
				break;
		}
	}

	/**
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionIndex(): AbstractReply
	{
		$page = $this->filterPage();
		$perPage = 20;

		$groupFinder = \XF::app()->finder(GroupFinder::class)
			->order('title')
			->limitByPage($page, $perPage)
		;

		$filter = $this->filter('_xfFilter', [
			'text' => InputFilterer::STRING,
			'prefix' => InputFilterer::BOOLEAN,
		]);
		if (strlen($filter['text']))
		{
			$groupFinder->where(
				$groupFinder->columnUtf8('title'),
				'LIKE',
				$groupFinder->escapeLike($filter['text'], $filter['prefix'] ? '?%' : '%?%')
			);
		}

		$total = $groupFinder->total();
		$this->assertValidPage($page, $perPage, $total, 'dbtech-social/groups');

		$groups = $groupFinder->fetch();
		$groupIds = $groups->keys();

		//		if (empty($groupIds) && strlen($filter['text']))
		//		{
		//			return $this->error(\XF::phrase('dbtech_social_groups_there_no_groups_matching_your_filters'));
		//		}

		$moderators = \XF::app()->repository(ModeratorRepository::class)
			->findContentModeratorsForList()
			->where('content_type', 'dbtechSocial')
			->where('content_id', $groupIds)
			->fetch()->groupBy('content_id');

		$sections = \XF::app()->finder(SectionFinder::class)
			->where('group_id', $groupIds)
			->fetch()->groupBy('group_id');

		$ids = [];
		if (!empty($groupIds))
		{
			$db = \XF::db();
			$ids = $db->fetchAllColumn("
				SELECT DISTINCT content_id
				FROM xf_permission_entry_content
				WHERE content_type = ?
					AND content_id IN(" . $db->quote($groupIds) . ")
			", 'dbtech_social_group');
		}

		$customPermissions = array_fill_keys($ids, true);

		$options = \XF::app()->em()->find(Option::class, 'dbtechSocialGroupsEnableSections');

		$viewParams = [
			'groups' => $groups,
			'sections' => $sections,
			'moderators' => $moderators,
			'customPermissions' => $customPermissions,

			'page' => $page,
			'perPage' => $perPage,
			'total' => $total,

			'options' => [$options],
		];
		return $this->view(
			View\Group\ListingView::class,
			'dbtech_social_groups_group_list',
			$viewParams
		);
	}

	/**
	 * @param Group $group
	 *
	 * @return AbstractReply
	 */
	protected function groupAddEdit(Group $group): AbstractReply
	{
		if ($group->exists())
		{
			$tagger = \XF::app()->service(ChangerService::class, 'dbtech_social_group', $group);
			$grouped = $tagger->getExistingTagsByEditability();
		}
		else
		{
			$grouped = [
				'editable' => null,
				'uneditable' => null,
			];
		}

		$viewParams = [
			'group' => $group,
			'editableTags' => $grouped['editable'],
			'uneditableTags' => $grouped['uneditable'],
			'groupOwner' => $group->exists() ? $group->User : \XF::visitor(),
		];
		return $this->view(
			View\Group\EditView::class,
			'dbtech_social_groups_group_edit',
			$viewParams
		);
	}

	/**
	 * @return AbstractReply
	 */
	public function actionAdd(): AbstractReply
	{
		return $this->groupAddEdit(
			\XF::app()->em()->create(Group::class)
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionEdit(ParameterBag $params): AbstractReply
	{
		$group = $this->assertGroupExists($params['group_id']);
		return $this->groupAddEdit($group);
	}

	/**
	 * @param Group $group
	 *
	 * @return FormAction
	 */
	protected function groupSaveProcess(Group $group): FormAction
	{
		$group->setOption('admin_edit', true);

		$form = $this->formAction();

		$input = $this->filter([
			'title' => InputFilterer::STRING,
			'tagline' => InputFilterer::STRING,

			'language_code' => InputFilterer::STRING,
			'text_direction' => InputFilterer::STRING,
			'group_state' => InputFilterer::STRING,
			'group_type' => InputFilterer::STRING,
			'sticky' => InputFilterer::BOOLEAN,
			'count_messages' => InputFilterer::BOOLEAN,
			'allow_posting' => InputFilterer::BOOLEAN,
			'allow_discussions' => InputFilterer::BOOLEAN,
			'allow_poll' => InputFilterer::BOOLEAN,
			'allow_members' => InputFilterer::BOOLEAN,
			'moderate_members' => InputFilterer::BOOLEAN,
			'moderate_discussions' => InputFilterer::BOOLEAN,
			'moderate_replies' => InputFilterer::BOOLEAN,
			'find_new' => InputFilterer::BOOLEAN,
			'allowed_watch_notifications' => InputFilterer::STRING,
			'default_sort_order' => InputFilterer::STRING,
			'default_sort_direction' => InputFilterer::STRING,
			'list_date_limit_days' => InputFilterer::UNSIGNED,
			//			'default_prefix_id' => InputFilterer::UNSIGNED,
			//			'require_prefix' => InputFilterer::BOOLEAN,
			'min_tags' => InputFilterer::UNSIGNED,
		]);

		if (\XF::options()->dbtechSocialEnableCalendar && \XF::isAddOnActive('NF/Calendar', 2060070))
		{
			$input['enable_calendar'] = $this->filter('enable_calendar', InputFilterer::BOOLEAN);
			$input['event_creation'] = $this->filter('event_creation', InputFilterer::STRING, 'group_owner');
		}

		$editorPlugin = $this->plugin(EditorPlugin::class);
		$input['description'] = $editorPlugin->fromInput('description');
		$input['rules'] = $editorPlugin->fromInput('rules');

		if (!$group->exists())
		{
			$userName = $this->filter('username', InputFilterer::STRING);

			$user = \XF::app()->finder(UserFinder::class)->where('username', $userName)->fetchOne();
			if (!$user)
			{
				$form->logError(\XF::phrase('requested_user_x_not_found', ['name' => $userName]));
			}
			else
			{
				$input['user_id'] = $user->user_id;
				$input['username'] = $user->username;
			}
		}

		$form->basicEntitySave($group, $input);

		$tags = $this->filter('tags', InputFilterer::STRING);
		$form->complete(function () use ($group, $tags)
		{
			$tagger = \XF::app()->service(ChangerService::class, 'dbtech_social_group', $group);
			$tagger->setEditableTags($tags);
			if (!$tagger->hasErrors())
			{
				$tagger->save();
			}
		});

		return $form;
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 * @throws PrintableException
	 */
	public function actionSave(ParameterBag $params): AbstractReply
	{
		if ($params['group_id'])
		{
			$group = $this->assertGroupExists($params['group_id']);
		}
		else
		{
			$group = \XF::app()->em()->create(Group::class);
		}

		$this->groupSaveProcess($group)->run();

		return $this->redirect($this->buildLink('dbtech-social/groups') . $this->buildLinkHash($group->group_id));
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionSections(ParameterBag $params): AbstractReply
	{
		$group = $this->assertGroupExists($params['group_id']);

		$sectionRepo = \XF::app()->repository(SectionRepository::class);
		$sectionTree = $sectionRepo->createSectionTree($sectionRepo->findSectionsInGroup($group)->fetch());

		$viewParams = [
			'group' => $group,
			'sectionTree' => $sectionTree,
		];
		return $this->view(
			View\Section\ListingView::class,
			'dbtech_social_groups_group_sections_list',
			$viewParams
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionSectionsSort(ParameterBag $params): AbstractReply
	{
		$group = $this->assertGroupExists($params['group_id']);

		$sectionRepo = \XF::app()->repository(SectionRepository::class);
		$sectionTree = $sectionRepo->createSectionTree($sectionRepo->findSectionsInGroup($group)->fetch());

		if ($this->isPost())
		{
			$sorter = $this->plugin(SortPlugin::class);
			$sortTree = $sorter->buildSortTree($this->filter('sections', InputFilterer::JSON_ARRAY));
			$sorter->sortTree($sortTree, $sectionTree->getAllData(), 'parent_section_id');

			return $this->redirect($this->buildLink('dbtech-social/groups/sections', $group));
		}

		$viewParams = [
			'group' => $group,
			'sectionTree' => $sectionTree,
		];
		return $this->view(
			View\Section\SortView::class,
			'dbtech_social_groups_group_sections_sort',
			$viewParams
		);
	}

	/**
	 * @param Section $section
	 *
	 * @return AbstractReply
	 */
	protected function sectionAddEdit(Section $section): AbstractReply
	{
		$sectionRepo = \XF::app()->repository(SectionRepository::class);
		$sectionTree = $sectionRepo->createSectionTree($sectionRepo->findSectionsInGroup($section->Group)->fetch());

		$viewParams = [
			'section' => $section,
			'group' => $section->Group,
			'sectionTree' => $sectionTree,
		];
		return $this->view(
			View\Section\EditView::class,
			'dbtech_social_groups_group_section_edit',
			$viewParams
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionSectionsAdd(ParameterBag $params): AbstractReply
	{
		$group = $this->assertGroupExists($params['group_id']);

		$section = \XF::app()->em()->create(Section::class);
		$section->hydrateRelation('Group', $group);

		// Will validate in the drop-down, so no need for manual validation
		$section->parent_section_id = $this->filter('parent_section_id', InputFilterer::UNSIGNED);

		if (empty($section->parent_section_id))
		{
			$section->display_order = intval(\XF::app()->db()->fetchOne('
				SELECT MAX(`display_order`) 
				FROM `xf_dbtech_social_groups_section` 
				WHERE `group_id` = ?
			', $group->group_id)) + 10;
		}

		return $this->sectionAddEdit($section);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionSectionsEdit(ParameterBag $params): AbstractReply
	{
		$group = $this->assertGroupExists($params['group_id']);

		$section = $this->assertSectionExists($this->filter('section_id', InputFilterer::UNSIGNED));
		return $this->sectionAddEdit($section);
	}

	/**
	 * @param Section $section
	 *
	 * @return FormAction
	 */
	protected function sectionSaveProcess(Section $section): FormAction
	{
		$form = $this->formAction();

		$input = $this->filter([
			'title' => InputFilterer::STRING,
			'description' => InputFilterer::STRING,
			'display_order' => InputFilterer::UNSIGNED,

			'parent_section_id' => InputFilterer::UNSIGNED,
			'staff_only' => InputFilterer::BOOLEAN,
			'count_messages' => InputFilterer::BOOLEAN,
			'allow_posting' => InputFilterer::BOOLEAN,
			'allow_discussions' => InputFilterer::BOOLEAN,
			'allow_poll' => InputFilterer::BOOLEAN,
			'moderate_discussions' => InputFilterer::BOOLEAN,
			'moderate_replies' => InputFilterer::BOOLEAN,
			'find_new' => InputFilterer::BOOLEAN,
			'allowed_watch_notifications' => InputFilterer::STRING,
			'default_sort_order' => InputFilterer::STRING,
			'default_sort_direction' => InputFilterer::STRING,
			'list_date_limit_days' => InputFilterer::UNSIGNED,
			//			'default_prefix_id' => InputFilterer::UNSIGNED,
			//			'require_prefix' => InputFilterer::BOOLEAN,
			'min_tags' => InputFilterer::UNSIGNED,
		]);

		$form->basicEntitySave($section, $input);

		return $form;
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 * @throws PrintableException
	 */
	public function actionSectionsSave(ParameterBag $params): AbstractReply
	{
		$group = $this->assertGroupExists($params['group_id']);

		$sectionId = $this->filter('section_id', InputFilterer::UNSIGNED);
		if ($sectionId)
		{
			$section = $this->assertSectionExists($sectionId);
		}
		else
		{
			$section = \XF::app()->em()->create(Section::class);
			$section->group_id = $group->group_id;

			$section->hydrateRelation('Group', $group);
		}

		$this->sectionSaveProcess($section)->run();

		return $this->redirect($this->buildLink('dbtech-social/groups/sections', $group) . $this->buildLinkHash($section->section_id));
	}

	/**
	 * @param Section $section
	 *
	 * @return void
	 * @throws PrintableException
	 */
	protected function sectionDelete(Section $section): void
	{
		$section->delete();
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 * @throws PrintableException
	 */
	public function actionSectionsDelete(ParameterBag $params): AbstractReply
	{
		$group = $this->assertGroupExists($params['group_id']);
		$section = $this->assertSectionExists($this->filter('section_id', InputFilterer::UNSIGNED));

		if (!$section->preDelete())
		{
			return $this->error($section->getErrors());
		}

		if ($this->isPost())
		{
			$childAction = $this->filter('child_sections_action', InputFilterer::STRING);
			$section->getBehavior(TreeStructured::class)->setOption('deleteChildAction', $childAction);

			$this->sectionDelete($section);
			return $this->redirect($this->buildLink('dbtech-social/groups/sections', $group));
		}
		else
		{
			$sectionRepo = \XF::app()->repository(SectionRepository::class);

			$sectionTree = $sectionRepo->createSectionTree($sectionRepo->findSectionsInGroup($section->Group)->fetch());
			$sectionTree = $sectionTree->filter(function ($sectionId) use ($section)
			{
				// Filter out the current section from the section tree.
				return !($sectionId == $section->section_id);
			});

			$viewParams = [
				'group' => $group,
				'section' => $section,
				'sectionTree' => $sectionTree,
			];
			return $this->view(
				View\Section\DeleteView::class,
				'dbtech_social_groups_group_section_delete',
				$viewParams
			);
		}
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws \LogicException
	 * @throws ReplyException
	 * @throws \Exception
	 * @throws PrintableException
	 */
	public function actionReassign(ParameterBag $params): AbstractReply
	{
		$group = $this->assertGroupExists($params['group_id']);

		if ($this->isPost())
		{
			$userName = $this->filter('username', InputFilterer::STRING);

			$user = \XF::app()->em()->findOne(User::class, ['username' => $userName]);
			if (!$user)
			{
				return $this->error(\XF::phrase('requested_user_x_not_found', ['name' => $userName]));
			}

			if (!$user->isMemberOfSocialGroup($group))
			{
				$user->setOption('override_social_group_moderation', true);

				\XF::app()->repository(GroupMemberRepository::class)
					->joinGroup($group, $user)
				;
			}

			$reassigner = \XF::app()->service(ReassignService::class, $group);

			if ($this->filter('alert', InputFilterer::BOOLEAN))
			{
				$reassigner->setSendAlert(true, $this->filter('alert_reason', InputFilterer::STRING));
			}

			$reassigner->reassignTo($user);

			return $this->redirect($this->buildLink('dbtech-social/groups', $group) . $this->buildLinkHash($group->group_id));
		}

		$viewParams = [
			'group' => $group,
		];
		return $this->view(
			View\Group\ReassignView::class,
			'dbtech_social_groups_group_reassign',
			$viewParams
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionDelete(ParameterBag $params): AbstractReply
	{
		$group = $this->assertGroupExists($params['group_id']);

		/** @var DeletePlugin $plugin */
		$plugin = $this->plugin(DeletePlugin::class);
		return $plugin->actionDeleteWithState(
			$group,
			'group_state',
			'DBTech\SocialGroups:Group\Delete',
			'dbtech_social_group',
			$this->buildLink('dbtech-social/groups/delete', $group),
			$this->buildLink('dbtech-social/groups/edit', $group),
			$this->buildLink('dbtech-social/groups'),
			$group->title,
			true,
			false
		);
	}

	/**
	 * @return AbstractReply
	 */
	public function actionAutoComplete(): AbstractReply
	{
		$q = ltrim($this->filter('q', InputFilterer::STRING, ['no-trim']));

		if ($q !== '' && \mb_strlen($q) >= 2)
		{
			$groupFinder = \XF::app()->finder(GroupFinder::class)
				->searchTitleForAutoComplete($q)
			;

			$groups = $groupFinder->fetch();
		}
		else
		{
			$groups = [];
			$q = '';
		}

		$viewParams = [
			'q' => $q,
			'groups' => $groups,
		];
		return $this->view(
			View\Group\FindView::class,
			'',
			$viewParams
		);
	}

	/**
	 * @param int|null $id
	 * @param array $with
	 * @param string|null $phraseKey
	 *
	 * @return Group
	 * @throws ReplyException
	 */
	protected function assertGroupExists(?int $id, array $with = [], ?string $phraseKey = null): Group
	{
		return $this->assertRecordExists(Group::class, $id, $with, $phraseKey);
	}

	/**
	 * @param int|null $id
	 * @param array $with
	 * @param string|null $phraseKey
	 *
	 * @return Section
	 * @throws ReplyException
	 */
	protected function assertSectionExists(?int $id, array $with = [], ?string $phraseKey = null): Section
	{
		return $this->assertRecordExists(Section::class, $id, $with, $phraseKey);
	}

	/**
	 * @return GroupPermissionPlugin
	 */
	protected function getGroupPermissionPlugin(): GroupPermissionPlugin
	{
		/** @var GroupPermissionPlugin $plugin */
		$plugin = $this->plugin(GroupPermissionPlugin::class);
		$plugin->setFormatters('DBTech\SocialGroups:Group\Permission%s', 'dbtech_social_groups_group_permission_%s');
		$plugin->setRoutePrefix('dbtech-social/groups/permissions');

		return $plugin;
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 */
	public function actionPermissions(ParameterBag $params): AbstractReply
	{
		return $this->getGroupPermissionPlugin()->actionList($params);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 */
	public function actionPermissionsEdit(ParameterBag $params): AbstractReply
	{
		return $this->getGroupPermissionPlugin()->actionEdit($params);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 */
	public function actionPermissionsSave(ParameterBag $params): AbstractReply
	{
		return $this->getGroupPermissionPlugin()->actionSave($params);
	}
}