<?php

namespace DBTech\SocialGroups\Admin\Controller;

use DBTech\SocialGroups\Admin\View;
use DBTech\SocialGroups\ControllerPlugin\GroupPermissionPlugin;
use DBTech\SocialGroups\Repository\GroupRepository;
use XF\Admin\Controller\AbstractController;
use XF\Mvc\ParameterBag;
use XF\Mvc\Reply\AbstractReply;
use XF\Mvc\Reply\Exception as ReplyException;
use XF\Repository\PermissionEntryRepository;

class PermissionController extends AbstractController
{
	/**
	 * @param $action
	 * @param ParameterBag $params
	 *
	 * @throws ReplyException
	 */
	protected function preDispatchController($action, ParameterBag $params): void
	{
		$this->assertAdminPermission('dbtechSocial');
	}

	/**
	 * @return GroupPermissionPlugin
	 */
	protected function getGroupPermissionPlugin(): GroupPermissionPlugin
	{
		/** @var GroupPermissionPlugin $plugin */
		$plugin = $this->plugin(GroupPermissionPlugin::class);
		$plugin->setFormatters('DBTech\SocialGroups:Permission\Group%s', 'dbtech_social_groups_permission_group_%s');
		$plugin->setRoutePrefix('permissions/dbtech-social-groups');

		return $plugin;
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 */
	public function actionGroup(ParameterBag $params): AbstractReply
	{
		if ($params->group_id)
		{
			return $this->getGroupPermissionPlugin()->actionList($params);
		}

		$groups = \XF::app()->repository(GroupRepository::class)
			->findGroupsForList()
			->fetch()
		;

		$customPermissions = \XF::app()->repository(PermissionEntryRepository::class)
			->getContentWithCustomPermissions('dbtech_social_group')
		;

		$viewParams = [
			'groups' => $groups,
			'customPermissions' => $customPermissions,
		];
		return $this->view(
			View\Permission\GroupOverviewView::class,
			'dbtech_social_groups_permission_group_overview',
			$viewParams
		);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 */
	public function actionGroupEdit(ParameterBag $params): AbstractReply
	{
		return $this->getGroupPermissionPlugin()->actionEdit($params);
	}

	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 */
	public function actionGroupSave(ParameterBag $params): AbstractReply
	{
		return $this->getGroupPermissionPlugin()->actionSave($params);
	}
}