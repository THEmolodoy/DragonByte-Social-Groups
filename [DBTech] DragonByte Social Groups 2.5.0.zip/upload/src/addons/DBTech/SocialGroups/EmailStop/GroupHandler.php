<?php

namespace DBTech\SocialGroups\EmailStop;

use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Repository\DiscussionWatchRepository;
use DBTech\SocialGroups\Repository\GroupWatchRepository;
use XF\EmailStop\AbstractHandler;
use XF\Entity\User;
use XF\Phrase;
use XF\PrintableException;

class GroupHandler extends AbstractHandler
{
	/**
	 * @param User $user
	 * @param $contentId
	 *
	 * @return Phrase|null
	 * @throws \Exception
	 */
	public function getStopOneText(User $user, $contentId): ?Phrase
	{
		$group = \XF::app()->em()->find(Group::class, $contentId);
		$canView = \XF::asVisitor(
			$user,
			function () use ($group) { return $group && $group->canView(); }
		);

		if ($canView)
		{
			return \XF::phrase('stop_notification_emails_from_x', ['title' => $group->title]);
		}
		else
		{
			return null;
		}
	}

	/**
	 * @param User $user
	 *
	 * @return Phrase
	 */
	public function getStopAllText(User $user): Phrase
	{
		return \XF::phrase('dbtech_social_groups_stop_notification_emails_from_all_discussions');
	}

	/**
	 * @param User $user
	 * @param $contentId
	 *
	 * @throws PrintableException
	 */
	public function stopOne(User $user, $contentId): void
	{
		$group = \XF::app()->em()->find(Group::class, $contentId);
		if ($group)
		{
			\XF::app()->repository(GroupWatchRepository::class)
				->setWatchState($group, $user, null, null, false)
			;
		}
	}

	/**
	 * @param User $user
	 */
	public function stopAll(User $user): void
	{
		// Note that we stop all discussion and group notifications here, as the distinction of the source is unlikely
		// to be clear and they've chosen to stop all emails of this type.

		\XF::app()->repository(DiscussionWatchRepository::class)
			->setWatchStateForAll($user, 'no_email')
		;

		\XF::app()->repository(GroupWatchRepository::class)
			->setWatchStateForAll($user, 'no_email')
		;
	}
}