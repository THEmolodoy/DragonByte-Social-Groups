<?php

namespace DBTech\SocialGroups\EditHistory;

use DBTech\SocialGroups\Entity\Message;
use DBTech\SocialGroups\Service\Message\EditorService;
use XF\EditHistory\AbstractHandler;
use XF\Entity\EditHistory;
use XF\Mvc\Entity\Entity;
use XF\Mvc\Router;

/**
 * @extends AbstractHandler<Message>
 */
class MessageHandler extends AbstractHandler
{
	public function canViewHistory(Entity $content): bool
	{
		return ($content->canView() && $content->canViewHistory());
	}

	public function canRevertContent(Entity $content)
	{
		return $content->canEdit();
	}

	public function getContentText(Entity $content)
	{
		return $content->message;
	}

	public function getBreadcrumbs(Entity $content)
	{
		/** @var Router $router */
		$router = \XF::app()->container('router');

		$breadcrumbs = $content->Discussion->Group->getBreadcrumbs();
		$breadcrumbs[] = [
			'value' => $content->Discussion->title,
			'href' => $router->buildLink('dbtech-social/discussions', $content->Discussion),
		];
		return $breadcrumbs;
	}

	public function revertToVersion(
		Entity $content,
		EditHistory $history,
		?EditHistory $previous = null
	)
	{
		$editor = \XF::app()->service(EditorService::class, $content);

		$editor->logEdit(false);
		$editor->setIsAutomated();
		$editor->setMessageContent($history->old_text);

		if (!$previous || $previous->edit_user_id != $content->user_id)
		{
			$content->last_edit_date = 0;
		}
		else if ($previous->edit_user_id == $content->user_id)
		{
			$content->last_edit_date = $previous->edit_date;
			$content->last_edit_user_id = $previous->edit_user_id;
		}

		return $editor->save();
	}

	public function getHtmlFormattedContent($text, ?Entity $content = null): mixed
	{
		return \XF::app()->templater()->func('bb_code', [$text, 'dbtech_social_message', $content]);
	}

	public function getSectionContext(): string
	{
		return 'dbtechSocial';
	}

	public function getEntityWith(): array
	{
		$visitor = \XF::visitor();
		return [
			'Discussion',
			'Discussion.Group',
			'Discussion.Group.Permissions|' . $visitor->permission_combination_id,
		];
	}
}