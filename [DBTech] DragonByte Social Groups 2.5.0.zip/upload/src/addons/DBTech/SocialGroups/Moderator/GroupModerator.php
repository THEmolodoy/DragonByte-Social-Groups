<?php

namespace DBTech\SocialGroups\Moderator;

use DBTech\SocialGroups\Repository\GroupRepository;
use XF\Moderator\AbstractModerator;

class GroupModerator extends AbstractModerator
{
	protected ?array $groupTitleCache = null;

	/**
	 * Gets the option for the moderator add "choice" page.
	 * @see AbstractModerator::getAddModeratorOption()
	 */
	public function getAddModeratorOption($selectedContentId, $contentType): array
	{
		return [
			'choices' => \XF::app()->repository(GroupRepository::class)
				->getGroupOptionsData(false)
			,
			'label' => \XF::phrase('dbtech_social_groups_group_moderator') . ':',
			'name' => \XF::escapeString("type_id[$contentType]"),
			'value' => $selectedContentId,
		];
	}

	/**
	 * Gets the titles of multiple pieces of content.
	 * @see AbstractModerator::getContentTitles()
	 */
	public function getContentTitles(array $ids): array
	{
		if ($this->groupTitleCache === null)
		{
			$groups = \XF::app()->repository(GroupRepository::class)
				->getFullGroupListCached('GroupModerator')
				->toArray()
			;
			$this->groupTitleCache = [];
			foreach ($groups AS $key => $group)
			{
				$this->groupTitleCache[$key] = \XF::phrase('dbtech_social_groups_social_group') . " - $group[title]";
			}
		}

		$titles = [];
		foreach ($ids AS $key => $id)
		{
			if (isset($this->groupTitleCache[$id]))
			{
				$titles[$key] = $this->groupTitleCache[$id];
			}
		}

		return $titles;
	}
}