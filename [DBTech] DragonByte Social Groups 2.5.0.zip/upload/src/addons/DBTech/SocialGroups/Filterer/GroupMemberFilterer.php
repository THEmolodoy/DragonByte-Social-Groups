<?php

namespace DBTech\SocialGroups\Filterer;

use DBTech\SocialGroups\Finder\GroupMemberFinder;
use XF\Filterer\AbstractFilterer;
use XF\Finder\UserFinder;
use XF\InputFilterer;
use XF\Mvc\Entity\Finder;

use function in_array;

class GroupMemberFilterer extends AbstractFilterer
{
	protected string $defaultOrder = 'username';
	protected string $defaultDirection = 'asc';

	protected array $validSorts = [
		'username' => true,
		'join_date' => true,
		'last_activity_date' => true,
		'last_message_date' => true,
		'last_media_upload_date' => true,
		'last_event_creation_date' => true,
		'message_count' => true,
		'album_count' => true,
		'media_count' => true,
		'event_count' => true,
		'member_state' => true,
		'random' => '__random__',
	];

	public function __construct(array $setupData = [])
	{
		parent::__construct($setupData);

		$this->defaultOrder = \XF::app()->options()->dbtechSocialMemberListDefaultOrder ?: 'username';
		$this->defaultDirection = $this->defaultOrder == 'username' ? 'asc' : 'desc';
	}

	/**
	 * @inheritDoc
	 * @noinspection PhpMissingReturnTypeInspection
	 */
	protected function initFinder(Finder $finder, array $setupData)
	{
		/** @var GroupMemberFinder $finder */

		$finder->with(['User', 'User.Profile', 'User.Option'])
			->where('group_id', $setupData['group_id'])
//			->isValidMember()
			->isValidUser()
			->useDefaultOrder()
		;
	}

	protected function getFinderType(): string
	{
		return GroupMemberFinder::class;
	}

	protected function getFilterTypeMap(): array
	{
		return [
			'username' => InputFilterer::STRING,
			'user_id' => InputFilterer::UNSIGNED,

			'joined_after' => InputFilterer::DATETIME,
			'joined_before' => InputFilterer::DATETIME,

			'order' => InputFilterer::STRING,
			'direction' => InputFilterer::STRING,
		];
	}

	protected function getLookupTypeList(): array
	{
		return [
			'order',
		];
	}

	protected function onFinalize(): void
	{
		/** @var GroupMemberFinder $finder */
		$finder = $this->finder;

		$sorts = $this->validSorts;
		$order = $this->rawFilters['order'] ?? null;
		$direction = $this->rawFilters['direction'] ?? null;

		if ($order && isset($sorts[$order]))
		{
			if (!in_array($direction, ['asc', 'desc']))
			{
				$direction = 'desc';
			}

			$defaultOrder = $this->defaultOrder;
			$defaultDirection = $this->defaultDirection;

			if ($order != $defaultOrder || $direction != $defaultDirection)
			{
				if ($sorts[$order] === true)
				{
					if ($order === 'username')
					{
						$finder->orderUsername($direction);
					}
					else
					{
						$finder->order($order, $direction);
					}
				}
				else if ($sorts[$order] == '__random__')
				{
					$finder->order($finder->expression('RAND()'));
				}
				else
				{
					$finder->order($sorts[$order], $direction);
				}

				$this->addLinkParam('order', $order);
				$this->addLinkParam('direction', $direction);
				$this->addDisplayValue('order', $order . '_' . $direction);
			}
		}
	}

	/**
	 * @param string $filterName
	 * @param $value
	 * @param $displayValue
	 *
	 * @return bool
	 * @throws \Exception
	 */
	protected function applyFilter(string $filterName, &$value, &$displayValue): bool
	{
		/** @var GroupMemberFinder $finder */
		$finder = $this->finder;

		switch ($filterName)
		{
			case 'username':
				if (!$value)
				{
					return false;
				}

				$user = \XF::finder(UserFinder::class)->where('username', $value)->fetchOne();
				if (!$user)
				{
					return false;
				}
				$finder->where('user_id', $user->user_id);
				return true;

			case 'user_id':
				if (!$value)
				{
					return false;
				}

				$finder->where('user_id', $value);
				return true;

			case 'joined_after':
			case 'joined_before':
				if (!$value)
				{
					return false;
				}

				$lookup = [
					'joined_after' => ['>=', 'join_date'],
					'joined_before' => ['<', 'join_date'],
				];

				$finder->where($lookup[$filterName][1], $lookup[$filterName][0], $value);
				$displayValue = \XF::language()->date($value);
				return true;
		}

		return false;
	}

	protected function getFormDefaults(): array
	{
		return [
			'order' => $this->defaultOrder,
			'direction' => $this->defaultDirection,
		];
	}
}