<?php

namespace DBTech\SocialGroups\Attachment;

use DBTech\SocialGroups\Entity\Discussion;
use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Entity\Message;
use DBTech\SocialGroups\Entity\Section;
use XF\Attachment\AbstractHandler;
use XF\Entity\Attachment;
use XF\Mvc\Entity\Entity;
use XF\PrintableException;
use XF\Repository\AttachmentRepository;

use function intval;

class MessageHandler extends AbstractHandler
{
	/**
	 * @return string[]
	 */
	public function getContainerWith(): array
	{
		$visitor = \XF::visitor();

		return [
			'Discussion',
			'Discussion.Group',
			'Discussion.Group.Permissions|' . $visitor->permission_combination_id,
		];
	}

	/**
	 * @param Attachment $attachment
	 * @param Entity $container
	 * @param $error
	 *
	 * @return bool
	 */
	public function canView(Attachment $attachment, Entity $container, &$error = null): bool
	{
		/** @var Message $container */
		if (!$container->canView())
		{
			return false;
		}

		/** @var Discussion $discussion */
		$discussion = $container->Discussion;
		return $discussion->canViewAttachments($error);
	}

	/**
	 * @param array $context
	 * @param $error
	 *
	 * @return bool
	 */
	public function canManageAttachments(array $context, &$error = null): bool
	{
		$group = $this->getGroupFromContext($context);
		return ($group && $group->canUploadAndManageAttachments());
	}

	/**
	 * @param Attachment $attachment
	 * @param Entity|null $container
	 *
	 * @throws PrintableException
	 */
	public function onAttachmentDelete(Attachment $attachment, ?Entity $container = null): void
	{
		if (!$container)
		{
			return;
		}

		/** @var Message $container */
		$container->attach_count--;
		$container->save();

		\XF::app()->logger()->logModeratorAction($this->contentType, $container, 'attachment_deleted', [], false);
	}

	/**
	 * @param array $context
	 *
	 * @return array
	 */
	public function getConstraints(array $context): array
	{
		$attachRepo = \XF::app()->repository(AttachmentRepository::class);

		$constraints = $attachRepo->getDefaultAttachmentConstraints();

		$group = $this->getGroupFromContext($context);
		if ($group && $group->canUploadVideos())
		{
			$constraints = $attachRepo->applyVideoAttachmentConstraints($constraints);
		}

		return $constraints;
	}

	/**
	 * @param array $context
	 *
	 * @return int|null
	 */
	public function getContainerIdFromContext(array $context): ?int
	{
		return isset($context['message_id']) ? intval($context['message_id']) : null;
	}

	/**
	 * @param Entity|null $entity
	 * @param array $extraContext
	 *
	 * @return array
	 */
	public function getContext(?Entity $entity = null, array $extraContext = []): array
	{
		if ($entity instanceof Message)
		{
			$extraContext['message_id'] = $entity->message_id;
		}
		else if ($entity instanceof Discussion)
		{
			$extraContext['discussion_id'] = $entity->discussion_id;
		}
		else if ($entity instanceof Section)
		{
			$extraContext['section_id'] = $entity->section_id;
		}
		else if ($entity instanceof Group)
		{
			$extraContext['group_id'] = $entity->group_id;
		}
		else
		{
			throw new \InvalidArgumentException("Entity must be message, discussion, section or group");
		}

		return $extraContext;
	}

	/**
	 * @param array $context
	 *
	 * @return Group|null
	 */
	protected function getGroupFromContext(array $context): ?Group
	{
		$group = null;

		if (!empty($context['message_id']))
		{
			$message = \XF::app()->em()->find(Message::class, intval($context['message_id']), ['Discussion', 'Discussion.Group']);
			if (!$message || !$message->canView() || !$message->canEdit())
			{
				return null;
			}

			$group = $message->Discussion->Group;
		}
		else if (!empty($context['discussion_id']))
		{
			$discussion = \XF::app()->em()->find(Discussion::class, intval($context['discussion_id']), ['Group']);
			if (!$discussion || !$discussion->canView())
			{
				return null;
			}

			$group = $discussion->Group;
		}
		else if (!empty($context['section_id']))
		{
			$section = \XF::app()->em()->find(Section::class, intval($context['section_id']), ['Group']);
			if (!$section || !$section->canView())
			{
				return null;
			}

			$group = $section->Group;
		}
		else if (!empty($context['group_id']))
		{
			$group = \XF::app()->em()->find(Group::class, intval($context['group_id']));
			if (!$group || !$group->canView())
			{
				return null;
			}
		}
		else
		{
			return null;
		}

		return $group;
	}
}