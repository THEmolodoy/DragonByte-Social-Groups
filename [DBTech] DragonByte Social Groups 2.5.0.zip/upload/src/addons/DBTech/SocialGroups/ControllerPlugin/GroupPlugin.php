<?php

namespace DBTech\SocialGroups\ControllerPlugin;

use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Finder\GroupFinder;
use DBTech\SocialGroups\Job\GroupActionCleanUp;
use DBTech\SocialGroups\Pub\View\Group\JoinView;
use DBTech\SocialGroups\Pub\View\Group\NoPermissionBannedView;
use DBTech\SocialGroups\Pub\View\Group\NoPermissionJoinGroupView;
use DBTech\SocialGroups\Repository\GroupMemberRepository;
use DBTech\SocialGroups\XF\Entity\User as ExtendedUserEntity;
use XF\ControllerPlugin\AbstractPlugin;
use XF\InputFilterer;
use XF\Mvc\Reply\AbstractReply;
use XF\Mvc\Reply\Exception as ReplyException;
use XF\PrintableException;

class GroupPlugin extends AbstractPlugin
{
	/**
	 * @param int|null $groupId
	 * @param array $extraWith
	 *
	 * @return Group
	 *
	 * @throws ReplyException
	 */
	public function assertGroupExists(?int $groupId, array $extraWith = []): Group
	{
		if ($groupId === null)
		{
			throw $this->exception($this->notFound(\XF::phrase('dbtech_social_groups_requested_group_not_found')));
		}

		$finder = \XF::app()->em()->getFinder(GroupFinder::class)
			->with('full')
		;
		if ($extraWith)
		{
			$finder->with($extraWith);
		}
		$finder->where('group_id', $groupId);

		/** @var Group $group */
		$group = $finder->fetchOne();
		if (!$group)
		{
			throw $this->exception($this->notFound(\XF::phrase('dbtech_social_groups_requested_group_not_found')));
		}

		return $group;
	}

	/**
	 * @param int|null $groupId
	 * @param array $extraWith
	 *
	 * @return Group
	 *
	 * @throws ReplyException
	 */
	public function assertViewableGroup(?int $groupId, array $extraWith = []): Group
	{
		/** @var Group $group */
		$group = $this->assertGroupExists($groupId, $extraWith);

		if (!$group->canView($error))
		{
			/** @var ExtendedUserEntity $visitor */
			$visitor = \XF::visitor();

			if ($visitor->user_id && $group->Bans[$visitor->user_id])
			{
				// Not a guest and is also banned
				$viewParams = [
					'ban' => $group->Bans[$visitor->user_id],
					'group' => $group,
				];
				$reply = $this->view(
					NoPermissionBannedView::class,
					'dbtech_social_groups_group_ban',
					$viewParams
				);
			}
			else if (!$visitor->isMemberOfSocialGroup($group))
			{
				if ($group->canJoin($error))
				{
					// User can join the group
					$viewParams = [
						'group' => $group,
					];
					$reply = $this->view(
						NoPermissionJoinGroupView::class,
						'dbtech_social_groups_group_nopermission_join',
						$viewParams
					);
				}
				else if (!$group->allow_members)
				{
					// Group is either closed or invite-only
					$reply = $this->noPermission(
						\XF::phraseDeferred('dbtech_social_groups_group_closed_or_invite_only')
					);
					$reply->setPageParam('skipSidebarWidgets', true);
				}
				else
				{
					$reply = $this->noPermission([
						\XF::phraseDeferred('dbtech_social_groups_private_group_cant_join_reason_below'),
						$error,
					]);
					$reply->setPageParam('skipSidebarWidgets', true);
				}
			}
			else
			{
				$reply = $this->noPermission($error);
				$reply->setPageParam('skipSidebarWidgets', true);
			}

			throw $this->exception($reply);
		}

		return $group;
	}

	/**
	 * @param Group $group
	 * @param string $confirmUrl
	 * @param string $contentUrl
	 * @param string $returnUrl
	 * @param string $contentTitle
	 * @param string|null $template
	 * @param array $params
	 *
	 * @return AbstractReply
	 * @throws PrintableException
	 */
	public function actionJoin(
		Group $group,
		string $confirmUrl,
		string $contentUrl,
		string $returnUrl,
		string $contentTitle,
		?string $template = null,
		array $params = []
	): AbstractReply
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		if ($visitor->isMemberOfSocialGroup($group))
		{
			return $this->error(\XF::phrase('dbtech_social_groups_you_are_already_member'));
		}

		if (!$group->canJoin($error))
		{
			return $this->noPermission($error);
		}

		if ($this->isPost())
		{
			if (!empty($group->rules) && !$this->filter('confirm', InputFilterer::BOOLEAN))
			{
				return $this->error(\XF::phrase('dbtech_social_groups_cannot_proceed_without_accepting_rules'));
			}

			\XF::app()->repository(GroupMemberRepository::class)
				->joinGroup($group, $visitor, true, $this->filter('reason', InputFilterer::STRING))
			;

			$moderated = $visitor->SocialGroupMemberships[$group->group_id]->member_state == 'moderated'
				? '_moderated'
				: ''
			;

			return $this->redirect(
				$returnUrl,
				\XF::phrase('dbtech_social_groups_joined_group_successfully' . $moderated)
			);
		}
		else
		{
			$viewParams = [
				'group' => $group,
				'confirmUrl' => $confirmUrl,
				'contentUrl' => $contentUrl,
				'contentTitle' => $contentTitle,
			] + $params;
			return $this->view(
				JoinView::class,
				$template ?: 'public:dbtech_social_groups_group_join_confirm',
				$viewParams
			);
		}
	}

	/**
	 * @param Group $group
	 * @param string $confirmUrl
	 * @param string $contentUrl
	 * @param string $returnUrl
	 * @param string $contentTitle
	 * @param string|null $template
	 * @param array $params
	 *
	 * @return AbstractReply
	 * @throws PrintableException
	 */
	public function actionLeave(
		Group $group,
		string $confirmUrl,
		string $contentUrl,
		string $returnUrl,
		string $contentTitle,
		?string $template = null,
		array $params = []
	): AbstractReply
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		if (!$visitor->isMemberOfSocialGroup($group))
		{
			return $this->error(\XF::phrase('dbtech_social_groups_you_are_not_member'));
		}

		if ($group->user_id === $visitor->user_id)
		{
			return $this->error(\XF::phrase('dbtech_social_groups_you_are_group_owner_cannot_leave'));
		}

		if ($this->isPost())
		{
			$groupMember = $group->Members[$visitor->user_id];

			\XF::app()->repository(GroupMemberRepository::class)
				->logAction($groupMember, 'leave')
			;

			$groupMember->delete();

			if (\XF::app()->options()->dbtechSocialMediaGalleryLeaveAction === 'unlink')
			{
				\XF::app()->jobManager()->enqueue(
					GroupActionCleanUp::class,
					[
						'groupId' => $group->group_id,
						'title' => $group->title,
						'userId' => $visitor->user_id,
					]
				);
			}

			return $this->redirect($returnUrl, \XF::phrase('dbtech_social_groups_left_group_successfully'));
		}
		else
		{
			$viewParams = [
				'group' => $group,
				'confirmUrl' => $confirmUrl,
				'contentUrl' => $contentUrl,
				'contentTitle' => $contentTitle,
			] + $params;
			return $this->view(
				JoinView::class,
				$template ?: 'public:dbtech_social_groups_group_leave_confirm',
				$viewParams
			);
		}
	}
}