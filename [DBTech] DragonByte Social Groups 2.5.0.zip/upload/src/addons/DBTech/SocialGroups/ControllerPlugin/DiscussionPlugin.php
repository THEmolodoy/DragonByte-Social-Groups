<?php

namespace DBTech\SocialGroups\ControllerPlugin;

use DBTech\SocialGroups\Entity\Message;
use XF\ControllerPlugin\AbstractPlugin;

class DiscussionPlugin extends AbstractPlugin
{
	/**
	 * @param Message $message
	 *
	 * @return string
	 */
	public function getMessageLink(Message $message): string
	{
		$discussion = $message->Discussion;
		if (!$discussion)
		{
			throw new \LogicException("Message has no discussion");
		}

		$page = floor($message->position / \XF::app()->options()->messagesPerPage) + 1;

		return $this->buildLink(
			'dbtech-social/discussions',
			$discussion,
			['page' => $page]
		) . '#message-' . $message->message_id;
	}
}