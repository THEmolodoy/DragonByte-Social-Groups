<?php

namespace DBTech\SocialGroups\ControllerPlugin;

use XF\ControllerPlugin\AbstractPlugin;
use XF\Entity\Page;

class TermsPlugin extends AbstractPlugin
{
	/**
	 * @return null|Page
	 */
	public function getTerms(): ?Page
	{
		if (!\XF::app()->options()->dbtechSocialTermsPageId)
		{
			return null;
		}

		return \XF::app()->em()->find(Page::class, \XF::app()->options()->dbtechSocialTermsPageId);
	}
}