<?php

namespace DBTech\SocialGroups\ControllerPlugin;

use XF\ControllerPlugin\AbstractPermission;

class GroupPermissionPlugin extends AbstractPermission
{
	/**
	 * @var string
	 */
	protected $viewFormatter = 'DBTech\SocialGroups:Permission\Group%s';

	/**
	 * @var string
	 */
	protected $templateFormatter = 'dbtech_social_permission_group_%s';

	/**
	 * @var string
	 */
	protected $routePrefix = 'permissions/dbtech-social-groups';

	/**
	 * @var string
	 */
	protected $contentType = 'dbtech_social_group';

	/**
	 * @var string
	 */
	protected $entityIdentifier = 'DBTech\SocialGroups:Group';

	/**
	 * @var string
	 */
	protected $primaryKey = 'group_id';

	/**
	 * @var string
	 */
	protected $privatePermissionGroupId = 'dbtechSocial';

	/**
	 * @var string
	 */
	protected $privatePermissionId = 'viewGroup';
}