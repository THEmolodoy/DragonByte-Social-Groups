<?php

namespace DBTech\SocialGroups\ControllerPlugin;

use DBTech\SocialGroups\Entity\GroupMember;
use DBTech\SocialGroups\Pub\View\Group\GroupMember\KickView;
use DBTech\SocialGroups\Pub\View\Group\Supervisors\RemoveView;
use DBTech\SocialGroups\Repository\GroupMemberRepository;
use DBTech\SocialGroups\Repository\GroupPermissionsRepository;
use XF\ControllerPlugin\AbstractPlugin;
use XF\InputFilterer;
use XF\Mvc\Reply\AbstractReply;
use XF\PrintableException;

class GroupMemberPlugin extends AbstractPlugin
{
	/**
	 * @param GroupMember $groupMember
	 * @param string $confirmUrl
	 * @param string $contentUrl
	 * @param string $returnUrl
	 * @param string $contentTitle
	 * @param string|null $template
	 * @param array $params
	 *
	 * @return AbstractReply
	 * @throws PrintableException
	 */
	public function actionKick(
		GroupMember $groupMember,
		string $confirmUrl,
		string $contentUrl,
		string $returnUrl,
		string $contentTitle,
		?string $template = null,
		array $params = []
	): AbstractReply
	{
		if ($groupMember->is_supervisor)
		{
			return $this->error(\XF::phrase('dbtech_social_groups_member_is_supervisor'));
		}

		if ($this->isPost())
		{
			\XF::app()->repository(GroupMemberRepository::class)
				->kickMember($groupMember, $this->filter('reason', InputFilterer::STRING))
			;

			return $this->redirect(
				$returnUrl,
				\XF::phrase('dbtech_social_groups_kicked_x_from_group_successfully', [
					'user' => $groupMember->User->username,
				])
			);
		}
		else
		{
			$viewParams = [
				'groupMember' => $groupMember,
				'confirmUrl' => $confirmUrl,
				'contentUrl' => $contentUrl,
				'contentTitle' => $contentTitle,
			] + $params;
			return $this->view(
				KickView::class,
				$template ?: 'public:dbtech_social_groups_group_kick_confirm',
				$viewParams
			);
		}
	}

	/**
	 * @param GroupMember $groupMember
	 * @param string $confirmUrl
	 * @param string $contentUrl
	 * @param string $returnUrl
	 * @param string $contentTitle
	 * @param string|null $template
	 * @param array $params
	 *
	 * @return AbstractReply
	 * @throws PrintableException
	 */
	public function actionRemoveSupervisor(
		GroupMember $groupMember,
		string $confirmUrl,
		string $contentUrl,
		string $returnUrl,
		string $contentTitle,
		?string $template = null,
		array $params = []
	): AbstractReply
	{
		if (!$groupMember->is_supervisor)
		{
			return $this->error(\XF::phrase('dbtech_social_groups_member_not_supervisor'));
		}

		if ($this->isPost())
		{
			\XF::app()->repository(GroupPermissionsRepository::class)
				->deleteModeratorPermissionsForUserInGroup($groupMember->User, $groupMember->Group)
			;

			if ($groupMember->user_id === \XF::visitor()->user_id)
			{
				\XF::app()->repository(GroupMemberRepository::class)
					->logAction($groupMember, 'supervisor_resigned')
				;
			}
			else
			{
				\XF::app()->repository(GroupMemberRepository::class)
					->logAction($groupMember, 'supervisor_removed', [], \XF::visitor())
				;
			}

			return $this->redirect($returnUrl);
		}
		else
		{
			$viewParams = [
				'groupMember' => $groupMember,
				'confirmUrl' => $confirmUrl,
				'contentUrl' => $contentUrl,
				'contentTitle' => $contentTitle,
			] + $params;
			return $this->view(
				RemoveView::class,
				$template ?: 'public:delete_confirm',
				$viewParams
			);
		}
	}
}