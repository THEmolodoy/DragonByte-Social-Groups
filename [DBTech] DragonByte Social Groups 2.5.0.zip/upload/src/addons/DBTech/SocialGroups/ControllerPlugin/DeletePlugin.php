<?php

namespace DBTech\SocialGroups\ControllerPlugin;

use DBTech\SocialGroups\Pub\View\Delete\StateView;
use XF\ControllerPlugin\AbstractPlugin;
use XF\ControllerPlugin\InlineModPlugin;
use XF\Entity\Phrase;
use XF\InputFilterer;
use XF\Mvc\Entity\Entity;
use XF\Mvc\Reply\AbstractReply;
use XF\Service\AbstractService;

use function count, get_class, intval;

class DeletePlugin extends AbstractPlugin
{
	/**
	 * @template T of AbstractService
	 * @param Entity $entity
	 * @param string $stateKey
	 * @param class-string<T> $deleterService
	 * @param string $contentType
	 * @param string $confirmUrl
	 * @param string $editLink
	 * @param string $redirectLink
	 * @param Phrase|string $title
	 * @param bool $canHardDelete
	 * @param bool $includeAuthorAlert
	 * @param string|null $templateName
	 * @param array $params
	 *
	 * @return AbstractReply
	 * @noinspection PhpMissingParamTypeInspection
	 */
	public function actionDeleteWithState(
		Entity $entity,
		string $stateKey,
		string $deleterService,
		string $contentType,
		string $confirmUrl,
		string $editLink,
		string $redirectLink,
		$title,
		bool $canHardDelete = false,
		bool $includeAuthorAlert = true,
		?string $templateName = null,
		array $params = []
	): AbstractReply
	{
		if (!\is_callable([$entity, 'canDelete']) || !\is_callable([$entity, 'canUndelete']))
		{
			throw new \LogicException('Either canDelete or canUndelete is not callable on ' . get_class($entity));
		}

		if (\XF::app()->get('app.classType') == 'Pub' && !$entity->canDelete('soft', $error))
		{
			return $this->noPermission($error);
		}

		if ($this->isPost())
		{
			$id = $entity->getIdentifierValues();
			if (!$id || count($id) != 1)
			{
				throw new \InvalidArgumentException("Entity does not have an ID or does not have a simple key");
			}
			$entityId = intval(\reset($id));

			if ($entity->{$stateKey} === 'deleted')
			{
				$linkHash = $this->buildLinkHash($entityId);

				$type = $this->filter('hard_delete', InputFilterer::UNSIGNED);
				switch ($type)
				{
					case 0:
						return $this->redirect($redirectLink . $linkHash);

					case 1:
						if (\XF::app()->get('app.classType') == 'Pub' && !$entity->canDelete('hard', $error))
						{
							return $this->noPermission($error);
						}

						$reason = $this->filter('reason', InputFilterer::STRING);

						$deleter = \XF::app()->service($deleterService, $entity);
						if ($includeAuthorAlert && $this->filter('author_alert', InputFilterer::BOOLEAN))
						{
							$deleter->setSendAlert(true, $this->filter('author_alert_reason', InputFilterer::STRING));
						}
						$deleter->delete('hard', $reason);

						$inlineModPlugin = $this->plugin(InlineModPlugin::class);
						$inlineModPlugin->clearIdFromCookie($contentType, $entityId);

						return $this->redirect($redirectLink);

					case 2:
						if (\XF::app()->get('app.classType') == 'Pub' && !$entity->canUndelete())
						{
							return $this->noPermission();
						}

						$deleter = \XF::app()->service($deleterService, $entity);
						if ($includeAuthorAlert && $this->filter('author_alert', InputFilterer::BOOLEAN))
						{
							$deleter->setSendAlert(true, $this->filter('author_alert_reason', InputFilterer::STRING));
						}

						/** @noinspection PhpUndefinedMethodInspection */
						$deleter->unDelete();

						return $this->redirect($redirectLink . $linkHash);
				}
			}
			else
			{
				$type = $this->filter('hard_delete', InputFilterer::BOOLEAN) ? 'hard' : 'soft';
				$reason = $this->filter('reason', InputFilterer::STRING);

				if (\XF::app()->get('app.classType') == 'Pub' && !$entity->canDelete($type, $error))
				{
					return $this->noPermission($error);
				}

				$deleter = \XF::app()->service($deleterService, $entity);
				if ($includeAuthorAlert && $this->filter('author_alert', InputFilterer::BOOLEAN))
				{
					$deleter->setSendAlert(true, $this->filter('author_alert_reason', InputFilterer::STRING));
				}
				$deleter->delete($type, $reason);

				$inlineModPlugin = $this->plugin(InlineModPlugin::class);
				$inlineModPlugin->clearIdFromCookie($contentType, $entityId);

				return $this->redirect($redirectLink);
			}
		}

		$templateName = $templateName ?: 'public:dbtech_social_groups_delete_state';

		/** @noinspection PhpFullyQualifiedNameUsageInspection */
		$viewClass = \XF::app()->get('app.classType') == 'Pub'
			? StateView::class
			: \DBTech\SocialGroups\Admin\View\Delete\StateView::class
		;

		$viewParams = [
			'entity'             => $entity,
			'stateKey'           => $stateKey,
			'title'              => $title,
			'editLink'           => $editLink,
			'confirmUrl'         => $confirmUrl,
			'canHardDelete'      => $canHardDelete,
			'includeAuthorAlert' => $includeAuthorAlert,
		] + $params;
		return $this->view(
			$viewClass,
			$templateName,
			$viewParams
		);
	}
}