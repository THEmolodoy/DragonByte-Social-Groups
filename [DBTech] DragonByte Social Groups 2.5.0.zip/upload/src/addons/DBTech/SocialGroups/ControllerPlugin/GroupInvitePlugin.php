<?php

namespace DBTech\SocialGroups\ControllerPlugin;

use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Pub\View\Group\JoinView;
use DBTech\SocialGroups\Repository\GroupInviteRepository;
use DBTech\SocialGroups\XF\Entity\User as ExtendedUserEntity;
use XF\ControllerPlugin\AbstractPlugin;
use XF\Mvc\Reply\AbstractReply;
use XF\PrintableException;

class GroupInvitePlugin extends AbstractPlugin
{
	/**
	 * @param Group $group
	 * @param string $confirmUrl
	 * @param string $contentUrl
	 * @param string $returnUrl
	 * @param string $contentTitle
	 * @param string|null $template
	 * @param array $params
	 *
	 * @return AbstractReply
	 * @throws PrintableException
	 */
	public function actionReject(
		Group $group,
		string $confirmUrl,
		string $contentUrl,
		string $returnUrl,
		string $contentTitle,
		?string $template = null,
		array $params = []
	): AbstractReply
	{
		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		if (!$group->canRejectInvite())
		{
			return $this->noPermission();
		}

		if ($this->isPost())
		{
			$invite = $group->Invites[$visitor->user_id];

			\XF::app()->repository(GroupInviteRepository::class)
				->rejectInvite($invite)
			;

			return $this->redirect($returnUrl, \XF::phrase('dbtech_social_groups_rejected_group_invite_successfully'));
		}
		else
		{
			$viewParams = [
				'group' => $group,
				'confirmUrl' => $confirmUrl,
				'contentUrl' => $contentUrl,
				'contentTitle' => $contentTitle,
			] + $params;
			return $this->view(
				JoinView::class,
				$template ?: 'public:dbtech_social_groups_group_invite_reject_confirm',
				$viewParams
			);
		}
	}
}