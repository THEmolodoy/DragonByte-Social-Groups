<?php

namespace DBTech\SocialGroups\ControllerPlugin;

use DBTech\SocialGroups\Entity\Section;
use DBTech\SocialGroups\Finder\SectionFinder;
use DBTech\SocialGroups\Pub\View\Group\NoPermissionBannedView;
use DBTech\SocialGroups\Pub\View\Group\NoPermissionJoinGroupView;
use DBTech\SocialGroups\XF\Entity\User as ExtendedUserEntity;
use XF\ControllerPlugin\AbstractPlugin;
use XF\Entity\User;
use XF\InputFilterer;
use XF\Mvc\Reply\Exception as ReplyException;

use function in_array;

class SectionPlugin extends AbstractPlugin
{
	/**
	 * @param int|null $sectionId
	 * @param array $extraWith
	 *
	 * @return Section
	 *
	 * @throws ReplyException
	 */
	public function assertSectionExists(?int $sectionId, array $extraWith = []): Section
	{
		if ($sectionId === null)
		{
			throw $this->exception($this->notFound(\XF::phrase('dbtech_social_groups_requested_section_not_found')));
		}

		$finder = \XF::app()->em()->getFinder(SectionFinder::class)
			->with('full')
		;
		if ($extraWith)
		{
			$finder->with($extraWith);
		}
		$finder->where('section_id', $sectionId);

		/** @var Section $section */
		$section = $finder->fetchOne();
		if (!$section)
		{
			throw $this->exception($this->notFound(\XF::phrase('dbtech_social_groups_requested_section_not_found')));
		}

		return $section;
	}

	/**
	 * @param int|null $sectionId
	 * @param array $extraWith
	 *
	 * @return Section
	 *
	 * @throws ReplyException
	 */
	public function assertViewableSection(?int $sectionId, array $extraWith = []): Section
	{
		/** @var Section $section */
		$section = $this->assertSectionExists($sectionId, $extraWith);

		if (!$section->canView($error))
		{
			/** @var ExtendedUserEntity $visitor */
			$visitor = \XF::visitor();

			if ($visitor->user_id && $section->Group->Bans[$visitor->user_id])
			{
				// Not a guest and is also banned
				$viewParams = [
					'ban' => $section->Group->Bans[$visitor->user_id],
					'group' => $section->Group,
				];
				$reply = $this->view(
					NoPermissionBannedView::class,
					'dbtech_social_groups_group_ban',
					$viewParams
				);
			}
			else if (!$visitor->isMemberOfSocialGroup($section->Group))
			{
				if ($section->Group->canJoin($error))
				{
					// User can join the group
					$viewParams = [
						'group' => $section->Group,
					];
					$reply = $this->view(
						NoPermissionJoinGroupView::class,
						'dbtech_social_groups_group_nopermission_join',
						$viewParams
					);
				}
				else if (!$section->Group->allow_members)
				{
					// Group is either closed or invite-only
					$reply = $this->noPermission(
						\XF::phraseDeferred('dbtech_social_groups_group_closed_or_invite_only')
					);
					$reply->setPageParam('skipSidebarWidgets', true);
				}
				else
				{
					$reply = $this->noPermission([
						\XF::phraseDeferred('dbtech_social_groups_private_group_cant_join_reason_below'),
						$error,
					]);
					$reply->setPageParam('skipSidebarWidgets', true);
				}
			}
			else
			{
				$reply = $this->noPermission($error);
				$reply->setPageParam('skipSidebarWidgets', true);
			}

			throw $this->exception($reply);
		}

		return $section;
	}



	/**
	 * @param Section $section
	 *
	 * @return array
	 */
	public function getSectionFilterInput(Section $section): array
	{
		$filters = [];

		$input = $this->filter([
			'prefix_id' => InputFilterer::UNSIGNED,
			'starter' => InputFilterer::STRING,
			'starter_id' => InputFilterer::UNSIGNED,
			'last_days' => InputFilterer::INT,
			'order' => InputFilterer::STRING,
			'direction' => InputFilterer::STRING,
			'no_date_limit' => InputFilterer::BOOLEAN,
		]);

		if ($input['no_date_limit'])
		{
			$filters['no_date_limit'] = $input['no_date_limit'];
		}

		//		if ($input['prefix_id'] && $section->isPrefixValid($input['prefix_id']))
		//		{
		//			$filters['prefix_id'] = $input['prefix_id'];
		//		}

		if ($input['starter_id'])
		{
			$filters['starter_id'] = $input['starter_id'];
		}
		else if ($input['starter'])
		{
			$user = \XF::app()->em()->findOne(User::class, ['username' => $input['starter']]);
			if ($user)
			{
				$filters['starter_id'] = $user->user_id;
			}
		}

		if (
			($input['last_days'] > 0 && $input['last_days'] != $section->list_date_limit_days)
			|| ($input['last_days'] < 0 && $section->list_date_limit_days)
		)
		{
			if (in_array($input['last_days'], $this->getAvailableDateLimits($section)))
			{
				$filters['last_days'] = $input['last_days'];
			}
		}

		$sorts = $this->getAvailableSectionSorts($section);

		if ($input['order'] && isset($sorts[$input['order']]))
		{
			if (!in_array($input['direction'], ['asc', 'desc']))
			{
				$input['direction'] = 'desc';
			}

			if ($input['order'] != $section->default_sort_order || $input['direction'] != $section->default_sort_direction)
			{
				$filters['order'] = $input['order'];
				$filters['direction'] = $input['direction'];
			}
		}

		return $filters;
	}

	/**
	 * @param Section $section
	 *
	 * @return string[]
	 */
	public function getAvailableSectionSorts(Section $section): array
	{
		// maps [name of sort] => field in/relative to Discussion entity
		return [
			'last_message_date' => 'last_message_date',
			'message_date' => 'message_date',
			'title' => 'title',
			'reply_count' => 'reply_count',
			'view_count' => 'view_count',
			'first_message_reaction_score' => 'first_message_reaction_score',
		];
	}

	/**
	 * @param Section $section
	 *
	 * @return int[]
	 */
	public function getAvailableDateLimits(Section $section): array
	{
		return [-1, 7, 14, 30, 60, 90, 182, 365];
	}
}