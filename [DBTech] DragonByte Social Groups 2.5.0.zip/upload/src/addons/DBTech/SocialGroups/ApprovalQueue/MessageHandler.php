<?php

namespace DBTech\SocialGroups\ApprovalQueue;

use DBTech\SocialGroups\Entity\Message;
use DBTech\SocialGroups\Service\Message\ApproverService;
use XF\ApprovalQueue\AbstractHandler;
use XF\Mvc\Entity\Entity;
use XF\PrintableException;

/**
 * @extends AbstractHandler<Message>
 */
class MessageHandler extends AbstractHandler
{
	protected function canActionContent(Entity $content, &$error = null): bool
	{
		return $content->canApproveUnapprove($error);
	}

	public function getEntityWith(): array
	{
		$visitor = \XF::visitor();

		return [
			'Discussion',
			'Discussion.Group',
			'Discussion.Group.Permissions|' . $visitor->permission_combination_id,
			'User',
		];
	}

	/**
	 * @param Message $message
	 *
	 * @throws PrintableException
	 */
	public function actionApprove(Message $message): void
	{
		$approver = \XF::app()->service(ApproverService::class, $message);
		$approver->setNotifyRunTime(1); // may be a lot happening
		$approver->approve();
	}

	/**
	 * @param Message $message
	 */
	public function actionDelete(Message $message): void
	{
		$this->quickUpdate($message, 'message_state', 'deleted');
	}

	/**
	 * @param Message $message
	 */
	public function actionSpamClean(Message $message): void
	{
		if (!$message->User)
		{
			return;
		}

		$this->_spamCleanInternal($message->User);
	}
}