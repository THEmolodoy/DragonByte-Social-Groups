<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\ApprovalQueue;

use DBTech\SocialGroups\Entity\GroupMember;
use DBTech\SocialGroups\Service\GroupMember\ApproverService;
use XF\ApprovalQueue\AbstractHandler;
use XF\Entity\ApprovalQueue;
use XF\Mvc\Entity\Entity;
use XF\PrintableException;

/**
 * @extends AbstractHandler<GroupMember>
 */
class GroupMemberHandler extends AbstractHandler
{
	/**
	 * @param Entity $content
	 * @param $error
	 *
	 * @return bool
	 */
	protected function canViewContent(Entity $content, &$error = null)
	{
		return true;
	}

	protected function canActionContent(Entity $content, &$error = null)
	{
		return $content->canApproveUnapprove($error);
	}

	public function getEntityWith()
	{
		$visitor = \XF::visitor();

		return ['Group', 'Group.Permissions|' . $visitor->permission_combination_id, 'User'];
	}

	public function getDefaultActions(): array
	{
		return [
			'' => \XF::phrase('do_nothing'),
			'approve' => \XF::phrase('approve'),
			'reject' => \XF::phrase('reject'),
		];
	}

	/**
	 * @param ApprovalQueue $unapprovedItem
	 *
	 * @return array
	 */
	public function getTemplateData(ApprovalQueue $unapprovedItem)
	{
		$templateData = parent::getTemplateData($unapprovedItem);

		/** @var GroupMember $content  */
		$content = $unapprovedItem->Content;

		$templateData['groupMember'] = $content;
		$templateData['user'] = $content->User;
		$templateData['group'] = $content->Group;

		return $templateData;
	}

	/**
	 * @param GroupMember $groupMember
	 *
	 * @throws PrintableException
	 */
	public function actionApprove(GroupMember $groupMember)
	{
		$notify = $this->getInput('notify', $groupMember->group_member_id);

		$approver = \XF::app()->service(ApproverService::class, $groupMember);
		$approver->setNotify($notify);
		$approver->setNotifyRunTime(1); // may be a lot happening
		$approver->approve();

		\XF::app()->logger()->logModeratorAction(
			'dbtech_social_member',
			$groupMember,
			'approved'
		);
	}

	/**
	 * @param GroupMember $groupMember
	 *
	 * @throws PrintableException
	 */
	public function actionReject(GroupMember $groupMember)
	{
		$notify = $this->getInput('notify', $groupMember->group_member_id);
		$reason = $this->getInput('reason', $groupMember->group_member_id);

		$approver = \XF::app()->service(ApproverService::class, $groupMember);
		$approver->setNotify($notify);
		$approver->setNotifyRunTime(1); // may be a lot happening
		$approver->setReason($reason);
		$approver->reject();

		\XF::app()->logger()->logModeratorAction(
			'dbtech_social_member',
			$groupMember,
			'rejected',
			['reason' => $reason]
		);
	}
}