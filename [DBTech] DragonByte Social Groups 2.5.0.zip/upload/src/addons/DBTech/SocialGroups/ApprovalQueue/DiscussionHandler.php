<?php

namespace DBTech\SocialGroups\ApprovalQueue;

use DBTech\SocialGroups\Entity\Discussion;
use DBTech\SocialGroups\Service\Discussion\ApproverService;
use XF\ApprovalQueue\AbstractHandler;
use XF\Mvc\Entity\Entity;
use XF\PrintableException;

/**
 * @extends AbstractHandler<Discussion>
 */
class DiscussionHandler extends AbstractHandler
{
	protected function canActionContent(Entity $content, &$error = null): bool
	{
		return $content->canApproveUnapprove($error);
	}

	public function getEntityWith(): array
	{
		$visitor = \XF::visitor();

		return ['Group', 'Group.Permissions|' . $visitor->permission_combination_id, 'FirstMessage', 'User'];
	}

	/**
	 * @param Discussion $discussion
	 *
	 * @throws PrintableException
	 */
	public function actionApprove(Discussion $discussion): void
	{
		$approver = \XF::app()->service(ApproverService::class, $discussion);
		$approver->setNotifyRunTime(1); // may be a lot happening
		$approver->approve();
	}

	/**
	 * @param Discussion $discussion
	 */
	public function actionDelete(Discussion $discussion): void
	{
		$this->quickUpdate($discussion, 'discussion_state', 'deleted');
	}

	/**
	 * @param Discussion $discussion
	 */
	public function actionSpamClean(Discussion $discussion): void
	{
		if (!$discussion->User)
		{
			return;
		}

		$this->_spamCleanInternal($discussion->User);
	}
}