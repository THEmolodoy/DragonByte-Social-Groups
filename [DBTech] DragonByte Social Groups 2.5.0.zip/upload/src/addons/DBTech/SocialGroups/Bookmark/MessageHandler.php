<?php

namespace DBTech\SocialGroups\Bookmark;

use DBTech\SocialGroups\Entity\Message;
use XF\Bookmark\AbstractHandler;
use XF\Entity\User;
use XF\Mvc\Entity\Entity;

/**
 * @extends AbstractHandler<Message>
 */
class MessageHandler extends AbstractHandler
{
	public function getContentUser(Entity $content): ?User
	{
		if ($content->isFirstMessage())
		{
			return $content->Discussion->User;
		}
		else
		{
			return $content->User;
		}
	}

	public function getContentLink(Entity $content): string
	{
		if ($content->isFirstMessage())
		{
			return $content->Discussion->getContentUrl(true);
		}
		else
		{
			return parent::getContentLink($content);
		}
	}

	public function getEntityWith(): array
	{
		$visitor = \XF::visitor();

		return [
			'Discussion',
			'Discussion.Group',
			'Discussion.Group.Permissions|' . $visitor->permission_combination_id,
		];
	}
}