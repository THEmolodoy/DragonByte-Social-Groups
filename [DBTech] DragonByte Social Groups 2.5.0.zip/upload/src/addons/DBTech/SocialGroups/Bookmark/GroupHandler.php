<?php

namespace DBTech\SocialGroups\Bookmark;

use DBTech\SocialGroups\Entity\Group;
use XF\Bookmark\AbstractHandler;
use XF\Mvc\Entity\Entity;

/**
 * @extends AbstractHandler<Group>
 */
class GroupHandler extends AbstractHandler
{
	public function getContentTitle(Entity $content): string
	{
		return $content->title;
	}

	public function getContentRoute(Entity $content): string
	{
		return 'dbtech-social';
	}

	public function getEntityWith(): array
	{
		$visitor = \XF::visitor();

		return [
			'Permissions|' . $visitor->permission_combination_id,
		];
	}

	public function getCustomIconTemplateName(): string
	{
		return 'public:dbtech_social_groups_bookmark_item_custom_icon_group';
	}
}