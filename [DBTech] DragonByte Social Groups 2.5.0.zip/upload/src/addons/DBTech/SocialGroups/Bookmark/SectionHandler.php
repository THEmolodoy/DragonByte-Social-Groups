<?php

namespace DBTech\SocialGroups\Bookmark;

use DBTech\SocialGroups\Entity\Section;
use XF\Bookmark\AbstractHandler;
use XF\Entity\User;
use XF\Mvc\Entity\Entity;

/**
 * @extends AbstractHandler<Section>
 */
class SectionHandler extends AbstractHandler
{
	public function getContentUser(Entity $content): ?User
	{
		return $content->Group->User;
	}

	public function getContentTitle(Entity $content): string
	{
		return $content->title;
	}

	public function getEntityWith(): array
	{
		$visitor = \XF::visitor();

		return [
			'Group',
			'Group.Permissions|' . $visitor->permission_combination_id,
		];
	}
}