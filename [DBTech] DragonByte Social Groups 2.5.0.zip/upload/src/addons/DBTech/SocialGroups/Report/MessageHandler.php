<?php

namespace DBTech\SocialGroups\Report;

use DBTech\SocialGroups\Entity\Message;
use XF\Entity\Report;
use XF\Mvc\Entity\Entity;
use XF\Phrase;
use XF\Report\AbstractHandler;

/**
 * @extends AbstractHandler<Message>
 */
class MessageHandler extends AbstractHandler
{
	/**
	 * @param Report $report
	 *
	 * @return bool
	 */
	protected function canViewContent(Report $report): bool
	{
		return \XF::visitor()
			->hasDbtechSocialGroupsGroupPermission($report->content_info['group_id'], 'viewGroup')
		;
	}

	/**
	 * @param Report $report
	 *
	 * @return bool
	 */
	protected function canActionContent(Report $report): bool
	{
		$visitor = \XF::visitor();
		$groupId = $report->content_info['group_id'];
		return (
			$visitor->hasDbtechSocialGroupsGroupPermission($groupId, 'editAnyMessage')
			|| $visitor->hasDbtechSocialGroupsGroupPermission($groupId, 'deleteAnyMessage')
		);
	}

	/**
	 * @param Report $report
	 * @param Message $content
	 */
	public function setupReportEntityContent(Report $report, Entity $content): void
	{
		$report->content_user_id = $content->user_id;
		$report->content_info = [
			'message' => $content->message,
			'group_id' => $content->Discussion->Group->group_id,
			'group_title' => $content->Discussion->Group->title,
			'message_id' => $content->message_id,
			'discussion_id' => $content->discussion_id,
			'discussion_title' => $content->Discussion->title,
			'user_id' => $content->user_id,
			'username' => $content->username,
		];
	}

	/**
	 * @param Report $report
	 *
	 * @return Phrase
	 */
	public function getContentTitle(Report $report): Phrase
	{
		return \XF::phrase('dbtech_social_groups_message_in_discussion_x', [
			'title' => \XF::app()->stringFormatter()->censorText($report->content_info['discussion_title']),
		]);
	}

	/**
	 * @param Report $report
	 *
	 * @return mixed
	 */
	public function getContentMessage(Report $report): mixed
	{
		return $report->content_info['message'];
	}

	/**
	 * @param Report $report
	 *
	 * @return string
	 */
	public function getContentLink(Report $report): string
	{
		if (!empty($report->content_info['message_id']))
		{
			$linkData = $report->content_info;
		}
		else
		{
			$linkData = ['message_id' => $report->content_id];
		}

		return \XF::app()->router('public')->buildLink('canonical:dbtech-social/messages', $linkData);
	}

	/**
	 * @return string[]
	 */
	public function getEntityWith(): array
	{
		return ['Discussion', 'Discussion.Group', 'User'];
	}
}