<?php

namespace DBTech\SocialGroups\Report;

use DBTech\SocialGroups\Entity\Group;
use XF\Entity\Report;
use XF\Mvc\Entity\Entity;
use XF\Phrase;
use XF\Report\AbstractHandler;

/**
 * @extends AbstractHandler<Group>
 */
class GroupHandler extends AbstractHandler
{
	/**
	 * @param Report $report
	 *
	 * @return bool
	 */
	protected function canViewContent(Report $report): bool
	{
		return \XF::visitor()
			->hasDbtechSocialGroupsGroupPermission($report->content_info['group_id'], 'viewGroup')
		;
	}

	/**
	 * @param Report $report
	 *
	 * @return bool
	 */
	protected function canActionContent(Report $report): bool
	{
		return \XF::visitor()
			->canEditAnyDbtechSocialGroups()
		;
	}

	/**
	 * @param Report $report
	 * @param Group $content
	 */
	public function setupReportEntityContent(Report $report, Entity $content): void
	{
		$report->content_user_id = $content->user_id;
		$report->content_info = [
			'tagline' => $content->tagline,
			'description' => $content->description,
			'group_id' => $content->group_id,
			'group_title' => $content->title,
			'user_id' => $content->user_id,
			'username' => $content->username,
		];
	}

	/**
	 * @param Report $report
	 *
	 * @return Phrase
	 */
	public function getContentTitle(Report $report): Phrase
	{
		return \XF::phrase('dbtech_social_groups_group_x', [
			'title' => \XF::app()->stringFormatter()->censorText($report->content_info['group_title']),
		]);
	}

	/**
	 * @param Report $report
	 *
	 * @return mixed
	 */
	public function getContentMessage(Report $report): mixed
	{
		return $report->content_info['description'];
	}

	/**
	 * @param Report $report
	 *
	 * @return string
	 */
	public function getContentLink(Report $report): string
	{
		if (!empty($report->content_info['group_id']))
		{
			$linkData = $report->content_info;
		}
		else
		{
			$linkData = ['group_id' => $report->content_id];
		}

		return \XF::app()->router('public')->buildLink('canonical:dbtech-social', $linkData);
	}

	/**
	 * @return string[]
	 */
	public function getEntityWith(): array
	{
		return ['User'];
	}
}