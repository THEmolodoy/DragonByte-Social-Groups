<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\XF\Repository;

use DBTech\SocialGroups\Repository\GroupRepository;

/**
 * @extends \XF\Repository\CountersRepository
 */
class CountersRepository extends XFCP_CountersRepository
{
	public function getForumStatisticsCacheData()
	{
		$cache = parent::getForumStatisticsCacheData();

		$groupRepo = \XF::app()->repository(GroupRepository::class);
		$cache += $groupRepo->getGroupCounterTotals();

		$latestGroup = $groupRepo->getLatestValidGroup();
		$cache['dbtechSocialGroupsLatestGroup'] = $latestGroup ? $latestGroup->toArray() : null;

		return $cache;
	}
}