<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\XF\Widget;

use DBTech\SocialGroups\Entity\Group;

/**
 * @extends \XF\Widget\TrendingContent
 */
class TrendingContent extends XFCP_TrendingContent
{
	protected function getContextualOptions(): array
	{
		$group = $this->contextParams['group'] ?? null;
		if ($group instanceof Group)
		{
			return [
				'content_type' => 'dbtech_social_discussion',
				'content_container_id' => $group->group_id,
			];
		}

		return parent::getContextualOptions();
	}
}