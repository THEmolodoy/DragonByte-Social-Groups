<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\XF\Mvc;

use XF\Mvc\RouteBuiltLink;

use function call_user_func_array, is_string;

/**
 * @extends \XF\Mvc\Router
 */
class Router extends XFCP_Router
{
	/**
	 * @param $prefix
	 * @param array $route
	 * @param $action
	 * @param null $data
	 * @param array $parameters
	 *
	 * @return string|string[]|RouteBuiltLink|null
	 * @throws \Exception
	 */
	protected function buildRouteUrl($prefix, array $route, $action, $data = null, array &$parameters = [])
	{
		if ($prefix == 'media')
		{
			$builderClass = null;
			if ($route['format'] == 'albums/:int<album_id,title>/:page')
			{
				$builderClass = \XF::extendClass('DBTech\SocialGroups\Pub\Route\Album');
			}
			else if ($route['format'] == ':int<media_id,title>/:page')
			{
				$builderClass = \XF::extendClass('DBTech\SocialGroups\Pub\Route\Media');
			}

			if ($builderClass)
			{
				$output = call_user_func_array(
					[$builderClass, 'build'],
					[&$prefix, &$route, &$action, &$data, &$parameters, $this]
				);
				if (is_string($output) || $output instanceof RouteBuiltLink)
				{
					return $output;
				}
			}
		}

		return parent::buildRouteUrl($prefix, $route, $action, $data, $parameters);
	}
}