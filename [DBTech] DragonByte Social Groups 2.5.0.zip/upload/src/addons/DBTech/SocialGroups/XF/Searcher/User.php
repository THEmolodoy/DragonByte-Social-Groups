<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\XF\Searcher;

/**
 * @extends \XF\Searcher\User
 */
class User extends XFCP_User
{
	/**
	 * @return array
	 */
	public function getFormDefaults()
	{
		$previous = parent::getFormDefaults();

		$previous['dbtech_social_groups_group_count'] = ['end' => -1];
		$previous['dbtech_social_groups_group_joined_count'] = ['end' => -1];

		return $previous;
	}
}