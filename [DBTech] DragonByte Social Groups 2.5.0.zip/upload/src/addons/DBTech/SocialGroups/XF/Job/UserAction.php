<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\XF\Job;

use DBTech\SocialGroups\Job\TransferGroups;
use XF\Entity\User;
use XF\Finder\UserFinder;

/**
 * @extends \XF\Job\UserAction
 */
class UserAction extends XFCP_UserAction
{
	protected function executeAction(User $user)
	{
		if ($this->getActionValue('delete')
			&& !$user->is_super_admin
			&& !$user->is_admin
			&& !$user->is_moderator
		)
		{
			if ($this->getActionValue('dbtech_social_groups_cleanup'))
			{
				$user->setOption('enqueue_social_content_cleanup', true);
			}

			$this->applySocialGroupTransfer($user);
		}

		parent::executeAction($user);
	}

	/**
	 * @param User $user
	 */
	protected function applySocialGroupTransfer(User $user)
	{
		$user->setOption('enqueue_social_group_cleanup', true);
		$user->setOption('social_group_transfer_recipient', 0); // Just in case
		$user->setOption('social_group_transfer_group_ids', [0]); // Just in case

		if (!$this->getActionValue('dbtech_social_groups_transfer_groups')
			|| !$this->getActionValue('dbtech_social_groups_group_recipient')
		)
		{
			return;
		}

		$recipient = \XF::app()->finder(UserFinder::class)
			->where('username', $this->getActionValue('dbtech_social_groups_group_recipient'))
			->fetchOne()
		;
		if (!$recipient)
		{
			return;
		}

		$socialGroupIds = \XF::db()->fetchAllColumn("
			SELECT group_id
			FROM xf_dbtech_social_groups_group
			WHERE user_id = ?
		", $user->user_id);

		// Override the above defaults with actual data
		$user->setOption('social_group_transfer_recipient', $recipient->user_id);
		$user->setOption('social_group_transfer_group_ids', $socialGroupIds);
	}

	/**
	 * @param User $user
	 */
	protected function applyExternalUserChange(User $user)
	{
		parent::applyExternalUserChange($user);

		if (!$this->getActionValue('dbtech_social_groups_transfer_groups')
			|| !$this->getActionValue('dbtech_social_groups_group_recipient')
		)
		{
			return;
		}

		$recipient = \XF::app()->finder(UserFinder::class)
			->where('username', $this->getActionValue('dbtech_social_groups_group_recipient'))
			->fetchOne()
		;
		if (!$recipient)
		{
			return;
		}

		$socialGroupIds = \XF::db()->fetchAllColumn("
			SELECT group_id
			FROM xf_dbtech_social_groups_group
			WHERE user_id = ?
		", $user->user_id);

		\XF::app()->jobManager()->enqueue(TransferGroups::class, [
			'toUserId' => $recipient->user_id,
			'groupIds' => $socialGroupIds,
		]);
	}
}