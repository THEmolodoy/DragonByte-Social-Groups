<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\XF;

use DBTech\SocialGroups\Entity\GroupMember;
use DBTech\SocialGroups\Entity\GroupMemberLog;
use XF\Entity\User;
use XF\PrintableException;

/**
 * @extends \XF\Logger
 */
class Logger extends XFCP_Logger
{
	protected ?\DBTech\SocialGroups\GroupMemberLog\Logger $dbtechSocialGroupsGroupMemberLogger = null;


	/**
	 * @return \DBTech\SocialGroups\GroupMemberLog\Logger
	 * @throws \Exception
	 */
	public function dbtechSocialGroupsGroupMemberLogger()
	{
		if (!$this->dbtechSocialGroupsGroupMemberLogger)
		{
			$class = \XF::extendClass(\DBTech\SocialGroups\GroupMemberLog\Logger::class);
			$this->dbtechSocialGroupsGroupMemberLogger = new $class();
		}

		return $this->dbtechSocialGroupsGroupMemberLogger;
	}

	/**
	 * @param GroupMember $content
	 * @param string $action
	 * @param array $params
	 * @param bool $throw
	 * @param User|null $actor
	 * @param bool|string $ip
	 *
	 * @return GroupMemberLog|null
	 * @throws PrintableException
	 * @throws \Exception
	 */
	public function logDbtechSocialGroupMember(
		GroupMember $content,
		string      $action,
		array       $params = [],
		bool        $throw = true,
		?User       $actor = null,
		bool|string $ip = false
	)
	{
		return $this->dbtechSocialGroupsGroupMemberLogger()
			->log(
				$content,
				$action,
				$params,
				$throw,
				$actor,
				$ip
			)
		;
	}
}