<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\XF\Service\User;

use DBTech\SocialGroups\Entity\GroupInvite;
use DBTech\SocialGroups\Finder\GroupInviteFinder;
use XF\Entity\UserIgnored;
use XF\Mvc\Entity\AbstractCollection;
use XF\PrintableException;

/**
 * @extends \XF\Service\User\IgnoreService
 */
class IgnoreService extends XFCP_IgnoreService
{
	/**
	 * @return UserIgnored
	 * @throws PrintableException
	 */
	public function ignore()
	{
		$userIgnored = parent::ignore();

		/** @var AbstractCollection<GroupInvite> $invites */
		$invites = \XF::app()->finder(GroupInviteFinder::class)
			->where('user_id', $this->ignoredBy->user_id)
			->where('invited_by_user_id', $this->ignoredUser->user_id)
			->fetch()
		;
		foreach ($invites AS $invite)
		{
			$invite->delete();
		}

		return $userIgnored;
	}
}