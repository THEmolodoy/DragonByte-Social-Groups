<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\XF\Service\User;

use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Entity\GroupMember;
use DBTech\SocialGroups\Finder\GroupFinder;
use DBTech\SocialGroups\Finder\GroupMemberFinder;
use XF\Mvc\Entity\AbstractCollection;
use XF\PrintableException;

/**
 * @extends \XF\Service\User\DeleteCleanUpService
 */
class DeleteCleanUpService extends XFCP_DeleteCleanUpService
{
	/**
	 * @return string[]
	 */
	protected function getSteps()
	{
		$steps = parent::getSteps();
		$steps[] = 'stepDeleteSocialGroupMemberships';
		return $steps;
	}

	/**
	 * @param $lastOffset
	 * @param $maxRunTime
	 *
	 * @return int|mixed|null
	 * @throws PrintableException
	 */
	protected function stepDeleteSocialGroupMemberships($lastOffset, $maxRunTime)
	{
		$start = microtime(true);

		$groupMemberFinder = \XF::app()->finder(GroupMemberFinder::class)
			->where('user_id', $this->userId)
			->order('group_member_id');

		if ($lastOffset !== null)
		{
			$groupMemberFinder->where('group_member_id', '>', $lastOffset);
		}

		$maxFetch = 1000;

		/** @var AbstractCollection<GroupMember> $groupMembers */
		$groupMembers = $groupMemberFinder->fetch($maxFetch);

		if (!$groupMembers->count())
		{
			return null;
		}

		foreach ($groupMembers AS $groupMember)
		{
			$lastOffset = $groupMember->group_member_id;

			$groupMember->delete();

			if ($maxRunTime && ((microtime(true) - $start) > $maxRunTime))
			{
				return $lastOffset;
			}
		}

		if ($groupMembers->count() == $maxFetch)
		{
			return $lastOffset;
		}

		return null;
	}

	/**
	 * @throws \LogicException
	 * @throws PrintableException
	 */
	protected function stepMiscCleanUp()
	{
		parent::stepMiscCleanUp();

		// Remove IP addresses
		$this->db()->update(
			'xf_dbtech_social_groups_group_member_log',
			['ip_address' => ''],
			'actor_id = ?',
			$this->userId
		);

		/** @var Group $group */
		$groups = \XF::app()->finder(GroupFinder::class)
			->where('user_id', $this->userId)
			->fetch()
		;
		foreach ($groups AS $group)
		{
			$group->delete(false);
		}
	}
}