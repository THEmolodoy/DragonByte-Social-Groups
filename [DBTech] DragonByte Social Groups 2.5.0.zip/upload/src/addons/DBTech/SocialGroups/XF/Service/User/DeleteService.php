<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\XF\Service\User;

/**
 * @extends \XF\Service\User\DeleteService
 */
class DeleteService extends XFCP_DeleteService
{
	/**
	 * @param bool $bool
	 * @param array $transferGroupIds
	 * @param int $transferGroupRecipient
	 *
	 * @return void
	 */
	public function setDeleteGroups(bool $bool, array $transferGroupIds, int $transferGroupRecipient)
	{
		$this->user->setOption('enqueue_social_group_cleanup', $bool);
		$this->user->setOption('social_group_transfer_recipient', $transferGroupRecipient);
		$this->user->setOption('social_group_transfer_group_ids', $transferGroupIds);
	}

	/**
	 * @param bool $bool
	 *
	 * @return void
	 */
	public function setDeleteContent(bool $bool)
	{
		$this->user->setOption('enqueue_social_content_cleanup', $bool);
	}
}