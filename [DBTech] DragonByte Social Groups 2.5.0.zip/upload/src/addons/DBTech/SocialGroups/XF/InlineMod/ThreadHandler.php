<?php

namespace DBTech\SocialGroups\XF\InlineMod;

use DBTech\SocialGroups\InlineMod\Thread\Import as ImportThread;
use DBTech\SocialGroups\Util\Arr;

/**
 * @extends \XF\InlineMod\ThreadHandler
 */
class ThreadHandler extends XFCP_ThreadHandler
{
	/**
	 * @noinspection PhpMissingReturnTypeInspection
	 * @noinspection PhpUnnecessaryLocalVariableInspection
	 */
	public function getPossibleActions()
	{
		return Arr::array_insert_after(
			parent::getPossibleActions(),
			'move',
			'dbt_soc_import',
			$this->getActionHandler(ImportThread::class)
		);
	}
}