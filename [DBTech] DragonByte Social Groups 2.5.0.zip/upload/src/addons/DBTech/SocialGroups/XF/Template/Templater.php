<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\XF\Template;

use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Entity\GroupMember;
use XF\Entity\User;
use XF\Phrase;
use XF\PreEscaped;
use XF\Repository\UserRepository;
use XF\Util\Color;
use XF\Util\Str;

use function array_key_exists, ord;

/**
 * @extends \XF\Template\Templater
 */
class Templater extends XFCP_Templater
{
	protected array $dbtechSocialGroupsIconDefaultStylingCache = [];
	protected string $dbtechSocialGroupsIconLetterRegex = '/[^\(\)\{\}\[\]\<\>\-\.\+\:\=\*\!\|\^\/\\\\\'`"_,#~ ]/u';


	/**
	 * @param \XF\Template\Templater $templater
	 * @param bool $escape
	 * @param GroupMember|null $groupMember
	 * @param array $attributes
	 *
	 * @return string
	 */
	public function fnDbtechSocialMemberBlurb(
		\XF\Template\Templater $templater,
		bool &$escape,
		?GroupMember $groupMember,
		array $attributes = []
	): string
	{
		$escape = false;

		if (!($groupMember instanceof GroupMember))
		{
			return '';
		}

		$user = $groupMember->User;

		if (!($user instanceof User))
		{
			return '';
		}

		$blurbParts = [];

		$memberTitle = $this->fnDbtechSocialMemberTitle($this, $escape, $groupMember, true);
		if ($memberTitle)
		{
			$blurbParts[] = $memberTitle;
		}
		if ($user->Profile->age)
		{
			$blurbParts[] = $user->Profile->age;
		}
		if ($user->Profile->location)
		{
			$location = \XF::escapeString($user->Profile->location);
			if (\XF::options()->geoLocationUrl)
			{
				$location = '<a href="' . $this->app->router('public')->buildLink('misc/location-info', null, ['location' => $location]) . '" class="u-concealed" target="_blank" rel="nofollow noreferrer">' . $location . '</a>';
			}
			$blurbParts[] = $this->phrase('from_x_location', ['location' => new PreEscaped($location)])->render();
		}

		$tag = $this->processAttributeToRaw($attributes, 'tag');
		if (!$tag)
		{
			$tag = 'div';
		}

		$class = $this->processAttributeToRaw($attributes, 'class', '%s', true);
		$unhandledAttrs = $this->processUnhandledAttributes($attributes);

		return "<{$tag} class=\"{$class}\" dir=\"auto\" {$unhandledAttrs}>"
			. implode(' <span role="presentation" aria-hidden="true">&middot;</span> ', $blurbParts)
			. "</{$tag}>";
	}

	/**
	 * @param \XF\Template\Templater $templater
	 * @param bool $escape
	 * @param GroupMember|null $groupMember
	 * @param bool $includeMember
	 *
	 * @return Phrase|null
	 */
	public function fnDbtechSocialMemberTitle(
		\XF\Template\Templater $templater,
		bool &$escape,
		?GroupMember $groupMember,
		bool $includeMember = false
	): ?Phrase
	{
		$escape = false;

		if ($groupMember->Group->user_id === $groupMember->user_id)
		{
			return \XF::phraseDeferred('dbtech_social_groups_group_owner_short');
		}
		else if ($groupMember->is_supervisor)
		{
			return \XF::phraseDeferred('dbtech_social_groups_group_supervisor_short');
		}
		else if ($groupMember->Group->Moderators[$groupMember->user_id])
		{
			return \XF::phraseDeferred('moderator');
		}
		else if ($groupMember->member_state === 'moderated')
		{
			return \XF::phraseDeferred('awaiting_approval');
		}
		else if ($groupMember->member_state === 'banned')
		{
			return \XF::phraseDeferred('banned');
		}

		return $includeMember ? \XF::phraseDeferred('dbtech_social_groups_group_member') : null;
	}

	/**
	 * @param \XF\Template\Templater $templater
	 * @param bool $escape
	 * @param Group|null $group
	 * @param string $sizeCode
	 * @param array $attributes
	 *
	 * @return string
	 */
	public function fnDbtechSocialGroupBanner(
		\XF\Template\Templater $templater,
		bool &$escape,
		?Group $group,
		string $sizeCode = 'm',
		array $attributes = []
	): string
	{
		$escape = false;

		$canonical = $this->processAttributeToRaw($attributes, 'canonical');
		$class = $this->processAttributeToRaw($attributes, 'class', ' %s', true);
		$style = $this->processAttributeToRaw($attributes, 'style', '%s', true);
		$toggleClass = $this->processAttributeToRaw($attributes, 'toggle', '%s', true);
		$href = $this->processAttributeToRaw($attributes, 'href', '%s', true);
		$overlay = $this->processAttributeToRaw($attributes, 'overlay', '%s', true);
		$hide = $this->processAttributeToRaw($attributes, 'hideempty', '%s', true);

		$sizeCode = preg_replace('#[^a-zA-Z0-9_-]#', '', $sizeCode);

		$bannerUrl = null;
		if ($group instanceof Group)
		{
			$bannerUrl = $group->getBannerUrl($sizeCode, $canonical);

			$class .= " dbtechSocialGroupsBanner-g" . $group->group_id . "-" . $sizeCode;
		}

		if ($hide)
		{
			$hide = 'data-hide-empty="true"';

			if (!$bannerUrl)
			{
				$class .= ' dbtechSocialGroupsBanner--empty';
			}
		}

		$styleAttr = '';
		if ($style || $bannerUrl)
		{
			$styleAttr = 'style="';
			if ($style)
			{
				$styleAttr .= rtrim($style, ';') . '; ';
			}
			if ($bannerUrl)
			{
				$styleAttr .= 'background-image: url(' . $bannerUrl . ');';

				if ($group->banner_position_y !== null)
				{
					$styleAttr .= ' background-position-y: ' . $group->banner_position_y . '%;';
				}
			}
			$styleAttr .= '"';
		}

		$link = '';
		if ($href)
		{
			if ($overlay)
			{
				$overlay = ' data-xf-click="overlay"';
			}
			$class .= ' fauxBlockLink';
			$link = "<a href=\"" . $href . "\" class=\"fauxBlockLink-blockLink\" " . $overlay . "></a>";
		}

		$unhandledAttrs = $this->processUnhandledAttributes($attributes);

		return "
			<div class=\"dbtechSocialGroupsBanner" . $class . "\" data-toggle-class=\"" . $toggleClass . "\" " . $hide . " " . $styleAttr . $unhandledAttrs . ">"
				. $link .
			"</div>
		";
	}

	/**
	 * @param \XF\Template\Templater $templater
	 * @param bool $escape
	 * @param Group|null $group
	 * @param string $size
	 * @param array $attributes
	 *
	 * @return string
	 */
	public function fnDbtechSocialGroupIcon(
		\XF\Template\Templater $templater,
		bool &$escape,
		?Group $group,
		string $size = 'm',
		array $attributes = []
	): string
	{
		$escape = false;

		$forceType = $this->processAttributeToRaw($attributes, 'forcetype', '', true);
		$canonical = $this->processAttributeToRaw($attributes, 'canonical');
		$update = $templater->processAttributeToRaw($attributes, 'update');

		$size = preg_replace('#[^a-zA-Z0-9_-]#', '', $size);

		if ($group instanceof Group)
		{
			$groupTitle = $group->title;
			if (isset($attributes['href']))
			{
				$href = $attributes['href'];
			}
			else
			{
				$linkPath = $this->currentTemplateType == 'admin' ? 'dbtech-social/groups/edit' : 'dbtech-social';
				$href = $this->getRouter()->buildLink(($canonical ? 'canonical:' : '') . $linkPath, $group);
			}

			$groupId = $group->group_id;
			if (!$groupId)
			{
				$href = null;
			}
			$hrefAttr = $href ? ' href="' . htmlspecialchars($href) . '"' : '';
			$iconType = $forceType ?: $group->getIconType();

			$canUpdate = ($update && $group->canUploadIcon());
		}
		else
		{
			$groupTitle = $attributes['defaultname'] ?? null;
			$hrefAttr = '';
			$groupId = 0;
			$iconType = 'default';
			$canUpdate = false;
		}

		$src = match ($iconType)
		{
			'custom' => $group->getIconUrl($size, $canonical),
			default => null,
		};

		$actualSize = $size;
		if (!array_key_exists($size, \XF::app()->container('avatarSizeMap')))
		{
			$actualSize = 's';
		}

		$sizeClass = 'dbtechSocialGroupsIcon-g' . $groupId . '-' . $actualSize;
		$innerClass = $this->processAttributeToRaw($attributes, 'innerclass', ' %s', true);
		$innerClassHtml = $sizeClass . $innerClass;

		if ($src && $forceType != 'default')
		{
			$srcSet = $group->getIconUrl2x($size, $canonical);

			$itemprop = $this->processAttributeToRaw($attributes, 'itemprop', '%s', true);

			$pixels = $this->app['avatarSizeMap'][$actualSize];

			$innerContent = '<img src="' . htmlspecialchars($src) . '" '
				. (!empty($srcSet) ? 'srcset="' . htmlspecialchars($srcSet) . ' 2x"' : '')
				. ' alt="' . htmlspecialchars($groupTitle) . '"'
				. ' class="' . $innerClassHtml . '"'
				. ' width="' . $pixels . '" height="' . $pixels . '" loading="lazy"'
				. ($itemprop ? ' itemprop="' . $itemprop . '"' : '')
				. ' />';
		}
		else
		{
			$innerContent = $this->getDynamicDbtechSocialGroupIconHtml($groupTitle, $innerClassHtml, $attributes);
		}

		$updateLink = '';
		$updateLinkClass = '';
		if ($canUpdate)
		{
			$updateLinkClass = ' dbtechSocialGroupsIcon--updateLink';
			$updateLink = '<div class="dbtechSocialGroupsIcon-update">
				<a href="' . htmlspecialchars($update) . '" data-xf-click="overlay">' . $this->phrase('dbtech_social_groups_edit_icon') . '</a>
			</div>';
		}

		$class = $this->processAttributeToRaw($attributes, 'class', ' %s', true);
		$xfInit = $this->processAttributeToRaw($attributes, 'data-xf-init', '', true);

		$xfInitAttr = $xfInit ? " data-xf-init=\"$xfInit\"" : '';

		unset($attributes['defaultname'], $attributes['href'], $attributes['itemprop']);

		if (!$hrefAttr && !isset($attributes['title']))
		{
			$attributes['title'] = $groupTitle;
		}

		$unhandledAttrs = $this->processUnhandledAttributes($attributes);

		if ($hrefAttr)
		{
			$tag = 'a';
		}
		else
		{
			$tag = 'span';
		}

		return "<" . $tag . $hrefAttr . " class=\"dbtechSocialGroupsIcon dbtechSocialGroupsIcon--" . $size . $updateLinkClass . $class . "\" data-group-id=\"" . $groupId . "\"" . $xfInitAttr . $unhandledAttrs . ">
			" . $innerContent . " " . $updateLink . "
		</" . $tag . ">";
	}

	/**
	 * @param string $groupTitle
	 * @param string $innerClassHtml
	 * @param array $outerAttributes
	 *
	 * @return string
	 */
	protected function getDynamicDbtechSocialGroupIconHtml(
		string $groupTitle,
		string $innerClassHtml,
		array &$outerAttributes
	)
	{
		if ($groupTitle)
		{
			return $this->getDefaultDbtechSocialGroupIconHtml($groupTitle, $innerClassHtml, $outerAttributes);
		}
		else
		{
			return $this->getFallbackDbtechSocialGroupIconHtml($innerClassHtml, $outerAttributes);
		}
	}

	/**
	 * @param string $groupTitle
	 * @param string $innerClassHtml
	 * @param array $outerAttributes
	 *
	 * @return string
	 */
	protected function getDefaultDbtechSocialGroupIconHtml(
		string $groupTitle,
		string $innerClassHtml,
		array &$outerAttributes
	)
	{
		$styling = $this->getDefaultDbtechSocialGroupIconStyling($groupTitle);

		if (empty($outerAttributes['style']))
		{
			$outerAttributes['style'] = '';
		}
		else
		{
			$outerAttributes['style'] .= '; ';
		}
		$outerAttributes['style'] .= "background-color: $styling[bgColor]; color: $styling[color]";

		if (empty($outerAttributes['class']))
		{
			$outerAttributes['class'] = '';
		}
		else
		{
			$outerAttributes['class'] .= ' ';
		}
		$outerAttributes['class'] .= 'dbtechSocialGroupsIcon--default dbtechSocialGroupsIcon--default--dynamic';

		return '<span class="' . $innerClassHtml . '" role="img" aria-label="' . htmlspecialchars($groupTitle) . '">'
			. $styling['innerContent'] . '</span>';
	}

	/**
	 * @param string $groupTitle
	 *
	 * @return array
	 */
	protected function getDefaultDbtechSocialGroupIconStyling(string $groupTitle): array
	{
		if (!isset($this->dbtechSocialGroupsIconDefaultStylingCache[$groupTitle]))
		{
			$bytes = md5($groupTitle, true);
			$r = dechex(round(5 * ord($bytes[0]) / 255) * 0x33);
			$g = dechex(round(5 * ord($bytes[1]) / 255) * 0x33);
			$b = dechex(round(5 * ord($bytes[2]) / 255) * 0x33);
			$hexBgColor = sprintf('%02s%02s%02s', $r, $g, $b);

			$hslBgColor = Color::hexToHsl($hexBgColor);

			$bgChanged = false;
			if ($hslBgColor[1] > 60)
			{
				$hslBgColor[1] = 60;
				$bgChanged = true;
			}
			else if ($hslBgColor[1] < 15)
			{
				$hslBgColor[1] = 15;
				$bgChanged = true;
			}

			if ($hslBgColor[2] > 85)
			{
				$hslBgColor[2] = 85;
				$bgChanged = true;
			}
			else if ($hslBgColor[2] < 15)
			{
				$hslBgColor[2] = 15;
				$bgChanged = true;
			}

			if ($bgChanged)
			{
				$hexBgColor = Color::hslToHex($hslBgColor);
			}

			$hslColor = Color::darkenOrLightenHsl($hslBgColor, 35);
			$hexColor = Color::hslToHex($hslColor);

			$bgColor = '#' . $hexBgColor;
			$color = '#' . $hexColor;

			if (preg_match($this->dbtechSocialGroupsIconLetterRegex, $groupTitle, $match))
			{
				$innerContent = htmlspecialchars(Str::strtoupper($match[0]));
			}
			else
			{
				$innerContent = '?';
			}

			$this->dbtechSocialGroupsIconDefaultStylingCache[$groupTitle] = [
				'bgColor'      => $bgColor,
				'color'        => $color,
				'innerContent' => $innerContent,
			];
		}

		return $this->dbtechSocialGroupsIconDefaultStylingCache[$groupTitle];
	}

	/**
	 * @param string $innerClassHtml
	 * @param array $outerAttributes
	 *
	 * @return string
	 */
	protected function getFallbackDbtechSocialGroupIconHtml(string $innerClassHtml, array &$outerAttributes): string
	{
		if (empty($outerAttributes['class']))
		{
			$outerAttributes['class'] = '';
		}
		else
		{
			$outerAttributes['class'] .= ' ';
		}

		$fallbackType = $this->style->getProperty('dbtechSocialGroupsIconDefaultType', 'text');
		$outerAttributes['class'] .= 'dbtechSocialGroupsIcon--default dbtechSocialGroupsIcon--default--' . $fallbackType;

		return '<span class="' . $innerClassHtml . '"></span>';
	}

	/**
	 * @param \XF\Template\Templater $templater
	 * @param bool $escape
	 * @param Group|null $group
	 * @param User|null $user
	 * @param array $attributes
	 *
	 * @return string
	 */
	public function fnDbtechSocialGroupUserBanner(
		\XF\Template\Templater $templater,
		bool &$escape,
		?Group $group,
		?User $user,
		array $attributes = []
	): string
	{
		$escape = false;

		if (!($user instanceof User) || !$user->user_id)
		{
			$user = \XF::app()->repository(UserRepository::class)
				->getGuestUser();
		}

		$class = $this->processAttributeToRaw($attributes, 'class', ' %s', true);

		if (!empty($attributes['tag']))
		{
			$tag = htmlspecialchars($attributes['tag']);
		}
		else
		{
			$tag = 'em';
		}

		unset($attributes['tag']);

		$unhandledAttrs = $this->processUnhandledAttributes($attributes);

		$banner = '';
		$options = \XF::options();

		if ($group->user_id === $user->user_id)
		{
			$p = $this->phrase('dbtech_social_groups_group_owner_short');
			$banner = "<" . $tag . " class=\"dbtechSocialGroupsUserBanner dbtechSocialGroupsUserBanner--owner" . $class . "\" dir=\"auto\"" . $unhandledAttrs . ">"
				. "<span class=\"dbtechSocialGroupsUserBanner-before\"></span>"
				. "<strong>" . $p . "</strong>"
				. "<span class=\"dbtechSocialGroupsUserBanner-after\"></span>"
			. "</" . $tag . ">";
		}
		else if ($group->Moderators[$user->user_id])
		{
			$p = $this->phrase('moderator');
			$banner = "<" . $tag . " class=\"dbtechSocialGroupsUserBanner dbtechSocialGroupsUserBanner--staff" . $class . "\" dir=\"auto\"" . $unhandledAttrs . ">"
				. "<span class=\"dbtechSocialGroupsUserBanner-before\"></span>"
				. "<strong>" . $p . "</strong>"
				. "<span class=\"dbtechSocialGroupsUserBanner-after\"></span>"
				. "</" . $tag . ">";
		}
		else if ($group->Supervisors[$user->user_id])
		{
			$p = $this->phrase('dbtech_social_groups_group_supervisor_short');
			$banner = "<" . $tag . " class=\"dbtechSocialGroupsUserBanner dbtechSocialGroupsUserBanner--staff" . $class . "\" dir=\"auto\"" . $unhandledAttrs . ">"
				. "<span class=\"dbtechSocialGroupsUserBanner-before\"></span>"
				. "<strong>" . $p . "</strong>"
				. "<span class=\"dbtechSocialGroupsUserBanner-after\"></span>"
				. "</" . $tag . ">";
		}
		else if ($group->Bans[$user->user_id])
		{
			$p = $this->phrase('banned');
			$banner = "<" . $tag . " class=\"dbtechSocialGroupsUserBanner dbtechSocialGroupsUserBanner--banned" . $class . "\" dir=\"auto\"" . $unhandledAttrs . ">"
				. "<span class=\"dbtechSocialGroupsUserBanner-before\"></span>"
				. "<strong>" . $p . "</strong>"
				. "<span class=\"dbtechSocialGroupsUserBanner-after\"></span>"
				. "</" . $tag . ">";
		}
		else if (!$user->isMemberOfSocialGroup($group))
		{
			$p = $this->phrase('dbtech_social_groups_non_member');
			$banner = "<" . $tag . " class=\"dbtechSocialGroupsUserBanner dbtechSocialGroupsUserBanner--non-member" . $class . "\" dir=\"auto\"" . $unhandledAttrs . ">"
				. "<span class=\"dbtechSocialGroupsUserBanner-before\"></span>"
				. "<strong>" . $p . "</strong>"
				. "<span class=\"dbtechSocialGroupsUserBanner-after\"></span>"
				. "</" . $tag . ">";
		}

		return $banner;
	}
}