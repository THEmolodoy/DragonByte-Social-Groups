<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\XF\Entity;

use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Entity\GroupBan;
use DBTech\SocialGroups\Entity\GroupInvite;
use DBTech\SocialGroups\Entity\GroupMember;
use DBTech\SocialGroups\Finder\GroupFinder;
use DBTech\SocialGroups\Finder\GroupMemberFinder;
use DBTech\SocialGroups\Job\TransferGroups;
use DBTech\SocialGroups\Job\UserDeleteCleanUpContent;
use DBTech\SocialGroups\Job\UserDeleteCleanUpGroups;
use XF\Entity\Page;
use XF\Mvc\Entity\AbstractCollection;
use XF\Mvc\Entity\Structure;
use XF\PrintableException;

use function array_key_exists, in_array, is_null;

/**
 * @extends \XF\Entity\User
 *
 * COLUMNS
 * @property array|null $dbtech_social_groups_group_ids
 * @property int $dbtech_social_groups_group_count
 * @property int $dbtech_social_groups_group_joined_count
 * @property int $dbtech_social_groups_group_invitation_count
 *
 *  GETTERS
 * @property Page|null $dbtech_social_groups_terms
 *
 * RELATIONS
 * @property AbstractCollection|Group[] $OwnedSocialGroups
 * @property AbstractCollection|GroupMember[] $SocialGroupMemberships
 * @property AbstractCollection|GroupInvite[] $SocialGroupInvitations
 * @property AbstractCollection|GroupBan[] $SocialGroupBans
 */
class User extends XFCP_User
{
	/**
	 * @param $error
	 * @return bool
	 */
	public function canViewDbtechSocialGroups(&$error = null)
	{
		return $this->hasPermission('dbtechSocial', 'viewGroup');
	}

	/**
	 * @param $error
	 * @return bool
	 */
	public function canCreateDbtechSocialGroups(&$error = null)
	{
		if (!$this->user_id)
		{
			return false;
		}

		$maxCreatedGroups = $this->hasPermission('dbtechSocial', 'maxCreatedGroups');
		if ($maxCreatedGroups != -1 && $this->dbtech_social_groups_group_count >= $maxCreatedGroups)
		{
			$error = \XF::phraseDeferred('dbtech_social_groups_you_have_reached_limit_x_created_groups', [
				'limit' => $maxCreatedGroups,
			]);
			return false;
		}

		return $this->hasPermission('dbtechSocial', 'createGroup');
	}

	/**
	 * @param $error
	 * @return bool
	 */
	public function canViewDeletedDbtechSocialGroups(&$error = null)
	{
		return $this->hasPermission('dbtechSocial', 'viewDeletedGroups');
	}

	/**
	 * @param $error
	 * @return bool
	 */
	public function canFeatureUnfeatureDbtechSocialGroups(&$error = null)
	{
		return $this->hasPermission('dbtechSocial', 'featureUnfeatureGroups');
	}

	/**
	 * @param $error
	 * @return bool
	 */
	public function canViewModeratedDbtechSocialGroups(&$error = null)
	{
		return $this->hasPermission('dbtechSocial', 'viewModeratedGroups');
	}

	/**
	 * @param $error
	 * @return bool
	 */
	public function canEditAnyDbtechSocialGroups(&$error = null)
	{
		return $this->hasPermission('dbtechSocial', 'editAny');
	}

	/**
	 * @param $error
	 * @return bool
	 */
	public function canViewAnyDbtechSocialGroupLogs(&$error = null)
	{
		return $this->hasPermission('dbtechSocial', 'viewAnyLog');
	}

	/**
	 * @param $error
	 * @return bool
	 */
	public function canImportThreadsToDbtechSocialGroups(&$error = null)
	{
		return $this->hasPermission('dbtechSocial', 'importThreads');
	}

	/**
	 * @param string $type
	 * @param $error
	 *
	 * @return bool
	 */
	public function canDeleteThreadsImportedToDbtechSocialGroups(string $type = 'soft', &$error = null)
	{
		return ($type === 'soft'
			? $this->hasPermission('dbtechSocial', 'deleteImportedThreads')
			: $this->hasPermission('dbtechSocial', 'hardDeleteImportedThreads')
		);
	}

	/**
	 * @param int $contentId
	 * @param string $permission
	 *
	 * @return mixed
	 */
	public function hasDbtechSocialGroupsGroupPermission(int $contentId, string $permission)
	{
		if (!in_array($permission, [
			'viewGroup',
			'viewOthers',
			'viewContent',
			'joinGroup',
		])
			&& !$this->isMemberOfSocialGroup($contentId)
			&& !$this->canEditAnyDbtechSocialGroups()
		)
		{
			return false;
		}

		/** @noinspection PhpInArrayCanBeReplacedWithComparisonInspection */
		if (in_array($permission, [
			'startDiscussion',
		])
			&& !$this->isMemberOfSocialGroup($contentId, true)
			&& !$this->canEditAnyDbtechSocialGroups()
		)
		{
			return false;
		}

		if ($this->isMemberOfSocialGroup($contentId))
		{
			$maximumPermissions = \json_decode(
				\XF::options()->dbtechSocialDefaultPermissions['groupOwner'] ?: '[]',
				true
			);
			if (array_key_exists($permission, $maximumPermissions['contentPermissions']['dbtechSocial']))
			{
				// Load all memberships
				$this->SocialGroupMemberships->populate();

				$groupMembership = $this->SocialGroupMemberships[$contentId];

				if (!empty($groupMembership->permissions)
					&& array_key_exists($permission, $groupMembership->permissions['contentPermissions']['dbtechSocial'])
					&& $groupMembership->permissions['contentPermissions']['dbtechSocial'][$permission] === 'content_allow'
				)
				{
					return true;
				}
			}
		}

		return $this->PermissionSet->hasContentPermission('dbtech_social_group', $contentId, $permission);
	}

	/**
	 * @param int|Group $socialGroupId
	 * @param bool $checkApproval
	 * @param bool $checkInvite
	 *
	 * @return bool
	 */
	public function isMemberOfSocialGroup(Group|int $socialGroupId, bool $checkApproval = false, bool $checkInvite = false)
	{
		if ($socialGroupId instanceof Group)
		{
			$socialGroupId = $socialGroupId->group_id;
		}

		if (!$socialGroupId)
		{
			return false;
		}

		if (is_null($this->dbtech_social_groups_group_ids))
		{
			$this->dbtech_social_groups_group_ids = [];
		}

		if (!in_array($socialGroupId, $this->dbtech_social_groups_group_ids))
		{
			if ($checkInvite)
			{
				$groupInvite = $this->SocialGroupInvitations[$socialGroupId];
				if ($groupInvite)
				{
					return true;
				}
			}

			return false;
		}

		if ($checkApproval)
		{
			$groupMembership = $this->SocialGroupMemberships[$socialGroupId];
			if (!$groupMembership)
			{
				return false;
			}

			return $groupMembership->isValid();
		}

		return true;
	}

	/**
	 * @param int|Group $socialGroupId
	 *
	 * @return bool
	 */
	public function isSupervisorOfSocialGroup(Group|int $socialGroupId)
	{
		if ($socialGroupId instanceof Group)
		{
			$socialGroupId = $socialGroupId->group_id;
		}

		if (!$socialGroupId)
		{
			return false;
		}

		if (is_null($this->dbtech_social_groups_group_ids))
		{
			return false;
		}

		// Load all memberships
		$this->SocialGroupMemberships->populate();

		if (!$this->SocialGroupMemberships[$socialGroupId])
		{
			return false;
		}

		return $this->SocialGroupMemberships[$socialGroupId]->is_supervisor;
	}

	/**
	 * @param bool $newTransaction
	 *
	 * @return void
	 * @throws PrintableException
	 */
	public function rebuildDbtechSocialGroupMemberships(bool $newTransaction = true): void
	{
		if (!$this->user_id)
		{
			throw new \LogicException("User must be saved first");
		}

		if (is_null($this->dbtech_social_groups_group_ids))
		{
			return;
		}

		$db = $this->db();
		$userId = $this->user_id;

		if ($newTransaction)
		{
			$db->beginTransaction();
		}

		$groupMembershipFinder = \XF::app()->finder(GroupMemberFinder::class)
			->with('Group')
			->where('user_id', $this->user_id)
		;

		if (!empty($this->dbtech_social_groups_group_ids))
		{
			$groupMembershipFinder->where('group_id', '!=', $this->dbtech_social_groups_group_ids);
		}

		/** @var AbstractCollection<GroupMember> $orphanMemberships */
		$orphanMemberships = $groupMembershipFinder->fetch();

		foreach ($orphanMemberships AS $groupMember)
		{
			// Cleanup memberships that don't exist in the array
			if ($groupMember->exists())
			{
				$groupMember->delete(true, false);
			}
		}

		if (!empty($this->dbtech_social_groups_group_ids))
		{
			foreach ($this->dbtech_social_groups_group_ids AS $groupId)
			{
				$groupMember = \XF::app()->em()->create(GroupMember::class);
				$groupMember->user_id = $this->user_id;
				$groupMember->group_id = $groupId;
				if ($this->getOption('override_social_group_moderation') || $this->canEditAnyDbtechSocialGroups())
				{
					$groupMember->member_state = 'valid';
				}
				if ($groupMember->preSave())
				{
					$groupMember->save(true, false);
				}
			}

			$this->clearCache('SocialGroupMemberships');
		}

		if ($newTransaction)
		{
			$db->commit();
		}
	}

	public function updateDbtechSocialGroupCounters()
	{
		$this->dbtech_social_groups_group_count = 0;
		$this->dbtech_social_groups_group_joined_count = 0;

		if (!empty($this->dbtech_social_groups_group_ids))
		{
			$groupIds = $this->dbtech_social_groups_group_ids;

			/** @var AbstractCollection<Group> $groups */
			$groups = \XF::app()->finder(GroupFinder::class)
				->with('Members|' . $this->user_id)
				->where('group_id', $groupIds)
				->fetch()
			;

			foreach ($groupIds AS $key => $groupId)
			{
				if (!$groups->offsetExists($groupId))
				{
					unset($groupIds[$key]);
					continue;
				}

				/** @var Group $group */
				$group = $groups->offsetGet($groupId);

				if (!$group->Members[$this->user_id])
				{
					unset($groupIds[$key]);
					continue;
				}

				if ($group->group_state !== 'deleted' && $group->Members[$this->user_id]->member_state !== 'banned')
				{
					if ($group->user_id === $this->user_id)
					{
						$this->dbtech_social_groups_group_count++;
					}
					else
					{
						$this->dbtech_social_groups_group_joined_count++;
					}
				}
			}

			$this->dbtech_social_groups_group_ids = $groupIds;
		}
	}

	/**
	 * @return int
	 */
	public function updateDbtechSocialGroupInvitationCount()
	{
		$invitations = $this->db()->fetchOne('
			SELECT COUNT(*)
			FROM `xf_dbtech_social_groups_group_invite` AS `gi`
			LEFT JOIN `xf_dbtech_social_groups_group` AS `g` USING(`group_id`)
			WHERE `gi`.`user_id` = ?
				AND `g`.`group_state` = ?
		', [$this->user_id, 'visible']);

		$this->dbtech_social_groups_group_invitation_count = $invitations;

		return $invitations;
	}

	/**
	 * @return null|Page
	 */
	public function getDbtechSocialGroupsTerms()
	{
		$options = \XF::options();

		if (!$options->dbtechSocialTermsPageId)
		{
			return null;
		}

		return \XF::app()->em()->find(Page::class, $options->dbtechSocialTermsPageId);
	}

	/**
	 * @return void
	 */
	protected function _preSave()
	{
		parent::_preSave();

		if ($this->isChanged('dbtech_social_groups_group_ids') && $this->user_id)
		{
			$this->updateDbtechSocialGroupCounters();
		}
	}

	/**
	 * @return void
	 * @throws PrintableException
	 */
	protected function _postSave()
	{
		parent::_postSave();

		if ($this->isChanged('dbtech_social_groups_group_ids'))
		{
			$this->rebuildDbtechSocialGroupMemberships(false);
		}
	}

	/**
	 * @return void
	 */
	protected function _postDelete()
	{
		if ($this->getOption('enqueue_social_group_cleanup'))
		{
			if ($this->getOption('social_group_transfer_group_ids') && $this->getOption('social_group_transfer_recipient'))
			{
				\XF::app()->jobManager()->enqueue(TransferGroups::class, [
					'toUserId' => $this->getOption('social_group_transfer_recipient'),
					'groupIds' => $this->getOption('social_group_transfer_group_ids'),
				]);
			}

			\XF::app()->jobManager()->enqueue(UserDeleteCleanUpGroups::class, [
				'userId' => $this->user_id,
				'username' => $this->username,
				'excludedGroupIds' => $this->getOption('social_group_transfer_group_ids'),
			]);
		}

		if ($this->getOption('enqueue_social_content_cleanup'))
		{
			\XF::app()->jobManager()->enqueue(UserDeleteCleanUpContent::class, [
				'userId' => $this->user_id,
				'username' => $this->username,
			]);
		}

		parent::_postDelete();
	}

	/**
	 * @param Structure $structure
	 *
	 * @return Structure
	 */
	public static function getStructure(Structure $structure)
	{
		$structure = parent::getStructure($structure);

		$structure->columns['dbtech_social_groups_group_ids'] = [
			'type'      => self::LIST_COMMA,
			'default'   => [],
			'changeLog' => false,
			'list'      => ['type' => 'posint', 'unique' => true, 'sort' => SORT_NUMERIC],
		];
		$structure->columns['dbtech_social_groups_group_count'] = [
			'type' => self::UINT, 'default' => 0, 'changeLog' => false,
		];
		$structure->columns['dbtech_social_groups_group_joined_count'] = [
			'type' => self::UINT, 'default' => 0, 'changeLog' => false,
		];
		$structure->columns['dbtech_social_groups_group_invitation_count'] = [
			'type' => self::UINT, 'default' => 0, 'changeLog' => false,
		];

		$structure->relations['OwnedSocialGroups'] = [
			'entity'     => Group::class,
			'type'       => self::TO_MANY,
			'conditions' => 'user_id',
			'key'        => 'group_id',
		];
		$structure->relations['SocialGroupMemberships'] = [
			'entity'     => GroupMember::class,
			'type'       => self::TO_MANY,
			'conditions' => 'user_id',
			'with'       => 'Group',
			'key'        => 'group_id',
		];
		$structure->relations['SocialGroupInvitations'] = [
			'entity'     => GroupInvite::class,
			'type'       => self::TO_MANY,
			'conditions' => 'user_id',
			'with'       => 'Group',
			'key'        => 'group_id',
		];
		$structure->relations['SocialGroupBans'] = [
			'entity'     => GroupBan::class,
			'type'       => self::TO_MANY,
			'conditions' => 'user_id',
			'with'       => 'Group',
			'key'        => 'group_id',
		];

		$structure->getters['dbtech_social_groups_terms'] = true;

		$structure->options['override_social_group_moderation'] = false;
		$structure->options['enqueue_social_group_cleanup'] = false;
		$structure->options['enqueue_social_content_cleanup'] = false;
		$structure->options['social_group_transfer_recipient'] = 0;
		$structure->options['social_group_transfer_group_ids'] = [];

		return $structure;
	}
}