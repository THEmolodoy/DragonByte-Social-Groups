<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\XF\Entity;

/**
 * @extends \XF\Entity\Thread
 */
class Thread extends XFCP_Thread
{
	protected function _postDelete()
	{
		parent::_postDelete();

		$db = $this->db();
		$db->delete('xf_dbtech_social_groups_related_thread', 'thread_id = ?', $this->thread_id);
	}
}