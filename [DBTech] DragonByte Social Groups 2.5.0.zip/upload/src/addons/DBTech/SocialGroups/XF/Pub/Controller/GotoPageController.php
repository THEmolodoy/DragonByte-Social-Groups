<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\XF\Pub\Controller;

use DBTech\SocialGroups\Pub\Controller\MessageController;
use XF\InputFilterer;
use XF\Mvc\ParameterBag;

/**
 * @extends \XF\Pub\Controller\GotoPageController
 */
class GotoPageController extends XFCP_GotoPageController
{
	public function actionDbtechSocialMessage(ParameterBag $params)
	{
		$params->offsetSet('message_id', $this->filter('id', InputFilterer::UNSIGNED));
		return $this->rerouteController(MessageController::class, 'index', $params);
	}
}