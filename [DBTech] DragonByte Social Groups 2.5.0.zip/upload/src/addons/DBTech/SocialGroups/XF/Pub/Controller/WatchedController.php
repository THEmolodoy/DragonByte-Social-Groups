<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\XF\Pub\Controller;

use DBTech\SocialGroups\Entity\Discussion;
use DBTech\SocialGroups\Entity\GroupWatch;
use DBTech\SocialGroups\Finder\GroupWatchFinder;
use DBTech\SocialGroups\Pub\View;
use DBTech\SocialGroups\Repository\DiscussionRepository;
use DBTech\SocialGroups\Repository\DiscussionWatchRepository;
use DBTech\SocialGroups\Repository\GroupWatchRepository;
use XF\InputFilterer;
use XF\Mvc\Entity\AbstractCollection;
use XF\Mvc\Reply\AbstractReply;
use XF\Mvc\Reply\Exception as ReplyException;
use XF\PrintableException;

/**
 * @extends \XF\Pub\Controller\WatchedController
 */
class WatchedController extends XFCP_WatchedController
{
	/**
	 * @return AbstractReply
	 */
	public function actionDbtechSocialDiscussions()
	{
		$this->setSectionContext('dbtechSocial');

		$page = $this->filterPage();
		$perPage = \XF::app()->options()->discussionsPerPage;

		$discussionRepo = \XF::app()->repository(DiscussionRepository::class);
		$discussionFinder = $discussionRepo->findDiscussionsForWatchedList();

		$total = $discussionFinder->total();
		$discussions = $discussionFinder->limitByPage($page, $perPage)->fetch();

		$viewParams = [
			'page' => $page,
			'perPage' => $perPage,
			'total' => $total,
			'discussions' => $discussions->filterViewable(),
		];
		return $this->view(
			View\Watched\DiscussionsView::class,
			'dbtech_social_groups_watched_discussions_list',
			$viewParams
		);
	}

	/**
	 * @return AbstractReply
	 */
	public function actionDiscussionsManage()
	{
		$this->setSectionContext('dbtechSocial');

		if (!$state = $this->filter('state', InputFilterer::STRING))
		{
			return $this->redirect($this->buildLink('watched/dbtech-social-discussions'));
		}

		if ($this->isPost())
		{
			$discussionWatchRepo = \XF::app()->repository(DiscussionWatchRepository::class);

			if ($discussionWatchRepo->isValidWatchState($state))
			{
				$discussionWatchRepo->setWatchStateForAll(\XF::visitor(), $state);
			}

			return $this->redirect($this->buildLink('watched/dbtech-social-discussions'));
		}
		else
		{
			$viewParams = [
				'state' => $state,
			];
			return $this->view(
				View\Watched\DiscussionsManageView::class,
				'dbtech_social_groups_watched_discussions_manage',
				$viewParams
			);
		}
	}

	/**
	 * @return AbstractReply
	 * @throws ReplyException
	 * @throws PrintableException
	 */
	public function actionDbtechSocialDiscussionsUpdate()
	{
		$this->assertPostOnly();
		$this->setSectionContext('dbtechSocial');

		$discussionWatchRepo = \XF::app()->repository(DiscussionWatchRepository::class);

		$state = $this->filter('state', InputFilterer::STRING);

		if ($state && $discussionWatchRepo->isValidWatchState($state))
		{
			$discussionIds = $this->filter('discussion_ids', 'array-uint');
			$discussions = \XF::app()->em()->findByIds(Discussion::class, $discussionIds);
			$visitor = \XF::visitor();

			foreach ($discussions AS $discussion)
			{
				$discussionWatchRepo->setWatchState($discussion, $visitor, $state);
			}
		}

		return $this->redirect($this->buildLink('watched/dbtech-social-discussions'));
	}

	/**
	 * @return AbstractReply
	 */
	public function actionDbtechSocialGroups()
	{
		$this->setSectionContext('dbtechSocial');

		$watchedFinder = \XF::app()->finder(GroupWatchFinder::class);

		/** @var AbstractCollection<GroupWatch> $watchedGroups */
		$watchedGroups = $watchedFinder->where('user_id', \XF::visitor()->user_id)
			->keyedBy('group_id')
			->with('Group', true)
			->fetch()
			->filterViewable()
		;

		$viewParams = [
			'watchedGroups' => $watchedGroups,
		];
		return $this->view(
			View\Watched\GroupsView::class,
			'dbtech_social_groups_watched_groups_list',
			$viewParams
		);
	}

	/**
	 * @return AbstractReply
	 */
	public function actionDbtechSocialGroupsManage()
	{
		$this->setSectionContext('dbtechSocial');

		if (!$state = $this->filter('state', InputFilterer::STRING))
		{
			return $this->redirect($this->buildLink('watched/dbtech-social-groups'));
		}

		if ($this->isPost())
		{
			$groupWatchRepo = \XF::app()->repository(GroupWatchRepository::class);

			if ($groupWatchRepo->isValidWatchState($state))
			{
				$groupWatchRepo->setWatchStateForAll(\XF::visitor(), $state);
			}

			return $this->redirect($this->buildLink('watched/dbtech-social-groups'));
		}
		else
		{
			$viewParams = [
				'state' => $state,
			];
			return $this->view(
				View\Watched\GroupsManageView::class,
				'dbtech_social_groups_watched_groups_manage',
				$viewParams
			);
		}
	}

	/**
	 * @return AbstractReply
	 * @throws ReplyException
	 * @throws PrintableException
	 */
	public function actionDbtechSocialGroupsUpdate()
	{
		$this->assertPostOnly();
		$this->setSectionContext('dbtechSocial');

		if ($action = $this->filter('action', InputFilterer::STRING))
		{
			$groupIds = $this->filter('group_ids', 'array-uint');
			$visitor = \XF::visitor();

			foreach ($groupIds AS $groupId)
			{
				$watch = \XF::app()->em()->find(GroupWatch::class, [
					'group_id' => $groupId,
					'user_id' => $visitor->user_id,
				]);
				if (!$watch)
				{
					continue;
				}

				switch ($action)
				{
					case 'email':
					case 'no_email':
						$watch->send_email = ($action == 'email');
						$watch->save();
						break;

					case 'alert':
					case 'no_alert':
						$watch->send_alert = ($action == 'alert');
						$watch->save();
						break;

					case 'delete':
						$watch->delete();
						break;
				}
			}
		}

		return $this->redirect($this->buildLink('watched/dbtech-social-groups'));
	}
}