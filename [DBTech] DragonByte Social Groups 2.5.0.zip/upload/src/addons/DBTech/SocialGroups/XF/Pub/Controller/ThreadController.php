<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\XF\Pub\Controller;

use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Entity\Section;
use DBTech\SocialGroups\Job\ThreadImportProcess;
use DBTech\SocialGroups\Pub\View;
use DBTech\SocialGroups\Repository\GroupRepository;
use DBTech\SocialGroups\XF\Entity\User as ExtendedUserEntity;
use XF\ControllerPlugin\InlineModPlugin;
use XF\Db\Exception as DbException;
use XF\InputFilterer;
use XF\Mvc\ParameterBag;
use XF\Mvc\Reply\AbstractReply;
use XF\Mvc\Reply\Exception as ReplyException;
use XF\PrintableException;

/**
 * @extends \XF\Pub\Controller\ThreadController
 */
class ThreadController extends XFCP_ThreadController
{
	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 * @throws DbException
	 * @throws PrintableException
	 */
	public function actionDbtechSocialImport(ParameterBag $params): AbstractReply
	{
		$thread = $this->assertViewableThread($params->get('thread_id'), ['FirstPost']);
		if (!$thread->canCopy($error))
		{
			return $this->noPermission($error);
		}

		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();
		if (!$visitor->canImportThreadsToDbtechSocialGroups($error))
		{
			return $this->noPermission($error);
		}

		$canDelete = \XF::visitor()->canDeleteThreadsImportedToDbtechSocialGroups();
		$canHardDelete = \XF::visitor()->canDeleteThreadsImportedToDbtechSocialGroups('hardDelete');

		if ($this->isPost())
		{
			$options = $this->filter([
				'target_group_id' => InputFilterer::UINT,
				'target_section_id' => InputFilterer::UINT,
				'cleanup_type' => InputFilterer::STRING,
				'reason' => InputFilterer::STRING,
			]);

			$groupId = $options['target_group_id'];
			$sectionId = $options['target_section_id'];
			$cleanupType = $options['cleanup_type'] ?: 'do_nothing';
			$reason = $options['reason'];

			$group = \XF::em()->find(
				Group::class,
				$groupId
			);
			if (!$group)
			{
				throw new \InvalidArgumentException("Invalid target social group ($groupId)");
			}

			$section = null;
			if ($sectionId)
			{
				$section = \XF::em()->find(
					Section::class,
					$sectionId
				);
				if ($section === null)
				{
					throw new \InvalidArgumentException("Invalid target social group section ($sectionId)");
				}
				if ($section->group_id !== $group->group_id)
				{
					throw new \InvalidArgumentException("Target section's group does not match the target group");
				}
			}

			if (!$canDelete && $cleanupType !== 'do_nothing')
			{
				throw new \LogicException("You don't have permission to delete the imported thread");
			}

			if (!$canHardDelete && $cleanupType === 'hard')
			{
				throw new \LogicException("You don't have permission to hard-delete the imported thread");
			}

			$jobManager = \XF::app()->jobManager();
			$jobManager->enqueueAutoBlocking(ThreadImportProcess::class, [
				'actorId' => $visitor->user_id,
				'threadId' => $thread->thread_id,
				'threadTitle' => $thread->title,
				'userId' => $thread->FirstPost->user_id,
				'username' => $thread->FirstPost->username,
				'groupId' => $group->group_id,
				'sectionId' => $section?->section_id,

				'cleanUpType' => $cleanupType,
				'reason' => $reason,
			]);
			$jobManager->setAutoBlockingMessage(\XF::phrase('dbtech_social_groups_processing_thread_import...'));

			$this->plugin(InlineModPlugin::class)->clearIdFromCookie('thread', $thread->thread_id);

			$router = \XF::app()->router('public');
			if ($section)
			{
				$redirect = $router->buildLink('dbtech-social/sections', $section);
			}
			else
			{
				$redirect = $router->buildLink('dbtech-social/discussions/list', $group);
			}

			return $this->redirect(
				$redirect,
				\XF::phrase('dbtech_social_group_thread_imported')
			);
		}

		$groups = \XF::repository(GroupRepository::class)
			->getFullGroupList()
			->filter(fn (Group $group) => $group->canImportThreads())
		;

		$viewParams = [
			'thread' => $thread,
			'groups' => $groups,
			'canDelete' => $canDelete,
			'canHardDelete' => $canHardDelete,
		];
		return $this->view(
			View\Thread\ImportView::class,
			'dbtech_social_groups_thread_import',
			$viewParams
		);
	}
}