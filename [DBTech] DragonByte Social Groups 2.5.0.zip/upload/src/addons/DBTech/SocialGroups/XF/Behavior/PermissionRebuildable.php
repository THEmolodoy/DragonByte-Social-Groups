<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\XF\Behavior;

use XF\Job\PermissionRebuild;

/**
 * @extends \XF\Behavior\PermissionRebuildable
 */
class PermissionRebuildable extends XFCP_PermissionRebuildable
{
	public function postSave()
	{
		parent::postSave();

		if (
			$this->config['permissionContentType'] === 'dbtech_social_group'
			&& $this->getOption('rebuildCache')
			&& $this->entity->isInsert()
			&& \XF::app()->get('app.classType') == 'Pub'
		)
		{
			// Public doesn't immediately run this
			$jobManager = \XF::app()->jobManager();
			$jobManager->cancelUniqueJob('permissionRebuild');

			$jobManager->enqueueAutoBlocking(PermissionRebuild::class);
			$jobManager->setAutoBlockingMessage(\XF::phrase('dbtech_social_groups_processing_new_group...'));
		}
	}
}