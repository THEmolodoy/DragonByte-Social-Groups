<?php

/** @noinspection PhpMissingReturnTypeInspection */

namespace DBTech\SocialGroups\XF\Admin\Controller;

use XF\Finder\UserFinder;
use XF\InputFilterer;
use XF\Mvc\ParameterBag;
use XF\Mvc\Reply\AbstractReply;
use XF\Mvc\Reply\Exception as ReplyException;
use XF\Service\User\DeleteService;

/**
 * @extends \XF\Admin\Controller\UserController
 */
class UserController extends XFCP_UserController
{
	/**
	 * @param ParameterBag $params
	 *
	 * @return AbstractReply
	 * @throws ReplyException
	 */
	public function actionDelete(ParameterBag $params)
	{
		if ($this->isPost())
		{
			$user = $this->assertUserExists($params->user_id);

			$this->assertCanEditUser($user);

			if ($user->is_super_admin)
			{
				if (!\XF::visitor()->authenticate($this->filter('visitor_password', InputFilterer::STRING)))
				{
					return $this->error(\XF::phrase('your_existing_password_is_not_correct'));
				}
			}

			$redirect = $this->getDynamicRedirectIfNot(
				$this->buildLink('users/edit', $user),
				$this->buildLink('users/list')
			);

			$deleter = \XF::app()->service(DeleteService::class, $user);

			if ($this->filter('social_group_cleanup', InputFilterer::BOOLEAN))
			{
				$recipientId = 0;
				if ($transferGroups = $this->filter('transfer_groups', 'array-uint'))
				{
					$user = \XF::app()->finder(UserFinder::class)
						->where('username', $this->filter('recipient', InputFilterer::STRING))
						->fetchOne()
					;
					if (!$user)
					{
						return $this->error(\XF::phrase('requested_user_x_not_found', ['name' => $this->filter('recipient', InputFilterer::STRING)]));
					}

					$recipientId = $user->user_id;
				}

				$deleter->setDeleteGroups(
					true,
					$transferGroups,
					$recipientId
				);
			}

			if ($this->filter('social_content_cleanup', InputFilterer::BOOLEAN))
			{
				$deleter->setDeleteContent(true);
			}

			if ($this->filter('rename', InputFilterer::BOOLEAN))
			{
				$renameTo = $this->filter('rename_to', InputFilterer::STRING);
				if (!$renameTo)
				{
					return $this->error(\XF::phrase('please_enter_name_to_rename_this_user_to'));
				}
				$deleter->renameTo($renameTo);
			}

			if (!$deleter->delete($errors))
			{
				return $this->error($errors);
			}

			return $this->redirect($redirect);
		}

		return parent::actionDelete($params);
	}
}