<?php

namespace DBTech\SocialGroups\Import\Importer;

use DBTech\SocialGroups\Import\Data\CommentReply;
use XF\Import\StepState;
use XF\Timer;

use function count;

trait StepGroupCommentRepliesTrait
{
	protected static int $commentRepliesStepLimit = 500;

	abstract public function getStepEndGroupComments(): int;
	abstract protected function getGroupCommentIdsForRepliesStep(int $startAfter, int $end, int $commentLimit): array;
	abstract protected function getGroupCommentRepliesForRepliesStep(int $commentId, int $startDate): array;
	abstract protected function getGroupCommentReplyDateField(): string;
	abstract protected function getGroupCommentReplyIdField(): string;
	abstract protected function handleGroupCommentReplyImport(
		array $groupCommentReply,
		int $newDiscussionId,
		StepState $state
	): ?CommentReply;


	/**
	 * @return int
	 */
	public function getStepEndGroupCommentReplies(): int
	{
		return $this->getStepEndGroupComments();
	}

	/**
	 * @param StepState $state
	 * @param array $stepConfig
	 * @param int $maxTime
	 * @param int $limit
	 *
	 * @return StepState
	 * @throws \Exception
	 */
	public function stepGroupCommentReplies(StepState $state, array $stepConfig, int $maxTime, int $limit = 200): StepState
	{
		if ($state->startAfter == 0 && $state->imported == 0)
		{
			// just in case these are lying around, get rid of them before continue...
			unset($state->extra['messageDateStart'], $state->extra['messagePosition']);
		}

		$timer = new Timer($maxTime);

		$commentIds = $this->getGroupCommentIdsForRepliesStep($state->startAfter, $state->end, $limit);

		if (!$commentIds)
		{
			return $state->complete();
		}

		$this->lookup('dbt_sg_group_comment', $commentIds);

		$dateField = $this->getGroupCommentReplyDateField();
		$idField = $this->getGroupCommentReplyIdField();

		foreach ($commentIds AS $oldDiscussionId)
		{
			$newDiscussionId = $this->lookupId('dbt_sg_comment', $oldDiscussionId);

			if (!$newDiscussionId)
			{
				$state = $this->setStateNextGroupComment($state, $oldDiscussionId);
				continue;
			}

			$total = 0;

			if (empty($state->extra['messageDateStart']))
			{
				// starting a new discussion, so initialize the variables that tell us we are mid-discussion
				$state->extra['messageDateStart'] = 0;
				$state->extra['messagePosition'] = 0;
			}

			$commentReplies = $this->getGroupCommentRepliesForRepliesStep($oldDiscussionId, $state->extra['messageDateStart']);

			if (!$commentReplies)
			{
				$state = $this->setStateNextGroupComment($state, $oldDiscussionId);
				continue;
			}

			$continueSameDiscussion = false;
			if (count($commentReplies) == self::$commentRepliesStepLimit)
			{
				$continueSameDiscussion = true;
				$lastDateline = $commentReplies[self::$commentRepliesStepLimit - 1][$dateField];
				while (count($commentReplies) && ($commentReplies[count($commentReplies) - 1][$dateField] == $lastDateline))
				{
					// since we limited the retrieved messages, we don't know
					// if there are further messages in the database with
					// the same dateline, so drop messages until we find one
					// with an earlier dateline.
					array_pop($commentReplies);
				}
			}

			foreach ($commentReplies AS $i => $commentReply)
			{
				$state->extra['messageDateStart'] = $commentReply[$dateField];

				$import = $this->handleGroupCommentReplyImport($commentReply, $newDiscussionId, $state);
				if (!$import)
				{
					continue;
				}

				if ($import->message_state == 'visible')
				{
					$state->extra['messagePosition']++;
				}

				$newId = $import->save($commentReply[$idField]);
				if ($newId)
				{
					$this->afterGroupCommentReplyImport($import, $commentReply, $newId);
					$state->imported++;
					$total++;
				}

				/*
				 * Only allow the timer to break the loop if the next message in the array
				 * has a dateline different from that of the current message, because when we
				 * pick up the loop again, we will only fetch messages that have a date that
				 * is greater than the current message, so in the event that the next message
				 * has a dateline that is the same as the current one, it would otherwise
				 * be omitted.
				 */
				$nextIndex = $i + 1;
				$next = $commentReplies[$nextIndex] ?? null;

				if ($next && $next[$dateField] != $commentReply[$dateField] && $timer->limitExceeded())
				{
					break 2; // end both the message loop, AND the discussion loop -- this will continue the same discussion
				}
			}

			if ($continueSameDiscussion)
			{
				break; // will resume the same discussion if needed
			}

			$state = $this->setStateNextGroupComment($state, $oldDiscussionId);

			if ($timer->limitExceeded())
			{
				break;
			}
		}

		return $state->resumeIfNeeded();
	}

	/**
	 * @param CommentReply $import
	 * @param array $sourceData
	 * @param int $newId
	 *
	 * @return void
	 */
	protected function afterGroupCommentReplyImport(
		CommentReply $import,
		array $sourceData,
		int $newId
	): void
	{
	}

	/**
	 * @param StepState $state
	 * @param $commentId
	 *
	 * @return StepState
	 */
	protected function setStateNextGroupComment(StepState $state, $commentId): StepState
	{
		// move on to the next discussion
		$state->startAfter = $commentId;

		// we've reached the end of a discussion, so reset the variables that tell us we are mid-discussion
		$state->extra['messageDateStart'] = 0;
		$state->extra['messagePosition'] = 0;

		return $state;
	}
}