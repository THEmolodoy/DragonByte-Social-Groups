<?php

namespace DBTech\SocialGroups\Import\Importer;

use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Import\Data\Comment;
use DBTech\SocialGroups\Import\Data\CommentReply;
use DBTech\SocialGroups\Import\Data\Discussion;
use DBTech\SocialGroups\Import\Data\DiscussionReplyBan;
use DBTech\SocialGroups\Import\Data\GroupInvite;
use DBTech\SocialGroups\Import\Data\GroupMember;
use DBTech\SocialGroups\Import\Data\Message;
use DBTech\SocialGroups\Import\Data\Section;
use DBTech\SocialGroups\Import\DataHelper\Banner;
use DBTech\SocialGroups\Import\DataHelper\Icon;
use XF\Db\AbstractAdapter;
use XF\Import\Data\Attachment;
use XF\Import\Data\EditHistory;
use XF\Import\Data\ReactionContent;
use XF\Import\Data\Warning;
use XF\Import\DataHelper\Tag;
use XF\Import\StepState;
use XF\Timer;

use function in_array, intval;

class NobitaSocialGroups extends AbstractCoreImporter
{
	use StepGroupCommentRepliesTrait;


	/**
	 * @return array
	 */
	public static function getListInfo(): array
	{
		return [
			'target' => 'DragonByte Social Groups',
			'source' => '[tl] Social Groups',
			'beta'   => true,
		];
	}

	/**
	 * @param AbstractAdapter $db
	 * @param $error
	 *
	 * @return bool
	 */
	protected function validateVersion(AbstractAdapter $db, &$error): bool
	{
		$versionId = $db->fetchOne("SELECT option_value FROM xf_option WHERE option_id = 'currentVersionId'");
		if (!$versionId || intval($versionId) < 2020031)
		{
			$error = \XF::phrase('xfi_you_may_only_import_from_xenforo_x', ['version' => '2.2+']);
			return false;
		}

		$versionId = $db->fetchOne("SELECT version_id FROM xf_addon WHERE addon_id = 'Truonglv/Groups'");
		if (!$versionId || intval($versionId) < 3030300)
		{
			$error = \XF::phrase('dbtech_social_groups_you_may_only_import_from_tl_x', ['version' => '3.3.3+']);
			return false;
		}

		return true;
	}

	/**
	 * @return array
	 */
	public function getSteps(): array
	{
		return [
			'groups' => [
				'title' => \XF::phrase('dbtech_social_groups_social_groups'),
			],
			'groupTags' => [
				'title' => \XF::phrase('dbtech_social_groups_group_tags'),
				'depends' => ['groups'],
			],
			'groupIcons' => [
				'title' => \XF::phrase('dbtech_social_groups_group_icons'),
				'depends' => ['groups'],
			],
			'groupBanners' => [
				'title' => \XF::phrase('dbtech_social_groups_group_banners'),
				'depends' => ['groups'],
			],
			'groupMembers' => [
				'title' => \XF::phrase('dbtech_social_groups_group_members'),
				'depends' => ['groups'],
			],
			'sections' => [
				'title' => \XF::phrase('dbtech_social_groups_sections'),
				'depends' => ['groups'],
			],
			'discussions' => [
				'title' => \XF::phrase('dbtech_social_groups_discussions_nav'),
				'depends' => ['groups'],
			],
			'discussionTags' => [
				'title' => \XF::phrase('dbtech_social_groups_discussion_tags'),
				'depends' => ['groups', 'discussions'],
			],
			'messages' => [
				'title' => \XF::phrase('dbtech_social_groups_discussion_replies'),
				'depends' => ['groups', 'discussions'],
			],
			'messageEditHistory' => [
				'title' => \XF::phrase('dbtech_social_groups_discussion_reply_edit_history'),
				'depends' => ['groups', 'discussions', 'messages'],
			],
			'messageWarnings' => [
				'title' => \XF::phrase('dbtech_social_groups_discussion_reply_warnings'),
				'depends' => ['groups', 'discussions', 'messages'],
			],
			'messageAttachments' => [
				'title' => \XF::phrase('dbtech_social_groups_group_discussion_attachments'),
				'depends' => ['groups', 'discussions', 'messages'],
			],
			'messageReactions' => [
				'title' => \XF::phrase('dbtech_social_groups_group_discussion_reactions'),
				'depends' => ['groups', 'discussions', 'messages'],
			],
			'groupComments' => [
				'title' => \XF::phrase('dbtech_social_groups_group_comments'),
				'depends' => ['groups'],
			],
			'groupCommentReplies' => [
				'title' => \XF::phrase('dbtech_social_groups_group_comment_replies'),
				'depends' => ['groups', 'groupComments'],
			],
			'groupCommentAttachments' => [
				'title' => \XF::phrase('dbtech_social_groups_group_comment_attachments'),
				'depends' => ['groups', 'groupComments', 'groupCommentReplies'],
			],
			'groupCommentReactions' => [
				'title' => \XF::phrase('dbtech_social_groups_group_comment_reactions'),
				'depends' => ['groups', 'groupComments', 'groupCommentReplies'],
			],
		];
	}


	// ########################### STEP: GROUPS ###############################

	/**
	 * @return int
	 */
	public function getStepEndGroups(): int
	{
		return $this->sourceDb->fetchOne("
			SELECT MAX(group_id)
			FROM xf_tl_group
		") ?: 0;
	}

	/**
	 * @param StepState $state
	 * @param array $stepConfig
	 * @param int|null $maxTime
	 * @param int $limit
	 *
	 * @return StepState
	 * @throws \Exception
	 */
	public function stepGroups(StepState $state, array $stepConfig, ?int $maxTime, int $limit = 500): StepState
	{
		$timer = new Timer($maxTime);

		$groups = $this->getGroups($state->startAfter, $state->end, $limit);

		if (!$groups)
		{
			return $state->complete();
		}

		foreach ($groups AS $oldId => $group)
		{
			$state->startAfter = $oldId;

			/** @var \DBTech\SocialGroups\Import\Data\Group $import */
			$import = $this->newHandler(\DBTech\SocialGroups\Import\Data\Group::class);

			$import->bulkSet($this->mapXfKeys($group, [
				'title'            => 'name',
				'tagline'          => 'short_description',
				'description',
				'member_count',
				'discussion_count',
				'view_count',
				'language_code',
				'user_id'          => 'owner_user_id',
				'username'         => 'owner_username',
				'creation_date'    => 'created_date',
				'last_update_date' => 'last_activity',
				'moderate_members' => 'always_moderate_join',
			]));

			$import->bulkSet([
				'group_type'                  => $this->decodeGroupType($group['privacy']),
				'group_state'                 => $this->decodeGroupState($group['group_state']),
				'allow_members'               => true,
				'moderate_discussions'        => false,
				'moderate_replies'            => false,
				'allow_posting'               => true,
				'allow_discussions'           => true,
				'allow_poll'                  => true,
				'find_new'                    => true,
				'allowed_watch_notifications' => 'all',
				'default_sort_order'          => 'last_message_date',
				'default_sort_direction'      => 'desc',
				'list_date_limit_days'        => 0,
				'min_tags'                    => 0,
				'rules'                       => '',
			]);

			if ($newId = $import->save($oldId))
			{
				$state->imported++;
			}

			if ($timer->limitExceeded())
			{
				break;
			}
		}

		return $state->resumeIfNeeded();
	}

	/**
	 * @param int $startAfter
	 * @param int $end
	 * @param int $limit
	 *
	 * @return array
	 */
	protected function getGroups(int $startAfter, int $end, int $limit): array
	{
		return $this->sourceDb->fetchAllKeyed("
			SELECT g.*
			FROM xf_tl_group AS
				g
			WHERE g.group_id > ? AND g.group_id <= ?
			ORDER BY g.group_id
			LIMIT $limit
		", 'group_id', [$startAfter, $end]);
	}


	// ########################### STEP: GROUP TAGS ###############################

	public function getStepEndGroupTags(): int
	{
		return $this->sourceDb->fetchOne("
			SELECT MAX(tag_content_id) 
			FROM xf_tag_content 
			WHERE content_type IN('tl_group')
		") ?: 0;
	}

	/**
	 * @param StepState $state
	 * @param array $stepConfig
	 * @param int|null $maxTime
	 * @param int $limit
	 *
	 * @return StepState
	 * @throws \Exception
	 */
	public function stepGroupTags(StepState $state, array $stepConfig, ?int $maxTime, int $limit = 1000): StepState
	{
		$timer = new Timer($maxTime);

		$tags = $this->getGroupTags($state->startAfter, $state->end, $limit);

		if (!$tags)
		{
			return $state->complete();
		}

		$this->lookup('dbt_sg_group', $this->pluck($tags, 'content_id'));

		/** @var Tag $tagHelper */
		$tagHelper = $this->getDataHelper(Tag::class);

		foreach ($tags AS $oldId => $tag)
		{
			$state->startAfter = $oldId;

			if (empty($tag['tag']))
			{
				continue;
			}

			$contentId = $this->lookupId('dbt_sg_group', $tag['content_id']);
			if (!$contentId)
			{
				continue;
			}

			$contentExtra = [
				'add_user_id' => $tag['add_user_id'],
				'add_date' => $tag['add_date'],
				'visible' => $tag['visible'],
				'content_date' => $tag['content_date'],
			];
			$tagExtra = [
				'tag_url' => $tag['tag_url'],
				'permanent' => $tag['permanent'],
			];

			$newId = $tagHelper->importTag(
				$tag['tag'],
				'dbtech_social_group',
				$contentId,
				$contentExtra,
				$tagExtra
			);
			if ($newId)
			{
				$state->imported++;
			}

			if ($timer->limitExceeded())
			{
				break;
			}
		}

		return $state->resumeIfNeeded();
	}

	/**
	 * @param int $startAfter
	 * @param int $end
	 * @param int $limit
	 *
	 * @return array
	 */
	protected function getGroupTags(int $startAfter, int $end, int $limit): array
	{
		return $this->sourceDb->fetchAllKeyed("
			SELECT tc.*,
				t.*
			FROM xf_tag_content AS tc
			INNER JOIN xf_tag AS t ON (tc.tag_id = t.tag_id)
			WHERE tc.tag_content_id > ? AND tc.tag_content_id <= ?
				AND tc.content_type IN ('tl_group')
			ORDER BY tc.tag_content_id
			LIMIT $limit
		", 'tag_content_id', [$startAfter, $end]);
	}


	// ########################### STEP: GROUP ICONS ###############################

	/**
	 * @return int
	 */
	public function getStepEndGroupIcons(): int
	{
		return $this->sourceDb->fetchOne("
			SELECT MAX(group_id)
			FROM xf_tl_group
			WHERE avatar_attachment_id <> 0
		") ?: 0;
	}

	/**
	 * @param StepState $state
	 * @param array $stepConfig
	 * @param int|null $maxTime
	 * @param int $limit
	 *
	 * @return StepState
	 * @throws \Exception
	 */
	public function stepGroupIcons(StepState $state, array $stepConfig, ?int $maxTime, int $limit = 500): StepState
	{
		$timer = new Timer($maxTime);

		$groupIcons = $this->getGroupIcons($state->startAfter, $state->end, $limit);

		if (!$groupIcons)
		{
			return $state->complete();
		}

		$this->lookup('dbt_sg_group', $this->pluck($groupIcons, 'group_id'));

		/** @var Icon $iconHelper */
		$iconHelper = $this->dataManager->helper(Icon::class);

		foreach ($groupIcons AS $oldId => $groupIcon)
		{
			$state->startAfter = $oldId;

			if (!$mappedGroupId = $this->lookupId('dbt_sg_group', $oldId))
			{
				continue;
			}

			$sourceFile = $this->getSourceAttachmentDataPath(
				$groupIcon['data_id'],
				$groupIcon['file_path'],
				$groupIcon['file_hash']
			);

			if (!file_exists($sourceFile) || !is_readable($sourceFile))
			{
				continue;
			}

			$targetGroup = \XF::app()->em()->find(Group::class, $mappedGroupId);
			if ($iconHelper->setIconFromFile($sourceFile, $targetGroup))
			{
				$state->imported++;
			}

			\XF::app()->em()->detachEntity($targetGroup);

			if ($timer->limitExceeded())
			{
				break;
			}
		}

		return $state->resumeIfNeeded();
	}

	/**
	 * @param int $startAfter
	 * @param int $end
	 * @param int $limit
	 *
	 * @return array
	 */
	protected function getGroupIcons(int $startAfter, int $end, int $limit): array
	{
		return $this->sourceDb->fetchAllKeyed("
			SELECT g.*, 
			       a.*, 
			       ad.*
			FROM xf_tl_group AS g
			INNER JOIN xf_attachment AS a ON(a.attachment_id = g.avatar_attachment_id)
			INNER JOIN xf_attachment_data AS ad ON (a.data_id = ad.data_id)
			WHERE g.group_id > ? AND g.group_id <= ?
				AND g.avatar_attachment_id <> 0
			ORDER BY g.group_id
			LIMIT $limit
		", 'group_id', [$startAfter, $end]);
	}


	// ########################### STEP: GROUP BANNERS ###############################

	/**
	 * @return int
	 */
	public function getStepEndGroupBanners(): int
	{
		return $this->sourceDb->fetchOne("
			SELECT MAX(group_id)
			FROM xf_tl_group
			WHERE cover_attachment_id <> 0
		") ?: 0;
	}

	/**
	 * @param StepState $state
	 * @param array $stepConfig
	 * @param int|null $maxTime
	 * @param int $limit
	 *
	 * @return StepState
	 * @throws \Exception
	 */
	public function stepGroupBanners(StepState $state, array $stepConfig, ?int $maxTime, int $limit = 500): StepState
	{
		$timer = new Timer($maxTime);

		$groupBanners = $this->getGroupBanners($state->startAfter, $state->end, $limit);

		if (!$groupBanners)
		{
			return $state->complete();
		}

		$this->lookup('dbt_sg_group', $this->pluck($groupBanners, 'group_id'));

		/** @var Banner $iconHelper */
		$iconHelper = $this->dataManager->helper(Banner::class);

		foreach ($groupBanners AS $oldId => $groupBanner)
		{
			$state->startAfter = $oldId;

			if (!$mappedGroupId = $this->lookupId('dbt_sg_group', $oldId))
			{
				continue;
			}

			$sourceFile = $this->getSourceAttachmentDataPath(
				$groupBanner['data_id'],
				$groupBanner['file_path'],
				$groupBanner['file_hash']
			);

			if (!file_exists($sourceFile) || !is_readable($sourceFile))
			{
				continue;
			}

			$targetGroup = \XF::app()->em()->find(Group::class, $mappedGroupId);
			if ($iconHelper->setBannerFromFile($sourceFile, $targetGroup))
			{
				$state->imported++;
			}

			\XF::app()->em()->detachEntity($targetGroup);

			if ($timer->limitExceeded())
			{
				break;
			}
		}

		return $state->resumeIfNeeded();
	}

	/**
	 * @param int $startAfter
	 * @param int $end
	 * @param int $limit
	 *
	 * @return array
	 */
	protected function getGroupBanners(int $startAfter, int $end, int $limit): array
	{
		return $this->sourceDb->fetchAllKeyed("
			SELECT g.*, 
			       a.*, 
			       ad.*
			FROM xf_tl_group AS g
			INNER JOIN xf_attachment AS a ON(a.attachment_id = g.cover_attachment_id)
			INNER JOIN xf_attachment_data AS ad ON (a.data_id = ad.data_id)
			WHERE g.group_id > ? AND g.group_id <= ?
				AND g.cover_attachment_id <> 0
			ORDER BY g.group_id
			LIMIT $limit
		", 'group_id', [$startAfter, $end]);
	}


	// ########################### STEP: GROUP MEMBERS ###############################

	/**
	 * @return int
	 */
	public function getStepEndGroupMembers(): int
	{
		return $this->sourceDb->fetchOne("
			SELECT MAX(member_id)
			FROM xf_tl_group_member
		") ?: 0;
	}

	/**
	 * @param StepState $state
	 * @param array $stepConfig
	 * @param int|null $maxTime
	 * @param int $limit
	 *
	 * @return StepState
	 * @throws \Exception
	 */
	public function stepGroupMembers(StepState $state, array $stepConfig, ?int $maxTime, int $limit = 1000): StepState
	{
		$timer = new Timer($maxTime);

		$groupMembers = $this->getGroupMembers($state->startAfter, $state->end, $limit);

		if (!$groupMembers)
		{
			return $state->complete();
		}

		$this->lookup('dbt_sg_group', $this->pluck($groupMembers, 'group_id'));

		foreach ($groupMembers AS $oldId => $groupMember)
		{
			$state->startAfter = $oldId;

			$newGroupId = $this->lookupId('dbt_sg_group', $groupMember['group_id']);

			if ($groupMember['member_state'] === 'invited')
			{
				/** @var GroupInvite $import */
				$import = $this->newHandler(GroupInvite::class);
				$import->group_id = $newGroupId;
				$import->invited_by_user_id = $groupMember['user_id'];
				$import->bulkSet($this->mapXfKeys($groupMember, [
					'user_id',
					'invite_date' => 'joined_date',
				]));
			}
			else
			{
				/** @var GroupMember $import */
				$import = $this->newHandler(GroupMember::class);

				$import->bulkSet($this->mapXfKeys($groupMember, [
					'user_id',
					'join_date' => 'joined_date',
				]));

				$role = $groupMember['member_role_id'];
				if ($groupMember['user_id'] === $groupMember['group_owner_id'])
				{
					// This is the group owner
					$role = 'admin';
				}
				else if ($groupMember['member_role_id'] === 'admin')
				{
					// Not the group owner but with role of admin
					$role = 'moderator';
				}

				$import->bulkSet([
					'group_id'      => $newGroupId,
					'member_state'  => $this->decodeGroupMemberState($groupMember['member_state']),
					'is_supervisor' => (
						$groupMember['user_id'] === $groupMember['group_owner_id'] || in_array(
							$groupMember['member_role_id'],
							['admin', 'moderator']
						)
					),
					'permissions'   => $this->decodeGroupMemberPermissions($role),
				]);

				if ($groupMember['alert'] !== 'off')
				{
					$watchData = $this->mapKeys($groupMember, [
						'user_id',
					]);

					$watchData['group_id'] = $newGroupId;
					$watchData['notify_on'] = 'discussion';
					$watchData['send_alert'] = in_array($groupMember['alert'], ['all', 'alert']);
					$watchData['send_email'] = in_array($groupMember['alert'], ['all', 'email']);
					$import->setWatch($watchData);
				}

				if ($groupMember['member_state'] === 'banned')
				{
					$banData = $this->mapKeys($groupMember, [
						'user_id',
						'end_date' => 'ban_end_date',
					]);

					$banData['group_id'] = $newGroupId;
					$banData['ban_date'] = \XF::$time;
					$banData['ban_user_id'] = $groupMember['group_owner_id'];
					$import->setBan($banData);
				}
			}

			if ($newId = $import->save($oldId))
			{
				$state->imported++;
			}

			if ($timer->limitExceeded())
			{
				break;
			}
		}

		return $state->resumeIfNeeded();
	}

	/**
	 * @param int $startAfter
	 * @param int $end
	 * @param int $limit
	 *
	 * @return array
	 */
	protected function getGroupMembers(int $startAfter, int $end, int $limit): array
	{
		return $this->sourceDb->fetchAllKeyed("
			SELECT gm.*, g.owner_user_id AS group_owner_id
			FROM xf_tl_group_member AS gm
			LEFT JOIN xf_tl_group AS g ON(g.group_id = gm.group_id)
			WHERE gm.member_id > ? AND gm.member_id <= ?
			ORDER BY gm.member_id
			LIMIT $limit
		", 'member_id', [$startAfter, $end]);
	}


	// ########################### STEP: SECTIONS ###############################

	/**
	 * @param StepState $state
	 *
	 * @return StepState
	 * @throws \Exception
	 */
	public function stepSections(StepState $state): StepState
	{
		$sourceDb = $this->sourceDb;

		$nodes = $sourceDb->fetchAllKeyed("
			SELECT n.*, gf.group_id
			FROM xf_node AS n
			LEFT JOIN xf_tl_group_forum AS gf ON(gf.node_id = n.node_id)
			WHERE n.node_id IN(
				SELECT node_id 
				FROM xf_tl_group_forum
			)
		", 'node_id');

		$typeData = [
			'Forum' => $sourceDb->fetchAllKeyed("SELECT * FROM xf_forum", 'node_id'),
		];

		$nodeTreeMap = [];
		foreach ($nodes AS $nodeId => $node)
		{
			$nodeTreeMap[$node['parent_node_id']][] = $nodeId;
		}

		$this->lookup('dbt_sg_group', $this->pluck($nodes, 'group_id'));

		$state->imported = $this->importSectionTree($nodes, $typeData, $nodeTreeMap);

		return $state->complete();
	}

	/**
	 * @param array $nodes
	 * @param array $typeData
	 * @param array $tree
	 * @param int $oldParentId
	 * @param int $newParentId
	 *
	 * @return int
	 * @throws \Exception
	 */
	protected function importSectionTree(
		array $nodes,
		array $typeData,
		array $tree,
		int $oldParentId = 0,
		int $newParentId = 0
	): int
	{
		if (!isset($tree[$oldParentId]))
		{
			return 0;
		}

		$total = 0;

		foreach ($tree[$oldParentId] AS $oldNodeId)
		{
			$node = $nodes[$oldNodeId];
			if (!isset($typeData[$node['node_type_id']][$oldNodeId]))
			{
				continue;
			}

			$importSection = $this->setupSectionImport($node, $typeData[$node['node_type_id']][$oldNodeId], $newParentId);

			$newNodeId = $importSection->save($oldNodeId);
			if ($newNodeId)
			{
				$total++;
				$total += $this->importSectionTree($nodes, $typeData, $tree, $oldNodeId, $newNodeId);
			}
		}

		return $total;
	}

	/**
	 * @param array $node
	 * @param array $typeData
	 * @param int $newParentId
	 *
	 * @return Section
	 */
	protected function setupSectionImport(
		array $node,
		array $typeData,
		int $newParentId
	): Section
	{
		/** @var Section $import */
		$import = $this->newHandler(Section::class);

		$import->bulkSet($this->mapKeys($node, [
			'title',
			'description',
			'group_id',
			'display_order',
		]));
		$import->group_id = $this->lookupId('dbt_sg_group', $node['group_id'], 0);
		$import->parent_section_id = $newParentId;

		$import->bulkSet($this->mapXfKeys($typeData, [
			'moderate_discussions' => 'moderate_threads',
			'moderate_replies',
			'allow_posting',
			'count_messages',
			'find_new',
			'list_date_limit_days',
			'min_tags',
		]));
		$import->bulkSet([
			'allow_poll' 				  => $typeData['allow_posting'],
			'allow_discussions' 	      => $typeData['allow_posting'],
			'allowed_watch_notifications' => 'all',
			'default_sort_order'          => 'last_message_date',
			'default_sort_direction'      => 'desc',
		]);

		return $import;
	}


	// ########################### STEP: DISCUSSIONS ###############################

	/**
	 * @return int
	 */
	public function getStepEndDiscussions(): int
	{
		return $this->sourceDb->fetchOne("
			SELECT MAX(thread_id)
			FROM xf_thread
			WHERE node_id IN(
				SELECT node_id 
				FROM xf_tl_group_forum
			)
		") ?: 0;
	}

	/**
	 * @param StepState $state
	 * @param array $stepConfig
	 * @param int|null $maxTime
	 * @param int $limit
	 *
	 * @return StepState
	 * @throws \Exception
	 */
	public function stepDiscussions(StepState $state, array $stepConfig, ?int $maxTime, int $limit = 1000): StepState
	{
		$timer = new Timer($maxTime);

		$discussions = $this->getDiscussions($state->startAfter, $state->end, $limit);

		if (!$discussions)
		{
			return $state->complete();
		}

		$this->lookup('dbt_sg_group', $this->pluck($discussions, 'group_id'));

		foreach ($discussions AS $oldId => $discussion)
		{
			$state->startAfter = $oldId;

			if (!$discussion['discussion_state'])
			{
				// invalid state, can't import this thread
				continue;
			}

			/** @var Discussion $import */
			$import = $this->newHandler(Discussion::class);
			$import->group_id = $this->lookupId('dbt_sg_group', $discussion['group_id'], 0);
			$import->section_id = $this->lookupId('dbt_sg_section', $discussion['node_id'], 0);
			$import->bulkSet($this->mapXfKeys($discussion, [
				'title',
				'reply_count',
				'view_count',
				'user_id',
				'username',
				'message_date' => 'post_date',
				'sticky',
				'discussion_state',
				'discussion_open',
				'discussion_type',
				'first_message_reaction_score' => 'first_post_reaction_score',
				'last_message_date' => 'last_post_date',
				'last_message_user_id' => 'last_post_user_id',
				'last_message_username' => 'last_post_username',
			]));
			$import->setDeletionLogData($this->extractDeletionLogData($discussion));

			$reactions = $this->decodeValue($discussion['first_post_reactions'], 'json-array');
			if ($reactions)
			{
				$import->first_message_reactions = $reactions;
			}

			$watchers = $this->sourceDb->fetchPairs("
				SELECT user_id, email_subscribe
				FROM xf_thread_watch
				WHERE thread_id = ?
			", $discussion['thread_id']);
			if ($watchers)
			{
				foreach ($watchers AS $watcherUserId => $emailSubscribe)
				{
					$import->addDiscussionWatcher($watcherUserId, (bool) $emailSubscribe);
				}
			}

			$replyBans = $this->sourceDb->fetchAllKeyed("
				SELECT *
				FROM xf_thread_reply_ban
				WHERE thread_id = ?
			", 'thread_reply_ban_id', $discussion['thread_id']);
			foreach ($replyBans AS $oldReplyBanId => $replyBan)
			{
				/** @var DiscussionReplyBan $importReplyBan */
				$importReplyBan = $this->newHandler(DiscussionReplyBan::class);
				$importReplyBan->bulkSet($this->mapKeys($replyBan, [
					'ban_date',
					'expiry_date',
					'reason',
				]));
				$importReplyBan->user_id = $replyBan['user_id'];
				$importReplyBan->ban_user_id = $replyBan['ban_user_id'];
				$import->addReplyBan($oldReplyBanId, $importReplyBan);
			}

			if ($newId = $import->save($oldId))
			{
				$state->imported++;
			}

			if ($timer->limitExceeded())
			{
				break;
			}
		}

		return $state->resumeIfNeeded();
	}

	/**
	 * @param int $startAfter
	 * @param int $end
	 * @param int $limit
	 *
	 * @return array
	 */
	protected function getDiscussions(int $startAfter, int $end, int $limit): array
	{
		return $this->sourceDb->fetchAllKeyed("
			SELECT t.*, gf.group_id,
				d.delete_date, d.delete_user_id, d.delete_username, d.delete_reason
			FROM xf_thread AS t
			LEFT JOIN xf_tl_group_forum AS gf ON(gf.node_id = t.node_id)
			LEFT JOIN xf_deletion_log AS d ON (d.content_type = 'thread' AND d.content_id = t.thread_id)
			WHERE t.thread_id > ? AND t.thread_id <= ?
				AND t.discussion_type <> 'redirect'
				AND gf.node_id IS NOT NULL
			ORDER BY t.thread_id
			LIMIT $limit
		", 'thread_id', [$startAfter, $end]);
	}


	// ########################### STEP: DISCUSSION TAGS ###############################

	public function getStepEndDiscussionTags(): int
	{
		return $this->sourceDb->fetchOne("
			SELECT MAX(tc.tag_content_id) 
			FROM xf_tag_content AS tc
			LEFT JOIN xf_thread AS th ON(th.thread_id = tc.content_id)
			WHERE tc.content_type IN('tl_group')
		") ?: 0;
	}

	/**
	 * @param StepState $state
	 * @param array $stepConfig
	 * @param int|null $maxTime
	 * @param int $limit
	 *
	 * @return StepState
	 * @throws \Exception
	 */
	public function stepDiscussionTags(StepState $state, array $stepConfig, ?int $maxTime, int $limit = 1000): StepState
	{
		$timer = new Timer($maxTime);

		$tags = $this->getDiscussionTags($state->startAfter, $state->end, $limit);

		if (!$tags)
		{
			return $state->complete();
		}

		$this->lookup('dbt_sg_discussion', $this->pluck($tags, 'content_id'));

		/** @var Tag $tagHelper */
		$tagHelper = $this->getDataHelper(Tag::class);

		foreach ($tags AS $oldId => $tag)
		{
			$state->startAfter = $oldId;

			$contentId = $this->lookupId('dbt_sg_discussion', $tag['content_id']);
			if (!$contentId)
			{
				continue;
			}

			$contentExtra = [
				'add_user_id' => $tag['add_user_id'],
				'add_date' => $tag['add_date'],
				'visible' => $tag['visible'],
				'content_date' => $tag['content_date'],
			];
			$tagExtra = [
				'tag_url' => $tag['tag_url'],
				'permanent' => $tag['permanent'],
			];

			$newId = $tagHelper->importTag(
				$tag['tag'],
				'dbtech_social_discussion',
				$contentId,
				$contentExtra,
				$tagExtra
			);
			if ($newId)
			{
				$state->imported++;
			}

			if ($timer->limitExceeded())
			{
				break;
			}
		}

		return $state->resumeIfNeeded();
	}

	/**
	 * @param int $startAfter
	 * @param int $end
	 * @param int $limit
	 *
	 * @return array
	 */
	protected function getDiscussionTags(int $startAfter, int $end, int $limit): array
	{
		return $this->sourceDb->fetchAllKeyed("
			SELECT tc.*, gf.group_id,
				t.*
			FROM xf_tag_content AS tc
			INNER JOIN xf_tag AS t ON (tc.tag_id = t.tag_id)
			LEFT JOIN xf_thread AS th ON(th.thread_id = tc.content_id)
			LEFT JOIN xf_tl_group_forum AS gf ON(gf.node_id = th.node_id)
			WHERE tc.tag_content_id > ? AND tc.tag_content_id <= ?
				AND tc.content_type IN ('thread')
				AND gf.node_id IS NOT NULL
			ORDER BY tc.tag_content_id
			LIMIT $limit
		", 'tag_content_id', [$startAfter, $end]);
	}


	// ########################### STEP: GROUP MESSAGES ###############################

	/**
	 * @return int
	 */
	public function getStepEndMessages(): int
	{
		return $this->sourceDb->fetchOne("
			SELECT MAX(p.post_id)
			FROM xf_post AS p
			LEFT JOIN xf_thread AS t ON(t.thread_id = p.thread_id)
			WHERE t.node_id IN(
				SELECT node_id 
				FROM xf_tl_group_forum
			)
		") ?: 0;
	}

	/**
	 * @param StepState $state
	 * @param array $stepConfig
	 * @param int|null $maxTime
	 * @param int $limit
	 *
	 * @return StepState
	 * @throws \Exception
	 */
	public function stepMessages(StepState $state, array $stepConfig, ?int $maxTime, int $limit = 1000): StepState
	{
		$timer = new Timer($maxTime);

		$messages = $this->getMessages($state->startAfter, $state->end, $limit);

		if (!$messages)
		{
			return $state->complete();
		}

		$this->lookup('dbt_sg_discussion', $this->pluck($messages, 'thread_id'));

		foreach ($messages AS $oldId => $message)
		{
			$state->startAfter = $oldId;

			$discussionId = $this->lookupId('dbt_sg_discussion', $message['thread_id']);
			if (!$discussionId)
			{
				continue;
			}

			if (!$message['message_state'])
			{
				// invalid state, can't import this thread
				continue;
			}

			/** @var Message $import */
			$import = $this->newHandler(Message::class);
			$import->bulkSet($this->mapXfKeys($message, [
				'user_id',
				'username',
				'message_date' => 'post_date',
				'message_state',
				'position',
				'warning_message',
				'last_edit_user_id',
				'last_edit_date',
				'edit_count',
			]));
			$import->discussion_id = $discussionId;
			$import->message = $this->rewriteQuotes($message['message']);
			if (!empty($message['ip']))
			{
				$import->setLoggedIp($message['ip']);
			}
			$import->setDeletionLogData($this->extractDeletionLogData($message));

			if ($newId = $import->save($oldId))
			{
				$state->imported++;
			}

			if ($timer->limitExceeded())
			{
				break;
			}
		}

		return $state->resumeIfNeeded();
	}

	/**
	 * @param int $startAfter
	 * @param int $end
	 * @param int $limit
	 *
	 * @return array
	 */
	protected function getMessages(int $startAfter, int $end, int $limit): array
	{
		return $this->sourceDb->fetchAllKeyed("
			SELECT p.*, gf.group_id,
				ip.ip,
				d.delete_date, d.delete_user_id, d.delete_username, d.delete_reason
			FROM xf_post AS p
		    LEFT JOIN xf_thread AS t ON(t.thread_id = p.thread_id)
			LEFT JOIN xf_tl_group_forum AS gf ON(gf.node_id = t.node_id)
			LEFT JOIN xf_ip AS ip ON (ip.ip_id = p.ip_id)
			LEFT JOIN xf_deletion_log AS d ON (d.content_type = 'post' AND d.content_id = p.post_id)
			WHERE p.post_id > ? AND p.post_id <= ?
				AND gf.node_id IS NOT NULL
			ORDER BY p.post_id
			LIMIT $limit
		", 'post_id', [$startAfter, $end]);
	}


	// ########################### STEP: MESSAGE EDIT HISTORY ###############################

	public function getStepEndMessageEditHistory(): int
	{
		return $this->sourceDb->fetchOne("
			SELECT MAX(eh.edit_history_id)
			FROM xf_edit_history AS eh
			LEFT JOIN xf_post AS p ON(p.post_id = eh.content_id)
			LEFT JOIN xf_thread AS t ON(t.thread_id = p.thread_id)
			WHERE eh.content_type = 'post'
			    AND t.node_id IN(
					SELECT node_id 
					FROM xf_tl_group_forum
				)
		") ?: 0;
	}

	/**
	 * @param StepState $state
	 * @param array $stepConfig
	 * @param int|null $maxTime
	 * @param int $limit
	 *
	 * @return StepState
	 * @throws \Exception
	 */
	public function stepMessageEditHistory(StepState $state, array $stepConfig, ?int $maxTime, int $limit = 1000): StepState
	{
		$timer = new Timer($maxTime);

		$edits = $this->getMessageEditHistory($state->startAfter, $state->end, $limit);
		if (!$edits)
		{
			return $state->complete();
		}

		$this->lookup('dbt_sg_message', $this->pluck($edits, 'content_id'));

		foreach ($edits AS $oldId => $edit)
		{
			$state->startAfter = $oldId;

			$messageId = $this->lookupId('dbt_sg_message', $edit['content_id']);
			if (!$messageId)
			{
				continue;
			}

			/** @var EditHistory $import */
			$import = $this->newHandler(EditHistory::class);
			$import->bulkSet($this->mapKeys($edit, [
				'edit_date',
				'old_text',
			]));
			$import->content_type = 'dbtech_social_message';
			$import->content_id = $messageId;
			$import->edit_user_id = $edit['edit_user_id'];

			if ($newId = $import->save($oldId))
			{
				$state->imported++;
			}

			if ($timer->limitExceeded())
			{
				break;
			}
		}

		return $state->resumeIfNeeded();
	}

	/**
	 * @param int $startAfter
	 * @param int $end
	 * @param int $limit
	 *
	 * @return array
	 */
	protected function getMessageEditHistory(int $startAfter, int $end, int $limit): array
	{
		return $this->sourceDb->fetchAllKeyed("
			SELECT eh.*
			FROM xf_edit_history AS eh
			LEFT JOIN xf_post AS p ON(p.post_id = eh.content_id)
			LEFT JOIN xf_thread AS t ON(t.thread_id = p.thread_id)
			LEFT JOIN xf_tl_group_forum AS gf ON(gf.node_id = t.node_id)
			WHERE eh.edit_history_id > ? AND eh.edit_history_id <= ?
				AND eh.content_type = 'post'
				AND gf.node_id IS NOT NULL
			ORDER BY eh.edit_history_id
			LIMIT $limit
		", 'edit_history_id', [$startAfter, $end]);
	}


	// ########################### STEP: MESSAGE WARNINGS ###############################

	public function getStepEndMessageWarnings(): int
	{
		return $this->sourceDb->fetchOne("
			SELECT MAX(w.warning_id)
			FROM xf_warning AS w
			LEFT JOIN xf_post AS p ON(p.post_id = w.content_id)
			LEFT JOIN xf_thread AS t ON(t.thread_id = p.thread_id)
			WHERE w.content_type = 'post'
			    AND t.node_id IN(
					SELECT node_id 
					FROM xf_tl_group_forum
				)
		") ?: 0;
	}

	/**
	 * @param StepState $state
	 * @param array $stepConfig
	 * @param int|null $maxTime
	 * @param int $limit
	 *
	 * @return StepState
	 * @throws \Exception
	 */
	public function stepMessageWarnings(StepState $state, array $stepConfig, ?int $maxTime, int $limit = 1000): StepState
	{
		$timer = new Timer($maxTime);

		$warnings = $this->getMessageWarnings($state->startAfter, $state->end, $limit);
		if (!$warnings)
		{
			return $state->complete();
		}

		$this->lookup('dbt_sg_message', $this->pluck($warnings, 'content_id'));

		foreach ($warnings AS $oldId => $warning)
		{
			$state->startAfter = $oldId;

			$messageId = $this->lookupId('dbt_sg_message', $warning['content_id']);
			if (!$messageId)
			{
				continue;
			}

			/** @var Warning $import */
			$import = $this->newHandler(Warning::class);
			$import->bulkSet($this->mapKeys($warning, [
				'content_title',
				'warning_date',
				'title',
				'user_id',
				'warning_user_id',
				'notes',
				'points',
				'expiry_date',
				'is_expired',
			]));
			$import->extra_user_group_ids = explode(',', $warning['extra_user_group_ids']);
			$import->content_type = 'dbtech_social_message';
			$import->content_id = $messageId;

			if ($newId = $import->save($oldId))
			{
				$state->imported++;
			}

			if ($timer->limitExceeded())
			{
				break;
			}
		}

		return $state->resumeIfNeeded();
	}

	/**
	 * @param int $startAfter
	 * @param int $end
	 * @param int $limit
	 *
	 * @return array
	 */
	protected function getMessageWarnings(int $startAfter, int $end, int $limit): array
	{
		return $this->sourceDb->fetchAllKeyed("
			SELECT w.*
			FROM xf_warning AS w
			LEFT JOIN xf_post AS p ON(p.post_id = w.content_id)
			LEFT JOIN xf_thread AS t ON(t.thread_id = p.thread_id)
			LEFT JOIN xf_tl_group_forum AS gf ON(gf.node_id = t.node_id)
			WHERE w.warning_id > ? AND w.warning_id <= ?
				AND w.content_type = 'post'
				AND gf.node_id IS NOT NULL
			ORDER BY w.warning_id
			LIMIT $limit
		", 'warning_id', [$startAfter, $end]);
	}


	// ########################### STEP: MESSAGE ATTACHMENTS ###############################

	public function getStepEndMessageAttachments(): int
	{
		return $this->sourceDb->fetchOne("
			SELECT MAX(a.attachment_id)
			FROM xf_attachment AS a
			LEFT JOIN xf_post AS p ON(p.post_id = a.content_id)
			LEFT JOIN xf_thread AS t ON(t.thread_id = p.thread_id)
			WHERE a.content_type = 'post'
			    AND t.node_id IN(
					SELECT node_id 
					FROM xf_tl_group_forum
				)
		") ?: 0;
	}

	/**
	 * @param StepState $state
	 * @param array $stepConfig
	 * @param int|null $maxTime
	 * @param int $limit
	 *
	 * @return StepState
	 * @throws \Exception
	 */
	public function stepMessageAttachments(StepState $state, array $stepConfig, ?int $maxTime, int $limit = 1000): StepState
	{
		$timer = new Timer($maxTime);

		$attachments = $this->getMessageAttachments($state->startAfter, $state->end, $limit);
		if (!$attachments)
		{
			return $state->complete();
		}

		$this->lookup('dbt_sg_message', $this->pluck($attachments, 'content_id'));

		foreach ($attachments AS $oldId => $attachment)
		{
			$state->startAfter = $oldId;

			$messageId = $this->lookupId('dbt_sg_message', $attachment['content_id']);
			if (!$messageId)
			{
				continue;
			}

			$sourceFile = $this->getSourceAttachmentDataPath(
				$attachment['data_id'],
				$attachment['file_path'],
				$attachment['file_hash']
			);
			if (!file_exists($sourceFile) || !is_readable($sourceFile))
			{
				continue;
			}

			/** @var Attachment $import */
			$import = $this->newHandler(Attachment::class);
			$import->bulkSet($this->mapKeys($attachment, [
				'attach_date',
				'temp_hash',
				'unassociated',
				'view_count',
			]));
			$import->content_type = 'dbtech_social_message';
			$import->content_id = $messageId;
			$import->setDataExtra('upload_date', $attachment['upload_date']);
			$import->setDataExtra('file_path', $attachment['file_path']);
			$import->setDataUserId($attachment['user_id']);
			$import->setSourceFile($sourceFile, $attachment['filename']);
			$import->setContainerCallback([$this, 'rewriteEmbeddedAttachments']);

			if ($newId = $import->save($oldId))
			{
				$state->imported++;
			}

			if ($timer->limitExceeded())
			{
				break;
			}
		}

		return $state->resumeIfNeeded();
	}

	/**
	 * @param int $startAfter
	 * @param int $end
	 * @param int $limit
	 *
	 * @return array
	 */
	protected function getMessageAttachments(int $startAfter, int $end, int $limit): array
	{
		return $this->sourceDb->fetchAllKeyed("
			SELECT a.*, gf.group_id,
				ad.*
			FROM xf_attachment AS a
			LEFT JOIN xf_post AS p ON(p.post_id = a.content_id)
			LEFT JOIN xf_thread AS t ON(t.thread_id = p.thread_id)
			LEFT JOIN xf_tl_group_forum AS gf ON(gf.node_id = t.node_id)
			INNER JOIN xf_attachment_data AS ad ON (a.data_id = ad.data_id)
			WHERE a.attachment_id > ? AND a.attachment_id <= ?
				AND a.content_type = 'post'
				AND gf.node_id IS NOT NULL
			ORDER BY a.attachment_id
			LIMIT $limit
		", 'attachment_id', [$startAfter, $end]);
	}


	// ########################### STEP: MESSAGE REACTIONS ###############################

	public function getStepEndMessageReactions(): int
	{
		return $this->sourceDb->fetchOne("
			SELECT MAX(rc.reaction_content_id)
			FROM xf_reaction_content AS rc
			LEFT JOIN xf_post AS p ON(p.post_id = rc.content_id)
			LEFT JOIN xf_thread AS t ON(t.thread_id = p.thread_id)
			WHERE rc.content_type = 'post'
			    AND t.node_id IN(
					SELECT node_id 
					FROM xf_tl_group_forum
				)
		") ?: 0;
	}

	/**
	 * @param StepState $state
	 * @param array $stepConfig
	 * @param int|null $maxTime
	 * @param int $limit
	 *
	 * @return StepState
	 * @throws \Exception
	 */
	public function stepMessageReactions(StepState $state, array $stepConfig, ?int $maxTime, int $limit = 1000): StepState
	{
		$timer = new Timer($maxTime);

		$reactions = $this->getMessageReactions($state->startAfter, $state->end, $limit);
		if (!$reactions)
		{
			return $state->complete();
		}

		$this->lookup('dbt_sg_message', $this->pluck($reactions, 'content_id'));

		foreach ($reactions AS $oldId => $reaction)
		{
			$state->startAfter = $oldId;

			$messageId = $this->lookupId('dbt_sg_message', $reaction['content_id']);
			if (!$messageId)
			{
				continue;
			}

			/** @var ReactionContent $import */
			$import = $this->newHandler(ReactionContent::class);
			$import->bulkSet($this->mapKeys($reaction, [
				'reaction_user_id',
				'content_user_id',
				'reaction_date',
				'is_counted',
			]));
			$import->setReactionId($reaction['reaction_id']);
			$import->content_id = $messageId;
			$import->content_type = 'dbtech_social_message';

			if ($newId = $import->save($oldId))
			{
				$state->imported++;
			}

			if ($timer->limitExceeded())
			{
				break;
			}
		}

		return $state->resumeIfNeeded();
	}

	/**
	 * @param int $startAfter
	 * @param int $end
	 * @param int $limit
	 *
	 * @return array
	 */
	protected function getMessageReactions(int $startAfter, int $end, int $limit): array
	{
		return $this->sourceDb->fetchAllKeyed("
			SELECT rc.*, gf.group_id
			FROM xf_reaction_content AS rc
			LEFT JOIN xf_post AS p ON(p.post_id = rc.content_id)
			LEFT JOIN xf_thread AS t ON(t.thread_id = p.thread_id)
			LEFT JOIN xf_tl_group_forum AS gf ON(gf.node_id = t.node_id)
			WHERE rc.reaction_content_id > ? AND rc.reaction_content_id <= ?
				AND rc.content_type = 'post'
				AND gf.node_id IS NOT NULL
			ORDER BY rc.reaction_content_id
			LIMIT $limit
		", 'reaction_content_id', [$startAfter, $end]);
	}


	// ########################### STEP: GROUP COMMENTS ###############################

	/**
	 * @return int
	 */
	public function getStepEndGroupComments(): int
	{
		return $this->sourceDb->fetchOne("
			SELECT MAX(post_id)
			FROM xf_tl_group_post
		") ?: 0;
	}

	/**
	 * @param StepState $state
	 * @param array $stepConfig
	 * @param int|null $maxTime
	 * @param int $limit
	 *
	 * @return StepState
	 * @throws \Exception
	 */
	public function stepGroupComments(StepState $state, array $stepConfig, ?int $maxTime, int $limit = 1000): StepState
	{
		$timer = new Timer($maxTime);

		$groupComments = $this->getGroupComments($state->startAfter, $state->end, $limit);

		if (!$groupComments)
		{
			return $state->complete();
		}

		$this->lookup('dbt_sg_group', $this->pluck($groupComments, 'group_id'));

		foreach ($groupComments AS $oldId => $groupComment)
		{
			$state->startAfter = $oldId;

			/** @var Comment $import */
			$import = $this->newHandler(Comment::class);
			$import->bulkSet($this->mapXfKeys($groupComment, [
				'user_id',
				'username',
				'message_date' => 'post_date',
				'reply_count' => 'comment_count',
				'sticky',
			]));

			$import->bulkSet([
				'group_id' => $this->lookupId('dbt_sg_group', $groupComment['group_id'], 0),
				'title' => 'Comment by ' . $groupComment['username'],
				'view_count' => 0,
				'discussion_state' => 'visible',
				'discussion_open' => true,
			]);

			if ($newId = $import->save($oldId))
			{
				$state->imported++;
			}

			if ($timer->limitExceeded())
			{
				break;
			}
		}

		return $state->resumeIfNeeded();
	}

	/**
	 * @param int $startAfter
	 * @param int $end
	 * @param int $limit
	 *
	 * @return array
	 */
	protected function getGroupComments(int $startAfter, int $end, int $limit): array
	{
		return $this->sourceDb->fetchAllKeyed("
			SELECT tlpost.*
			FROM xf_tl_group_post AS
				tlpost
			WHERE tlpost.post_id > ? AND tlpost.post_id <= ?
			ORDER BY tlpost.post_id
			LIMIT $limit
		", 'post_id', [$startAfter, $end]);
	}


	// ########################### STEP: GROUP COMMENT REPLIES ###############################

	protected function getGroupCommentIdsForRepliesStep(int $startAfter, int $end, int $commentLimit): array
	{
		return $this->sourceDb->fetchAllColumn("
			SELECT post_id
			FROM xf_tl_group_post
			WHERE post_id > ? AND post_id <= ?
			ORDER BY post_id
			LIMIT $commentLimit
		", [$startAfter, $end]);
	}

	protected function getGroupCommentRepliesForRepliesStep(int $commentId, int $startDate): array
	{
		return $this->sourceDb->fetchAll("
			SELECT gc.*,
			    ip.ip,
				d.delete_date, d.delete_user_id, d.delete_username, d.delete_reason
			FROM xf_tl_group_comment AS
				gc
			LEFT JOIN xf_ip AS ip ON (ip.ip_id = gc.ip_id)
			LEFT JOIN xf_deletion_log AS d ON (d.content_type = 'tl_group_comment' AND d.content_id = gc.comment_id)
			WHERE gc.content_id = ?
				AND gc.comment_date > ?
			ORDER BY gc.comment_date, gc.comment_id
			LIMIT 500
		", [$commentId, $startDate]);
	}

	protected function getGroupCommentReplyDateField(): string
	{
		return 'comment_date';
	}

	protected function getGroupCommentReplyIdField(): string
	{
		return 'comment_id';
	}

	protected function handleGroupCommentReplyImport(
		array $groupCommentReply,
		int $newDiscussionId,
		StepState $state
	): ?CommentReply
	{
		if (!$groupCommentReply['message_state'])
		{
			// invalid state, can't import this
			return null;
		}

		/** @var CommentReply $import */
		$import = $this->newHandler(CommentReply::class);
		$import->bulkSet($this->mapXfKeys($groupCommentReply, [
			'username',
			'message_date' => 'comment_date',
			'message_state',
			'last_edit_date',
			'edit_count',
		]));
		$import->discussion_id = $newDiscussionId;
		$import->user_id = $groupCommentReply['user_id'];
		$import->last_edit_user_id = $groupCommentReply['last_edit_user_id'] ?: 0;
		$import->message = $this->rewriteQuotes($groupCommentReply['message']);
		$import->position = $state->extra['messagePosition'];
		if (!empty($groupCommentReply['ip']))
		{
			$import->setLoggedIp($groupCommentReply['ip']);
		}
		$import->setDeletionLogData($this->extractDeletionLogData($groupCommentReply));

		return $import;
	}


	// ########################### STEP: MESSAGE ATTACHMENTS ###############################

	public function getStepEndGroupCommentAttachments(): int
	{
		return $this->sourceDb->fetchOne("
			SELECT MAX(a.attachment_id)
			FROM xf_attachment AS a
			WHERE a.content_type = 'tl_group_comment'
		") ?: 0;
	}

	/**
	 * @param StepState $state
	 * @param array $stepConfig
	 * @param int|null $maxTime
	 * @param int $limit
	 *
	 * @return StepState
	 * @throws \Exception
	 */
	public function stepGroupCommentAttachments(StepState $state, array $stepConfig, ?int $maxTime, int $limit = 1000): StepState
	{
		$timer = new Timer($maxTime);

		$attachments = $this->getGroupCommentAttachments($state->startAfter, $state->end, $limit);
		if (!$attachments)
		{
			return $state->complete();
		}

		$this->lookup('dbt_sg_comment_reply', $this->pluck($attachments, 'content_id'));

		foreach ($attachments AS $oldId => $attachment)
		{
			$state->startAfter = $oldId;

			$messageId = $this->lookupId('dbt_sg_comment_reply', $attachment['content_id']);
			if (!$messageId)
			{
				continue;
			}

			$sourceFile = $this->getSourceAttachmentDataPath(
				$attachment['data_id'],
				$attachment['file_path'],
				$attachment['file_hash']
			);
			if (!file_exists($sourceFile) || !is_readable($sourceFile))
			{
				continue;
			}

			/** @var Attachment $import */
			$import = $this->newHandler(Attachment::class);
			$import->bulkSet($this->mapKeys($attachment, [
				'attach_date',
				'temp_hash',
				'unassociated',
				'view_count',
			]));
			$import->content_type = 'dbtech_social_message';
			$import->content_id = $messageId;
			$import->setDataExtra('upload_date', $attachment['upload_date']);
			$import->setDataExtra('file_path', $attachment['file_path']);
			$import->setDataUserId($attachment['user_id']);
			$import->setSourceFile($sourceFile, $attachment['filename']);
			$import->setContainerCallback([$this, 'rewriteEmbeddedAttachments']);

			if ($newId = $import->save($oldId))
			{
				$state->imported++;
			}

			if ($timer->limitExceeded())
			{
				break;
			}
		}

		return $state->resumeIfNeeded();
	}

	/**
	 * @param int $startAfter
	 * @param int $end
	 * @param int $limit
	 *
	 * @return array
	 */
	protected function getGroupCommentAttachments(int $startAfter, int $end, int $limit): array
	{
		return $this->sourceDb->fetchAllKeyed("
			SELECT a.*,
				ad.*
			FROM xf_attachment AS a
			INNER JOIN xf_attachment_data AS ad ON (a.data_id = ad.data_id)
			WHERE a.attachment_id > ? AND a.attachment_id <= ?
				AND a.content_type = 'tl_group_comment'
			ORDER BY a.attachment_id
			LIMIT $limit
		", 'attachment_id', [$startAfter, $end]);
	}


	// ########################### STEP: MESSAGE REACTIONS ###############################

	public function getStepEndGroupCommentReactions(): int
	{
		return $this->sourceDb->fetchOne("
			SELECT MAX(rc.reaction_content_id)
			FROM xf_reaction_content AS rc
			WHERE rc.content_type = 'tl_group_comment'
		") ?: 0;
	}

	/**
	 * @param StepState $state
	 * @param array $stepConfig
	 * @param int|null $maxTime
	 * @param int $limit
	 *
	 * @return StepState
	 * @throws \Exception
	 */
	public function stepGroupCommentReactions(StepState $state, array $stepConfig, ?int $maxTime, int $limit = 1000): StepState
	{
		$timer = new Timer($maxTime);

		$reactions = $this->getGroupCommentReactions($state->startAfter, $state->end, $limit);
		if (!$reactions)
		{
			return $state->complete();
		}

		$this->lookup('dbt_sg_comment_reply', $this->pluck($reactions, 'content_id'));

		foreach ($reactions AS $oldId => $reaction)
		{
			$state->startAfter = $oldId;

			$messageId = $this->lookupId('dbt_sg_comment_reply', $reaction['content_id']);
			if (!$messageId)
			{
				continue;
			}

			/** @var ReactionContent $import */
			$import = $this->newHandler(ReactionContent::class);
			$import->bulkSet($this->mapKeys($reaction, [
				'reaction_user_id',
				'content_user_id',
				'reaction_date',
				'is_counted',
			]));
			$import->setReactionId($reaction['reaction_id']);
			$import->content_id = $messageId;
			$import->content_type = 'dbtech_social_message';

			if ($newId = $import->save($oldId))
			{
				$state->imported++;
			}

			if ($timer->limitExceeded())
			{
				break;
			}
		}

		return $state->resumeIfNeeded();
	}

	/**
	 * @param int $startAfter
	 * @param int $end
	 * @param int $limit
	 *
	 * @return array
	 */
	protected function getGroupCommentReactions(int $startAfter, int $end, int $limit): array
	{
		return $this->sourceDb->fetchAllKeyed("
			SELECT rc.*
			FROM xf_reaction_content AS rc
			WHERE rc.reaction_content_id > ? AND rc.reaction_content_id <= ?
				AND rc.content_type = 'tl_group_comment'
			ORDER BY rc.reaction_content_id
			LIMIT $limit
		", 'reaction_content_id', [$startAfter, $end]);
	}


	/**
	 * @param array $data
	 *
	 * @return array
	 */
	protected function extractDeletionLogData(array $data): array
	{
		$deletionLog = [];
		foreach ($data AS $k => $v)
		{
			if ($v === null)
			{
				continue;
			}

			switch ($k)
			{
				case 'delete_date':
					$deletionLog['date'] = $v;
					break;

				case 'delete_user_id':
					$deletionLog['user_id'] = $v ?: 0;
					break;

				case 'delete_username':
					$deletionLog['username'] = $v;
					break;

				case 'delete_reason':
					$deletionLog['reason'] = $v;
					break;
			}
		}

		return $deletionLog;
	}

	/**
	 * @param string $privacy
	 *
	 * @return string
	 */
	protected function decodeGroupType(string $privacy): string
	{
		return match ($privacy)
		{
			'closed' => 'closed',
			'secret' => 'private',
			default => 'public',
		};
	}

	/**
	 * @param string $state
	 *
	 * @return string
	 */
	protected function decodeGroupState(string $state): string
	{
		return match ($state)
		{
			'moderated' => 'moderated',
			'deleted' => 'deleted',
			default => 'visible',
		};
	}

	/**
	 * @param string $state
	 *
	 * @return string
	 */
	protected function decodeGroupMemberState(string $state): string
	{
		return match ($state)
		{
			'moderated' => 'moderated',
			'banned' => 'banned',
			default => 'valid',
		};
	}

	/**
	 * @param string $role
	 *
	 * @return array
	 */
	protected function decodeGroupMemberPermissions(string $role): array
	{
		return match ($role)
		{
			'admin' => \json_decode(
				\XF::options()->dbtechSocialDefaultPermissions['groupOwner'],
				true
			),
			'moderator' => \json_decode(
				\XF::options()->dbtechSocialDefaultPermissions['groupModerators'],
				true
			),
			default => [],
		};
	}
}