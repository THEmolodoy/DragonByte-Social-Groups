<?php

namespace DBTech\SocialGroups\Import\Importer;

use DBTech\SocialGroups\Job\DiscussionRebuild;
use DBTech\SocialGroups\Job\GroupMemberRebuild;
use DBTech\SocialGroups\Job\GroupMembershipRebuild;
use DBTech\SocialGroups\Job\GroupRebuild;
use DBTech\SocialGroups\Job\SectionRebuild;
use XF\Db\Mysqli\Adapter;
use XF\Import\Importer\AbstractAddOnImporter;
use XF\Import\Importer\XenForoSourceTrait;
use XF\Job\PermissionRebuild;

abstract class AbstractCoreImporter extends AbstractAddOnImporter
{
	use XenForoSourceTrait;


	/**
	 * @return array
	 */
	protected function getBaseConfigDefault(): array
	{
		$config = \XF::app()->config();
		return [
			'db' => [
				'host' => $config['db']['host'],
				'username' => $config['db']['username'],
				'password' => $config['db']['password'],
				'dbname' => $config['db']['dbname'],
				'port' => $config['db']['port'],
			],
			'data_dir' => $config['externalDataPath'],
			'internal_data_dir' => $config['internalDataPath'],
		];
	}

	/**
	 * @param $importType
	 *
	 * @return bool
	 */
	protected function isForumType($importType): bool
	{
		return (!str_starts_with($importType, 'dbt_sg_') && !str_starts_with($importType, 'xfmg_'));
	}

	/**
	 * @return bool
	 */
	public function canRetainIds(): bool
	{
		$db = \XF::app()->db();

		$maxGroupId = $db->fetchOne("SELECT MAX(group_id) FROM xf_dbtech_social_groups_group");
		if ($maxGroupId)
		{
			return false;
		}

		$maxDiscussionId = $db->fetchOne("SELECT MAX(discussion_id) FROM xf_dbtech_social_groups_discussion");
		if ($maxDiscussionId)
		{
			return false;
		}

		$maxMessageId = $db->fetchOne("SELECT MAX(message_id) FROM xf_dbtech_social_groups_message");
		if ($maxMessageId)
		{
			return false;
		}

		$maxMemberId = $db->fetchOne("SELECT MAX(group_member_id) FROM xf_dbtech_social_groups_group_member");
		if ($maxMemberId)
		{
			return false;
		}

		return true;
	}

	/**
	 *
	 */
	public function resetDataForRetainIds(): void
	{
	}

	/**
	 * @return array
	 */
	protected function getStepConfigDefault(): array
	{
		return [];
	}

	/**
	 * @param array $vars
	 *
	 * @return string
	 */
	public function renderStepConfigOptions(array $vars): string
	{
		return '';
	}

	/**
	 * @param array $steps
	 * @param array $stepConfig
	 * @param array $errors
	 *
	 * @return bool
	 */
	public function validateStepConfig(array $steps, array &$stepConfig, array &$errors): bool
	{
		return true;
	}

	/**
	 * @return void
	 */
	protected function doInitializeSource(): void
	{
		$this->sourceDb = new Adapter(
			$this->baseConfig['db'],
			\XF::app()->config('fullUnicode')
		);
	}

	/**
	 * @param array $vars
	 *
	 * @return string|null
	 */
	public function renderBaseConfigOptions(array $vars): ?string
	{
		if (\XF::$developmentMode)
		{
			$vars['requiresDataPath'] = $this->requiresDataPath();
			$vars['requiresInternalDataPath'] = $this->requiresInternalDataPath();

			$vars['requiresForumImportLog'] = $this->requiresForumImportLog();

			return \XF::app()->templater()->renderTemplate('admin:import_config_xenforo_source', $vars);
		}

		return null;
	}

	/**
	 * @param array $stepsRun
	 *
	 * @return array
	 */
	public function getFinalizeJobs(array $stepsRun): array
	{
		$jobs = [];

		$jobs[] = GroupRebuild::class;
		$jobs[] = SectionRebuild::class;
		$jobs[] = GroupMemberRebuild::class;
		$jobs[] = GroupMembershipRebuild::class;
		$jobs[] = DiscussionRebuild::class;
		$jobs[] = PermissionRebuild::class;

		return $jobs;
	}

	/**
	 * @param string $text
	 * @param string $importType
	 *
	 * @return array|string|string[]|null
	 */
	protected function rewriteQuotes(string $text, string $importType = 'message'): array|string|null
	{
		if (stripos($text, '[quote=') === false)
		{
			return $text;
		}

		return preg_replace_callback(
			'/\[quote=("|\'|)(?P<username>[^,]*)\s*,\s*(?P<content_type>[^:]*):\s*(?P<content_id>\d+)\s*(?:,\s*member:\s*(?P<user_id>\d+))?\s*\1\]/iU',
			function ($match) use ($importType)
			{
				if (!empty($match['user_id']))
				{
					return sprintf(
						'[QUOTE="%s, %s: %d, member: %d"]',
						$match['username'],
						'dbtech_social_' . $importType,
						$this->lookupId('dbt_sg_' . $importType, $match['content_id'], 0),
						$match['user_id']
					);
				}
				else
				{
					return sprintf(
						'[QUOTE="%s, %s: %d"]',
						$match['username'],
						'dbtech_social_' . $importType,
						$this->lookupId('dbt_sg_' . $importType, $match['content_id'], 0)
					);
				}
			},
			$text
		);
	}
}