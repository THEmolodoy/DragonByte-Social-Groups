<?php

namespace DBTech\SocialGroups\Import\Importer;

use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Import\Data\Comment;
use DBTech\SocialGroups\Import\Data\CommentReply;
use DBTech\SocialGroups\Import\Data\Discussion;
use DBTech\SocialGroups\Import\Data\DiscussionReplyBan;
use DBTech\SocialGroups\Import\Data\GroupInvite;
use DBTech\SocialGroups\Import\Data\GroupMember;
use DBTech\SocialGroups\Import\Data\Message;
use DBTech\SocialGroups\Import\Data\Section;
use DBTech\SocialGroups\Import\DataHelper\Banner;
use DBTech\SocialGroups\Import\DataHelper\Icon;
use XF\Db\AbstractAdapter;
use XF\Import\Data\Attachment;
use XF\Import\Data\EditHistory;
use XF\Import\Data\ReactionContent;
use XF\Import\Data\Warning;
use XF\Import\StepState;
use XF\Timer;
use XF\Util\Arr;
use XF\Util\File;
use XFMG\Import\Data\Album;
use XFMG\Import\Data\MediaItem;
use XFMG\Job\AlbumRatingRebuild;
use XFMG\Job\AlbumThumb;
use XFMG\Job\Category;
use XFMG\Job\MediaRatingRebuild;
use XFMG\Job\UserCount;
use XFMG\Job\UserMediaQuota;

use function in_array, intval;

class SnogSocialGroups extends AbstractCoreImporter
{
	use StepGroupCommentRepliesTrait;


	/**
	 * @return array
	 */
	public static function getListInfo(): array
	{
		return [
			'target' => 'DragonByte Social Groups',
			'source' => '[OzzModz] Social Groups',
			'beta'   => true,
		];
	}

	/**
	 * @param AbstractAdapter $db
	 * @param $error
	 *
	 * @return bool
	 */
	protected function validateVersion(AbstractAdapter $db, &$error): bool
	{
		$versionId = $db->fetchOne("SELECT option_value FROM xf_option WHERE option_id = 'currentVersionId'");
		if (!$versionId || intval($versionId) < 2020031)
		{
			$error = \XF::phrase('xfi_you_may_only_import_from_xenforo_x', ['version' => '2.2+']);
			return false;
		}

		$versionId = $db->fetchOne("SELECT version_id FROM xf_addon WHERE addon_id = 'Snog/Groups'");
		if (!$versionId || intval($versionId) < 2013370)
		{
			$error = \XF::phrase('dbtech_social_groups_you_may_only_import_from_snog_x', ['version' => '2.1.33+']);
			return false;
		}

		return true;
	}

	/**
	 * @return array
	 */
	public function getSteps(): array
	{
		$steps = [
			'groups' => [
				'title' => \XF::phrase('dbtech_social_groups_social_groups'),
			],
			'groupIcons' => [
				'title' => \XF::phrase('dbtech_social_groups_group_icons'),
				'depends' => ['groups'],
			],
			'groupBanners' => [
				'title' => \XF::phrase('dbtech_social_groups_group_banners'),
				'depends' => ['groups'],
			],
			'groupMembers' => [
				'title' => \XF::phrase('dbtech_social_groups_group_members'),
				'depends' => ['groups'],
			],
			'sections' => [
				'title' => \XF::phrase('dbtech_social_groups_sections'),
				'depends' => ['groups'],
			],
			'discussions' => [
				'title' => \XF::phrase('dbtech_social_groups_discussions_nav'),
				'depends' => ['groups'],
			],
			'messages' => [
				'title' => \XF::phrase('dbtech_social_groups_discussion_replies'),
				'depends' => ['groups', 'discussions'],
			],
			'messageEditHistory' => [
				'title' => \XF::phrase('dbtech_social_groups_discussion_reply_edit_history'),
				'depends' => ['groups', 'discussions', 'messages'],
			],
			'messageWarnings' => [
				'title' => \XF::phrase('dbtech_social_groups_discussion_reply_warnings'),
				'depends' => ['groups', 'discussions', 'messages'],
			],
			'messageAttachments' => [
				'title' => \XF::phrase('dbtech_social_groups_group_discussion_attachments'),
				'depends' => ['groups', 'discussions', 'messages'],
			],
			'messageReactions' => [
				'title' => \XF::phrase('dbtech_social_groups_group_discussion_reactions'),
				'depends' => ['groups', 'discussions', 'messages'],
			],
			'groupComments' => [
				'title' => \XF::phrase('dbtech_social_groups_group_comments'),
				'depends' => ['groups'],
			],
			'groupCommentReplies' => [
				'title' => \XF::phrase('dbtech_social_groups_group_comment_replies'),
				'depends' => ['groups', 'groupComments'],
			],
			'groupCommentReactions' => [
				'title' => \XF::phrase('dbtech_social_groups_group_comment_reactions'),
				'depends' => ['groups', 'groupComments', 'groupCommentReplies'],
			],
		];

		if (\XF::isAddOnActive('XFMG') && \XF::options()->dbtechSocialEnableMediaGallery)
		{
			$steps['groupPhotos'] = [
				'title' => \XF::phrase('dbtech_social_groups_importer_group_photos'),
				'depends' => ['groups'],
			];
			$steps['groupPhotoComments'] = [
				'title' => \XF::phrase('dbtech_social_groups_importer_group_photo_comments'),
				'depends' => ['groups'],
			];
			$steps['groupMedia'] = [
				'title' => \XF::phrase('dbtech_social_groups_importer_group_media'),
				'depends' => ['groups'],
			];
		}

		return $steps;
	}

	public function getFinalizeJobs(array $stepsRun): array
	{
		$jobs = parent::getFinalizeJobs($stepsRun);

		if (\XF::isAddOnActive('XFMG')
			&& (
				in_array('groupPhotos', $stepsRun, true)
				|| in_array('groupMedia', $stepsRun, true)
			)
		)
		{
			$jobs[] = Category::class;
			$jobs[] = \XFMG\Job\Album::class;
			$jobs[] = \XFMG\Job\MediaItem::class;
			$jobs[] = AlbumRatingRebuild::class;
			$jobs[] = MediaRatingRebuild::class;
			$jobs[] = UserCount::class;
			$jobs[] = UserMediaQuota::class;
			$jobs[] = AlbumThumb::class;
		}

		return $jobs;
	}


	// ########################### STEP: GROUPS ###############################

	/**
	 * @return int
	 */
	public function getStepEndGroups(): int
	{
		return $this->sourceDb->fetchOne("
			SELECT MAX(groupid)
			FROM xf_snog_groups
		") ?: 0;
	}

	/**
	 * @param StepState $state
	 * @param array $stepConfig
	 * @param int|null $maxTime
	 * @param int $limit
	 *
	 * @return StepState
	 * @throws \Exception
	 */
	public function stepGroups(StepState $state, array $stepConfig, ?int $maxTime, int $limit = 500): StepState
	{
		$timer = new Timer($maxTime);

		$groups = $this->getGroups($state->startAfter, $state->end, $limit);

		if (!$groups)
		{
			return $state->complete();
		}

		foreach ($groups AS $oldId => $group)
		{
			$state->startAfter = $oldId;

			$import = $this->newHandler(\DBTech\SocialGroups\Import\Data\Group::class);

			$import->bulkSet($this->mapXfKeys($group, [
				'title'            => 'name',
				'tagline'          => 'shortdescription',
				'description'      => 'groupdescription',
				'member_count'     => 'membercount',
				'discussion_count' => 'threadcount',
				'user_id'          => 'owner_id',
				'username'         => 'owner_username',
				'moderate_members' => 'approval',
			]));

			$import->creation_date = \XF::$time;
			$import->last_update_date = \XF::$time;
			$import->group_type = $this->decodeGroupTypeFromFlags($group);
			$import->group_state = 'visible';
			$import->allow_members = true;
			$import->moderate_discussions = false;
			$import->moderate_replies = false;
			$import->allow_posting = true;
			$import->allow_discussions = true;
			$import->allow_poll = true;
			$import->find_new = true;
			$import->allowed_watch_notifications = 'all';
			$import->default_sort_order = 'last_message_date';
			$import->default_sort_direction = 'desc';
			$import->list_date_limit_days = 0;
			$import->min_tags = 0;
			$import->rules = '';

			if ($newId = $import->save($oldId))
			{
				$state->imported++;
			}

			if ($timer->limitExceeded())
			{
				break;
			}
		}

		return $state->resumeIfNeeded();
	}

	/**
	 * @param int $startAfter
	 * @param int $end
	 * @param int $limit
	 *
	 * @return array
	 */
	protected function getGroups(int $startAfter, int $end, int $limit): array
	{
		return $this->sourceDb->fetchAllKeyed("
			SELECT g.*, u.username AS owner_username
			FROM xf_snog_groups AS
				g
			LEFT JOIN xf_user AS u ON(u.user_id = g.owner_id)
			WHERE g.groupid > ? AND g.groupid <= ?
			ORDER BY g.groupid
			LIMIT $limit
		", 'groupid', [$startAfter, $end]);
	}

	// ########################### STEP: GROUP ICONS ###############################

	/**
	 * @return int
	 */
	public function getStepEndGroupIcons(): int
	{
		return $this->sourceDb->fetchOne("
			SELECT MAX(groupid)
			FROM xf_snog_groups
			WHERE groupbanner <> ''
		") ?: 0;
	}

	/**
	 * @param StepState $state
	 * @param array $stepConfig
	 * @param int|null $maxTime
	 * @param int $limit
	 *
	 * @return StepState
	 * @throws \Exception
	 */
	public function stepGroupIcons(StepState $state, array $stepConfig, ?int $maxTime, int $limit = 500): StepState
	{
		$timer = new Timer($maxTime);

		$groupIcons = $this->getGroupIcons($state->startAfter, $state->end, $limit);

		if (!$groupIcons)
		{
			return $state->complete();
		}

		$this->lookup('dbt_sg_group', $this->pluck($groupIcons, 'groupid'));

		$iconHelper = $this->dataManager->helper(Icon::class);

		foreach ($groupIcons AS $oldId => $groupIcon)
		{
			$state->startAfter = $oldId;

			if (!$mappedGroupId = $this->lookupId('dbt_sg_group', $oldId))
			{
				continue;
			}

			$sourceFile = $this->getSourceGroupAvatarDataPath(
				$groupIcon['groupid'],
				$groupIcon['groupbanner'],
			);

			if (!file_exists($sourceFile) || !is_readable($sourceFile))
			{
				continue;
			}

			$targetGroup = \XF::app()->em()->find(Group::class, $mappedGroupId);
			if ($iconHelper->setIconFromFile($sourceFile, $targetGroup))
			{
				$state->imported++;
			}

			\XF::app()->em()->detachEntity($targetGroup);

			if ($timer->limitExceeded())
			{
				break;
			}
		}

		return $state->resumeIfNeeded();
	}

	/**
	 * @param int $startAfter
	 * @param int $end
	 * @param int $limit
	 *
	 * @return array
	 */
	protected function getGroupIcons(int $startAfter, int $end, int $limit): array
	{
		return $this->sourceDb->fetchAllKeyed("
			SELECT g.*
			FROM xf_snog_groups AS g
			WHERE g.groupid > ? AND g.groupid <= ?
				AND g.groupbanner <> ''
			ORDER BY g.groupid
			LIMIT $limit
		", 'groupid', [$startAfter, $end]);
	}


	// ########################### STEP: GROUP BANNERS ###############################

	/**
	 * @return int
	 */
	public function getStepEndGroupBanners(): int
	{
		return $this->sourceDb->fetchOne("
			SELECT MAX(groupid)
			FROM xf_snog_groups
			WHERE groupbanner <> ''
		") ?: 0;
	}

	/**
	 * @param StepState $state
	 * @param array $stepConfig
	 * @param int|null $maxTime
	 * @param int $limit
	 *
	 * @return StepState
	 * @throws \Exception
	 */
	public function stepGroupBanners(StepState $state, array $stepConfig, ?int $maxTime, int $limit = 500): StepState
	{
		$timer = new Timer($maxTime);

		$groupBanners = $this->getGroupBanners($state->startAfter, $state->end, $limit);

		if (!$groupBanners)
		{
			return $state->complete();
		}

		$this->lookup('dbt_sg_group', $this->pluck($groupBanners, 'groupid'));

		$iconHelper = $this->dataManager->helper(Banner::class);

		foreach ($groupBanners AS $oldId => $groupBanner)
		{
			$state->startAfter = $oldId;

			if (!$mappedGroupId = $this->lookupId('dbt_sg_group', $oldId))
			{
				continue;
			}

			$sourceFile = $this->getSourceGroupBannerDataPath(
				$groupBanner['groupid'],
				$groupBanner['groupbanner']
			);

			if (!file_exists($sourceFile) || !is_readable($sourceFile))
			{
				continue;
			}

			$targetGroup = \XF::app()->em()->find(Group::class, $mappedGroupId);
			if ($iconHelper->setBannerFromFile($sourceFile, $targetGroup))
			{
				$state->imported++;
			}

			\XF::app()->em()->detachEntity($targetGroup);

			if ($timer->limitExceeded())
			{
				break;
			}
		}

		return $state->resumeIfNeeded();
	}

	/**
	 * @param int $startAfter
	 * @param int $end
	 * @param int $limit
	 *
	 * @return array
	 */
	protected function getGroupBanners(int $startAfter, int $end, int $limit): array
	{
		return $this->sourceDb->fetchAllKeyed("
			SELECT g.*
			FROM xf_snog_groups AS g
			WHERE g.groupid > ? AND g.groupid <= ?
				AND g.groupbanner <> ''
			ORDER BY g.groupid
			LIMIT $limit
		", 'groupid', [$startAfter, $end]);
	}


	// ########################### STEP: GROUP MEMBERS ###############################

	/**
	 * @return int
	 */
	public function getStepEndGroupMembers(): int
	{
		return $this->sourceDb->fetchOne("
			SELECT MAX(user_id)
			FROM xf_snog_groups_members
		") ?: 0;
	}

	/**
	 * @param StepState $state
	 * @param array $stepConfig
	 * @param int|null $maxTime
	 * @param int $limit
	 *
	 * @return StepState
	 * @throws \Exception
	 */
	public function stepGroupMembers(StepState $state, array $stepConfig, ?int $maxTime, int $limit = 1000): StepState
	{
		$timer = new Timer($maxTime);

		$groupMembers = $this->getGroupMembers($state->startAfter, $state->end, $limit);

		if (!$groupMembers)
		{
			return $state->complete();
		}

		$this->lookup('dbt_sg_group', $this->pluck($groupMembers, 'group_id'));

		foreach ($groupMembers AS $oldId => $groupMember)
		{
			$state->startAfter = $oldId;

			$groupMember['groups'] = \json_decode($groupMember['groups'], true);
			$groupMember['moderator'] = \json_decode($groupMember['moderator'], true);
			$groupMember['owner'] = \json_decode($groupMember['owner'], true);
			$groupMember['pending'] = \json_decode($groupMember['pending'], true);
			$groupMember['invites'] = \json_decode($groupMember['invites'], true);

			foreach ($groupMember['groups'] AS $memberGroupId)
			{
				if (in_array($memberGroupId, $groupMember['owner']))
				{
					// Owns the group
					continue;
				}

				if (in_array($memberGroupId, $groupMember['moderator']))
				{
					// Moderates the group
					continue;
				}

				if (in_array($memberGroupId, $groupMember['pending']))
				{
					// Pending approval - no idea if this would happen
					continue;
				}

				$import = $this->newHandler(GroupMember::class);
				$import->user_id = $groupMember['user_id'];
				$import->group_id = $this->lookupId('dbt_sg_group', $memberGroupId);
				$import->join_date = \XF::$time;
				$import->is_supervisor = false;
				$import->member_state = 'valid';
				$import->permissions = $this->decodeGroupMemberPermissions('member');

				if ($newId = $import->save(false))
				{
					$state->imported++;
				}
			}

			foreach ($groupMember['moderator'] AS $moderatorGroupId)
			{
				if (in_array($moderatorGroupId, $groupMember['owner']))
				{
					// Somehow both a moderator and owner
					continue;
				}

				$import = $this->newHandler(GroupMember::class);
				$import->user_id = $groupMember['user_id'];
				$import->group_id = $this->lookupId('dbt_sg_group', $moderatorGroupId);
				$import->join_date = \XF::$time;
				$import->is_supervisor = true;
				$import->member_state = 'valid';
				$import->permissions = $this->decodeGroupMemberPermissions('moderator');

				if ($newId = $import->save(false))
				{
					$state->imported++;
				}
			}

			foreach ($groupMember['owner'] AS $ownerGroupId)
			{
				$import = $this->newHandler(GroupMember::class);
				$import->user_id = $groupMember['user_id'];
				$import->group_id = $this->lookupId('dbt_sg_group', $ownerGroupId);
				$import->join_date = \XF::$time;
				$import->is_supervisor = true;
				$import->member_state = 'valid';
				$import->permissions = $this->decodeGroupMemberPermissions('admin');

				if ($newId = $import->save(false))
				{
					$state->imported++;
				}
			}

			foreach ($groupMember['pending'] AS $pendingGroupId)
			{
				$import = $this->newHandler(GroupMember::class);
				$import->user_id = $groupMember['user_id'];
				$import->group_id = $this->lookupId('dbt_sg_group', $pendingGroupId);
				$import->join_date = \XF::$time;
				$import->is_supervisor = false;
				$import->member_state = 'moderated';
				$import->permissions = $this->decodeGroupMemberPermissions('member');

				if ($newId = $import->save(false))
				{
					$state->imported++;
				}
			}

			foreach ($groupMember['invites'] AS $invitedGroupId)
			{
				$import = $this->newHandler(GroupInvite::class);
				$import->user_id = $groupMember['user_id'];
				$import->group_id = $this->lookupId('dbt_sg_group', $invitedGroupId);
				$import->invited_by_user_id = $groupMember['user_id'];
				$import->invite_date = \XF::$time;

				if ($newId = $import->save(false))
				{
					$state->imported++;
				}
			}

			if ($timer->limitExceeded())
			{
				break;
			}
		}

		return $state->resumeIfNeeded();
	}

	/**
	 * @param int $startAfter
	 * @param int $end
	 * @param int $limit
	 *
	 * @return array
	 */
	protected function getGroupMembers(int $startAfter, int $end, int $limit): array
	{
		return $this->sourceDb->fetchAllKeyed("
			SELECT gm.*
			FROM xf_snog_groups_members AS gm
			WHERE gm.user_id > ? AND gm.user_id <= ?
			ORDER BY gm.user_id
			LIMIT $limit
		", 'user_id', [$startAfter, $end]);
	}


	// ########################### STEP: SECTIONS ###############################

	/**
	 * @param StepState $state
	 *
	 * @return StepState
	 * @throws \Exception
	 */
	public function stepSections(StepState $state): StepState
	{
		$sourceDb = $this->sourceDb;

		$nodes = $sourceDb->fetchAllKeyed("
			SELECT IFNULL(IFNULL(gc.groupid, gf.groupid), g.groupid) AS group_id, n.*
			FROM xf_node AS n
			LEFT JOIN xf_snog_groups_subforums AS gf ON(gf.node_id = n.node_id)
			LEFT JOIN xf_snog_groups AS g ON(g.node_id = n.node_id)
			LEFT JOIN xf_snog_groups AS gc ON(gc.category_id = n.node_id)
			WHERE n.node_id IN(
				SELECT node_id 
				FROM xf_snog_groups_subforums
			) OR n.node_id IN(
			    SELECT node_id
			    FROM xf_snog_groups
			) OR n.node_id IN(
			    SELECT category_id
			    FROM xf_snog_groups
			)
		", 'node_id');

		$typeData = [
			'Forum' => $sourceDb->fetchAllKeyed("SELECT * FROM xf_forum", 'node_id'),
		];

		$nodeTreeMap = [];
		foreach ($nodes AS $nodeId => $node)
		{
			$nodeTreeMap[$node['parent_node_id']][] = $nodeId;
		}

		$this->lookup('dbt_sg_group', $this->pluck($nodes, 'group_id'));

		$state->imported = $this->importSectionTree($nodes, $typeData, $nodeTreeMap);

		return $state->complete();
	}

	/**
	 * @param array $nodes
	 * @param array $typeData
	 * @param array $tree
	 * @param int $oldParentId
	 * @param int $newParentId
	 *
	 * @return int
	 * @throws \Exception
	 */
	protected function importSectionTree(
		array $nodes,
		array $typeData,
		array $tree,
		int $oldParentId = 0,
		int $newParentId = 0
	): int
	{
		if (!isset($tree[$oldParentId]))
		{
			return 0;
		}

		$total = 0;

		foreach ($tree[$oldParentId] AS $oldNodeId)
		{
			$node = $nodes[$oldNodeId];

			if ($node['node_type_id'] === 'Category')
			{
				// Skip importing the category and treat its immediate child as root section
				$total += $this->importSectionTree(
					$nodes,
					$typeData,
					$tree,
					$oldNodeId
				);
			}
			else
			{
				if (!isset($typeData[$node['node_type_id']][$oldNodeId]))
				{
					continue;
				}

				$importSection = $this->setupSectionImport(
					$node,
					$typeData[$node['node_type_id']][$oldNodeId],
					$newParentId
				);

				$newNodeId = $importSection->save($oldNodeId);
				if ($newNodeId)
				{
					$total++;
					$total += $this->importSectionTree(
						$nodes,
						$typeData,
						$tree,
						$oldNodeId,
						$newNodeId
					);
				}
			}
		}

		return $total;
	}

	/**
	 * @param array $node
	 * @param array $typeData
	 * @param int $newParentId
	 *
	 * @return Section
	 */
	protected function setupSectionImport(
		array $node,
		array $typeData,
		int $newParentId
	): Section
	{
		$import = $this->newHandler(Section::class);

		$import->bulkSet($this->mapKeys($node, [
			'title',
			'description',
			'group_id',
			'display_order',
		]));
		$import->group_id = $this->lookupId('dbt_sg_group', $node['group_id'], 0);
		$import->parent_section_id = $newParentId;

		$import->bulkSet($this->mapXfKeys($typeData, [
			'moderate_discussions' => 'moderate_threads',
			'moderate_replies',
			'allow_posting',
			'count_messages',
			'find_new',
			'list_date_limit_days',
			'min_tags',
		]));
		$import->allow_poll = $typeData['allow_posting'];
		$import->allow_discussions = $typeData['allow_posting'];
		$import->allowed_watch_notifications = 'all';
		$import->default_sort_order = 'last_message_date';
		$import->default_sort_direction = 'desc';

		return $import;
	}


	// ########################### STEP: DISCUSSIONS ###############################

	/**
	 * @return int
	 */
	public function getStepEndDiscussions(): int
	{
		return $this->sourceDb->fetchOne("
			SELECT MAX(thread_id)
			FROM xf_thread
			WHERE node_id IN(
				SELECT node_id 
				FROM xf_snog_groups_subforums
			) OR node_id IN(
			    SELECT node_id
			    FROM xf_snog_groups
			)
		") ?: 0;
	}

	/**
	 * @param StepState $state
	 * @param array $stepConfig
	 * @param int|null $maxTime
	 * @param int $limit
	 *
	 * @return StepState
	 * @throws \Exception
	 */
	public function stepDiscussions(StepState $state, array $stepConfig, ?int $maxTime, int $limit = 1000): StepState
	{
		$timer = new Timer($maxTime);

		$discussions = $this->getDiscussions($state->startAfter, $state->end, $limit);

		if (!$discussions)
		{
			return $state->complete();
		}

		$this->lookup('dbt_sg_group', $this->pluck($discussions, 'group_id'));

		foreach ($discussions AS $oldId => $discussion)
		{
			$state->startAfter = $oldId;

			if (!$discussion['discussion_state'])
			{
				// invalid state, can't import this thread
				continue;
			}

			$import = $this->newHandler(Discussion::class);
			$import->group_id = $this->lookupId('dbt_sg_group', $discussion['group_id'], 0);
			$import->section_id = $this->lookupId('dbt_sg_section', $discussion['node_id'], 0);
			$import->bulkSet($this->mapXfKeys($discussion, [
				'title',
				'reply_count',
				'view_count',
				'user_id',
				'username',
				'message_date' => 'post_date',
				'sticky',
				'discussion_state',
				'discussion_open',
				'discussion_type',
				'first_message_reaction_score' => 'first_post_reaction_score',
				'last_message_date' => 'last_post_date',
				'last_message_user_id' => 'last_post_user_id',
				'last_message_username' => 'last_post_username',
			]));
			$import->setDeletionLogData($this->extractDeletionLogData($discussion));

			$reactions = $this->decodeValue($discussion['first_post_reactions'], 'json-array');
			if ($reactions)
			{
				$import->first_message_reactions = $reactions;
			}

			$watchers = $this->sourceDb->fetchPairs("
				SELECT user_id, email_subscribe
				FROM xf_thread_watch
				WHERE thread_id = ?
			", $discussion['thread_id']);
			if ($watchers)
			{
				foreach ($watchers AS $watcherUserId => $emailSubscribe)
				{
					$import->addDiscussionWatcher($watcherUserId, (bool) $emailSubscribe);
				}
			}

			$replyBans = $this->sourceDb->fetchAllKeyed("
				SELECT *
				FROM xf_thread_reply_ban
				WHERE thread_id = ?
			", 'thread_reply_ban_id', $discussion['thread_id']);
			foreach ($replyBans AS $oldReplyBanId => $replyBan)
			{
				$importReplyBan = $this->newHandler(DiscussionReplyBan::class);
				$importReplyBan->bulkSet($this->mapKeys($replyBan, [
					'ban_date',
					'expiry_date',
					'reason',
				]));
				$importReplyBan->user_id = $replyBan['user_id'];
				$importReplyBan->ban_user_id = $replyBan['ban_user_id'];
				$import->addReplyBan($oldReplyBanId, $importReplyBan);
			}

			if ($newId = $import->save($oldId))
			{
				$state->imported++;
			}

			if ($timer->limitExceeded())
			{
				break;
			}
		}

		return $state->resumeIfNeeded();
	}

	/**
	 * @param int $startAfter
	 * @param int $end
	 * @param int $limit
	 *
	 * @return array
	 */
	protected function getDiscussions(int $startAfter, int $end, int $limit): array
	{
		return $this->sourceDb->fetchAllKeyed("
			SELECT t.*, IFNULL(gf.groupid, g.groupid) AS group_id,
				d.delete_date, d.delete_user_id, d.delete_username, d.delete_reason
			FROM xf_thread AS t
			LEFT JOIN xf_snog_groups_subforums AS gf ON(gf.node_id = t.node_id)
			LEFT JOIN xf_snog_groups AS g ON(g.node_id = t.node_id)
			LEFT JOIN xf_deletion_log AS d ON (d.content_type = 'thread' AND d.content_id = t.thread_id)
			WHERE t.thread_id > ? AND t.thread_id <= ?
				AND t.discussion_type <> 'redirect'
				AND (
					gf.node_id IS NOT NULL
					OR g.node_id IS NOT NULL
				)
			ORDER BY t.thread_id
			LIMIT $limit
		", 'thread_id', [$startAfter, $end]);
	}


	// ########################### STEP: GROUP MESSAGES ###############################

	/**
	 * @return int
	 */
	public function getStepEndMessages(): int
	{
		return $this->sourceDb->fetchOne("
			SELECT MAX(p.post_id)
			FROM xf_post AS p
			LEFT JOIN xf_thread AS t ON(t.thread_id = p.thread_id)
			WHERE t.node_id IN(
				SELECT node_id 
				FROM xf_snog_groups_subforums
			) OR t.node_id IN(
			    SELECT node_id
			    FROM xf_snog_groups
			)
		") ?: 0;
	}

	/**
	 * @param StepState $state
	 * @param array $stepConfig
	 * @param int|null $maxTime
	 * @param int $limit
	 *
	 * @return StepState
	 * @throws \Exception
	 */
	public function stepMessages(StepState $state, array $stepConfig, ?int $maxTime, int $limit = 1000): StepState
	{
		$timer = new Timer($maxTime);

		$messages = $this->getMessages($state->startAfter, $state->end, $limit);

		if (!$messages)
		{
			return $state->complete();
		}

		$this->lookup('dbt_sg_discussion', $this->pluck($messages, 'thread_id'));

		foreach ($messages AS $oldId => $message)
		{
			$state->startAfter = $oldId;

			$discussionId = $this->lookupId('dbt_sg_discussion', $message['thread_id']);
			if (!$discussionId)
			{
				continue;
			}

			if (!$message['message_state'])
			{
				// invalid state, can't import this thread
				continue;
			}

			$import = $this->newHandler(Message::class);
			$import->bulkSet($this->mapXfKeys($message, [
				'user_id',
				'username',
				'message_date' => 'post_date',
				'message_state',
				'position',
				'warning_message',
				'last_edit_user_id',
				'last_edit_date',
				'edit_count',
			]));
			$import->discussion_id = $discussionId;
			$import->message = $this->rewriteQuotes($message['message']);
			if (!empty($message['ip']))
			{
				$import->setLoggedIp($message['ip']);
			}
			$import->setDeletionLogData($this->extractDeletionLogData($message));

			if ($newId = $import->save($oldId))
			{
				$state->imported++;
			}

			if ($timer->limitExceeded())
			{
				break;
			}
		}

		return $state->resumeIfNeeded();
	}

	/**
	 * @param int $startAfter
	 * @param int $end
	 * @param int $limit
	 *
	 * @return array
	 */
	protected function getMessages(int $startAfter, int $end, int $limit): array
	{
		return $this->sourceDb->fetchAllKeyed("
			SELECT p.*, IFNULL(gf.groupid, g.groupid) AS group_id,
				ip.ip,
				d.delete_date, d.delete_user_id, d.delete_username, d.delete_reason
			FROM xf_post AS p
		    LEFT JOIN xf_thread AS t ON(t.thread_id = p.thread_id)
			LEFT JOIN xf_snog_groups_subforums AS gf ON(gf.node_id = t.node_id)
			LEFT JOIN xf_snog_groups AS g ON(g.node_id = t.node_id)
			LEFT JOIN xf_ip AS ip ON (ip.ip_id = p.ip_id)
			LEFT JOIN xf_deletion_log AS d ON (d.content_type = 'post' AND d.content_id = p.post_id)
			WHERE p.post_id > ? AND p.post_id <= ?
				AND (
					gf.node_id IS NOT NULL
					OR g.node_id IS NOT NULL
				)
			ORDER BY p.post_id
			LIMIT $limit
		", 'post_id', [$startAfter, $end]);
	}


	// ########################### STEP: MESSAGE EDIT HISTORY ###############################

	public function getStepEndMessageEditHistory(): int
	{
		return $this->sourceDb->fetchOne("
			SELECT MAX(eh.edit_history_id)
			FROM xf_edit_history AS eh
			LEFT JOIN xf_post AS p ON(p.post_id = eh.content_id)
			LEFT JOIN xf_thread AS t ON(t.thread_id = p.thread_id)
			WHERE eh.content_type = 'post'
			    AND (
			        t.node_id IN(
						SELECT node_id 
						FROM xf_snog_groups_subforums
					) OR t.node_id IN(
						SELECT node_id
						FROM xf_snog_groups
					)
			    )
		") ?: 0;
	}

	/**
	 * @param StepState $state
	 * @param array $stepConfig
	 * @param int|null $maxTime
	 * @param int $limit
	 *
	 * @return StepState
	 * @throws \Exception
	 */
	public function stepMessageEditHistory(StepState $state, array $stepConfig, ?int $maxTime, int $limit = 1000): StepState
	{
		$timer = new Timer($maxTime);

		$edits = $this->getMessageEditHistory($state->startAfter, $state->end, $limit);
		if (!$edits)
		{
			return $state->complete();
		}

		$this->lookup('dbt_sg_message', $this->pluck($edits, 'content_id'));

		foreach ($edits AS $oldId => $edit)
		{
			$state->startAfter = $oldId;

			$messageId = $this->lookupId('dbt_sg_message', $edit['content_id']);
			if (!$messageId)
			{
				continue;
			}

			$import = $this->newHandler(EditHistory::class);
			$import->bulkSet($this->mapKeys($edit, [
				'edit_date',
				'old_text',
			]));
			$import->content_type = 'dbtech_social_message';
			$import->content_id = $messageId;
			$import->edit_user_id = $edit['edit_user_id'];

			if ($newId = $import->save($oldId))
			{
				$state->imported++;
			}

			if ($timer->limitExceeded())
			{
				break;
			}
		}

		return $state->resumeIfNeeded();
	}

	/**
	 * @param int $startAfter
	 * @param int $end
	 * @param int $limit
	 *
	 * @return array
	 */
	protected function getMessageEditHistory(int $startAfter, int $end, int $limit): array
	{
		return $this->sourceDb->fetchAllKeyed("
			SELECT eh.*
			FROM xf_edit_history AS eh
			LEFT JOIN xf_post AS p ON(p.post_id = eh.content_id)
			LEFT JOIN xf_thread AS t ON(t.thread_id = p.thread_id)
			LEFT JOIN xf_snog_groups_subforums AS gf ON(gf.node_id = t.node_id)
			LEFT JOIN xf_snog_groups AS g ON(g.node_id = t.node_id)
			WHERE eh.edit_history_id > ? AND eh.edit_history_id <= ?
				AND eh.content_type = 'post'
				AND (
					gf.node_id IS NOT NULL
					OR g.node_id IS NOT NULL
				)
			ORDER BY eh.edit_history_id
			LIMIT $limit
		", 'edit_history_id', [$startAfter, $end]);
	}


	// ########################### STEP: MESSAGE WARNINGS ###############################

	public function getStepEndMessageWarnings(): int
	{
		return $this->sourceDb->fetchOne("
			SELECT MAX(w.warning_id)
			FROM xf_warning AS w
			LEFT JOIN xf_post AS p ON(p.post_id = w.content_id)
			LEFT JOIN xf_thread AS t ON(t.thread_id = p.thread_id)
			WHERE w.content_type = 'post'
			    AND (
			        t.node_id IN(
						SELECT node_id 
						FROM xf_snog_groups_subforums
					) OR t.node_id IN(
						SELECT node_id
						FROM xf_snog_groups
					)
			    )
		") ?: 0;
	}

	/**
	 * @param StepState $state
	 * @param array $stepConfig
	 * @param int|null $maxTime
	 * @param int $limit
	 *
	 * @return StepState
	 * @throws \Exception
	 */
	public function stepMessageWarnings(StepState $state, array $stepConfig, ?int $maxTime, int $limit = 1000): StepState
	{
		$timer = new Timer($maxTime);

		$warnings = $this->getMessageWarnings($state->startAfter, $state->end, $limit);
		if (!$warnings)
		{
			return $state->complete();
		}

		$this->lookup('dbt_sg_message', $this->pluck($warnings, 'content_id'));

		foreach ($warnings AS $oldId => $warning)
		{
			$state->startAfter = $oldId;

			$messageId = $this->lookupId('dbt_sg_message', $warning['content_id']);
			if (!$messageId)
			{
				continue;
			}

			$import = $this->newHandler(Warning::class);
			$import->bulkSet($this->mapKeys($warning, [
				'content_title',
				'warning_date',
				'title',
				'user_id',
				'warning_user_id',
				'notes',
				'points',
				'expiry_date',
				'is_expired',
			]));
			$import->extra_user_group_ids = explode(',', $warning['extra_user_group_ids']);
			$import->content_type = 'dbtech_social_message';
			$import->content_id = $messageId;

			if ($newId = $import->save($oldId))
			{
				$state->imported++;
			}

			if ($timer->limitExceeded())
			{
				break;
			}
		}

		return $state->resumeIfNeeded();
	}

	/**
	 * @param int $startAfter
	 * @param int $end
	 * @param int $limit
	 *
	 * @return array
	 */
	protected function getMessageWarnings(int $startAfter, int $end, int $limit): array
	{
		return $this->sourceDb->fetchAllKeyed("
			SELECT w.*
			FROM xf_warning AS w
			LEFT JOIN xf_post AS p ON(p.post_id = w.content_id)
			LEFT JOIN xf_thread AS t ON(t.thread_id = p.thread_id)
			LEFT JOIN xf_snog_groups_subforums AS gf ON(gf.node_id = t.node_id)
			LEFT JOIN xf_snog_groups AS g ON(g.node_id = t.node_id)
			WHERE w.warning_id > ? AND w.warning_id <= ?
				AND w.content_type = 'post'
				AND (
					gf.node_id IS NOT NULL
					OR g.node_id IS NOT NULL
				)
			ORDER BY w.warning_id
			LIMIT $limit
		", 'warning_id', [$startAfter, $end]);
	}


	// ########################### STEP: MESSAGE ATTACHMENTS ###############################

	public function getStepEndMessageAttachments(): int
	{
		return $this->sourceDb->fetchOne("
			SELECT MAX(a.attachment_id)
			FROM xf_attachment AS a
			LEFT JOIN xf_post AS p ON(p.post_id = a.content_id)
			LEFT JOIN xf_thread AS t ON(t.thread_id = p.thread_id)
			WHERE a.content_type = 'post'
			    AND (
					t.node_id IN(
						SELECT node_id 
						FROM xf_snog_groups_subforums
					) OR t.node_id IN(
						SELECT node_id
						FROM xf_snog_groups
					)
				)
		") ?: 0;
	}

	/**
	 * @param StepState $state
	 * @param array $stepConfig
	 * @param int|null $maxTime
	 * @param int $limit
	 *
	 * @return StepState
	 * @throws \Exception
	 */
	public function stepMessageAttachments(StepState $state, array $stepConfig, ?int $maxTime, int $limit = 1000): StepState
	{
		$timer = new Timer($maxTime);

		$attachments = $this->getMessageAttachments($state->startAfter, $state->end, $limit);
		if (!$attachments)
		{
			return $state->complete();
		}

		$this->lookup('dbt_sg_message', $this->pluck($attachments, 'content_id'));

		foreach ($attachments AS $oldId => $attachment)
		{
			$state->startAfter = $oldId;

			$messageId = $this->lookupId('dbt_sg_message', $attachment['content_id']);
			if (!$messageId)
			{
				continue;
			}

			$sourceFile = $this->getSourceAttachmentDataPath(
				$attachment['data_id'],
				$attachment['file_path'],
				$attachment['file_hash']
			);
			if (!file_exists($sourceFile) || !is_readable($sourceFile))
			{
				continue;
			}

			$import = $this->newHandler(Attachment::class);
			$import->bulkSet($this->mapKeys($attachment, [
				'attach_date',
				'temp_hash',
				'unassociated',
				'view_count',
			]));
			$import->content_type = 'dbtech_social_message';
			$import->content_id = $messageId;
			$import->setDataExtra('upload_date', $attachment['upload_date']);
			$import->setDataExtra('file_path', $attachment['file_path']);
			$import->setDataUserId($attachment['user_id']);
			$import->setSourceFile($sourceFile, $attachment['filename']);
			$import->setContainerCallback([$this, 'rewriteEmbeddedAttachments']);

			if ($newId = $import->save($oldId))
			{
				$state->imported++;
			}

			if ($timer->limitExceeded())
			{
				break;
			}
		}

		return $state->resumeIfNeeded();
	}

	/**
	 * @param int $startAfter
	 * @param int $end
	 * @param int $limit
	 *
	 * @return array
	 */
	protected function getMessageAttachments(int $startAfter, int $end, int $limit): array
	{
		return $this->sourceDb->fetchAllKeyed("
			SELECT a.*, IFNULL(gf.groupid, g.groupid) AS group_id,
				ad.*
			FROM xf_attachment AS a
			LEFT JOIN xf_post AS p ON(p.post_id = a.content_id)
			LEFT JOIN xf_thread AS t ON(t.thread_id = p.thread_id)
			LEFT JOIN xf_snog_groups_subforums AS gf ON(gf.node_id = t.node_id)
			LEFT JOIN xf_snog_groups AS g ON(g.node_id = t.node_id)
			INNER JOIN xf_attachment_data AS ad ON (a.data_id = ad.data_id)
			WHERE a.attachment_id > ? AND a.attachment_id <= ?
				AND a.content_type = 'post'
				AND (
					gf.node_id IS NOT NULL
					OR g.node_id IS NOT NULL
				)
			ORDER BY a.attachment_id
			LIMIT $limit
		", 'attachment_id', [$startAfter, $end]);
	}


	// ########################### STEP: MESSAGE REACTIONS ###############################

	public function getStepEndMessageReactions(): int
	{
		return $this->sourceDb->fetchOne("
			SELECT MAX(rc.reaction_content_id)
			FROM xf_reaction_content AS rc
			LEFT JOIN xf_post AS p ON(p.post_id = rc.content_id)
			LEFT JOIN xf_thread AS t ON(t.thread_id = p.thread_id)
			WHERE rc.content_type = 'post'
			    AND (
					t.node_id IN(
						SELECT node_id 
						FROM xf_snog_groups_subforums
					) OR t.node_id IN(
						SELECT node_id
						FROM xf_snog_groups
					)
				)
		") ?: 0;
	}

	/**
	 * @param StepState $state
	 * @param array $stepConfig
	 * @param int|null $maxTime
	 * @param int $limit
	 *
	 * @return StepState
	 * @throws \Exception
	 */
	public function stepMessageReactions(StepState $state, array $stepConfig, ?int $maxTime, int $limit = 1000): StepState
	{
		$timer = new Timer($maxTime);

		$reactions = $this->getMessageReactions($state->startAfter, $state->end, $limit);
		if (!$reactions)
		{
			return $state->complete();
		}

		$this->lookup('dbt_sg_message', $this->pluck($reactions, 'content_id'));

		foreach ($reactions AS $oldId => $reaction)
		{
			$state->startAfter = $oldId;

			$messageId = $this->lookupId('dbt_sg_message', $reaction['content_id']);
			if (!$messageId)
			{
				continue;
			}

			$import = $this->newHandler(ReactionContent::class);
			$import->bulkSet($this->mapKeys($reaction, [
				'reaction_user_id',
				'content_user_id',
				'reaction_date',
				'is_counted',
			]));
			$import->setReactionId($reaction['reaction_id']);
			$import->content_id = $messageId;
			$import->content_type = 'dbtech_social_message';

			if ($newId = $import->save($oldId))
			{
				$state->imported++;
			}

			if ($timer->limitExceeded())
			{
				break;
			}
		}

		return $state->resumeIfNeeded();
	}

	/**
	 * @param int $startAfter
	 * @param int $end
	 * @param int $limit
	 *
	 * @return array
	 */
	protected function getMessageReactions(int $startAfter, int $end, int $limit): array
	{
		return $this->sourceDb->fetchAllKeyed("
			SELECT rc.*, IFNULL(gf.groupid, g.groupid) AS group_id
			FROM xf_reaction_content AS rc
			LEFT JOIN xf_post AS p ON(p.post_id = rc.content_id)
			LEFT JOIN xf_thread AS t ON(t.thread_id = p.thread_id)
			LEFT JOIN xf_snog_groups_subforums AS gf ON(gf.node_id = t.node_id)
			LEFT JOIN xf_snog_groups AS g ON(g.node_id = t.node_id)
			WHERE rc.reaction_content_id > ? AND rc.reaction_content_id <= ?
				AND rc.content_type = 'post'
				AND (
					gf.node_id IS NOT NULL
					OR g.node_id IS NOT NULL
				)
			ORDER BY rc.reaction_content_id
			LIMIT $limit
		", 'reaction_content_id', [$startAfter, $end]);
	}


	// ########################### STEP: GROUP COMMENTS ###############################

	/**
	 * @return int
	 */
	public function getStepEndGroupComments(): int
	{
		return $this->sourceDb->fetchOne("
			SELECT MAX(discussion_id)
			FROM xf_snog_groups_discussions
			WHERE parent_id = 0
		") ?: 0;
	}

	/**
	 * @param StepState $state
	 * @param array $stepConfig
	 * @param int|null $maxTime
	 * @param int $limit
	 *
	 * @return StepState
	 * @throws \Exception
	 */
	public function stepGroupComments(StepState $state, array $stepConfig, ?int $maxTime, int $limit = 1000): StepState
	{
		$timer = new Timer($maxTime);

		$groupComments = $this->getGroupComments($state->startAfter, $state->end, $limit);

		if (!$groupComments)
		{
			return $state->complete();
		}

		$this->lookup('dbt_sg_group', $this->pluck($groupComments, 'groupid'));

		$idField = $this->getGroupCommentReplyIdField();

		foreach ($groupComments AS $oldId => $groupComment)
		{
			$state->startAfter = $oldId;

			$import = $this->newHandler(Comment::class);
			$import->bulkSet($this->mapXfKeys($groupComment, [
				'user_id',
				'username',
				'message_date' => 'date',
				'reply_count',
				'title',
			]));

			$import->group_id = $this->lookupId('dbt_sg_group', $groupComment['groupid'], 0);
			$import->view_count = 0;
			$import->discussion_state = $this->decodeGroupDiscussionState($groupComment['state']);
			$import->discussion_open = $groupComment['state'] !== 'locked';

			if ($newId = $import->save($oldId))
			{
				$state->imported++;
				$state->extra['messagePosition'] = 0;

				$firstMessageImport = $this->handleGroupCommentReplyImport(
					$groupComment,
					$newId,
					$state
				);
				if ($firstMessageImport)
				{
					$newFirstMessageId = $firstMessageImport->save($groupComment[$idField]);
					if ($newFirstMessageId)
					{
						$this->afterGroupCommentReplyImport(
							$firstMessageImport,
							$groupComment,
							$newFirstMessageId
						);
					}
				}
			}

			if ($timer->limitExceeded())
			{
				break;
			}
		}

		return $state->resumeIfNeeded();
	}

	/**
	 * @param int $startAfter
	 * @param int $end
	 * @param int $limit
	 *
	 * @return array
	 */
	protected function getGroupComments(int $startAfter, int $end, int $limit): array
	{
		return $this->sourceDb->fetchAllKeyed("
			SELECT gc.*,
			    ip.ip,
				IF(gc.delete_date, gc.user_id, 0) AS delete_user_id, gc.deleted_by AS delete_username, gc.reason AS delete_reason
			FROM xf_snog_groups_discussions AS
				gc
			LEFT JOIN xf_ip AS ip ON (ip.ip_id = gc.ip_id)
			WHERE gc.discussion_id > ? AND gc.discussion_id <= ?
				AND gc.parent_id = 0
			ORDER BY gc.discussion_id
			LIMIT $limit
		", 'discussion_id', [$startAfter, $end]);
	}


	// ########################### STEP: GROUP COMMENT REPLIES ###############################

	protected function getGroupCommentIdsForRepliesStep(int $startAfter, int $end, int $commentLimit): array
	{
		return $this->sourceDb->fetchAllColumn("
			SELECT discussion_id
			FROM xf_snog_groups_discussions
			WHERE discussion_id > ? AND discussion_id <= ?
				AND parent_id = 0
			ORDER BY discussion_id
			LIMIT $commentLimit
		", [$startAfter, $end]);
	}

	protected function getGroupCommentRepliesForRepliesStep(int $commentId, int $startDate): array
	{
		return $this->sourceDb->fetchAll("
			SELECT gc.*,
			    ip.ip,
				IF(gc.delete_date, gc.user_id, 0) AS delete_user_id, gc.deleted_by AS delete_username, gc.reason AS delete_reason
			FROM xf_snog_groups_discussions AS
				gc
			LEFT JOIN xf_ip AS ip ON (ip.ip_id = gc.ip_id)
			WHERE gc.parent_id = ?
				AND gc.date > ?
			ORDER BY gc.date, gc.discussion_id
			LIMIT 500
		", [$commentId, $startDate]);
	}

	protected function getGroupCommentReplyDateField(): string
	{
		return 'date';
	}

	protected function getGroupCommentReplyIdField(): string
	{
		return 'discussion_id';
	}

	protected function handleGroupCommentReplyImport(
		array $groupCommentReply,
		int $newDiscussionId,
		StepState $state
	): ?CommentReply
	{
		if (!$groupCommentReply['state'])
		{
			// invalid state, can't import this
			return null;
		}

		$import = $this->newHandler(CommentReply::class);
		$import->bulkSet($this->mapXfKeys($groupCommentReply, [
			'username',
			'message_date' => 'date',
		]));
		$import->discussion_id = $newDiscussionId;
		$import->user_id = $groupCommentReply['user_id'];
		$import->last_edit_user_id = 0;
		$import->message = $this->rewriteQuotes($groupCommentReply['message']);
		$import->message_state = $this->decodeGroupDiscussionState($groupCommentReply['state']);
		$import->position = $state->extra['messagePosition'];
		if (!empty($groupCommentReply['ip']))
		{
			$import->setLoggedIp($groupCommentReply['ip']);
		}
		$import->setDeletionLogData($this->extractDeletionLogData($groupCommentReply));

		return $import;
	}


	// ########################### STEP: MESSAGE REACTIONS ###############################

	public function getStepEndGroupCommentReactions(): int
	{
		return $this->sourceDb->fetchOne("
			SELECT MAX(rc.reaction_content_id)
			FROM xf_reaction_content AS rc
			WHERE rc.content_type = 'discussion'
		") ?: 0;
	}

	/**
	 * @param StepState $state
	 * @param array $stepConfig
	 * @param int|null $maxTime
	 * @param int $limit
	 *
	 * @return StepState
	 * @throws \Exception
	 */
	public function stepGroupCommentReactions(StepState $state, array $stepConfig, ?int $maxTime, int $limit = 1000): StepState
	{
		$timer = new Timer($maxTime);

		$reactions = $this->getGroupCommentReactions($state->startAfter, $state->end, $limit);
		if (!$reactions)
		{
			return $state->complete();
		}

		$this->lookup('dbt_sg_comment_reply', $this->pluck($reactions, 'content_id'));

		foreach ($reactions AS $oldId => $reaction)
		{
			$state->startAfter = $oldId;

			$messageId = $this->lookupId('dbt_sg_comment_reply', $reaction['content_id']);
			if (!$messageId)
			{
				continue;
			}

			$import = $this->newHandler(ReactionContent::class);
			$import->bulkSet($this->mapKeys($reaction, [
				'reaction_user_id',
				'content_user_id',
				'reaction_date',
				'is_counted',
			]));
			$import->setReactionId($reaction['reaction_id']);
			$import->content_id = $messageId;
			$import->content_type = 'dbtech_social_message';

			if ($newId = $import->save($oldId))
			{
				$state->imported++;
			}

			if ($timer->limitExceeded())
			{
				break;
			}
		}

		return $state->resumeIfNeeded();
	}

	/**
	 * @param int $startAfter
	 * @param int $end
	 * @param int $limit
	 *
	 * @return array
	 */
	protected function getGroupCommentReactions(int $startAfter, int $end, int $limit): array
	{
		return $this->sourceDb->fetchAllKeyed("
			SELECT rc.*
			FROM xf_reaction_content AS rc
			WHERE rc.reaction_content_id > ? AND rc.reaction_content_id <= ?
				AND rc.content_type = 'discussion'
			ORDER BY rc.reaction_content_id
			LIMIT $limit
		", 'reaction_content_id', [$startAfter, $end]);
	}


	// ############################## STEP: GROUP PHOTOS #########################

	public function getStepEndGroupPhotos()
	{
		return $this->sourceDb->fetchOne("
			SELECT MAX(photo_id)
			FROM xf_snog_groups_photos
		") ?: 0;
	}

	/**
	 * @param StepState $state
	 * @param array $stepConfig
	 * @param int|null $maxTime
	 * @param int $limit
	 *
	 * @return StepState
	 * @throws \Exception
	 */
	public function stepGroupPhotos(StepState $state, array $stepConfig, ?int $maxTime, int $limit = 500): StepState
	{
		$timer = new Timer($maxTime);

		$groupPhotos = $this->getGroupPhotos($state->startAfter, $state->end, $limit);
		if (!$groupPhotos)
		{
			return $state->complete();
		}

		$this->lookup('dbt_sg_group', $this->pluck($groupPhotos, 'groupid'));

		foreach ($groupPhotos AS $groupPhoto)
		{
			$oldId = $groupPhoto['photo_id'];
			$state->startAfter = $oldId;

			$albumImport = $this->newHandler(Album::class);
			$albumImport->bulkSet([
				'title' => $groupPhoto['title'],
				'username' => $groupPhoto['username'],
				'user_id' => $groupPhoto['user_id'],
				'category_id' => \XF::options()->dbtechSocialMediaGalleryCategoryId,
				'create_date' => \XF::$time,
				'view_privacy' => 'private',
			]);

			$albumImport->preventRetainIds();
			$albumImport->log(false);

			$albumId = $albumImport->save($oldId);

			$this->db()->insert('xf_dbtech_social_groups_group_album', [
				'group_id' => $this->lookupId('dbt_sg_group', $groupPhoto['groupid'], 0),
				'album_id' => $albumId,
				'existing_category_id' => 0,
			], false, false, 'IGNORE');

			$mediaImport = $this->newHandler(MediaItem::class);
			$mediaImport->bulkSet([
				'title' => $groupPhoto['title'],
				'description' => '',
				'user_id' => $groupPhoto['user_id'],
				'username' => $groupPhoto['username'],
				'view_count' => 0,
				'media_date' => \XF::$time,
				'album_id' => $albumId,
				'category_id' => \XF::options()->dbtechSocialMediaGalleryCategoryId,
				'media_state' => $groupPhoto['state'],
			]);

			if ($groupPhoto['state'] == 'deleted')
			{
				$mediaImport->setDeletionLogData([
					'date' => $groupPhoto['delete_date'],
					'user_id' => $groupPhoto['user_id'],
					'username' => $groupPhoto['username'],
					'reason' => $groupPhoto['reason'],
				]);
			}

			$sourceFile = null;

			$filename = $groupPhoto['name'];
			$extension = $groupPhoto['extension'];

			[$mediaType, $filePath] = $this->getMediaTypeAndFilePathFromExtension($extension);

			if (!$mediaType)
			{
				continue;
			}

			$mediaImport->media_type = $mediaType;

			$sourceFile = $this->getSourceGroupPhotoDataPath(
				$groupPhoto['groupid'],
				$groupPhoto['user_id'],
				$groupPhoto['name'],
			);

			if (!file_exists($sourceFile) || !is_readable($sourceFile))
			{
				continue;
			}

			$attachmentImport = $this->newHandler(Attachment::class);

			$attachmentImport->attach_date = \XF::$time;
			$attachmentImport->content_type = 'xfmg_media';
			$attachmentImport->unassociated = false;

			$attachmentImport->setDataExtra('upload_date', \XF::$time);
			if ($filePath)
			{
				$attachmentImport->setDataExtra('file_path', $filePath);
			}
			$attachmentImport->setDataUserId($groupPhoto['user_id']);
			$attachmentImport->setSourceFile($sourceFile, $groupPhoto['name']);

			$mediaImport->addAttachment($attachmentImport);

			$newId = $mediaImport->save($oldId);
			if ($newId)
			{
				$state->imported++;
			}

			if ($timer->limitExceeded())
			{
				break;
			}
		}

		File::cleanUpTempFiles();

		return $state->resumeIfNeeded();
	}

	/**
	 * @param int $startAfter
	 * @param int $end
	 * @param int $limit
	 *
	 * @return array
	 */
	protected function getGroupPhotos(int $startAfter, int $end, int $limit): array
	{
		return $this->sourceDb->fetchAllKeyed("
			SELECT
				p.*,
				u.username,
			    g.name AS group_name
			FROM xf_snog_groups_photos AS p
			LEFT JOIN xf_snog_groups AS g ON (g.groupid = p.groupid)
			LEFT JOIN xf_user AS u ON (u.user_id = p.user_id)
			WHERE p.photo_id > ? AND p.photo_id <= ?
			ORDER BY p.photo_id
			LIMIT $limit
		", 'photo_id', [$startAfter, $end]);
	}


	// ############################## STEP: GROUP PHOTO COMMENTS #########################

	public function getStepEndGroupPhotoComments()
	{
		return $this->sourceDb->fetchOne("
			SELECT MAX(comment_id)
			FROM xf_snog_groups_photos_comments
		") ?: 0;
	}

	/**
	 * @param StepState $state
	 * @param array $stepConfig
	 * @param int|null $maxTime
	 * @param int $limit
	 *
	 * @return StepState
	 * @throws \Exception
	 */
	public function stepGroupPhotoComments(StepState $state, array $stepConfig, ?int $maxTime, int $limit = 1000): StepState
	{
		$timer = new Timer($maxTime);

		$groupPhotoComments = $this->getGroupPhotoComments($state->startAfter, $state->end, $limit);
		if (!$groupPhotoComments)
		{
			return $state->complete();
		}

		$this->lookup('dbt_sg_group', $this->pluck($groupPhotoComments, 'groupid'));
		$this->lookup('xfmg_media', $this->pluck($groupPhotoComments, 'photo_id'));

		foreach ($groupPhotoComments AS $comment)
		{
			$oldId = $comment['comment_id'];
			$state->startAfter = $oldId;

			$contentId = $this->lookupId('xfmg_media', $comment['photo_id']);
			if (!$contentId)
			{
				continue;
			}

			$import = $this->newHandler(\XFMG\Import\Data\Comment::class);

			$import->bulkSet([
				'username' => $comment['username'],
				'comment_date' => $comment['comment_date'],
				'message' => $comment['message'],
				'content_id' => $contentId,
				'content_type' => 'xfmg_media',
				'user_id' => $comment['user_id'],
				'rating_id' => 0,
			]);

			$newId = $import->save($oldId);
			if ($newId)
			{
				$state->imported++;
			}

			if ($timer->limitExceeded())
			{
				break;
			}
		}

		return $state->resumeIfNeeded();
	}

	/**
	 * @param int $startAfter
	 * @param int $end
	 * @param int $limit
	 *
	 * @return array
	 */
	protected function getGroupPhotoComments(int $startAfter, int $end, int $limit): array
	{
		return $this->sourceDb->fetchAllKeyed("
			SELECT
				pc.*,
				u.username
			FROM xf_snog_groups_photos_comments AS pc
			LEFT JOIN xf_user AS u ON (u.user_id = pc.user_id)
			WHERE pc.comment_id > ? AND pc.comment_id <= ?
			ORDER BY pc.comment_id
			LIMIT $limit
		", 'comment_id', [$startAfter, $end]);
	}


	// ############################## STEP: GROUP PHOTOS #########################

	public function getStepEndGroupMedia()
	{
		return $this->sourceDb->fetchOne("
			SELECT MAX(mi.media_id)
			FROM xf_mg_media_item AS mi
			LEFT JOIN xf_snog_groups AS g ON (g.media_id = mi.category_id)
			WHERE g.media_id <> 0
		") ?: 0;
	}

	/**
	 * @param StepState $state
	 * @param array $stepConfig
	 * @param int|null $maxTime
	 * @param int $limit
	 *
	 * @return StepState
	 * @throws \Exception
	 */
	public function stepGroupMedia(StepState $state, array $stepConfig, ?int $maxTime, int $limit = 500): StepState
	{
		$timer = new Timer($maxTime);

		$groupMedia = $this->getGroupMedia($state->startAfter, $state->end, $limit);
		if (!$groupMedia)
		{
			return $state->complete();
		}

		$this->lookup('dbt_sg_group', $this->pluck($groupMedia, 'groupid'));

		foreach ($groupMedia AS $mediaItem)
		{
			$oldId = $mediaItem['media_id'];
			$state->startAfter = $oldId;

			$albumImport = $this->newHandler(Album::class);
			$albumImport->bulkSet([
				'title' => $mediaItem['title'],
				'username' => $mediaItem['username'],
				'user_id' => $mediaItem['user_id'],
				'category_id' => \XF::options()->dbtechSocialMediaGalleryCategoryId,
				'create_date' => $mediaItem['media_date'],
				'view_privacy' => 'private',
			]);

			$albumImport->preventRetainIds();
			$albumImport->log(false);

			$albumId = $albumImport->save($oldId);
			$categoryId = \XF::options()->dbtechSocialMediaGalleryCategoryId;
			$userId = $mediaItem['user_id'];

			$this->db()->insert('xf_dbtech_social_groups_group_album', [
				'group_id' => $this->lookupId('dbt_sg_group', $mediaItem['groupid'], 0),
				'album_id' => $albumId,
				'existing_category_id' => $mediaItem['category_id'],
			], false, false, 'IGNORE');

			$mediaImport = $this->newHandler(MediaItem::class);

			$dataDir = $this->baseConfig['data_dir'];
			$internalDataDir = $this->baseConfig['internal_data_dir'];

			$oldGroupId = floor($oldId / 1000);
			$mediaHash = $mediaItem['media_hash'];

			$oldThumbPath = "$dataDir/xfmg/thumbnail/$oldGroupId/$oldId-$mediaHash.jpg";
			$mediaImport->setThumbnailPath($oldThumbPath);

			if ($mediaItem['custom_thumbnail_date'])
			{
				$oldCustomThumbPath = "$dataDir/xfmg/custom_thumbnail/$oldGroupId/$oldId-$mediaHash.jpg";
				$mediaImport->setCustomThumbnailPath($oldCustomThumbPath);
			}

			if ($mediaItem['watermarked'])
			{
				$oldOriginalPath = "$internalDataDir/xfmg/original/$oldGroupId/$oldId-$mediaHash.data";
				$mediaImport->setOriginalPath($oldOriginalPath);
			}

			$mediaImport->bulkSet($this->mapKeys($mediaItem, [
				'title',
				'description',
				'media_date',
				'last_edit_date',
				'media_type',
				'media_tag',
				'media_embed_url',
				'media_state',
				'username',
				'view_count',
				'watermarked',
				'warning_message',
				'custom_thumbnail_date',
			]));
			$mediaImport->bulkSet([
				'album_id' => $albumId,
				'category_id' => $categoryId,
				'user_id' => $userId,
				'warning_id' => 0,
				'exif_data' => $this->decodeValue($mediaItem['exif_data'], 'json-array'),
			]);

			$mediaImport->setLoggedIp($mediaItem['ip']);
			$mediaImport->setDeletionLogData($this->extractDeletionLogData($mediaItem));

			$customFields = $this->decodeValue($mediaItem['custom_fields'], 'serialized-json-array');
			if ($customFields)
			{
				$mediaImport->setCustomFields($this->mapCustomFields('xfmg_media_field', $customFields));
			}

			$attachmentImport = null;

			if ($mediaItem['media_type'] != 'embed')
			{
				$sourceFile = $this->getSourceAttachmentDataPath(
					$mediaItem['data_id'],
					$mediaItem['file_path'],
					$mediaItem['file_key'] ?? $mediaItem['file_hash']
				);
				if (!file_exists($sourceFile) || !is_readable($sourceFile))
				{
					continue;
				}

				/** @var Attachment $attachmentImport */
				$attachmentImport = $this->newHandler(Attachment::class);
				$attachmentImport->bulkSet($this->mapKeys($mediaItem, [
					'content_type',
					'attach_date',
					'temp_hash',
					'unassociated',
					'view_count',
				]));
				$attachmentImport->setDataExtra('upload_date', $mediaItem['media_date']);
				$attachmentImport->setDataExtra('file_path', $mediaItem['file_path']);
				$attachmentImport->setDataUserId($mediaItem['user_id']);
				$attachmentImport->setSourceFile($sourceFile, $mediaItem['filename']);

				$mediaImport->addAttachment($attachmentImport);
			}

			$newId = $mediaImport->save($oldId);
			if ($newId)
			{
				$state->imported++;
			}

			if ($timer->limitExceeded())
			{
				break;
			}
		}

		File::cleanUpTempFiles();

		return $state->resumeIfNeeded();
	}

	/**
	 * @param int $startAfter
	 * @param int $end
	 * @param int $limit
	 *
	 * @return array
	 */
	protected function getGroupMedia(int $startAfter, int $end, int $limit): array
	{
		return $this->sourceDb->fetchAllKeyed("
			SELECT
				g.groupid,
				mitem.*,
				a.*,
				ad.*,
				user.*,
				mitem.username AS username,
				ip.ip,
				d.delete_date,
				d.delete_user_id,
				d.delete_username,
				d.delete_reason
				FROM
					xf_mg_media_item AS mitem
				INNER JOIN xf_snog_groups AS g ON (g.media_id = mitem.category_id)
				INNER JOIN xf_attachment AS a ON (mitem.media_id = a.content_id AND a.content_type = 'xfmg_media')
				INNER JOIN xf_attachment_data AS ad ON (a.data_id = ad.data_id)
				LEFT JOIN xf_user AS user ON (mitem.user_id	= user.user_id)
				LEFT JOIN xf_ip AS ip ON (mitem.ip_id = ip.ip_id)
				LEFT JOIN xf_deletion_log AS d ON (d.content_type = 'xfmg_media' AND d.content_id = mitem.media_id)			
			WHERE mitem.media_id > ? AND mitem.media_id <= ?
				AND g.media_id <> 0
			ORDER BY mitem.media_id
			LIMIT $limit
		", 'media_id', [$startAfter, $end]);
	}


	/**
	 * @param array $data
	 *
	 * @return array
	 */
	protected function extractDeletionLogData(array $data): array
	{
		$deletionLog = [];
		foreach ($data AS $k => $v)
		{
			if ($v === null)
			{
				continue;
			}

			switch ($k)
			{
				case 'delete_date':
					$deletionLog['date'] = $v;
					break;

				case 'delete_user_id':
					$deletionLog['user_id'] = $v ?: 0;
					break;

				case 'delete_username':
					$deletionLog['username'] = $v;
					break;

				case 'delete_reason':
					$deletionLog['reason'] = $v;
					break;
			}
		}

		return $deletionLog;
	}

	/**
	 * @param int $dataId
	 * @param int $userId
	 * @param string $fileName
	 *
	 * @return string
	 */
	protected function getSourceGroupPhotoDataPath(int $dataId, int $userId, string $fileName): string
	{
		$path = sprintf(
			'data://groups/Photos/o/%d/%d/%s',
			$dataId,
			$userId,
			$fileName
		);

		return strtr($path, [
			'data://' => $this->baseConfig['data_dir'] . '/',
		]);
	}

	/**
	 * @param int $dataId
	 * @param string $fileName
	 *
	 * @return string
	 */
	protected function getSourceGroupAvatarDataPath(int $dataId, string $fileName): string
	{
		$group = floor($dataId / 1000);

		$path = sprintf(
			'data://groups/GroupBanners/a/%d/%s',
			$group,
			$fileName
		);

		return strtr($path, [
			'data://' => $this->baseConfig['data_dir'] . '/',
		]);
	}

	/**
	 * @param int $dataId
	 * @param string $fileName
	 *
	 * @return string
	 */
	protected function getSourceGroupBannerDataPath(int $dataId, string $fileName): string
	{
		$group = floor($dataId / 1000);

		$path = sprintf(
			'data://groups/GroupBanners/o/%d/%s',
			$group,
			$fileName
		);

		return strtr($path, [
			'data://' => $this->baseConfig['data_dir'] . '/',
		]);
	}

	/**
	 * @param array $group
	 *
	 * @return string
	 */
	protected function decodeGroupTypeFromFlags(array $group): string
	{
		if ($group['privategroup'])
		{
			return 'private';
		}
		else if ($group['privatehide'])
		{
			return 'hidden';
		}
		else if ($group['restricted'])
		{
			return 'closed';
		}

		return 'public';
	}

	/**
	 * @param string $state
	 *
	 * @return string
	 */
	protected function decodeGroupState(string $state): string
	{
		return match ($state)
		{
			'moderated' => 'moderated',
			'deleted' => 'deleted',
			default => 'visible',
		};
	}

	/**
	 * @param string $state
	 *
	 * @return string
	 */
	protected function decodeGroupMemberState(string $state): string
	{
		return match ($state)
		{
			'moderated' => 'moderated',
			'banned' => 'banned',
			default => 'valid',
		};
	}

	/**
	 * @param string $state
	 *
	 * @return string
	 */
	protected function decodeGroupDiscussionState(string $state): string
	{
		return match ($state)
		{
			'moderated' => 'moderated',
			'deleted' => 'deleted',
			default => 'visible',
		};
	}

	/**
	 * @param string $role
	 *
	 * @return array
	 */
	protected function decodeGroupMemberPermissions(string $role): array
	{
		return match ($role)
		{
			'admin' => \json_decode(
				\XF::options()->dbtechSocialDefaultPermissions['groupOwner'],
				true
			),
			'moderator' => \json_decode(
				\XF::options()->dbtechSocialDefaultPermissions['groupModerators'],
				true
			),
			default => [],
		};
	}

	/**
	 * @param string $extension
	 *
	 * @return null[]|string[]
	 */
	protected function getMediaTypeAndFilePathFromExtension(string $extension): array
	{
		[$imageExtensions, $videoExtensions, $audioExtensions] = $this->getAllowedUploadExtensions();

		$mediaType = null;
		$filePath = null;

		if (in_array($extension, $imageExtensions, true))
		{
			$mediaType = 'image';
		}
		else if (in_array($extension, $videoExtensions))
		{
			$mediaType = 'video';
			$filePath = 'data://xfmg/video/%FLOOR%/%DATA_ID%-%HASH%.mp4';
		}
		else if (in_array($extension, $audioExtensions))
		{
			$mediaType = 'audio';
			$filePath = 'data://xfmg/audio/%FLOOR%/%DATA_ID%-%HASH%.mp3';
		}

		return [
			$mediaType,
			$filePath,
		];
	}

	/**
	 * @return array
	 */
	protected function getAllowedUploadExtensions(): array
	{
		$options = $this->app->options();

		$imageExtensions = Arr::stringToArray($options->xfmgImageExtensions);
		$videoExtensions = Arr::stringToArray($options->xfmgVideoExtensions);
		$audioExtensions = Arr::stringToArray($options->xfmgAudioExtensions);

		return [
			$imageExtensions,
			$videoExtensions,
			$audioExtensions,
		];
	}
}