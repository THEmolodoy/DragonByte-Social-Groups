<?php

namespace DBTech\SocialGroups\Import\DataHelper;

use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Service\Group\BannerService;
use XF\Import\DataHelper\AbstractHelper;
use XF\PrintableException;
use XF\Util\File;

class Banner extends AbstractHelper
{
	/**
	 * @param string $sourceFile
	 * @param string $size
	 * @param Group $group
	 *
	 * @return bool
	 */
	public function copyFinalBannerFile(string $sourceFile, string $size, Group $group): bool
	{
		$targetPath = $group->getAbstractedBannerPath($size);
		return File::copyFileToAbstractedPath($sourceFile, $targetPath);
	}

	/**
	 * @param array $sourceFileMap
	 * @param Group $group
	 *
	 * @return bool
	 */
	public function copyFinalBannerFiles(array $sourceFileMap, Group $group): bool
	{
		$success = true;
		foreach ($sourceFileMap AS $size => $sourceFile)
		{
			if (!$this->copyFinalBannerFile($sourceFile, $size, $group))
			{
				$success = false;
				break;
			}
		}

		return $success;
	}

	/**
	 * @param string $sourceFile
	 * @param Group $group
	 *
	 * @return bool
	 * @throws PrintableException
	 * @throws \Exception
	 */
	public function setBannerFromFile(string $sourceFile, Group $group): bool
	{
		$bannerService = \XF::app()->service(BannerService::class, $group);
		$bannerService->silentRunning(true);

		if ($bannerService->setImage($sourceFile))
		{
			$bannerService->updateBanner();
			return true;
		}

		return false;
	}
}