<?php

namespace DBTech\SocialGroups\Import\DataHelper;

use XF\Import\DataHelper\AbstractHelper;

use function is_scalar;

class Discussion extends AbstractHelper
{
	/**
	 * @param int $discussionId
	 * @param int $userId
	 * @param bool $email
	 *
	 * @return void
	 */
	public function importDiscussionWatch(int $discussionId, int $userId, bool $email = false): void
	{
		$this->importDiscussionWatchBulk($discussionId, [$userId => $email]);
	}

	/**
	 * @param int $discussionId
	 * @param array $userConfigs
	 *
	 * @return void
	 */
	public function importDiscussionWatchBulk(int $discussionId, array $userConfigs): void
	{
		$insert = [];

		foreach ($userConfigs AS $userId => $config)
		{
			if (is_scalar($config))
			{
				$config = ['email_subscribe' => (bool) $config];
			}

			$insert[] = [
				'user_id' => $userId,
				'discussion_id' => $discussionId,
				'email_subscribe' => empty($config['email_subscribe']) ? 0 : 1,
			];
		}

		if ($insert)
		{
			$this->db()->insertBulk(
				'xf_dbtech_social_groups_discussion_watch',
				$insert,
				false,
				'email_subscribe = VALUES(email_subscribe)'
			);
		}
	}
}