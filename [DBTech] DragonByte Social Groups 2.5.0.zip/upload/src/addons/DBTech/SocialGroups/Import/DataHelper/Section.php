<?php

namespace DBTech\SocialGroups\Import\DataHelper;

use XF\Import\DataHelper\AbstractHelper;

class Section extends AbstractHelper
{
	/**
	 * @param int $sectionId
	 * @param int $userId
	 * @param array $userConfig
	 *
	 * @return void
	 */
	public function importSectionWatch(int $sectionId, int $userId, array $userConfig): void
	{
		$this->importSectionWatchBulk($sectionId, [$userId => $userConfig]);
	}

	/**
	 * @param int $sectionId
	 * @param array $userConfigs
	 *
	 * @return void
	 */
	public function importSectionWatchBulk(int $sectionId, array $userConfigs): void
	{
		$insert = [];

		foreach ($userConfigs AS $userId => $config)
		{
			$insert[] = [
				'user_id' => $userId,
				'section_id' => $sectionId,
				'notify_on' => empty($config['notify_on']) ? '' : $config['notify_on'],
				'send_alert' => empty($config['send_alert']) ? 0 : 1,
				'send_email' => empty($config['send_email']) ? 0 : 1,
			];
		}

		if ($insert)
		{
			$this->db()->insertBulk(
				'xf_dbtech_social_groups_section_watch',
				$insert,
				false,
				'notify_on = VALUES(notify_on), send_alert = VALUES(send_alert), send_email = VALUES(send_email)'
			);
		}
	}
}