<?php

namespace DBTech\SocialGroups\Import\DataHelper;

use XF\Import\DataHelper\AbstractHelper;

class Group extends AbstractHelper
{
	/**
	 * @param int $groupId
	 * @param int $userId
	 * @param array $userConfig
	 *
	 * @return void
	 */
	public function importGroupWatch(int $groupId, int $userId, array $userConfig): void
	{
		$this->importGroupWatchBulk($groupId, [$userId => $userConfig]);
	}

	/**
	 * @param int $groupId
	 * @param array $userConfigs
	 *
	 * @return void
	 */
	public function importGroupWatchBulk(int $groupId, array $userConfigs): void
	{
		$insert = [];

		foreach ($userConfigs AS $userId => $config)
		{
			$insert[] = [
				'user_id' => $userId,
				'group_id' => $groupId,
				'notify_on' => empty($config['notify_on']) ? '' : $config['notify_on'],
				'send_alert' => empty($config['send_alert']) ? 0 : 1,
				'send_email' => empty($config['send_email']) ? 0 : 1,
			];
		}

		if ($insert)
		{
			$this->db()->insertBulk(
				'xf_dbtech_social_groups_group_watch',
				$insert,
				false,
				'notify_on = VALUES(notify_on), send_alert = VALUES(send_alert), send_email = VALUES(send_email)'
			);
		}
	}
}