<?php

namespace DBTech\SocialGroups\Import\DataHelper;

use DBTech\SocialGroups\Entity\Group;
use DBTech\SocialGroups\Service\Group\IconService;
use XF\Import\DataHelper\AbstractHelper;
use XF\PrintableException;
use XF\Util\File;

class Icon extends AbstractHelper
{
	/**
	 * @param $sourceFile
	 * @param $size
	 * @param Group $group
	 *
	 * @return bool
	 */
	public function copyFinalIconFile($sourceFile, $size, Group $group): bool
	{
		$targetPath = $group->getAbstractedCustomIconPath($size);
		return File::copyFileToAbstractedPath($sourceFile, $targetPath);
	}

	/**
	 * @param array $sourceFileMap
	 * @param Group $group
	 *
	 * @return bool
	 */
	public function copyFinalIconFiles(array $sourceFileMap, Group $group): bool
	{
		$success = true;
		foreach ($sourceFileMap AS $size => $sourceFile)
		{
			if (!$this->copyFinalIconFile($sourceFile, $size, $group))
			{
				$success = false;
				break;
			}
		}

		return $success;
	}

	/**
	 * @param string $sourceFile
	 * @param Group $group
	 *
	 * @return bool
	 * @throws PrintableException
	 * @throws \Exception
	 */
	public function setIconFromFile(string $sourceFile, Group $group): bool
	{
		$iconService = \XF::app()->service(IconService::class, $group);
		$iconService->silentRunning(true);

		if ($iconService->setImage($sourceFile))
		{
			$iconService->updateIcon();
			return true;
		}

		return false;
	}
}