<?php

namespace DBTech\SocialGroups\Import\Data;

use XF\Import\Data\AbstractEmulatedData;

/**
 * @mixin \DBTech\SocialGroups\Entity\GroupWatch
 */
class GroupWatch extends AbstractEmulatedData
{
	/**
	 * @return string
	 */
	public function getImportType(): string
	{
		return 'dbt_sg_group_watch';
	}

	/**
	 * @return string
	 */
	protected function getEntityShortName(): string
	{
		return 'DBTech\SocialGroups:GroupWatch';
	}
}