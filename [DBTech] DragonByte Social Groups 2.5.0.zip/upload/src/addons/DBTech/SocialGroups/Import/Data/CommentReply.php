<?php

namespace DBTech\SocialGroups\Import\Data;

class CommentReply extends Message
{
	/**
	 * @return string
	 */
	public function getImportType(): string
	{
		return 'dbt_sg_comment_reply';
	}
}