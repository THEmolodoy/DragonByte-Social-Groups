<?php

namespace DBTech\SocialGroups\Import\Data;

use DBTech\SocialGroups\Import\DataHelper\Group;
use XF\Import\Data\AbstractEmulatedData;

/**
 * @mixin \DBTech\SocialGroups\Entity\GroupMember
 */
class GroupMember extends AbstractEmulatedData
{
	protected ?GroupBan $ban = null;
	protected ?array $watch = null;


	/**
	 * @return string
	 */
	public function getImportType(): string
	{
		return 'dbt_sg_group_member';
	}

	/**
	 * @return string
	 */
	protected function getEntityShortName(): string
	{
		return 'DBTech\SocialGroups:GroupMember';
	}

	/**
	 * @param array $data
	 *
	 * @return void
	 */
	public function setBan(array $data): void
	{
		if (!$this->ban)
		{
			/** @noinspection PhpFieldAssignmentTypeMismatchInspection */
			$this->ban = $this->dataManager->newHandler(GroupBan::class, false);
		}

		$this->ban->bulkSet($data);
	}

	/**
	 * @param array $data
	 *
	 * @return void
	 */
	public function setWatch(array $data): void
	{
		$this->watch = $data;
	}

	/**
	 * @param $oldId
	 * @param $newId
	 *
	 * @return void
	 * @throws \Exception
	 */
	protected function postSave($oldId, $newId): void
	{
		if ($this->watch)
		{
			/** @var Group $groupHelper */
			$groupHelper = $this->dataManager->helper(Group::class);
			$groupHelper->importGroupWatch(
				$this->group_id,
				$this->user_id,
				$this->watch
			);
		}

		$this->ban?->save($oldId);
	}
}