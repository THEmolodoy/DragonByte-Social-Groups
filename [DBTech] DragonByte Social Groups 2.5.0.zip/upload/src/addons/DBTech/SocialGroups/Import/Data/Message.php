<?php

namespace DBTech\SocialGroups\Import\Data;

use XF\Import\Data\AbstractEmulatedData;
use XF\Import\Data\HasDeletionLogTrait;

/**
 * @mixin \DBTech\SocialGroups\Entity\Message
 */
class Message extends AbstractEmulatedData
{
	use HasDeletionLogTrait;

	protected ?string $loggedIp = null;


	/**
	 * @return string
	 */
	public function getImportType(): string
	{
		return 'dbt_sg_message';
	}

	/**
	 * @return string
	 */
	protected function getEntityShortName(): string
	{
		return 'DBTech\SocialGroups:Message';
	}

	/**
	 * @param string $loggedIp
	 *
	 * @return void
	 */
	public function setLoggedIp(string $loggedIp): void
	{
		$this->loggedIp = $loggedIp;
	}

	/**
	 * @param $oldId
	 *
	 * @return void|null
	 */
	protected function preSave($oldId)
	{
		$this->forceNotEmpty('username', $oldId);
		$this->forceNotEmpty('message', $oldId);
	}

	/**
	 * @param $oldId
	 * @param $newId
	 *
	 * @return void
	 */
	protected function postSave($oldId, $newId): void
	{
		$this->logIp($this->loggedIp, $this->message_date);
		$this->insertStateRecord($this->message_state, $this->message_date);

		if ($this->message_state == 'visible' && $this->user_id)
		{
			$this->db()->insert('xf_dbtech_social_groups_discussion_user_message', [
				'discussion_id' => $this->discussion_id,
				'user_id' => $this->user_id,
				'message_count' => 1,
			], false, 'message_count = message_count + VALUES(message_count)');
		}
	}
}