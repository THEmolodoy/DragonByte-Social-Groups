<?php

namespace DBTech\SocialGroups\Import\Data;

use XF\Import\Data\AbstractEmulatedData;

/**
 * @mixin \DBTech\SocialGroups\Entity\DiscussionReplyBan
 */
class DiscussionReplyBan extends AbstractEmulatedData
{
	/**
	 * @return string
	 */
	public function getImportType(): string
	{
		return 'dbt_sg_discussion_reply_ban';
	}

	/**
	 * @return string
	 */
	protected function getEntityShortName(): string
	{
		return 'DBTech\SocialGroups:DiscussionReplyBan';
	}
}