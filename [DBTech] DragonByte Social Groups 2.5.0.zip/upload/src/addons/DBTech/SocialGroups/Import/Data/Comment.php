<?php

namespace DBTech\SocialGroups\Import\Data;

class Comment extends Discussion
{
	/**
	 * @return string
	 */
	public function getImportType(): string
	{
		return 'dbt_sg_comment';
	}
}