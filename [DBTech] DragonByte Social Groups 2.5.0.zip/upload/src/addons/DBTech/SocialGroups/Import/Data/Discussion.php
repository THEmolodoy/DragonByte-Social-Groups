<?php

namespace DBTech\SocialGroups\Import\Data;

use XF\Import\Data\AbstractEmulatedData;
use XF\Import\Data\HasDeletionLogTrait;

/**
 * @mixin \DBTech\SocialGroups\Entity\Discussion
 */
class Discussion extends AbstractEmulatedData
{
	use HasDeletionLogTrait;

	/** @var DiscussionReplyBan[] */
	protected array $replyBans = [];

	/** @var bool[] */
	protected array $watchers = [];


	/**
	 * @return string
	 */
	public function getImportType(): string
	{
		return 'dbt_sg_discussion';
	}

	/**
	 * @return string
	 */
	protected function getEntityShortName(): string
	{
		return 'DBTech\SocialGroups:Discussion';
	}

	/**
	 * @param int $oldId
	 * @param DiscussionReplyBan $ban
	 *
	 * @return void
	 */
	public function addReplyBan(int $oldId, DiscussionReplyBan $ban): void
	{
		$this->replyBans[$oldId] = $ban;
	}

	/**
	 * @param int $userId
	 * @param bool $emailSubscribe
	 *
	 * @return void
	 */
	public function addDiscussionWatcher(int $userId, bool $emailSubscribe): void
	{
		$this->watchers[$userId] = $emailSubscribe;
	}

	/**
	 * @param $oldId
	 *
	 * @return void|null
	 */
	protected function preSave($oldId)
	{
		$this->forceNotEmpty('username', $oldId);
		$this->forceNotEmpty('title', $oldId);
	}

	/**
	 * @param $oldId
	 * @param $newId
	 *
	 * @return void
	 * @throws \Exception
	 */
	protected function postSave($oldId, $newId): void
	{
		$this->insertStateRecord($this->discussion_state, $this->message_date);

		if ($this->replyBans)
		{
			foreach ($this->replyBans AS $oldReplyBanId => $replyBan)
			{
				$replyBan->discussion_id = $newId;
				$replyBan->log(false);
				$replyBan->checkExisting(false);
				$replyBan->useTransaction(false);

				$replyBan->save($oldReplyBanId);
			}
		}

		if ($this->watchers)
		{
			/** @var \DBTech\SocialGroups\Import\DataHelper\Discussion $discussionHelper */
			$discussionHelper = $this->dataManager->helper(\DBTech\SocialGroups\Import\DataHelper\Discussion::class);
			$discussionHelper->importDiscussionWatchBulk($newId, $this->watchers);
		}
	}
}