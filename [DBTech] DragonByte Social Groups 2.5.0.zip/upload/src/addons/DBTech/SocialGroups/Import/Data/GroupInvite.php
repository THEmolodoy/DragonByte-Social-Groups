<?php

namespace DBTech\SocialGroups\Import\Data;

use XF\Import\Data\AbstractEmulatedData;

/**
 * @mixin \DBTech\SocialGroups\Entity\GroupInvite
 */
class GroupInvite extends AbstractEmulatedData
{
	/**
	 * @return string
	 */
	public function getImportType(): string
	{
		return 'dbt_sg_group_invite';
	}

	/**
	 * @return string
	 */
	protected function getEntityShortName(): string
	{
		return 'DBTech\SocialGroups:GroupInvite';
	}
}