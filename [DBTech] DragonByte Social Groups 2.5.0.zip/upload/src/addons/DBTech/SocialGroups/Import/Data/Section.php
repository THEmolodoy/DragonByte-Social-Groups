<?php

namespace DBTech\SocialGroups\Import\Data;

use XF\Import\Data\AbstractEmulatedData;

/**
 * @mixin \DBTech\SocialGroups\Entity\Section
 */
class Section extends AbstractEmulatedData
{
	protected array $watchers = [];


	/**
	 * @return string
	 */
	public function getImportType(): string
	{
		return 'dbt_sg_section';
	}

	/**
	 * @return string
	 */
	protected function getEntityShortName(): string
	{
		return 'DBTech\SocialGroups:Section';
	}

	/**
	 * @param int $userId
	 * @param array $userConfig
	 *
	 * @return void
	 */
	public function addSectionWatcher(int $userId, array $userConfig): void
	{
		$this->watchers[$userId] = $userConfig;
	}

	/**
	 * @param $oldId
	 *
	 * @return void|null
	 */
	protected function preSave($oldId)
	{
		$this->forceNotEmpty('title', $oldId);
	}

	/**
	 * @param $oldId
	 * @param $newId
	 *
	 * @return void
	 */
	protected function postSave($oldId, $newId): void
	{
		if ($this->watchers)
		{
			/** @var \DBTech\SocialGroups\Import\DataHelper\Section $sectionHelper */
			$sectionHelper = $this->dataManager->helper(\DBTech\SocialGroups\Import\DataHelper\Section::class);
			$sectionHelper->importSectionWatchBulk($newId, $this->watchers);
		}
	}
}