<?php

namespace DBTech\SocialGroups\Import\Data;

use XF\Import\Data\AbstractEmulatedData;

/**
 * @mixin \DBTech\SocialGroups\Entity\Group
 */
class Group extends AbstractEmulatedData
{
	protected array $watchers = [];


	/**
	 * @return string
	 */
	public function getImportType(): string
	{
		return 'dbt_sg_group';
	}

	/**
	 * @return string
	 */
	protected function getEntityShortName(): string
	{
		return 'DBTech\SocialGroups:Group';
	}

	/**
	 * @param int $userId
	 * @param array $userConfig
	 *
	 * @return void
	 */
	public function addGroupWatcher(int $userId, array $userConfig): void
	{
		$this->watchers[$userId] = $userConfig;
	}

	/**
	 * @param $oldId
	 *
	 * @return void|null
	 */
	protected function preSave($oldId)
	{
		$this->forceNotEmpty('username', $oldId);
		$this->forceNotEmpty('title', $oldId);
		$this->forceNotEmpty('tagline', $oldId);
	}

	/**
	 * @param $oldId
	 * @param $newId
	 *
	 * @return void
	 */
	protected function postSave($oldId, $newId): void
	{
		if ($this->watchers)
		{
			/** @var \DBTech\SocialGroups\Import\DataHelper\Group $groupHelper */
			$groupHelper = $this->dataManager->helper(\DBTech\SocialGroups\Import\DataHelper\Group::class);
			$groupHelper->importGroupWatchBulk($newId, $this->watchers);
		}
	}
}