<?php

namespace DBTech\SocialGroups\Cli\Command\Seed;

use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use TickTackk\Seeder\Cli\Command\Seed\AbstractSeedCommand;

if (class_exists(AbstractSeedCommand::class))
{
	class SeedSocialGroupGroup extends AbstractSeedCommand
	{
		protected function getSeedName(): string
		{
			return 'social-group-group';
		}

		protected function getContentTypePlural(?InputInterface $input = null): string
		{
			return 'Social groups';
		}

		protected function configureOptions(): void
		{
			$this
				->addOption(
					'only-visible',
					null,
					InputOption::VALUE_OPTIONAL,
					'Also copies the resulting file(s) to the \'_no_upload\' directory.',
					true
				)
			;
		}

		protected function getSeedParams(InputInterface $input): array
		{
			$options = $input->getOptions();

			return ['onlyVisible' => $options['only-visible']];
		}
	}
}