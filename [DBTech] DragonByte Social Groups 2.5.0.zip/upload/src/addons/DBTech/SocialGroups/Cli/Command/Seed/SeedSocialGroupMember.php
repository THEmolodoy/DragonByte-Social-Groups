<?php

namespace DBTech\SocialGroups\Cli\Command\Seed;

use Symfony\Component\Console\Input\InputInterface;
use TickTackk\Seeder\Cli\Command\Seed\AbstractSeedCommand;

if (class_exists(AbstractSeedCommand::class))
{
	class SeedSocialGroupMember extends AbstractSeedCommand
	{
		protected function getSeedName(): string
		{
			return 'social-group-member';
		}

		protected function getContentTypePlural(?InputInterface $input = null): string
		{
			return 'Social group members';
		}
	}
}