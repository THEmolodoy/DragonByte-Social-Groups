<?php

namespace DBTech\SocialGroups\Warning;

use DBTech\SocialGroups\Entity\Message;
use DBTech\SocialGroups\Service\Message\DeleterService;
use XF\Entity\User;
use XF\Entity\Warning;
use XF\Mvc\Entity\Entity;
use XF\Phrase;
use XF\PrintableException;
use XF\Warning\AbstractHandler;

use function is_string, strlen;

/**
 * @extends AbstractHandler<Message>
 */
class MessageHandler extends AbstractHandler
{
	/**
	 * @param Message $entity
	 *
	 * @return string
	 */
	public function getStoredTitle(Entity $entity): string
	{
		return $entity->Discussion ? $entity->Discussion->title : '';
	}

	/**
	 * @param $title
	 *
	 * @return Phrase
	 */
	public function getDisplayTitle($title): Phrase
	{
		return \XF::phrase('dbtech_social_groups_message_in_discussion_x', ['title' => $title]);
	}

	/**
	 * @param Message $entity
	 *
	 * @return string
	 */
	public function getContentForConversation(Entity $entity): string
	{
		return $entity->message;
	}

	/**
	 * @param Message $entity
	 *
	 * @return User
	 */
	public function getContentUser(Entity $entity): User
	{
		return $entity->User;
	}

	/**
	 * @param Message $entity
	 * @param $error
	 *
	 * @return bool
	 */
	public function canViewContent(Entity $entity, &$error = null): bool
	{
		return $entity->canView();
	}

	/**
	 * @param Message $entity
	 * @param Warning $warning
	 *
	 * @throws PrintableException
	 */
	public function onWarning(Entity $entity, Warning $warning): void
	{
		$entity->warning_id = $warning->warning_id;
		$entity->save();
	}

	/**
	 * @param Message $entity
	 * @param Warning $warning
	 *
	 * @throws PrintableException
	 */
	public function onWarningRemoval(Entity $entity, Warning $warning): void
	{
		$entity->warning_id = 0;
		$entity->warning_message = '';
		$entity->save();
	}

	/**
	 * @param Message $entity
	 * @param $action
	 * @param array $options
	 *
	 * @throws PrintableException
	 */
	public function takeContentAction(Entity $entity, $action, array $options): void
	{
		if ($action == 'public')
		{
			$message = $options['message'] ?? '';
			if (is_string($message) && strlen($message))
			{
				$entity->warning_message = $message;
				$entity->save();
			}
		}
		else if ($action == 'delete')
		{
			$reason = $options['reason'] ?? '';
			if (!is_string($reason))
			{
				$reason = '';
			}

			$deleter = \XF::app()->service(DeleterService::class, $entity);
			$deleter->delete('soft', $reason);
		}
	}

	/**
	 * @param Message $entity
	 *
	 * @return bool
	 */
	protected function canWarnPublicly(Entity $entity): bool
	{
		return true;
	}

	/**
	 * @param Message $entity
	 *
	 * @return bool
	 */
	protected function canDeleteContent(Entity $entity): bool
	{
		return $entity->canDelete();
	}

	/**
	 * @return string[]
	 */
	public function getEntityWith(): array
	{
		$visitor = \XF::visitor();
		return [
			'Discussion',
			'Discussion.Group',
			'Discussion.Group.Permissions|' . $visitor->permission_combination_id,
		];
	}
}