<?php

namespace DBTech\SocialGroups\BbCode;

use DBTech\SocialGroups\XF\Entity\User as ExtendedUserEntity;
use XF\BbCode\Renderer\AbstractRenderer;
use XF\BbCode\Renderer\EmailHtml;
use XF\BbCode\Renderer\SimpleHtml;

use function intval;

class Group
{
	/**
	 * @param array $tagChildren
	 * @param $tagOption
	 * @param array $tag
	 * @param array $options
	 * @param AbstractRenderer $renderer
	 *
	 * @return string
	 */
	public static function renderTagGroup(
		array $tagChildren,
		$tagOption,
		array $tag,
		array $options,
		AbstractRenderer $renderer
	): string
	{
		if (!$tag['option'])
		{
			return $renderer->renderUnparsedTag($tag, $options);
		}

		$groupId = intval($tagOption);

		/** @var ExtendedUserEntity $visitor */
		$visitor = \XF::visitor();

		if (!$visitor->canViewDbtechSocialGroups()
			|| $renderer instanceof SimpleHtml
			|| $renderer instanceof EmailHtml
		)
		{
			return self::renderTagSimple($groupId);
		}

		$viewParams = [
			'id' => $groupId,
			'text' => $tag['children'] ?? '',
		];

		/** @noinspection PhpIssetCanBeReplacedWithCoalesceInspection */
		if (isset($options['dbtechSocialGroups'][$groupId]))
		{
			$group = $options['dbtechSocialGroups'][$groupId];
		}
		else
		{
			$group = \XF::app()->em()->find(\DBTech\SocialGroups\Entity\Group::class, $groupId, [
				'Permissions|' . $visitor->permission_combination_id,
			]);
		}
		if (!$group || !$group->canView())
		{
			return self::renderTagSimple($groupId);
		}
		else if ($visitor->isIgnoring($group->user_id))
		{
			return '';
		}

		$viewParams['group'] = $group;
		$viewParams['contentUrl'] = $group->getContentUrl(true);

		return $renderer->getTemplater()->renderTemplate('public:dbtech_social_groups_group_bb_code', $viewParams);
	}

	/**
	 * @param int $id
	 *
	 * @return string
	 */
	protected static function renderTagSimple(int $id): string
	{
		$router = \XF::app()->router('public');

		$link = $router->buildLink('full:dbtech-social', ['group_id' => $id]);
		$phrase = \XF::phrase('dbtech_social_groups_view_group_x', ['id' => $id]);

		return '<a href="' . htmlspecialchars($link) . '">' . $phrase . '</a>';
	}
}