var DBTech = window.DBTech || {};
DBTech.SocialGroups = window.DBTech.SocialGroups || {};

((window, document) =>
{
	'use strict';

	DBTech.SocialGroups.MessageEdit = XF.Element.newHandler({

		init ()
		{
			XF.on(this.target, 'quickedit:editcomplete', this.editComplete.bind(this))
		},

		editComplete (data)
		{
			XF.setupHtmlInsert(data.html, (html, container, onComplete) =>
			{
				const discussionChanges = data.discussionChanges || {}

				if (discussionChanges.title)
				{
					document.querySelector('h1.p-title-value').innerHTML = container.h1
					document.querySelector('title').innerHTML = container.title

					// This effectively runs twice, but we do need the title to be correct if updating this way.
					if (XF.config.visitorCounts['title_count'] && data.visitor)
					{
						XF.pageTitleCache = container.title
						XF.pageTitleCounterUpdate(data.visitor.total_unread)
					}
				}
			})
		},
	});

	XF.Element.register('dbtech-social-message-edit', 'DBTech.SocialGroups.MessageEdit');
})(window, document)