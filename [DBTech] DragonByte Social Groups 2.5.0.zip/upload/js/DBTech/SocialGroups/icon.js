var DBTech = window.DBTech || {};
DBTech.SocialGroups = window.DBTech.SocialGroups || {};

((window, document) =>
{
	'use strict';

	DBTech.SocialGroups.Icon = {
		updateIcons: (groupId, newIcons, includeEditor) =>
		{
			const iconElements = document.querySelectorAll('.dbtechSocialGroupsIcon')

			iconElements.forEach(iconContainer =>
			{
				const icon = iconContainer.querySelector('img, span')
				const classPrefix = 'dbtechSocialGroupsIcon-g' + groupId + '-'
				const update = iconContainer.classList.contains('icon--updateLink')
					? iconContainer.querySelector('.icon-update')
					: null
				let newIcon

				if (!includeEditor && icon.classList.contains('js-croppedIcon'))
				{
					return
				}

				if (icon.className.startsWith(classPrefix))
				{
					if (icon.classList.contains(classPrefix + 's'))
					{
						newIcon = XF.createElementFromString(newIcons['s'])
					}
					else if (icon.classList.contains(classPrefix + 'm'))
					{
						newIcon = XF.createElementFromString(newIcons['m'])
					}
					else if (icon.classList.contains(classPrefix + 'l'))
					{
						newIcon = XF.createElementFromString(newIcons['l'])
					}
					else if (icon.classList.contains(classPrefix + 'o'))
					{
						newIcon = XF.createElementFromString(newIcons['o'])
					}
					else
					{
						return
					}

					iconContainer.innerHTML = newIcon.innerHTML

					if (newIcon.classList.contains('dbtechSocialGroupsIcon--default'))
					{
						iconContainer.classList.add('dbtechSocialGroupsIcon--default')

						if (newIcon.classList.contains('dbtechSocialGroupsIcon--default--dynamic'))
						{
							iconContainer.classList.add('dbtechSocialGroupsIcon--default--dynamic')
						}
						else if (newIcon.classList.contains('dbtechSocialGroupsIcon--default--text'))
						{
							iconContainer.classList.add('dbtechSocialGroupsIcon--default--text')
						}
						else if (newIcon.classList.contains('dbtechSocialGroupsIcon--default--image'))
						{
							iconContainer.classList.add('dbtechSocialGroupsIcon--default--image')
						}
					}
					else
					{
						iconContainer.classList.remove('dbtechSocialGroupsIcon--default', 'dbtechSocialGroupsIcon--default--dynamic', 'dbtechSocialGroupsIcon--default--text', 'dbtechSocialGroupsIcon--default--image')
					}

					iconContainer.setAttribute('style', newIcon.getAttribute('style'))

					if (update)
					{
						iconContainer.appendChild(update)
					}
				}
			})
		},
	};

	// ################################## AVATAR UPLOAD HANDLER ###########################################

	DBTech.SocialGroups.IconUpload = XF.Element.newHandler({

		options: {},

		init ()
		{
			const form = this.target
			const file = form.querySelector('.js-uploadIcon')
			const icon = form.querySelector('.js-icon')
			const deleteButton = form.querySelector('.js-deleteIcon')

			if (icon.querySelector('img'))
			{
				XF.display(deleteButton, 'inline-block')
			}
			else
			{
				XF.display(deleteButton, 'none')
			}

			XF.on(file, 'change', this.changeFile.bind(this))
			XF.on(form, 'ajax-submit:response', this.ajaxResponse.bind(this))
		},

		changeFile (e)
		{
			if (e.target.value != '')
			{
				XF.trigger(this.target, XF.customEvent('submit'))
			}
		},

		ajaxResponse (e)
		{
			const { data } = e

			if (data.errors || data.exception)
			{
				return
			}

			e.preventDefault()

			if (data.message)
			{
				XF.flashMessage(data.message, 3000)
			}

			const form = this.target
			const deleteBtn = form.querySelector('.js-deleteIcon')
			const file = form.querySelector('.js-uploadIcon')
			const icon = form.querySelector('.js-icon')
			const x = form.querySelector('.js-iconX')
			const y = form.querySelector('.js-iconY')
			const useCustom = (form.querySelector('input[name="use_custom"]:checked').value == 1)

			if (useCustom)
			{
				icon.style.left = `${ data.cropX * -1 }px`
				icon.style.top = `${ data.cropY * -1 }px`
				x.value = data.cropX
				y.value = data.cropY

				XF.Element.initializeElement(icon)

				file.value = ''
			}

			DBTech.SocialGroups.Icon.updateIcons(data.groupId, data.icons, useCustom)

			if (data.defaultIcons)
			{
				XF.display(deleteBtn, 'none')
			}
			else
			{
				XF.display(deleteBtn, 'inline-block')
			}

			const cropper = document.querySelector('.js-iconCropper')
			XF.trigger(cropper, XF.customEvent('dbtech-social-icon:updated', { data }))
		},
	});

	// ################################## AVATAR CROPPER HANDLER ###########################################

	DBTech.SocialGroups.IconCropper = XF.Element.newHandler({

		options: {
			size: 96,
			x: 0,
			y: 0
		},

		img: null,
		size: 96,

		x: 0,
		y: 0,

		imgW: null,
		imgH: null,

		cropSize: null,
		scale: null,

		init ()
		{
			XF.on(this.target, 'dbtech-social-icon:updated', this.iconsUpdated.bind(this), { once: true })

			this.img = this.target.querySelector('img')

			if (!this.img)
			{
				return
			}

			this.initTest()
		},

		iconsUpdated (e)
		{
			this.options.x = e.data.cropX
			this.options.y = e.data.cropY
			this.init()
		},

		initTest ()
		{
			const img = this.img
			let tests = 0

			const test = () =>
			{
				tests++
				if (tests > 50)
				{
					return
				}

				if (img.naturalWidth > 0)
				{
					this.setup()
				}
				else if (img.naturalWidth === 0)
				{
					setTimeout(test, 100)
				}
				// if no naturalWidth support (IE <9), don't init
			}

			test()
		},

		setup ()
		{
			this.imgW = this.img.naturalWidth
			this.imgH = this.img.naturalHeight

			this.cropSize = Math.min(this.imgW, this.imgH)
			this.scale = this.cropSize / this.options.size

			const cropbox = new XF.CropBox(this.img, {
				width: this.size,
				height: this.size,
				zoom: 0,
				maxZoom: 0,
				result: {
					cropX: this.options.x * this.scale,
					cropY: this.options.y * this.scale,
					cropW: this.cropSize,
					cropH: this.cropSize,
				},
			})

			XF.on(this.img, 'cropbox', this.onCrop.bind(this))

			// workaround for image dragging bug in Firefox
			// https://bugzilla.mozilla.org/show_bug.cgi?id=1376369
			if (XF.browser.mozilla)
			{
				XF.on(this.img, 'mousedown', e => e.preventDefault())
			}
		},

		onCrop (e)
		{
			this.target.parentNode.querySelector('.js-iconX').value = e.results.cropX / this.scale
			this.target.parentNode.querySelector('.js-iconY').value = e.results.cropY / this.scale
		},
	});

	XF.Element.register('dbtech-social-icon-upload', 'DBTech.SocialGroups.IconUpload');
	XF.Element.register('dbtech-social-icon-cropper', 'DBTech.SocialGroups.IconCropper');
})(window, document)