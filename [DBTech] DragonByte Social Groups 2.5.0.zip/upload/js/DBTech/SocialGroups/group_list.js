var DBTech = window.DBTech || {};
DBTech.SocialGroups = window.DBTech.SocialGroups || {};

((window, document) =>
{
	// ################################## --- ###########################################
	DBTech.SocialGroups.InfiniteScroll = XF.Element.newHandler({
		init ()
		{
			let $grid = this.target;

			let scroller = new InfiniteScroll(this.target, {
				button: '.group-button',
				append: '.groupList-group,.groupGrid-group',
				hideNav: '.block-outer--pagination',
				path: '.block-outer--pagination .pageNav-jump--next',
				status: '.group-status',
				history: $grid.getAttribute('data-infinite-scroll-history') ? 'push' : false
			});

			let scrollStatus = $grid.querySelector('.group-status');
			let scrollLoader = $grid.querySelector('.group-loader');

			scroller.on('last.infiniteScroll', () =>
			{
				scrollStatus.style.display = 'none';
				scrollLoader.style.display = 'none';
			});

			if ($grid.getAttribute('data-infinite-scroll-click'))
			{
				if ($grid.getAttribute('data-infinite-scroll-after'))
				{
					scroller.on('load.infiniteScroll', () =>
					{
						if (scroller.getAttribute('data-infiniteScroll').loadCount == $grid.getAttribute('data-infinite-scroll-after'))
						{
							scrollLoader.style.display = 'block';

							scroller.infiniteScroll('option', { loadOnScroll: false });
							scroller.off('load.infiniteScroll', onPageLoad);
						}
					});
				}
				else if (scrollLoader)
				{
					scrollLoader.style.display = 'block';
					scroller.infiniteScroll('option', { loadOnScroll: false });
				}
			}
		}
	});

	// ################################## --- ###########################################

	XF.Element.register('dbtech-social-groups-infinite-scroll', 'DBTech.SocialGroups.InfiniteScroll');
})(window, document)