var DBTech = window.DBTech || {};
DBTech.SocialGroups = window.DBTech.SocialGroups || {};
DBTech.SocialGroups.XF = DBTech.SocialGroups.XF || {};
DBTech.SocialGroups.XF.AutoComplete = DBTech.SocialGroups.XF.AutoComplete || {};

!((window, document) =>
{
	// ################################## --- ###########################################
	DBTech.SocialGroups.GroupAutoCompleteResults = XF.extend(XF.AutoCompleteResults, {
		__backup: {
			'createResultItem': '_createResultItem',
		},

		createResultItem (result, value)
		{
			const listItem = this._createResultItem(result, value);
			listItem.dataset.groupId = result.id;

			return listItem;
		},
	});

	DBTech.SocialGroups.XF.AutoComplete.BaseOpts = {
		inputName: 'group_id'
	}

	DBTech.SocialGroups.GroupAutoComplete = XF.extend(XF.AutoComplete, {
		__backup: {
			'init': '_init',
			'addValue': '_addValue',
		},

		options: XF.extendObject({}, XF.AutoComplete.prototype.options, DBTech.SocialGroups.XF.AutoComplete.BaseOpts),

		init ()
		{
			this._init();

			this.options.single = true;

			this.results = new DBTech.SocialGroups.GroupAutoCompleteResults({
				onInsert: this.addValue.bind(this),
				displayTemplate: this.getDisplayTemplate(),
			})
		},

		addValue (value, res, e)
		{
			this._addValue(value);

			this.target.closest('form')
				.querySelector('input[type="hidden"][name="' + this.options.inputName + '"]')
				.value = res.dataset.groupId
			;
		},

		getDisplayTemplate ()
		{
			return `<div class="contentRow contentRow--alignMiddle" title="{{{textPlain}}}">
						{{#icon}}<div class="contentRow-figure">{{{icon}}}</div>{{/icon}}
						<div class="contentRow-main contentRow-main--close u-singleLine">
							{{{text}}}
							<div class="contentRow-minor contentRow-minor--smaller">
								<ul class="listInline listInline--bullet u-singleLine">
									<li>{{{desc}}}</li>
								</ul>
							</div>
						</div>
					</div>`
		},
	});

	// ################################## --- ###########################################

	XF.Element.register('dbtech-social-groups-group-auto-complete', 'DBTech.SocialGroups.GroupAutoComplete');
})(window, document)