var DBTech = window.DBTech || {};
DBTech.SocialGroups = window.DBTech.SocialGroups || {};

((window, document) =>
{
	'use strict'

	// ################################## SECTION LOADER HANDLER ###########################################

	DBTech.SocialGroups.SectionLoader = XF.Element.newHandler({

		options: {
			listenTo: '',
			initUpdate: true,
			href: '',
		},

		init ()
		{
			if (!this.target.matches('select'))
			{
				console.error('Must trigger on select')
				return
			}

			if (this.options.href)
			{
				console.log(this.options.listenTo)
				const listenTo = this.options.listenTo ? XF.findRelativeIf(this.options.listenTo, this.target) : null
				if (!listenTo)
				{
					console.error('Cannot load sections dynamically as no element set to listen to for changes')
				}
				else
				{
					XF.on(listenTo, 'change', this.loadSections.bind(this))

					if (this.options.initUpdate)
					{
						XF.trigger(listenTo, 'change')
					}
				}
			}
		},

		loadSections (e)
		{
			XF.ajax('POST', this.options.href, {
				val: e.target.value,
			}, this.loadSuccess.bind(this))
		},

		loadSuccess (data)
		{
			if (data.html)
			{
				const select = this.target

				XF.setupHtmlInsert(data.html, html =>
				{
					const val = select.value

					if (html instanceof HTMLSelectElement)
					{
						select.innerHTML = ''
						select.append(...Array.from(html.children))

						let hasValue = false
						const options = select.querySelectorAll('option')
						options.forEach(option =>
						{
							if (option.getAttribute('value') === val)
							{
								select.value = val
								hasValue = true
							}
						})
						if (!hasValue)
						{
							select.value = options[0].getAttribute('value')
						}

						return false
					}
				})
			}
		},
	})

	XF.Element.register('dbtech-social-groups-section-loader', 'DBTech.SocialGroups.SectionLoader')
})(window, document)