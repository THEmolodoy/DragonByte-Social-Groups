# Changelog

#### v2.5.0

* **Feature:** Optionally bypass "Max joined groups" when inviting users (#212) *2025-10-04*
* **Feature:** Link to list of messages/media/albums in member list (#214) *2025-10-04*
* **Change:** Refactor permission checks for `canReply` and `canStartDiscussion` *2025-10-04*
* **Fix:** Fix a race condition with `canReply` check *2025-10-04*
* **Fix:** Fix `canView` check on Section Watch *2025-10-04*
* **Fix:** Fix server error when deleting a message from a deleted user (#211) *2025-10-04*
* **Fix:** Don't allow invites for users who cannot join this group (#212) *2025-10-04*
* **Fix:** Fix logic for joining invite-only groups (#212) *2025-10-04*
* **Fix:** Don't include non-`visible` items in group member count rebuild (#215) *2025-10-04*


#### v2.4.0


* **Feature:** Add Discussion support to Trending Content *2025-09-12*
* **Feature:** Created a new "Maintenance" page for easy access to the "Rebuild caches" options available in this addon *2025-09-12*
* **Feature:** Reaction import support (#205) *2025-09-12*
* **Feature:** Track last activity, user messages, calendar events and media items per social group *2025-09-12*
* **Feature:** Group member and group supervisor lists now show the stats a member has in each individual group, rather than XF global stats *2025-09-12*
* **Feature:** Group member and group supervisor lists now show the group title (e.g. "Group owner") instead of the XF user title *2025-09-12*
* **Feature:** Sorting options for the group members list (#207) *2025-09-12*
* **Feature:** Enhanced group activity tracking (#207) *2025-09-12*
* **Change:** Move database query calls from templates to PHP files *2025-09-12*
* **Change:** Add a separate phrase for "Discussions" when used in a navigation context *2025-09-12*
* **Change:** Convert MEMORY tables to InnoDB (#198) *2025-09-12*
* **Change:** Add "Edit group icon" and "Edit group banner" to the group management menu (#209) *2025-09-12*
* **Change:** "Private" groups no longer show up in membership lists when viewing other users' group memberships (#200) *2025-09-12*
* **Change:** Imported threads now also copy the view count (#203) *2025-09-12*
* **Change:** Rewrite post quotes on import (#202) *2025-09-12*
* **Change:** Replace `messages` phrase with `dbtech_social_groups_messages` (#208) *2025-09-12*
* **Change:** Clarify the social group counters (#200) *2025-09-12*
* **Fix:** Calendar integration would infinitely spawn new calendars every time the group was edited *2025-09-12*
* **Fix:** Reaction list would not show any entries (#199) *2025-09-12*
* **Fix:** Fix search index rebuild after thread import *2025-09-12*
* **Fix:** Fix server error on thread import (#201) *2025-09-12*


#### v2.3.0

* **Change:** XenForo 2.3.8 compatibility *2025-07-29*


#### v2.3.0b1

* **Feature:** Calendar integration *2025-06-19*
* **Change:** The group overview's "About" block is now hidden on mobile devices *2025-06-19*
* **Change:** Update privacy downgrade warning to be more prominent (#194) *2025-06-19*
* **Fix:** Check can start discussion on the Overview page (#193) *2025-06-19*
* **Fix:** Limit the permission rebuild override correctly *2025-06-19*
* **Fix:** The "Node list container" feature no longer runs an excessive amount of queries *2025-06-19*
* **Fix:** Reduced query count needed for group lists if the latest discussion was in a Section *2025-06-19*
* **Fix:** The "Node list container" feature now correctly shows the "Owner" or "Moderator" badge as necessary *2025-06-19*


#### v2.2.3

* **Feature:** "Start discussion" button on overview page *2025-01-24*
* **Change:** If the current user can't view the discussion list, hide the section list too *2025-01-24*
* **Fix:** "Private" groups would not correctly show up in the group list *2025-01-24*
* **Fix:** [OzzModz] Social Groups importer will now properly import the first post of group comments *2025-01-24*
* **Fix:** [OzzModz] Social Groups importer will now properly import group icons *2025-01-24*


#### v2.2.2

* **Fix:** Fix undeleting social groups infinite loop *2024-12-20*
* **Fix:** "Time limit on editing own messages" default permission was set incorrectly *2024-12-20*


#### v2.2.1

* **Fix:** Fix content not embedding in Discussions (#190) *2024-11-12*
* **Change:** Thread import is now more robust for very large threads (#97) *2024-11-12*
* **Fix:** Work around an issue with inviting someone to a private group *2024-11-12*


#### v2.2.0.1

* **Fix:** Fix `attach_count` not transferring when importing forum threads to Social Groups *2024-11-05*


#### v2.2.0

* **Feature:** Import forum threads to social groups (#97) *2024-11-04*
* **Feature:** [OzzModz] Social Groups importer *2024-11-04*
* **Change:** Use a unique phrase for Group Memberships rebuild jobs *2024-11-04*
* **Fix:** Media index now respects the "Enable XFMG Integration" setting *2024-11-04*
* **Fix:** Fix some template macro references *2024-11-04*
* **Fix:** A section's "Minimum tags" setting was not correctly applied to new discussions *2024-11-04*
* **Fix:** A missing phrase used in the Featured Content setup has been added *2024-11-04*
* **Fix:** Fix importing XFMG data *2024-11-04*
* **Fix:** Rebuild group members after import *2024-11-04*
* **Fix:** Ensure we only restore the previous album category if it's an "Album" type category *2024-11-04*
* **Fix:** Ensure album_count is at least 0 *2024-11-04*
* **Fix:** Fix server errors from an incorrect import *2024-11-04*


#### v2.0.1

* **Feature:** Auto-embed Group, Discussion and Message links (#182) *2024-08-20*
* **Change:** Only forum staff can see the fallback username in member logs (#180) *2024-08-20*
* **Change:** Update ld+json data for Discussions *2024-08-20*
* **Fix:** Fix server errors when editing permissions (#185) *2024-08-20*
* **Fix:** Fix group ownership counter not refreshing when ownership is transferred (#184) *2024-08-20*
* **Fix:** Fix group ownership counter not refreshing when group is soft deleted/undeleted (#184) *2024-08-20*
* **Fix:** Fix group membership counter not refreshing when group is soft deleted/undeleted (#184) *2024-08-20*
* **Fix:** Sections were not being cleaned up on social group deletion (#186) *2024-08-20*
* **Fix:** Fix JS error with infinite scroll *2024-08-20*
* **Fix:** Fix incorrect phrase when viewing a deleted discussion (#187) *2024-08-20*
* **Fix:** Fix visibility checks for deleted group member log entries (#180) *2024-08-20*
* **Fix:** Fix pagination on group media page *2024-08-20*
* **Fix:** Fix quick reply not working in certain scenarios (#183) *2024-08-20*


#### v2.0.0

* **Feature:** View your own pending join requests / groups you've been banned from (#178) *2024-07-24*
* **Feature:** Allow viewing other users' pending group requests / group bans (#178) *2024-07-24*
* **Feature:** Ability to leave groups directly from your own membership lists *2024-07-24*
* **Change:** Discussions in sections now also show the group name in discussion lists (#177) *2024-07-24*
* **Change:** Don't send an alert about being removed as supervisor on group reassign (#179) *2024-07-24*
* **Change:** IP addresses are now purged from group member logs when the "actor" is deleted (#180) *2024-07-24*
* **Fix:** Attempting to view invited users would produce a server error *2024-07-24*
* **Fix:** Attempting to view your group invitations would produce a server error *2024-07-24*
* **Fix:** Show "(deleted member)" instead of nothing when the member who banned someone from a group is deleted (#180) *2024-07-24*
* **Fix:** Fix server errors when viewing certain Membership pages *2024-07-24*


#### v2.0.0rc1

* **Feature:** Add Embed support to Discussion and Message *2024-07-05*
* **Change:** Replace deprecated function calls *2024-07-05*
* **Change:** Update entity references to use class-string *2024-07-05*
* **Change:** Updated macros to XF 2.3 format *2024-07-05*
* **Change:** Replace various references with `class-string<T>` equivalents *2024-07-05*
* **Change:** Update code for PHP 8.0 *2024-07-05*
* **Change:** Add compatibility with new XenForo 2.3 Beta 6 feature *2024-07-05*
* **Change:** Remove "XenForo" from copyright footer *2024-07-05*
* **Change:** Necessary changes for the new XenForo 2.3 coding style *2024-07-05*
* **Change:** Automatically clean up files on upgrade *2024-07-05*
* **Fix:** Removed unnecessary JS code *2024-07-05*
* **Fix:** Message editing used the wrong JS file *2024-07-05*
* **Fix:** Quick discussion issues *2024-07-05*
* **Fix:** Fixed template modifications *2024-07-05*
* **Fix:** Fix CSS compatibility *2024-07-05*
* **Fix:** Fix various missing FontAwesome icons *2024-07-05*
* **Fix:** Fix inconsistent `confirmUrl` behaviour with deletion *2024-07-05*
* **Fix:** Fix server error when editing discussion messages *2024-07-05*


#### v1.3.0

* **Feature:** Add WebP support for group banners (Requires DragonByte WebP v1.0.0+ installed) *2024-04-04*
* **Feature:** Add WebP support for group icons (Requires DragonByte WebP v1.0.0+ installed) *2024-04-04*
* **Feature:** Add group name to alert phrases (#165) *2024-04-04*
* **Change:** Replace `xfmg_media` with `nav.xfmg` where appropriate (#173) *2024-04-04*
* **Change:** Refactored backend code *2024-04-04*
* **Change:** Bump minimum PHP version to 7.4 and recommended version to 8.2 *2024-04-04*
* **Fix:** "Approve / reject members" supervisor permission did not work as intended (#174) *2024-04-04*
* **Fix:** Supervisors with "Approve/Reject Members" permission could be unable to perform those duties (#174) *2024-04-04*
* **Fix:** Fix `canVote` check for polls to use the correct group flag (#172) *2024-04-04*
* **Fix:** Fix not all media showing on the `dbtech-social/media` route in certain circumstances (#171) *2024-04-04*
* **Fix:** Fix server error on import *2024-04-04*
* **Fix:** Attempt to fix a duplicate key exception while using database replication (#170) *2024-04-04*
* **Fix:** Fix PHP 8.4 compatibility issue *2024-04-04*


#### v1.2.5

* **Feature:** Invite-only group warning to group administrators (#161) *2024-01-19*
* **Feature:** Support username change / user merge / user deletion feature in XenForo for Member Log (#147) *2024-01-19*
* **Change:** Add group name to group wrapper description (#166) *2024-01-19*
* **Change:** Group icons/banners now have a hashed filename (#167) *2024-01-19*
* **Change:** Group invitations are now removed when a user is placed on ignore (#163) *2024-01-19*
* **Change:** Banning a non-member from a group no longer alerts the user being banned (#162) *2024-01-19*
* **Change:** You can no longer invite users who are ignoring you (#163) *2024-01-19*
* **Change:** Validate all group invites before actually submitting any group invites *2024-01-19*
* **Change:** Add strike-through for soft-deleted groups in the AdminCP "confirm delete" dialog (#157) *2024-01-19*
* **Fix:** The `GROUP` BBCode did not work for normal users, only moderators (#169) *2024-01-19*
* **Fix:** Fix potential server errors when uploading invalid icons or banners (#164) *2024-01-19*
* **Fix:** Media Items / Albums / Album Comments would not be marked as viewed (#160) *2024-01-19*
* **Fix:** Fix missing bookmark templates (#159) *2024-01-19*
* **Fix:** A server error could occur if the Message or Group Comment Reply did not have a valid IP address *2024-01-19*
* **Fix:** Potentially fix duplicate key exception (#158) *2024-01-19*
* **Fix:** Fix pagination on the Banned and Invite pages (#156) *2024-01-19*


#### v1.2.1

* **Feature:** Per-group locale setting *2024-01-02*
* **Feature:** Add "Banned" badge text for group membership views *2024-01-02*
* **Feature:** Add notice for abandoned groups *2024-01-02*
* **Fix:** Fix race condition where a temp file is deleted partway through upload *2024-01-02*
* **Fix:** Fix default social group owner options check when saving groups in the front-end *2024-01-02*
* **Fix:** Fix server error when attempting to check Terms of Service *2024-01-02*
* **Fix:** Fix potential server error when adding media to a social group *2024-01-02*


#### v1.2.0

* **Feature:** Sections (#99) *2023-12-14*
* **Feature:** New banner to indicate whether a post was made by a non-member of the social group (#124) *2023-12-14*
* **Feature:** Ability to join Private groups that accept new members (#141) *2023-12-14*
* **Feature:** Add widget showing group creation / joining limits (#143) *2023-12-14*
* **Feature:** Optional "Terms of Service" page for group add/edit form in the front-end (#139) *2023-12-14*
* **Feature:** Show a notice if group is invite-only (#134) *2023-12-14*
* **Feature:** New permission: Join social group (#131) *2023-12-14*
* **Feature:** Add "Your groups" to main "Social Groups" menu (#130) *2023-12-14*
* **Feature:** Add "New social groups" to "What's new" (#126) *2023-12-14*
* **Change:** Use member's join date as the moderation date (#146) *2023-12-14*
* **Change:** "Can join group" check now also checks group bans (#141) *2023-12-14*
* **Change:** "Social group memberships" counter in the profile view now includes owned groups (#133) *2023-12-14*
* **Change:** Groups under moderation can no longer add content or invite members (#138) *2023-12-14*
* **Change:** Member list is now sorted alphabetically, with supervisors listed first (#140) *2023-12-14*
* **Change:** XFMG media list / media items are now only accessible to group members (#135) *2023-12-14*
* **Change:** Social group owners and supervisors can always reply to discussions (#122) *2023-12-14*
* **Change:** Social group owners and supervisors can always start discussions (#122) *2023-12-14*
* **Fix:** Attachments in Public groups can now be viewed by everyone (#144) *2023-12-14*
* **Fix:** Ensure we check "View group" permission everywhere it makes sense (#136) *2023-12-14*
* **Fix:** Remove double "Awaiting approval" notice *2023-12-14*
* **Fix:** Fix server error when deleting social groups with discussions *2023-12-14*
* **Fix:** Fix a server error if Join Group or Reject Invite checks failed *2023-12-14*
* **Fix:** Users with no permissions to access the social groups feature no longer see its search tabs (#127) *2023-12-14*
* **Fix:** New users who are invited to a social group would not be able to see the invitation (#129) *2023-12-14*
* **Fix:** Users with no permission to access social groups can no longer be invited (#132) *2023-12-14*
* **Fix:** Fix server error on certain routes if XFMG integration was enabled (#128) *2023-12-14*


#### v1.1.0

* **Feature:** XFMG integration *2023-10-25*
* **Feature:** Virtual category *2023-10-25*
* **Feature:** Search for social groups *2023-10-25*
* **Feature:** Related Threads *2023-10-25*
* **Feature:** Sticky groups *2023-10-25*
* **Feature:** Batch invite users *2023-10-25*
* **Feature:** Widget: New Messages *2023-10-25*
* **Feature:** Widget: Social group statistics *2023-10-25*
* **Feature:** Widget: Joined Groups *2023-10-25*
* **Feature:** Widget: New Groups *2023-10-25*
* **Feature:** Widget: Owned Groups *2023-10-25*
* **Feature:** Widget: Random Groups *2023-10-25*
* **Feature:** Widget: Featured Groups *2023-10-25*
* **Feature:** Widget: Tag Cloud *2023-10-25*
* **Feature:** New group option: Allow new discussions *2023-10-25*
* **Feature:** Count social group messages towards users' total message counts *2023-10-25*
* **Change:** Improve compatibility with databases setup for replication *2023-10-25*
* **Change:** Add "Awaiting approval" text to group membership lists *2023-10-25*
* **Fix:** Fix default permission for "createGroup" *2023-10-25*
* **Fix:** Editing a supervisor would not load the correct existing permissions *2023-10-25*
* **Fix:** Fix incorrect table references causing SQL errors during search *2023-10-25*
* **Fix:** "Join Group" button no longer appears for banned non-members *2023-10-25*


#### v1.0.0

* Initial release *2023-05-02*
